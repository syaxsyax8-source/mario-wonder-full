#!/usr/bin/env python3
"""Generate the launcher icon for the Super Mario Arcade APK.

Draws a chunky pixel-art 'M' cap badge and writes it as a PNG using only the
Python standard library (no Pillow needed in the build sandbox).
"""
import struct
import sys
import zlib

SIZE = 192
BG_OUTER = (11, 14, 26)
BG = (214, 40, 29)
BG_DARK = (140, 20, 12)
BRIM = (92, 44, 22)
WHITE = (255, 245, 204)
GOLD = (251, 191, 36)

# 12x12 pixel-art grid: '.' transparent-ish bg, 'R' red, 'D' dark red,
# 'W' white M glyph, 'B' cap brim, 'G' gold trim.
GRID = [
    "....GGGG....",
    "..GGRRRRGG..",
    ".GGRRRRRRGG.",
    "GGRRRRRRRRGG",
    "GRRWRRRRWRRG",
    "GRWWWRRWWWRG",
    "GRWWWWWWWWRG",
    "GRWWRWWRWWRG",
    "GRWWRRRRWWRG",
    "GDWRRRRRRWDG",
    ".BBBBBBBBBB.",
    "..BBBBBBBB..",
]

COLORS = {
    "R": BG,
    "D": BG_DARK,
    "W": WHITE,
    "B": BRIM,
    "G": GOLD,
    ".": BG_OUTER,
}


def build_pixels():
    cell = SIZE // len(GRID)
    rows = []
    for y in range(SIZE):
        row = bytearray()
        row.append(0)  # PNG filter type 0 for this scanline
        gy = min(len(GRID) - 1, y // cell)
        for x in range(SIZE):
            gx = min(len(GRID[0]) - 1, x // cell)
            r, g, b = COLORS[GRID[gy][gx]]
            row += bytes((r, g, b))
        rows.append(bytes(row))
    return b"".join(rows)


def chunk(tag, data):
    return (
        struct.pack(">I", len(data))
        + tag
        + data
        + struct.pack(">I", zlib.crc32(tag + data) & 0xFFFFFFFF)
    )


def main(path):
    header = struct.pack(">IIBBBBB", SIZE, SIZE, 8, 2, 0, 0, 0)
    png = (
        b"\x89PNG\r\n\x1a\n"
        + chunk(b"IHDR", header)
        + chunk(b"IDAT", zlib.compress(build_pixels(), 9))
        + chunk(b"IEND", b"")
    )
    with open(path, "wb") as handle:
        handle.write(png)
    print("icon written:", path, len(png), "bytes")


if __name__ == "__main__":
    main(sys.argv[1])
