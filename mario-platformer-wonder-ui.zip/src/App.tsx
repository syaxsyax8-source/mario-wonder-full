import React, { useCallback, useEffect, useRef, useState } from 'react';
import { MarioGameEngine } from './game/engine';
import { MarioRenderer } from './game/renderer';

import {
  DIFFICULTY_CONFIG,
  DIFFICULTY_ORDER,
  Difficulty,
  getLevelTier,
  HighScoreEntry,
  HudSnapshot,
  InputState,
  TOTAL_LEVELS,
} from './game/types';
import { LevelSelect } from './components/LevelSelect';
import { getLevelBiome } from './game/biomes';
import { discoveredCount, TOTAL_BIOMES } from './utils/discovery';
import {
  loadClearedLevels,
  loadUnlockedLevel,
  markLevelCleared,
  unlockLevel,
} from './utils/progress';
import {
  isQualifyingHighScore,
  loadHighScores,
  loadLastInitials,
  saveHighScore,
} from './utils/highScores';
import { TouchControls } from './components/TouchControls';
import {
  WEAPONS,
  CharacterId,
  CHARACTERS,
  CHARACTER_ORDER,
} from './game/types';
import { CharacterShop } from './components/CharacterShop';
import { IntroSplash } from './components/IntroSplash';
import { AccountGate } from './components/AccountGate';
import { Bestiary } from './components/Bestiary';
import { dailyLevelFor, dailyKey } from './game/types';
import {
  loadAccount, Account, exportSave, syncActiveSave, signOut,
} from './utils/account';
import {
  ACHIEVEMENTS,
  PETS,
  PET_ORDER,
  PetId,
} from './game/types';
import {
  loadPet, savePet, loadOwnedPets, buyPet,
  reportProgress, loadProgress, unlockedCount,
} from './utils/achievements';
import { spendCoins } from './utils/wallet';
import {
  buyCharacter,
  loadCoins,
  loadOwnedCharacters,
  loadSelectedCharacter,
  saveSelectedCharacter,
  installWalletGuards,
  flushCoins,
} from './utils/wallet';
import { AndroidDownload } from './components/AndroidDownload';
import { sound } from './game/sound';

const FIXED_DT = 1 / 60;

export function App() {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const engineRef = useRef<MarioGameEngine | null>(null);
  const resizeCanvasRef = useRef<(() => void) | null>(null);
  /**
   * True while a full-screen overlay (boot intro / sign-in) completely
   * covers the game. The main loop idles instead of rendering a canvas
   * nobody can see, which keeps those screens at a full frame rate.
   */
  const suspendGameRef = useRef(true);
  const rendererRef = useRef<MarioRenderer | null>(null);

  const keyInputRef = useRef({
    left: false,
    right: false,
    up: false,
    down: false,
    jumpHeld: false,
    jumpPressed: false,
    runHeld: false,
    firePressed: false,
    switchPressed: false,
    dashPressed: false,
    grapplePressed: false,
  });

  const touchInputRef = useRef({
    left: false,
    right: false,
    down: false,
    jumpHeld: false,
    jumpPressed: false,
    runHeld: false,
    firePressed: false,
    switchPressed: false,
    dashPressed: false,
    grapplePressed: false,
  });

  const [hud, setHud] = useState<HudSnapshot>(() => ({
    screen: 'title',
    score: 0,
    highScore: 28500,
    coins: 0,
    lives: 3,
    worldLabel: '1-1',
    worldSubtitle: 'MUSHROOM PLAINS',
    levelIndex: 0,
    loopCount: 1,
    timeRemaining: 360,
    power: 'small',
    starActive: false,
    maxCombo: 1,
    stageBonus: 0,
    timeBonus: 0,
    difficulty: 'medium',
    levelNumber: 1,
    themeName: 'MUSHROOM PLAINS',
    themeIcon: '🍄',
    themeAccent: '#4ade80',
    tierName: 'ROOKIE',
    tierColor: '#4ade80',
    hazardLabel: 'Bouncy mushroom pads',
    character: 'mario',
    bankedCoins: 0,
    demoMode: false,
    freshDiscovery: false,
    weatherLabel: 'RAIN',
    weatherSchedule: 'ALL MAP',
    timeSlow: 0,
    magnet: 0,
    shadow: 0,
    dashCharges: 1,
    relicFound: false,
    pet: 'none',
    isNight: false,
    slippery: false,
    stompChain: 0,
    rewinds: 3,
    rewinding: false,
    bossHp: -1,
    bossPhase: 0,
    dailyLevel: 1,
    isDaily: false,
    weapon: null,
    weaponAmmo: 0,
    ownedWeapons: [],
    weaponAmmoMap: {},
    checkpointIndex: -1,
    checkpointTotal: 0,
    soundEnabled: true,
    musicEnabled: true,
  }));

  const [difficulty, setDifficulty] = useState<Difficulty>(() => {
    try {
      const saved = localStorage.getItem('smb_npc_difficulty');
      if (DIFFICULTY_ORDER.includes(saved as Difficulty)) {
        return saved as Difficulty;
      }
    } catch {
      // Ignore storage access issues
    }
    // Medium is the recommended baseline: extra NPC squads + Hammer Bros.
    return 'medium';
  });

  useEffect(() => {
    try {
      localStorage.setItem('smb_npc_difficulty', difficulty);
    } catch {
      // Ignore storage access issues
    }
  }, [difficulty]);

  const [selectedLevel, setSelectedLevel] = useState(() => loadUnlockedLevel());
  const [unlocked, setUnlocked] = useState(() => loadUnlockedLevel());
  const [cleared, setCleared] = useState<Set<number>>(() => loadClearedLevels());
  const [showLevelSelect, setShowLevelSelect] = useState(false);
  const [showShop, setShowShop] = useState(false);
  const [shopNotice, setShopNotice] = useState<string | null>(null);
  /** Character being test-driven for free (coins are not banked). */
  const [demoChar, setDemoChar] = useState<CharacterId | null>(null);
  const [worldsFound, setWorldsFound] = useState(() => discoveredCount());
  /** Boot animation, shown once per app launch. */
  const [showIntro, setShowIntro] = useState(true);
  const [pet, setPet] = useState<PetId>(() => loadPet() as PetId);
  const [ownedPets, setOwnedPets] = useState<string[]>(() => loadOwnedPets());
  const [showAch, setShowAch] = useState(false);
  const [achCount, setAchCount] = useState(() => unlockedCount());
  const [achToast, setAchToast] = useState<string | null>(null);
  const [account, setAccount] = useState<Account | null>(() => loadAccount());
  /** The sign-in panel is optional and opened from the dashboard. */
  const [showLogin, setShowLogin] = useState(false);
  const [showBestiary, setShowBestiary] = useState(false);
  const dailyLv = dailyLevelFor(new Date());
  const [dailyDone, setDailyDone] = useState<boolean>(() => {
    try {
      return localStorage.getItem('smb_daily_v1') === dailyKey(new Date());
    } catch { return false; }
  });
  const [bankCoins, setBankCoins] = useState(() => loadCoins());
  const [ownedChars, setOwnedChars] = useState<CharacterId[]>(
    () => loadOwnedCharacters()
  );
  const [character, setCharacter] = useState<CharacterId>(
    () => loadSelectedCharacter()
  );
  const [showNpcBriefing, setShowNpcBriefing] = useState(false);
  const previousHudScreen = useRef<HudSnapshot['screen']>('title');
  const [showTitleScores, setShowTitleScores] = useState(false);
  const [highScores, setHighScores] = useState<HighScoreEntry[]>(() =>
    loadHighScores()
  );
  const [initials, setInitials] = useState<string>(() => loadLastInitials());
  const [savedEntryId, setSavedEntryId] = useState<string | null>(null);
  const [hasSavedRun, setHasSavedRun] = useState(false);

  /**
   * Height reserved at the bottom of the screen for the touch pad.
   * The canvas is shrunk by this amount so the controls can never overlap
   * the playfield (and therefore never cover Mario).
   */
  const [padHeight, setPadHeight] = useState(0);
  const padHeightRef = useRef(0);
  padHeightRef.current = padHeight;

  const [touchVisible, setTouchVisible] = useState<boolean>(() => {
    if (typeof window === 'undefined') return false;
    return (
      'ontouchstart' in window ||
      navigator.maxTouchPoints > 0 ||
      window.matchMedia('(pointer: coarse)').matches
    );
  });

  // Initialize game engine, renderer, resize observer, and 60fps loop
  useEffect(() => {
    // Coins must survive closing the game / switching apps.
    installWalletGuards();

    const engine = new MarioGameEngine((snapshot) => {
      setHud(snapshot);
    });
    const renderer = new MarioRenderer();
    engineRef.current = engine;
    rendererRef.current = renderer;

    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const updateCanvasSize = () => {
      const dpr = Math.min(window.devicePixelRatio || 1, 2);
      const w = window.innerWidth;
      const h = Math.max(220, window.innerHeight - padHeightRef.current);
      canvas.width = Math.floor(w * dpr);
      canvas.height = Math.floor(h * dpr);
      canvas.style.height = `${h}px`;
      engine.setViewport(canvas.width, canvas.height);
    };

    resizeCanvasRef.current = updateCanvasSize;
    updateCanvasSize();
    window.addEventListener('resize', updateCanvasSize);
    window.addEventListener('orientationchange', updateCanvasSize);

    let animId = 0;
    let lastTime = performance.now();
    let accumulator = 0;

    const frame = (now: number) => {
      const frameDelta = Math.min(0.1, Math.max(0, (now - lastTime) / 1000));
      lastTime = now;
      accumulator += frameDelta;

      while (accumulator >= FIXED_DT) {
        const k = keyInputRef.current;
        const t = touchInputRef.current;
        const combined: InputState = {
          left: k.left || t.left,
          right: k.right || t.right,
          up: k.up,
          down: k.down || t.down,
          jumpHeld: k.jumpHeld || t.jumpHeld,
          jumpPressed: k.jumpPressed || t.jumpPressed,
          runHeld: k.runHeld || t.runHeld,
          firePressed: k.firePressed || t.firePressed,
          switchPressed: k.switchPressed || t.switchPressed,
          dashPressed: k.dashPressed || t.dashPressed,
          grapplePressed: k.grapplePressed || t.grapplePressed,
          // Holding Down on a pipe mouth enters it.
          enterPipe: k.down || t.down,
        };

        // Consume single-tick triggers
        k.jumpPressed = false;
        k.firePressed = false;
        k.switchPressed = false;
        k.dashPressed = false;
        k.grapplePressed = false;
        t.jumpPressed = false;
        t.dashPressed = false;
        t.grapplePressed = false;
        t.firePressed = false;
        t.switchPressed = false;

        if (!suspendGameRef.current) engine.step(FIXED_DT, combined);
        accumulator -= FIXED_DT;
      }

      if (!suspendGameRef.current) {
        renderer.render(ctx, engine, canvas.width, canvas.height);
      }
      animId = requestAnimationFrame(frame);
    };

    animId = requestAnimationFrame(frame);

    const handleVisibility = () => {
      if (document.hidden && engine.screen === 'playing') {
        engine.togglePause();
      }
    };
    document.addEventListener('visibilitychange', handleVisibility);

    return () => {
      cancelAnimationFrame(animId);
      window.removeEventListener('resize', updateCanvasSize);
      window.removeEventListener('orientationchange', updateCanvasSize);
      document.removeEventListener('visibilitychange', handleVisibility);
      sound.stopMusic();
      flushCoins();
      syncActiveSave();
    };
  }, []);

  // Idle the game loop whenever a full-screen overlay hides the canvas.
  useEffect(() => {
    suspendGameRef.current = showIntro || showLogin;
  }, [showIntro, showLogin]);

  // Mirror the engine's banked coin counter into the shop UI.
  useEffect(() => {
    if (hud.bankedCoins !== bankCoins) setBankCoins(hud.bankedCoins);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [hud.bankedCoins]);

  // Size the control strip to the device, then resize the canvas to match.
  useEffect(() => {
    const compute = () => {
      if (!touchVisible || hud.screen !== 'playing') return 0;
      // Scale with viewport but stay inside sensible bounds.
      const h = Math.round(
        Math.min(132, Math.max(96, window.innerHeight * 0.19))
      );
      return h;
    };
    const apply = () => setPadHeight(compute());
    apply();
    window.addEventListener('resize', apply);
    window.addEventListener('orientationchange', apply);
    return () => {
      window.removeEventListener('resize', apply);
      window.removeEventListener('orientationchange', apply);
    };
  }, [touchVisible, hud.screen]);

  useEffect(() => {
    resizeCanvasRef.current?.();
  }, [padHeight]);

  // Reset run score save tracking when entering playing state
  useEffect(() => {
    if (hud.screen === 'playing') {
      setHasSavedRun(false);
      setSavedEntryId(null);
    } else if (hud.screen === 'gameover' || hud.screen === 'victory') {
      setHighScores(loadHighScores());
    }
  }, [hud.screen]);

  // Belt-and-braces: also flush the wallet at natural break points, in case
  // the OS kills the app without firing a pagehide/visibilitychange event.
  useEffect(() => {
    if (hud.screen !== 'playing') {
      flushCoins();
      // Mirror the fresh progress into the signed-in account's slot.
      syncActiveSave();
    }
    setWorldsFound(discoveredCount());

    // Fold this run's counters into the persistent achievement progress.
    const eng = engineRef.current;
    if (!eng) return;
    const base = loadProgress();
    const add = (id: string, v: number) => (base[id] ?? 0) + v;
    const gained = reportProgress({
      first_clear: add('first_clear', eng.stats.clears),
      relics_10: add('relics_10', eng.stats.relics),
      relics_50: add('relics_50', eng.stats.relics),
      coins_1000: eng.bankedCoins,
      dash_100: add('dash_100', eng.stats.dashes),
      grapple_50: add('grapple_50', eng.stats.grapples),
      slam_50: add('slam_50', eng.stats.slamKills),
      wallrun_30: add('wallrun_30', eng.stats.wallRuns),
      puzzles_20: add('puzzles_20', eng.stats.puzzles),
      worlds_25: discoveredCount(),
      level_100: hud.levelNumber,
      level_1000: hud.levelNumber,
    });
    eng.stats = {
      dashes: 0, grapples: 0, slamKills: 0, wallRuns: 0,
      puzzles: 0, relics: 0, clears: 0,
    };
    setAchCount(unlockedCount());
    if (gained.length) {
      const def = ACHIEVEMENTS.find((a) => a.id === gained[0]);
      if (def) {
        setAchToast(`${def.icon} ${def.name}`);
        setTimeout(() => setAchToast(null), 3800);
      }
    }
  }, [hud.screen, hud.levelNumber]);

  // Persist campaign progress whenever a stage is cleared.
  useEffect(() => {
    if (hud.screen !== 'stage_clear') return;
    setCleared(markLevelCleared(hud.levelNumber));
    setUnlocked(unlockLevel(hud.levelNumber + 1));
  }, [hud.screen, hud.levelNumber]);

  // Brief NPC-mode briefing on each new stage so Medium difficulty is obvious.
  useEffect(() => {
    const previous = previousHudScreen.current;
    previousHudScreen.current = hud.screen;
    if (hud.screen !== 'playing') {
      setShowNpcBriefing(false);
      return;
    }
    // Don't repeat the briefing when simply resuming from pause.
    if (previous === 'paused') return;
    setShowNpcBriefing(true);
    const timer = window.setTimeout(() => setShowNpcBriefing(false), 3400);
    return () => window.clearTimeout(timer);
  }, [hud.screen, hud.levelIndex]);

  const commitRunScoreIfNeeded = useCallback(
    (forceSave = false) => {
      if (hasSavedRun) return;
      const engine = engineRef.current;
      if (!engine || engine.score <= 0) return;

      if (forceSave || isQualifyingHighScore(engine.score)) {
        const res = saveHighScore({
          initials,
          score: engine.score,
          coins: engine.coins,
          world:
            engine.loopCount > 1
              ? `${engine.levelDef.worldLabel}+`
              : engine.levelDef.worldLabel,
        });
        setHighScores(res.scores);
        setSavedEntryId(res.insertedId);
        setHasSavedRun(true);
      }
    },
    [hasSavedRun, initials]
  );

  const handleStartGame = useCallback(
    (level = selectedLevel, npcDifficulty = difficulty) => {
      commitRunScoreIfNeeded(false);
      const clamped = Math.max(1, Math.min(TOTAL_LEVELS, level));
      setSelectedLevel(clamped);
      setShowLevelSelect(false);
      // startNewGame takes a 0-based level index.
      engineRef.current?.startNewGame(
        clamped - 1, npcDifficulty, character, false, pet
      );
      setDemoChar(null);
    },
    [character, commitRunScoreIfNeeded, difficulty, pet, selectedLevel]
  );

  /** Resume a lost run at the last checkpoint instead of restarting level 1. */
  const handleContinueCheckpoint = useCallback(() => {
    commitRunScoreIfNeeded(false);
    engineRef.current?.continueFromCheckpoint();
  }, [commitRunScoreIfNeeded]);

  /** Start today's globally-shared daily challenge. */
  const handleDaily = useCallback(() => {
    commitRunScoreIfNeeded(false);
    const eng = engineRef.current;
    if (!eng) return;
    eng.startNewGame(dailyLv - 1, difficulty, character, false, pet);
    eng.isDaily = true;
    try { localStorage.setItem('smb_daily_v1', dailyKey(new Date())); } catch { /* ignore */ }
    setDailyDone(true);
    setShowLevelSelect(false);
  }, [character, commitRunScoreIfNeeded, dailyLv, difficulty, pet]);

  const handleContinueLoop = useCallback(() => {
    commitRunScoreIfNeeded(false);
    engineRef.current?.continueNextLoop();
  }, [commitRunScoreIfNeeded]);

  // Keyboard listener for tight platforming & quick restart/pause hotkeys
  useEffect(() => {
    const onKeyDown = (e: KeyboardEvent) => {
      const target = e.target as HTMLElement | null;
      const isTyping =
        target &&
        (target.tagName === 'INPUT' || target.tagName === 'TEXTAREA');

      if (isTyping) {
        if (e.key === 'Enter') {
          e.preventDefault();
          commitRunScoreIfNeeded(true);
          (target as HTMLInputElement).blur();
        }
        return;
      }

      const engine = engineRef.current;
      if (!engine) return;

      const code = e.code;

      if (
        code === 'ArrowLeft' ||
        code === 'ArrowRight' ||
        code === 'ArrowUp' ||
        code === 'ArrowDown' ||
        code === 'Space'
      ) {
        e.preventDefault();
      }

      if (engine.screen === 'title') {
        if (code === 'Enter' || code === 'Space') {
          handleStartGame(selectedLevel);
          return;
        }
      }

      if (engine.screen === 'gameover') {
        if (code === 'KeyC' || code === 'Enter' || code === 'Space') {
          handleContinueCheckpoint();
          return;
        }
        if (code === 'KeyR') {
          handleStartGame(engine.levelIndex + 1);
          return;
        }
      }

      if (engine.screen === 'victory') {
        if (code === 'KeyR' || code === 'Enter' || code === 'Space') {
          handleStartGame(1);
          return;
        }
      }

      if (code === 'KeyP' || code === 'Escape') {
        if (engine.screen === 'playing' || engine.screen === 'paused') {
          engine.togglePause();
        }
        return;
      }

      if (code === 'KeyR' && engine.screen === 'paused') {
        handleStartGame(engine.levelIndex);
        return;
      }

      const k = keyInputRef.current;
      if (code === 'ArrowLeft' || code === 'KeyA') k.left = true;
      if (code === 'ArrowRight' || code === 'KeyD') k.right = true;
      if (code === 'ArrowDown' || code === 'KeyS') k.down = true;
      if (code === 'ArrowUp' || code === 'KeyW') k.up = true;

      if (
        code === 'Space' ||
        code === 'ArrowUp' ||
        code === 'KeyW' ||
        code === 'KeyZ'
      ) {
        if (!k.jumpHeld) k.jumpPressed = true;
        k.jumpHeld = true;
      }

      if (
        code === 'ShiftLeft' ||
        code === 'ShiftRight' ||
        code === 'KeyX' ||
        code === 'KeyJ' ||
        code === 'KeyK'
      ) {
        if (!k.runHeld) k.firePressed = true;
        k.runHeld = true;
      }

      if (code === 'KeyC' || code === 'ShiftRight') {
        e.preventDefault();
        k.dashPressed = true;
      }
      if (code === 'KeyR' && engine.screen === 'playing') {
        e.preventDefault();
        engine.startRewind();
        return;
      }
      if (code === 'KeyG' || code === 'KeyF') {
        e.preventDefault();
        k.grapplePressed = true;
      }

      if (code === 'KeyQ' || code === 'KeyE' || code === 'Tab') {
        e.preventDefault();
        k.switchPressed = true;
      }
    };

    const onKeyUp = (e: KeyboardEvent) => {
      const code = e.code;
      const k = keyInputRef.current;

      if (code === 'ArrowLeft' || code === 'KeyA') k.left = false;
      if (code === 'ArrowRight' || code === 'KeyD') k.right = false;
      if (code === 'ArrowDown' || code === 'KeyS') k.down = false;
      if (code === 'ArrowUp' || code === 'KeyW') k.up = false;

      if (
        code === 'Space' ||
        code === 'ArrowUp' ||
        code === 'KeyW' ||
        code === 'KeyZ'
      ) {
        k.jumpHeld = false;
      }

      if (
        code === 'ShiftLeft' ||
        code === 'ShiftRight' ||
        code === 'KeyX' ||
        code === 'KeyJ' ||
        code === 'KeyK'
      ) {
        k.runHeld = false;
      }
    };

    const clearKeys = () => {
      keyInputRef.current = {
        left: false,
        right: false,
        up: false,
        down: false,
        jumpHeld: false,
        jumpPressed: false,
        runHeld: false,
        firePressed: false,
        switchPressed: false,
        dashPressed: false,
        grapplePressed: false,
      };
    };

    window.addEventListener('keydown', onKeyDown);
    window.addEventListener('keyup', onKeyUp);
    window.addEventListener('blur', clearKeys);
    return () => {
      window.removeEventListener('keydown', onKeyDown);
      window.removeEventListener('keyup', onKeyUp);
      window.removeEventListener('blur', clearKeys);
    };
  }, [
    commitRunScoreIfNeeded,
    handleContinueCheckpoint,
    handleStartGame,
    selectedLevel,
  ]);

  const touchCallbacks = useRef({
    onMoveChange(left: boolean, right: boolean, down: boolean) {
      touchInputRef.current.left = left;
      touchInputRef.current.right = right;
      touchInputRef.current.down = down;
    },
    onJumpChange(held: boolean, justPressed: boolean) {
      touchInputRef.current.jumpHeld = held;
      if (justPressed) touchInputRef.current.jumpPressed = true;
    },
    onRunFireChange(held: boolean, justPressed: boolean) {
      touchInputRef.current.runHeld = held;
      if (justPressed) touchInputRef.current.firePressed = true;
    },
    onSwitchWeapon() {
      touchInputRef.current.switchPressed = true;
    },
    onDash() {
      touchInputRef.current.dashPressed = true;
    },
    onGrapple() {
      touchInputRef.current.grapplePressed = true;
    },
  }).current;

  const qualifiesForTable =
    hud.score > 0 && (hasSavedRun || isQualifyingHighScore(hud.score));

  return (
    <div className="relative h-[100dvh] w-screen overflow-hidden bg-[#0b0e1a] select-none">
      {/* Full-Viewport Crisp Pixel-Art Canvas */}
      <canvas
        ref={canvasRef}
        className="pixel-canvas absolute top-0 left-0 block w-full touch-none"
      />

      {/* Minimal Classic Top Arcade HUD */}
      {/* Gameplay HUD — hidden on the title screen so the dashboard owns it */}
      <header
        className={`pointer-events-none fixed inset-x-0 top-0 z-20 flex items-start justify-between px-3 pt-2.5 pb-4 sm:px-6 sm:pt-3.5 ${
          hud.screen === 'title' ? 'hidden' : ''
        }`}
      >
        <div className="wonder-pill grid grid-cols-5 gap-3 px-4 py-2 sm:gap-7 sm:px-6 md:gap-9">
          {/* Score & Active Power Pill */}
          <div className="flex flex-col">
            <div className="flex items-center gap-1.5">
              <span className="font-pixel text-[13px] tracking-wider text-[#ffb3be] pixel-text-shadow-sm sm:text-xs">
                {CHARACTERS[hud.character].name}
              </span>
              {hud.starActive ? (
                <span className="rounded bg-amber-300 px-1 py-0.5 font-pixel text-[11px] text-slate-950 animate-pulse">
                  STAR
                </span>
              ) : hud.power === 'fire' ? (
                <span className="rounded bg-orange-500 px-1 py-0.5 font-pixel text-[11px] text-white">
                  FIRE
                </span>
              ) : hud.power === 'big' ? (
                <span className="rounded bg-red-500 px-1 py-0.5 font-pixel text-[11px] text-white">
                  SUPER
                </span>
              ) : null}
            </div>
            <span className="mt-1 font-pixel text-xs text-white pixel-text-shadow-sm sm:text-sm">
              {String(hud.score).padStart(6, '0')}
            </span>
          </div>

          {/* Coins */}
          <div className="flex flex-col">
            <span className="font-pixel text-[13px] tracking-wider text-[#c8f6e6] pixel-text-shadow-sm sm:text-xs">
              KOIN
            </span>
            <div className="mt-1 flex items-center gap-1 font-pixel text-xs text-white pixel-text-shadow-sm sm:text-sm">
              <span className="inline-block h-3 w-2.5 rounded-full border border-amber-900 bg-amber-300 shadow-[0_0_6px_#fbbf24]" />
              <span>×{String(hud.coins).padStart(2, '0')}</span>
            </div>
          </div>

          {/* World */}
          <div className="flex flex-col">
            <span className="font-pixel text-[13px] tracking-wider text-[#c8f6e6] pixel-text-shadow-sm sm:text-xs">
              LEVEL
            </span>
            <span className="mt-1 flex items-center gap-1 font-pixel text-xs text-white pixel-text-shadow-sm sm:text-sm">
              <span>{hud.themeIcon}</span>
              <span>{hud.levelNumber}</span>
            </span>
          </div>

          {/* Time */}
          <div className="flex flex-col">
            <span className="font-pixel text-[13px] tracking-wider text-[#c8f6e6] pixel-text-shadow-sm sm:text-xs">
              WAKTU
            </span>
            <span
              className={`mt-1 font-pixel text-xs pixel-text-shadow-sm sm:text-sm ${
                hud.timeRemaining <= 100 && hud.screen === 'playing'
                  ? 'animate-pulse text-rose-400'
                  : 'text-white'
              }`}
            >
              {String(hud.timeRemaining).padStart(3, '0')}
            </span>
          </div>

          {/* Lives */}
          <div className="flex flex-col">
            <span className="font-pixel text-[13px] tracking-wider text-[#c8f6e6] pixel-text-shadow-sm sm:text-xs">
              NYAWA
            </span>
            <span className="mt-1 font-pixel text-xs text-[#ff6678] pixel-text-shadow-sm sm:text-sm">
              ♥×{hud.lives}
            </span>
            {hud.checkpointTotal > 0 && (
              <span className="mt-1 flex items-center gap-0.5" title="Checkpoints reached">
                {Array.from({ length: hud.checkpointTotal }).map((_, i) => (
                  <span
                    key={i}
                    className={`inline-block h-2 w-2 rounded-sm border ${
                      i <= hud.checkpointIndex
                        ? 'border-emerald-200 bg-emerald-400 shadow-[0_0_6px_#4ade80]'
                        : 'border-white/35 bg-slate-700/70'
                    }`}
                  />
                ))}
              </span>
            )}
          </div>
        </div>

        {/* Subtle Top-Right Controls */}
        <div className="pointer-events-auto flex items-center gap-1.5 sm:gap-2">
          <button
            type="button"
            onClick={() => setTouchVisible((v) => !v)}
            title="Toggle On-Screen Touch Pad"
            className={`flex h-8 items-center justify-center rounded-lg border px-2 font-pixel text-[12px] transition ${
              touchVisible
                ? 'border-[#f6c343] bg-[#f6c343]/30 text-[#fff2c6]'
                : 'border-[#fff2c6] bg-[#172747]/95 text-white hover:brightness-125'
            }`}
          >
            PAD
          </button>

          <button
            type="button"
            onClick={() => engineRef.current?.toggleSound()}
            title={hud.soundEnabled ? 'Mute Audio' : 'Unmute Audio'}
            className="flex h-8 w-9 items-center justify-center rounded-xl border-2 border-[#fff2c6] bg-[#172747]/95 font-pixel text-[13px] text-white hover:brightness-125"
          >
            {hud.soundEnabled ? '🔊' : '🔇'}
          </button>

          {(hud.screen === 'playing' || hud.screen === 'paused') && (
            <button
              type="button"
              onClick={() => engineRef.current?.togglePause()}
              title="Pause Game (P)"
              className="flex h-8 items-center justify-center rounded-xl border-2 border-[#fff2c6] bg-[#172747]/95 px-3 font-pixel text-[13px] text-white hover:brightness-125"
            >
              {hud.screen === 'paused' ? '▶ LANJUT' : 'Ⅱ JEDA'}
            </button>
          )}
        </div>
      </header>

      {/* Free-trial banner: makes it unmistakable that coins are not banked */}
      {hud.demoMode && (hud.screen === 'playing' || hud.screen === 'paused') && (
        <div className="pointer-events-none fixed inset-x-0 top-0 z-30 flex justify-center">
          <div className="mt-1 flex items-center gap-2 rounded-b-xl border-x border-b border-sky-300/60 bg-sky-500/25 px-3.5 py-1.5 backdrop-blur-sm">
            <span className="text-xs">🎮</span>
            <span className="font-pixel text-[12px] text-sky-100">
              FREE TRIAL · {CHARACTERS[hud.character].name}
            </span>
            <span className="hidden text-[10px] font-bold text-sky-200/90 sm:inline">
              coins not banked
            </span>
          </div>
        </div>
      )}

      {/* First-visit celebration — a long-term collection goal */}
      {hud.freshDiscovery && hud.screen === 'playing' && (
        <div className="pointer-events-none fixed inset-x-0 top-[132px] z-30 flex justify-center px-4 sm:top-[142px]">
          <div className="animate-float-slow flex items-center gap-2.5 rounded-xl border-2 border-amber-300 bg-slate-950/90 px-4 py-2 shadow-[0_0_24px_rgba(251,191,36,0.45)] backdrop-blur">
            <span className="text-lg">{hud.themeIcon}</span>
            <span className="font-pixel text-[13px] text-amber-300">
              NEW WORLD DISCOVERED!
            </span>
            {!hud.demoMode && (
              <span className="font-pixel text-[12px] text-emerald-300">
                +25 COINS
              </span>
            )}
          </div>
        </div>
      )}

      {/* Boss health bar */}
      {hud.screen === 'playing' && hud.bossHp >= 0 && (
        <div className="pointer-events-none fixed inset-x-0 bottom-[150px] z-20 flex justify-center px-6">
          <div className="w-full max-w-md">
            <div className="mb-1 flex items-center justify-between">
              <span className="font-pixel text-[12px] text-orange-300">
                KOOPA WARLORD
              </span>
              <span className="font-pixel text-[11px] text-slate-300">
                PHASE {hud.bossPhase}/3
              </span>
            </div>
            <div className="h-3 overflow-hidden rounded-full border-2 border-orange-300/70 bg-slate-950/80">
              <div
                className="h-full rounded-full transition-[width] duration-200"
                style={{
                  width: `${Math.max(0, hud.bossHp) * 100}%`,
                  background:
                    hud.bossPhase >= 3 ? '#ef4444'
                      : hud.bossPhase === 2 ? '#f97316' : '#fbbf24',
                }}
              />
            </div>
          </div>
        </div>
      )}

      {/* Stomp chain meter */}
      {hud.screen === 'playing' && hud.stompChain >= 2 && (
        <div className="pointer-events-none fixed inset-x-0 top-[112px] z-20 flex justify-center">
          <div className="rounded-full border-2 border-amber-300 bg-slate-950/85 px-3 py-1">
            <span className="font-pixel text-[13px] text-amber-300">
              CHAIN ×{hud.stompChain}
            </span>
            <span className="ml-2 text-[9px] font-bold text-emerald-300">
              {hud.stompChain >= 4 ? 'RARE DROP!' : `${4 - hud.stompChain} to rare`}
            </span>
          </div>
        </div>
      )}

      {/* Rewind flash */}
      {hud.rewinding && (
        <div className="pointer-events-none fixed inset-0 z-30 flex items-center justify-center bg-indigo-500/15">
          <span className="font-pixel text-lg text-indigo-200 pixel-text-shadow">
            ⏪ REWIND
          </span>
        </div>
      )}

      {/* Costume + ability status */}
      {hud.screen === 'playing' && (
        <div className="pointer-events-none fixed top-[62px] right-3 z-20 flex flex-col items-end gap-1 sm:top-[70px] sm:right-6">
          {hud.timeSlow > 0 && (
            <span className="rounded-md border border-indigo-300/70 bg-indigo-500/25 px-2 py-1 font-pixel text-[12px] text-indigo-100">
              ⏱ SLOW {hud.timeSlow.toFixed(1)}s
            </span>
          )}
          {hud.magnet > 0 && (
            <span className="rounded-md border border-amber-300/70 bg-amber-500/25 px-2 py-1 font-pixel text-[12px] text-amber-100">
              🧲 MAGNET {hud.magnet.toFixed(1)}s
            </span>
          )}
          {hud.shadow > 0 && (
            <span className="rounded-md border border-fuchsia-300/70 bg-fuchsia-500/25 px-2 py-1 font-pixel text-[12px] text-fuchsia-100">
              👤 SHADOW {hud.shadow.toFixed(1)}s
            </span>
          )}
          <span className="flex items-center gap-1 rounded-md border border-white/20 bg-slate-950/70 px-2 py-1">
            <span className="font-pixel text-[11px] text-slate-400">DASH</span>
            {Array.from({ length: Math.max(1, hud.dashCharges) }).map((_, i) => (
              <span
                key={i}
                className={`inline-block h-2 w-2 rounded-full ${
                  i < hud.dashCharges ? 'bg-cyan-300' : 'bg-white/20'
                }`}
              />
            ))}
          </span>
          <span className="flex items-center gap-1 rounded-md border border-indigo-300/50 bg-slate-950/70 px-2 py-1">
            <span className="font-pixel text-[11px] text-indigo-300">⏪ R</span>
            <span className="font-pixel text-[12px] text-white">{hud.rewinds}</span>
          </span>
          {hud.relicFound && (
            <span className="rounded-md border border-amber-300/70 bg-amber-500/20 px-2 py-1 font-pixel text-[12px] text-amber-200">
              🏺 RELIC
            </span>
          )}
          {hud.isNight && (
            <span className="rounded-md border border-indigo-400/60 bg-slate-900/80 px-2 py-1 font-pixel text-[11px] text-indigo-200">
              🌙 NIGHT · NPC+
            </span>
          )}
          {hud.slippery && (
            <span className="rounded-md border border-sky-400/60 bg-slate-900/80 px-2 py-1 font-pixel text-[11px] text-sky-200">
              ⚠ SLIPPERY
            </span>
          )}
        </div>
      )}

      {/* Weapon belt — shows everything collected in earlier maps */}
      {(hud.screen === 'playing' || hud.screen === 'paused') &&
        hud.ownedWeapons.length > 0 && (
          <div className="pointer-events-none fixed top-[62px] left-3 z-20 flex items-center gap-1.5 sm:top-[72px] sm:left-6">
            {hud.ownedWeapons.map((w) => {
              const def = WEAPONS[w];
              const ammo = hud.weaponAmmoMap[w];
              const isEquipped = hud.weapon === w;
              const unlimited = ammo === undefined || ammo === Infinity;
              const empty = !unlimited && (ammo ?? 0) <= 0;
              return (
                <div
                  key={w}
                  className={`flex items-center gap-1 rounded-md border px-1.5 py-1 backdrop-blur-sm transition ${
                    isEquipped
                      ? 'scale-105 bg-slate-900/90'
                      : 'bg-slate-950/60 opacity-70'
                  } ${empty ? 'grayscale' : ''}`}
                  style={{
                    borderColor: isEquipped ? def.color : 'rgba(255,255,255,0.15)',
                    boxShadow: isEquipped ? `0 0 10px ${def.color}66` : undefined,
                  }}
                >
                  <span className="text-xs leading-none">{def.icon}</span>
                  <span
                    className="font-pixel text-[11px] leading-none"
                    style={{ color: isEquipped ? def.glow : '#94a3b8' }}
                  >
                    {unlimited ? '∞' : ammo}
                  </span>
                </div>
              );
            })}
            <span className="ml-1 hidden font-pixel text-[10px] text-slate-400 sm:inline">
              Q/E SWAP
            </span>
          </div>
        )}

      {/* Level briefing — one compact card, never overlaps other toasts */}
      {hud.screen === 'playing' && showNpcBriefing && (
        <div className="pointer-events-none fixed inset-x-0 top-[62px] z-10 flex justify-center px-3 sm:top-[70px]">
          <div className="max-w-[94vw] rounded-xl border border-amber-300/55 bg-slate-950/88 px-3.5 py-2 shadow-lg backdrop-blur-sm">
            <div className="flex flex-wrap items-center justify-center gap-x-2 gap-y-1">
              <span className="font-pixel text-[12px] tracking-wide text-amber-300">
                LV {hud.levelNumber}
              </span>
              <span className="text-[11px] font-bold text-slate-100">
                {hud.themeIcon} {hud.themeName}
              </span>
              <span
                className="rounded px-1.5 py-0.5 font-pixel text-[11px]"
                style={{ color: hud.tierColor, background: `${hud.tierColor}22` }}
              >
                {hud.tierName}
              </span>
              <span className="rounded bg-sky-500/30 px-1.5 py-0.5 font-pixel text-[11px] text-sky-100">
                {hud.weatherLabel}
              </span>
              <span className="rounded bg-slate-700/60 px-1.5 py-0.5 font-pixel text-[11px] text-slate-200">
                {hud.weatherSchedule}
              </span>
            </div>
            <p className="mt-1 hidden text-center text-[10px] font-semibold text-sky-200/90 sm:block">
              ⚠ {hud.hazardLabel}
            </p>
          </div>
        </div>
      )}

      {/* Stage Clear Non-Blocking Celebration Banner */}
      {hud.screen === 'stage_clear' && (
        <div className="pointer-events-none fixed inset-x-0 top-16 z-20 flex flex-col items-center px-4 text-center">
          <div className="wonder-paper px-8 py-5">
            <h2 className="font-pixel text-xl sm:text-3xl">
              LEVEL {hud.levelNumber} SELESAI!
            </h2>
            <p className="font-pixel text-2xl" style={{ color: '#f4bb32' }}>
              ★ ★ ★
            </p>
            <p className="mt-1 font-pixel text-[12px] text-slate-300">
              NEXT: {getLevelBiome(hud.levelNumber + 1).icon}{' '}
              {getLevelBiome(hud.levelNumber + 1).name}
            </p>
            <div className="mt-2 flex items-center justify-center gap-5 font-pixel text-[13px] text-white sm:text-xs">
              <span>FLAG +{hud.stageBonus}</span>
              <span className="text-emerald-300">TIME BONUS +{hud.timeBonus}</span>
            </div>
          </div>
        </div>
      )}

      {/* START SCREEN — spacious two-column dashboard over the attract demo */}
      {hud.screen === 'title' && (
        <div className="bg-wonder-home fixed inset-0 z-30 overflow-y-auto touch-pan-y">
          <div className="mx-auto flex min-h-full w-full max-w-5xl flex-col justify-center gap-3 px-3 py-4 sm:gap-4 sm:px-5 sm:py-6">

            {/* ---- Marquee ---- */}
            <header className="wonder-pill relative shrink-0 overflow-hidden px-5 py-3 text-center sm:px-8 sm:py-5">
              <span className="absolute top-2.5 left-2.5 h-2 w-2 rounded-full bg-[#ffd966]" />
              <span className="absolute top-2.5 right-2.5 h-2 w-2 rounded-full bg-[#ffd966]" />
              <span className="absolute bottom-2.5 left-2.5 h-2 w-2 rounded-full bg-[#ffd966]" />
              <span className="absolute bottom-2.5 right-2.5 h-2 w-2 rounded-full bg-[#ffd966]" />

              <h1 className="wonder-title font-pixel text-2xl leading-tight sm:text-5xl">
                SUPER MARIO BROS.
              </h1>
              <p className="font-pixel text-sm text-[#c8f6e6] sm:text-lg">
                PETUALANGAN DIMULAI DI SINI
              </p>

              <div className="mt-2 flex flex-wrap items-center justify-center gap-1.5 sm:gap-2.5">
                <span className="rounded-full border border-amber-200/45 bg-black/25 px-2.5 py-1 font-pixel text-[11px] text-amber-100 sm:text-[12px]">
                  TOP {String(hud.highScore).padStart(6, '0')}
                </span>
                <span className="flex items-center gap-1.5 rounded-full border border-amber-200/45 bg-black/25 px-2.5 py-1 font-pixel text-[11px] text-amber-100 sm:text-[12px]">
                  <span className="inline-block h-2 w-1.5 rounded-full bg-amber-300" />
                  {bankCoins.toLocaleString()}
                </span>
                <span className="rounded-full border border-amber-200/45 bg-black/25 px-2.5 py-1 font-pixel text-[11px] text-amber-100 sm:text-[12px]">
                  {TOTAL_LEVELS.toLocaleString()} LEVELS
                </span>
                <span className="rounded-full border border-emerald-300/50 bg-black/25 px-2.5 py-1 font-pixel text-[11px] text-emerald-200 sm:text-[12px]">
                  🌍 {worldsFound}/{TOTAL_BIOMES}
                </span>
                <button
                  type="button"
                  onClick={() => setShowLogin(true)}
                  className="cursor-pointer rounded-full border border-sky-300/50 bg-black/25 px-2.5 py-1 font-pixel text-[11px] text-sky-200 transition hover:border-sky-200 hover:bg-black/40 sm:text-[12px]"
                >
                  👤 {account ? account.name : 'SIGN IN'}
                </button>
              </div>
            </header>

            {!showTitleScores ? (
              /* Two columns on anything wide enough — keeps PLAY on screen
                 even on short landscape phones. */
              <div className="grid flex-1 items-start gap-3 md:grid-cols-2 md:gap-4">

                {/* ===== Left: stage + character ===== */}
                <div className="flex flex-col gap-3">
                  <button
                    type="button"
                    onClick={() => setShowLevelSelect(true)}
                    className="group arcade-card flex cursor-pointer items-center gap-3 rounded-2xl p-3 text-left transition hover:brightness-110 sm:p-4"
                  >
                    <span className="text-3xl leading-none sm:text-4xl">
                      {getLevelBiome(selectedLevel).icon}
                    </span>
                    <span className="min-w-0 flex-1">
                      <span className="flex items-center justify-between gap-2">
                        <span className="font-pixel text-[11px] tracking-widest text-sky-200/90">
                          STAGE
                        </span>
                        <span className="font-pixel text-[11px] text-slate-400">
                          {unlocked}/{TOTAL_LEVELS}
                        </span>
                      </span>
                      <span className="mt-1 flex items-baseline gap-2">
                        <span className="font-pixel text-base text-amber-300">
                          {selectedLevel}
                        </span>
                        <span className="truncate text-[11px] font-bold text-slate-200">
                          {getLevelBiome(selectedLevel).name}
                        </span>
                      </span>
                      <span className="mt-1.5 flex items-center gap-2">
                        <span
                          className="rounded px-1.5 py-0.5 text-[9px] font-bold"
                          style={{
                            color: getLevelTier(selectedLevel).color,
                            background: `${getLevelTier(selectedLevel).color}1f`,
                          }}
                        >
                          {getLevelTier(selectedLevel).name}
                        </span>
                        <span className="font-pixel text-[11px] text-slate-500 group-hover:text-amber-200">
                          BROWSE →
                        </span>
                      </span>
                    </span>
                  </button>

                  <button
                    type="button"
                    onClick={() => {
                      setBankCoins(loadCoins());
                      setOwnedChars(loadOwnedCharacters());
                      setShowShop(true);
                    }}
                    className="group arcade-card flex cursor-pointer items-center gap-3 rounded-2xl p-3 text-left transition hover:brightness-110 sm:p-4"
                  >
                    <span
                      className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl border-2 sm:h-12 sm:w-12"
                      style={{
                        borderColor: CHARACTERS[character].palette.R,
                        background: `${CHARACTERS[character].palette.R}22`,
                      }}
                    >
                      <span
                        className="h-6 w-5 rounded-sm"
                        style={{
                          background: `linear-gradient(180deg, ${CHARACTERS[character].palette.R} 55%, ${CHARACTERS[character].palette.B} 55%)`,
                        }}
                      />
                    </span>
                    <span className="min-w-0 flex-1">
                      <span className="flex items-center justify-between gap-2">
                        <span className="font-pixel text-[11px] tracking-widest text-emerald-200/90">
                          CHARACTER
                        </span>
                        <span className="font-pixel text-[11px] text-slate-400">
                          {ownedChars.length}/{CHARACTER_ORDER.length}
                        </span>
                      </span>
                      <span className="mt-1 block font-pixel text-sm text-white">
                        {CHARACTERS[character].name}
                      </span>
                      <span className="mt-1.5 flex items-center gap-2">
                        <span
                          className="rounded px-1.5 py-0.5 text-[9px] font-bold"
                          style={{
                            color: CHARACTERS[character].palette.R,
                            background: `${CHARACTERS[character].palette.R}22`,
                          }}
                        >
                          {CHARACTERS[character].perk}
                        </span>
                        <span className="font-pixel text-[11px] text-slate-500 group-hover:text-emerald-200">
                          SHOP · TRY FREE →
                        </span>
                      </span>
                    </span>
                  </button>
                </div>

                {/* ===== Right: difficulty + play ===== */}
                <div className="flex flex-col gap-3">
                  <section className="arcade-card rounded-2xl p-3 sm:p-4">
                    <div className="mb-2 flex items-center justify-between gap-2">
                      <span className="font-pixel text-[11px] tracking-widest text-rose-200">
                        NPC CHALLENGE
                      </span>
                      <span className="font-pixel text-[11px] text-amber-300/90">
                        ★ MEDIUM
                      </span>
                    </div>
                    <div className="grid grid-cols-4 gap-1.5">
                      {DIFFICULTY_ORDER.map((tier) => {
                        const active = difficulty === tier;
                        const tone =
                          tier === 'easy' ? '#34d399'
                            : tier === 'medium' ? '#fbbf24'
                              : tier === 'hard' ? '#fb923c' : '#e879f9';
                        return (
                          <button
                            key={tier}
                            type="button"
                            onClick={() => setDifficulty(tier)}
                            aria-pressed={active}
                            className={`cursor-pointer rounded-lg border-2 px-1 py-2 text-center transition ${
                              active
                                ? 'text-white'
                                : 'border-white/12 bg-slate-900/70 text-slate-300 hover:border-white/35'
                            }`}
                            style={
                              active
                                ? { borderColor: tone, background: `${tone}26` }
                                : undefined
                            }
                          >
                            <span
                              className="block font-pixel text-[11px] leading-tight"
                              style={{ color: active ? '#fff' : tone }}
                            >
                              {DIFFICULTY_CONFIG[tier].label}
                            </span>
                            <span
                              className="mt-1 block text-[8px] font-bold"
                              style={{ color: tone }}
                            >
                              {DIFFICULTY_CONFIG[tier].short}
                            </span>
                          </button>
                        );
                      })}
                    </div>
                    <p className="mt-2 text-center text-[10px] leading-snug font-semibold text-slate-300">
                      {DIFFICULTY_CONFIG[difficulty].blurb}
                    </p>
                  </section>

                  <button
                    type="button"
                    onClick={() => handleStartGame(selectedLevel, difficulty)}
                    className="arcade-btn-primary w-full cursor-pointer rounded-2xl py-3.5 font-pixel text-sm text-white pixel-text-shadow-sm sm:py-4 sm:text-lg"
                  >
                    ▶ MULAI BERMAIN
                  </button>

                  {/* Daily challenge — same level for everyone, worldwide */}
                  <button
                    type="button"
                    onClick={handleDaily}
                    className="flex w-full cursor-pointer items-center justify-between rounded-xl border-2 border-violet-400/70 bg-violet-500/15 px-3 py-2.5 transition hover:brightness-110"
                  >
                    <span className="text-left">
                      <span className="block font-pixel text-[12px] text-violet-200">
                        🗓 DAILY CHALLENGE
                      </span>
                      <span className="mt-0.5 block text-[10px] font-bold text-slate-300">
                        LV {dailyLv} · same for everyone today
                      </span>
                    </span>
                    <span
                      className={`shrink-0 rounded px-2 py-1 font-pixel text-[11px] ${
                        dailyDone
                          ? 'bg-emerald-500/30 text-emerald-200'
                          : 'bg-violet-400/30 text-violet-100'
                      }`}
                    >
                      {dailyDone ? 'PLAYED' : 'PLAY'}
                    </span>
                  </button>

                  <div className="grid grid-cols-2 gap-2">
                    <button
                      type="button"
                      onClick={() => {
                        setHighScores(loadHighScores());
                        setShowTitleScores(true);
                      }}
                      className="arcade-btn-secondary cursor-pointer rounded-xl py-2.5 font-pixel text-[13px] text-amber-200"
                    >
                      🏆 SCORES
                    </button>
                    <button
                      type="button"
                      onClick={() => { setAchCount(unlockedCount()); setShowAch(true); }}
                      className="arcade-btn-secondary cursor-pointer rounded-xl py-2.5 font-pixel text-[13px] text-emerald-200"
                    >
                      🏅 {achCount}/{ACHIEVEMENTS.length}
                    </button>
                    <button
                      type="button"
                      onClick={() => setShowBestiary(true)}
                      className="arcade-btn-secondary cursor-pointer rounded-xl py-2.5 font-pixel text-[13px] text-sky-200"
                    >
                      📖 BESTIARY
                    </button>
                    <div className="[&>button]:w-full [&>button]:py-2.5">
                      <AndroidDownload />
                    </div>
                  </div>
                </div>
              </div>
            ) : (
              <section className="arcade-card rounded-2xl p-4">
                <div className="flex items-center justify-between border-b border-white/15 pb-2.5">
                  <h2 className="font-pixel text-[14px] text-amber-300 sm:text-sm">
                    🏆 LOCAL HALL OF FAME
                  </h2>
                  <button
                    type="button"
                    onClick={() => setShowTitleScores(false)}
                    className="arcade-btn-secondary cursor-pointer rounded-lg px-3 py-1.5 font-pixel text-[13px] text-white"
                  >
                    BACK
                  </button>
                </div>
                <div className="mt-2.5">
                  <HighScoreTable
                    scores={highScores}
                    highlightId={savedEntryId}
                  />
                </div>
              </section>
            )}

            {/* ---- Controls (hidden on very short screens) ---- */}
            {!showTitleScores && (
              <footer className="hidden flex-wrap items-center justify-center gap-x-4 gap-y-1.5 rounded-xl border border-white/10 bg-slate-950/50 px-3 py-2 text-[11px] text-slate-300 [@media(min-height:620px)]:flex">
                {[
                  ['◀ ▶', 'Move'],
                  ['SPACE', 'Jump'],
                  ['SHIFT', 'Run & Fire'],
                  ['Q / E', 'Swap weapon'],
                  ['C', 'Dash'],
                  ['G', 'Grapple'],
                  ['↓ air', 'Ground slam'],
                  ['R', 'Rewind'],
                ].map(([k, label]) => (
                  <span key={k} className="flex items-center gap-1.5">
                    <kbd className="rounded border border-white/25 bg-slate-800 px-1.5 py-0.5 font-pixel text-[11px] text-amber-200">
                      {k}
                    </kbd>
                    <span>{label}</span>
                  </span>
                ))}
              </footer>
            )}
          </div>
        </div>
      )}

      {/* PAUSE OVERLAY */}
      {hud.screen === 'paused' && (
        <div className="fixed inset-0 z-30 flex items-center justify-center bg-[#11162b]/60 px-4">
          <div className="wonder-paper max-h-[94dvh] w-full max-w-sm overflow-y-auto p-6 text-center">
            <h2 className="font-pixel text-3xl">
              JEDA DULU!
            </h2>
            <p className="mt-1.5 text-sm font-semibold text-slate-300">
              LV {hud.levelNumber} · {hud.themeIcon} {hud.worldSubtitle}
            </p>
            {hud.checkpointTotal > 0 && (
              <p className="mt-2 font-pixel text-[12px] text-emerald-300">
                CHECKPOINT {Math.max(0, hud.checkpointIndex + 1)}/
                {hud.checkpointTotal}
              </p>
            )}
            <span className="mt-2 inline-block rounded-md border border-amber-300/50 bg-amber-400/15 px-2 py-1 font-pixel text-[12px] text-amber-200">
              NPC: {DIFFICULTY_CONFIG[hud.difficulty].label} · TIER{' '}
              <span style={{ color: hud.tierColor }}>{hud.tierName}</span>
            </span>

            <div className="mt-5 flex flex-col gap-2.5">
              <button
                type="button"
                onClick={() => engineRef.current?.togglePause()}
                className="arcade-btn-primary cursor-pointer rounded-xl py-3 font-pixel text-xs text-white"
              >
                ▶ LANJUTKAN BERMAIN (P)
              </button>

              <button
                type="button"
                onClick={() => handleStartGame(hud.levelNumber)}
                className="arcade-btn-secondary cursor-pointer rounded-xl py-2.5 font-pixel text-xs text-white"
              >
                ↻ ULANGI LEVEL (R)
              </button>

              <div className="grid grid-cols-2 gap-2">
                <button
                  type="button"
                  onClick={() => engineRef.current?.toggleSound()}
                  className="arcade-btn-secondary cursor-pointer rounded-xl py-2.5 font-pixel text-[13px] text-sky-200"
                >
                  SFX: {hud.soundEnabled ? 'ON' : 'OFF'}
                </button>
                <button
                  type="button"
                  onClick={() => engineRef.current?.toggleMusic()}
                  className="arcade-btn-secondary cursor-pointer rounded-xl py-2.5 font-pixel text-[13px] text-emerald-200"
                >
                  BGM: {hud.musicEnabled ? 'ON' : 'OFF'}
                </button>
              </div>

              {account ? (
                <button
                  type="button"
                  onClick={() => {
                    signOut();
                    setAccount(null);
                    setBankCoins(loadCoins());
                    setOwnedChars(loadOwnedCharacters());
                    setUnlocked(loadUnlockedLevel());
                  }}
                  className="arcade-btn-secondary cursor-pointer rounded-xl py-2.5 font-pixel text-[13px] text-slate-300"
                >
                  👤 SIGN OUT ({account.name})
                </button>
              ) : null}

              <button
                type="button"
                onClick={() => {
                  const code = exportSave();
                  navigator.clipboard?.writeText(code).catch(() => {});
                  setShopNotice(null);
                  window.prompt('Transfer code — paste this on another device:', code);
                }}
                className="arcade-btn-secondary cursor-pointer rounded-xl py-2.5 font-pixel text-[13px] text-sky-200"
              >
                📤 EXPORT SAVE
              </button>

              <AndroidDownload variant="compact" />

              <button
                type="button"
                onClick={() => engineRef.current?.quitToTitle()}
                className="arcade-btn-secondary mt-1 cursor-pointer rounded-xl py-2.5 font-pixel text-[13px]"
              >
                KELUAR KE MENU
              </button>
            </div>
          </div>
        </div>
      )}

      {/* GAME OVER & VICTORY OVERLAY WITH INSTANT RESTART + HIGH-SCORE TABLE */}
      {(hud.screen === 'gameover' || hud.screen === 'victory') && (
        <div className="fixed inset-0 z-30 flex items-center justify-center bg-slate-950/70 px-4 py-4 backdrop-blur-xs">
          <div className="arcade-card max-h-[92dvh] w-full max-w-lg overflow-y-auto rounded-2xl p-5 sm:p-6">
            <div className="text-center">
              <p className="font-pixel text-[13px] tracking-widest text-amber-300">
                {hud.screen === 'victory'
                  ? 'MUSHROOM KINGDOM SAVED!'
                  : 'OUT OF LIVES'}
              </p>
              <h2
                className={`mt-1.5 font-pixel text-2xl pixel-text-shadow sm:text-3xl ${
                  hud.screen === 'victory' ? 'text-emerald-300' : 'text-rose-400'
                }`}
              >
                {hud.screen === 'victory' ? 'SUPER VICTORY!' : 'GAME OVER'}
              </h2>
              {hud.demoMode && (
                <p className="mt-2 rounded-lg border border-sky-400/50 bg-sky-500/15 px-3 py-1.5 text-[11px] font-bold text-sky-200">
                  Free trial as {CHARACTERS[hud.character].name} — coins from
                  this run were not banked.
                </p>
              )}
              <p className="mt-1.5 font-pixel text-[12px] text-slate-400">
                NPC MODE:{' '}
                <span className="text-amber-300">
                  {DIFFICULTY_CONFIG[hud.difficulty].label}
                </span>
              </p>
            </div>

            {/* Run Summary Stats */}
            <div className="mt-4 grid grid-cols-3 gap-2 rounded-xl border border-white/15 bg-slate-950/60 p-3 text-center">
              <div>
                <div className="font-pixel text-[12px] text-slate-400">SCORE</div>
                <div className="mt-1 font-pixel text-xs text-amber-300 sm:text-sm">
                  {String(hud.score).padStart(6, '0')}
                </div>
              </div>
              <div>
                <div className="font-pixel text-[12px] text-slate-400">COINS</div>
                <div className="mt-1 font-pixel text-xs text-white sm:text-sm">
                  {hud.coins}
                </div>
              </div>
              <div>
                <div className="font-pixel text-[12px] text-slate-400">LEVEL</div>
                <div className="mt-1 font-pixel text-xs text-sky-300 sm:text-sm">
                  {hud.levelNumber}
                </div>
              </div>
            </div>

            {/* Arcade Initials High-Score Entry (Non-Blocking!) */}
            {qualifiesForTable && !hasSavedRun && (
              <div className="mt-3.5 flex items-center justify-between gap-2 rounded-xl border-2 border-amber-300/70 bg-amber-400/10 px-3 py-2.5">
                <div className="text-left">
                  <div className="font-pixel text-[13px] text-amber-300">
                    ★ NEW HIGH SCORE!
                  </div>
                  <div className="text-xs text-amber-100/85">
                    Enter your 3-letter arcade tag:
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  <input
                    type="text"
                    maxLength={3}
                    value={initials}
                    onChange={(e) =>
                      setInitials(
                        e.target.value.toUpperCase().replace(/[^A-Z0-9]/g, '')
                      )
                    }
                    className="w-16 rounded-lg border-2 border-amber-300 bg-slate-950 px-2 py-1.5 text-center font-pixel text-xs text-white uppercase focus:outline-none"
                  />
                  <button
                    type="button"
                    onClick={() => commitRunScoreIfNeeded(true)}
                    className="arcade-btn-secondary cursor-pointer rounded-lg px-3 py-2 font-pixel text-[13px] text-amber-200"
                  >
                    SAVE
                  </button>
                </div>
              </div>
            )}

            {/* Local High-Score Leaderboard */}
            <div className="mt-4">
              <div className="mb-1.5 flex items-center justify-between">
                <span className="font-pixel text-[13px] text-sky-200">
                  🏆 HIGH SCORES
                </span>
                {hasSavedRun && (
                  <span className="font-pixel text-[12px] text-emerald-300">
                    SCORE RECORDED!
                  </span>
                )}
              </div>
              <HighScoreTable
                scores={highScores}
                highlightId={savedEntryId}
              />
            </div>

            {/* Instant Restart & Loop Actions */}
            <div className="mt-5 flex flex-col gap-2.5 sm:flex-row">
              {hud.screen === 'victory' && (
                <button
                  type="button"
                  onClick={handleContinueLoop}
                  className="arcade-btn-primary flex-1 cursor-pointer rounded-xl py-3 font-pixel text-xs text-white"
                >
                  ★ PLAY LOOP {hud.loopCount + 1}+
                </button>
              )}
              {hud.screen === 'gameover' && (
                <button
                  type="button"
                  onClick={handleContinueCheckpoint}
                  className="arcade-btn-primary flex-1 cursor-pointer rounded-xl py-3 font-pixel text-xs text-white"
                >
                  ▶ CONTINUE (C)
                  <span className="mt-1 block text-[9px] font-bold text-amber-100">
                    {hud.checkpointIndex >= 0
                      ? `LV ${hud.levelNumber} · CHECKPOINT ${hud.checkpointIndex + 1}`
                      : `LV ${hud.levelNumber} · FROM START`}
                  </span>
                </button>
              )}
              <button
                type="button"
                onClick={() => handleStartGame(hud.screen === 'victory' ? 1 : hud.levelNumber)}
                className={`${
                  hud.screen === 'victory'
                    ? 'arcade-btn-primary text-white'
                    : 'arcade-btn-secondary text-amber-200'
                } flex-1 cursor-pointer rounded-xl py-3 font-pixel text-xs`}
              >
                ↻ RESTART LV (R)
              </button>
              <button
                type="button"
                onClick={() => {
                  commitRunScoreIfNeeded(false);
                  engineRef.current?.quitToTitle();
                }}
                className="arcade-btn-secondary cursor-pointer rounded-xl px-4 py-3 font-pixel text-xs text-slate-200"
              >
                TITLE
              </button>
            </div>
          </div>
        </div>
      )}

      {showIntro && <IntroSplash onDone={() => setShowIntro(false)} />}

      {/* Optional sign-in, opened from the dashboard */}
      {!showIntro && showLogin && (
        <AccountGate
          onDone={(a) => {
            if (a) setAccount(a);
            setShowLogin(false);
            // Progress may have been swapped in with the account.
            setBankCoins(loadCoins());
            setOwnedChars(loadOwnedCharacters());
            setUnlocked(loadUnlockedLevel());
            setWorldsFound(discoveredCount());
            setAchCount(unlockedCount());
          }}
        />
      )}

      {/* Bestiary */}
      {hud.screen === 'title' && showBestiary && (
        <Bestiary onClose={() => setShowBestiary(false)} />
      )}

      {/* Character shop */}
      {hud.screen === 'title' && showShop && (
        <CharacterShop
          coins={bankCoins}
          owned={ownedChars}
          selected={character}
          notice={shopNotice}
          onBuy={(id) => {
            const res = buyCharacter(id);
            if (res.ok) {
              setOwnedChars(res.owned);
              setBankCoins(res.coins);
              setCharacter(id);
              saveSelectedCharacter(id);
              setShopNotice(null);
            } else {
              setBankCoins(res.coins);
              setShopNotice(
                res.reason === 'not enough coins'
                  ? `Not enough coins — you need ${CHARACTERS[id].cost.toLocaleString()}.`
                  : 'Could not complete that purchase.'
              );
            }
          }}
          onSelect={(id) => {
            setCharacter(id);
            saveSelectedCharacter(id);
            setShopNotice(null);
          }}
          onTryDemo={(id) => {
            commitRunScoreIfNeeded(false);
            setDemoChar(id);
            setShowShop(false);
            setShopNotice(null);
            engineRef.current?.startNewGame(
              Math.max(0, Math.min(TOTAL_LEVELS, selectedLevel) - 1),
              difficulty, id, true, pet
            );
          }}
          onClose={() => {
            setShowShop(false);
            setShopNotice(null);
          }}
          pets={PET_ORDER}
          ownedPets={ownedPets}
          activePet={pet}
          onBuyPet={(id: PetId) => {
            const def = PETS[id];
            if (ownedPets.includes(id)) { setPet(id); savePet(id); return; }
            if (bankCoins < def.cost) {
              setShopNotice(
                `Not enough coins — ${def.name} costs ${def.cost.toLocaleString()}.`
              );
              return;
            }
            if (spendCoins(def.cost)) {
              buyPet(id);
              setOwnedPets(loadOwnedPets());
              setBankCoins(loadCoins());
              setPet(id);
              savePet(id);
              setShopNotice(null);
            }
          }}
        />
      )}

      {/* Achievements */}
      {hud.screen === 'title' && showAch && (
        <div className="fixed inset-0 z-40 overflow-y-auto bg-slate-950/88 px-3 py-6 backdrop-blur-sm">
          <div className="mx-auto w-full max-w-2xl">
            <div className="arcade-card rounded-2xl p-4 sm:p-5">
              <div className="flex items-center justify-between border-b border-white/15 pb-3">
                <h2 className="font-pixel text-xs text-amber-300 sm:text-sm">
                  🏅 ACHIEVEMENTS {achCount}/{ACHIEVEMENTS.length}
                </h2>
                <button
                  type="button"
                  onClick={() => setShowAch(false)}
                  className="arcade-btn-secondary cursor-pointer rounded-lg px-3 py-1.5 font-pixel text-[13px] text-white"
                >
                  BACK
                </button>
              </div>
              <div className="mt-3 grid gap-2 sm:grid-cols-2">
                {ACHIEVEMENTS.map((a) => {
                  const have = loadProgress()[a.id] ?? 0;
                  const done = have >= a.goal;
                  const pct = Math.min(100, (have / a.goal) * 100);
                  return (
                    <div
                      key={a.id}
                      className={`rounded-xl border-2 p-2.5 ${
                        done
                          ? 'border-amber-300/80 bg-amber-400/15'
                          : 'border-white/12 bg-slate-950/60'
                      }`}
                    >
                      <div className="flex items-center gap-2">
                        <span className={`text-lg ${done ? '' : 'grayscale opacity-50'}`}>
                          {a.icon}
                        </span>
                        <span className="min-w-0 flex-1">
                          <span className="block font-pixel text-[13px] text-white">
                            {a.name}
                          </span>
                          <span className="block text-[10px] text-slate-400">
                            {a.desc}
                          </span>
                        </span>
                        {done && (
                          <span className="font-pixel text-[11px] text-amber-300">
                            ✓
                          </span>
                        )}
                      </div>
                      <div className="mt-1.5 h-1.5 overflow-hidden rounded-full bg-white/10">
                        <div
                          className="h-full rounded-full bg-amber-400"
                          style={{ width: `${pct}%` }}
                        />
                      </div>
                      <div className="mt-1 text-right text-[9px] text-slate-500">
                        {Math.min(have, a.goal)}/{a.goal}
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Achievement unlock toast */}
      {achToast && (
        <div className="pointer-events-none fixed inset-x-0 top-20 z-50 flex justify-center px-4">
          <div className="animate-float-slow rounded-xl border-2 border-amber-300 bg-slate-950/95 px-4 py-2.5 shadow-[0_0_24px_rgba(251,191,36,0.5)]">
            <p className="font-pixel text-[12px] text-amber-300">ACHIEVEMENT</p>
            <p className="mt-1 font-pixel text-[14px] text-white">{achToast}</p>
          </div>
        </div>
      )}

      {/* After a trial ends, offer to buy the character that was tested. */}
      {hud.screen === 'title' && demoChar && !showShop && (
        <div className="fixed inset-x-0 bottom-4 z-30 flex justify-center px-4">
          <div className="flex items-center gap-3 rounded-xl border-2 border-sky-300/70 bg-slate-900/95 px-4 py-2.5 shadow-lg backdrop-blur">
            <span className="text-sm">🎮</span>
            <span className="text-[11px] font-bold text-slate-200">
              Liked {CHARACTERS[demoChar].name}?
            </span>
            <button
              type="button"
              onClick={() => {
                setBankCoins(loadCoins());
                setOwnedChars(loadOwnedCharacters());
                setShowShop(true);
              }}
              className="arcade-btn-primary cursor-pointer rounded-lg px-3 py-1.5 font-pixel text-[12px] text-white"
            >
              BUY {CHARACTERS[demoChar].cost.toLocaleString()}
            </button>
            <button
              type="button"
              onClick={() => setDemoChar(null)}
              className="cursor-pointer px-1 font-pixel text-[13px] text-slate-400 hover:text-white"
            >
              ✕
            </button>
          </div>
        </div>
      )}

      {/* 8000-level campaign browser */}
      {hud.screen === 'title' && showLevelSelect && (
        <LevelSelect
          selected={selectedLevel}
          unlocked={unlocked}
          cleared={cleared}
          onSelect={setSelectedLevel}
          onPlay={(lv) => handleStartGame(lv, difficulty)}
          onClose={() => setShowLevelSelect(false)}
        />
      )}

      {/* Ergonomic Multi-Touch Arcade Controls */}
      {touchVisible && hud.screen === 'playing' && (
        <TouchControls
          callbacks={touchCallbacks}
          isFireMario={hud.power === 'fire'}
          weapon={hud.weapon}
          weaponAmmo={hud.weaponAmmo}
          ownedCount={hud.ownedWeapons.length}
          padHeight={padHeight}
        />
      )}
    </div>
  );
}

interface HighScoreTableProps {
  scores: HighScoreEntry[];
  highlightId: string | null;
}

const HighScoreTable: React.FC<HighScoreTableProps> = ({
  scores,
  highlightId,
}) => {
  return (
    <div className="overflow-hidden rounded-xl border border-white/15 bg-slate-950/65">
      <div className="grid grid-cols-12 border-b border-white/10 bg-white/5 px-3 py-2 font-pixel text-[12px] text-slate-400">
        <span className="col-span-2">RNK</span>
        <span className="col-span-3">NAME</span>
        <span className="col-span-4 text-right">SCORE</span>
        <span className="col-span-3 text-right">WORLD</span>
      </div>
      <div className="divide-y divide-white/5">
        {scores.slice(0, 5).map((entry, idx) => {
          const isHighlighted = entry.id === highlightId;
          return (
            <div
              key={entry.id}
              className={`grid grid-cols-12 items-center px-3 py-2 font-pixel text-[13px] sm:text-xs ${
                isHighlighted
                  ? 'bg-amber-400/20 text-amber-200'
                  : idx === 0
                    ? 'text-amber-300'
                    : 'text-slate-200'
              }`}
            >
              <span className="col-span-2">#{idx + 1}</span>
              <span className="col-span-3 tracking-wider">{entry.initials}</span>
              <span className="col-span-4 text-right">
                {String(entry.score).padStart(6, '0')}
              </span>
              <span className="col-span-3 text-right text-sky-300">
                {entry.world}
              </span>
            </div>
          );
        })}
      </div>
    </div>
  );
};

export default App;
