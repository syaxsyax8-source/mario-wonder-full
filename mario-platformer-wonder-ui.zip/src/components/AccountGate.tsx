import React, { useEffect, useRef, useState } from 'react';
import { getSprites, getBiomeTiles } from '../game/sprites';
import { getLevelBiome } from '../game/biomes';
import { MarioRenderer } from '../game/renderer';
import {
  Account, exportSave, importSave, listAccounts,
  loginAccount, registerAccount,
} from '../utils/account';

interface Props {
  /** Called with the signed-in account, or null when the player skips. */
  onDone: (a: Account | null) => void;
  /** Hides the "play without an account" option (used from the dashboard). */
  requireChoice?: boolean;
}

/**
 * Shown once on first launch. Players can sign in, play as a guest, or
 * restore a save from another device using a transfer code.
 */
/** Scenic worlds the sign-in screen cycles through. */
const SHOWCASE_LEVELS = [1, 4, 22, 46, 57, 64, 91];

/**
 * Animated backdrop for the sign-in screen.
 *
 * This is additive: the boot intro is untouched. It now renders with the
 * *actual* game assets — the real biome parallax, tile set, Mario sprite,
 * coins and Goombas — so the login screen looks exactly like playing the
 * game rather than an approximation. Worlds slowly crossfade into one
 * another, which also previews the variety in the campaign.
 */
const LoginBackdrop: React.FC = () => {
  const ref = useRef<HTMLCanvasElement | null>(null);

  useEffect(() => {
    const cv = ref.current;
    if (!cv) return;
    const ctx = cv.getContext('2d');
    if (!ctx) return;

    // This is a decorative backdrop behind a dialog, so it renders at a
    // reduced backing-store resolution and is scaled up by CSS. That cuts
    // the fill cost dramatically while staying visually indistinguishable
    // for chunky pixel art.
    const RES = 0.62;
    const resize = () => {
      cv.width = Math.max(320, Math.floor(window.innerWidth * RES));
      cv.height = Math.max(200, Math.floor(window.innerHeight * RES));
    };
    resize();
    window.addEventListener('resize', resize);

    const sprites = getSprites();
    const renderer = new MarioRenderer();

    // Start on a random world so repeat launches look different.
    const offset = Math.floor(Math.random() * SHOWCASE_LEVELS.length);
    const CYCLE = 9;          // seconds per world
    const FADE = 1.4;         // crossfade length

    const TILE = 32;
    const LOGICAL_H = 15 * TILE;     // same vertical scale as the game
    const GROUND_Y = 13 * TILE;      // top of the ground

    // A few props that scroll past, placed in world pixels.
    const coins = Array.from({ length: 10 }, (_, i) => ({
      wx: 300 + i * 260 + (i % 3) * 70,
      wy: 250 + (i % 4) * 34,
    }));
    const foes = Array.from({ length: 4 }, (_, i) => ({
      wx: 520 + i * 620,
    }));
    const blocks = Array.from({ length: 6 }, (_, i) => ({
      wx: 420 + i * 430,
      wy: 9 * TILE,
    }));

    let raf = 0;
    let vignette: CanvasGradient | null = null;
    let vignetteW = 0;
    let vignetteH = 0;
    const t0 = performance.now();

    const frame = (now: number) => {
      // The first rAF timestamp can be marginally earlier than t0, which
      // would make `t` negative — and a negative modulo in JS yields a
      // negative array index. Clamping keeps every frame index valid.
      const t = Math.max(0, (now - t0) / 1000);
      const W = cv.width;
      const H = cv.height;

      // Match the game's vertical scale, then letterbox horizontally.
      const scale = H / LOGICAL_H;
      const viewW = W / scale;
      const camX = t * 46;                   // slow forward drift

      ctx.setTransform(1, 0, 0, 1, 0, 0);
      ctx.clearRect(0, 0, W, H);
      ctx.save();
      ctx.scale(scale, scale);
      ctx.imageSmoothingEnabled = false;

      // ---- real biome backdrop, crossfading between worlds -------------
      const slot = t / CYCLE;
      const iA = (offset + Math.floor(slot)) % SHOWCASE_LEVELS.length;
      const iB = (iA + 1) % SHOWCASE_LEVELS.length;
      const lbA = getLevelBiome(SHOWCASE_LEVELS[iA]);
      const lbB = getLevelBiome(SHOWCASE_LEVELS[iB]);
      const intoCycle = (slot % 1) * CYCLE;
      const blend =
        intoCycle > CYCLE - FADE ? (intoCycle - (CYCLE - FADE)) / FADE : 0;

      renderer.drawShowcaseBackdrop(ctx, lbA, camX, viewW, LOGICAL_H, t);
      if (blend > 0) {
        ctx.save();
        ctx.globalAlpha = blend;
        renderer.drawShowcaseBackdrop(ctx, lbB, camX, viewW, LOGICAL_H, t);
        ctx.restore();
      }

      // The tile set follows whichever world is currently dominant.
      const lb = blend > 0.5 ? lbB : lbA;
      const tiles = getBiomeTiles(lb.biome);

      // ---- ground, drawn with the game's own tiles ---------------------
      const startCol = Math.floor(camX / TILE) - 1;
      const endCol = startCol + Math.ceil(viewW / TILE) + 2;
      for (let c = startCol; c <= endCol; c++) {
        const x = c * TILE - camX;
        ctx.drawImage(tiles.ground, x, GROUND_Y, TILE, TILE);
        ctx.drawImage(tiles.ground, x, GROUND_Y + TILE, TILE, TILE);
      }

      // ---- floating question blocks ------------------------------------
      const qFrame = Math.floor(t * 5.5) % sprites.tiles.qBlocks.length;
      for (const b of blocks) {
        const x = b.wx - camX * 1.0;
        const wrapped = ((x % 2600) + 2600) % 2600 - 200;
        if (wrapped > viewW + 40) continue;
        ctx.drawImage(
          sprites.tiles.qBlocks[qFrame], wrapped, b.wy, TILE, TILE
        );
      }

      // ---- coins, using the real spinning sprite ------------------------
      const coinFrame = Math.floor(t * 8) % sprites.items.coins.length;
      for (let i = 0; i < coins.length; i++) {
        const cn = coins[i];
        const x = cn.wx - camX;
        const wrapped = ((x % 2600) + 2600) % 2600 - 200;
        if (wrapped > viewW + 40) continue;
        const bob = Math.sin(t * 4.5 + i) * 4;
        ctx.drawImage(
          sprites.items.coins[coinFrame],
          wrapped, cn.wy + bob, TILE, TILE
        );
      }

      // ---- Goombas patrolling ------------------------------------------
      for (let i = 0; i < foes.length; i++) {
        const x = foes[i].wx - camX;
        const wrapped = ((x % 2600) + 2600) % 2600 - 200;
        if (wrapped > viewW + 40) continue;
        const walk =
          Math.floor(t * 6 + i) % 2 === 0
            ? sprites.goomba.walk1
            : sprites.goomba.walk2;
        ctx.drawImage(walk, wrapped, GROUND_Y - 28 - 2, TILE, TILE);
      }

      // ---- Mario, the real sprite, hopping along --------------------- --
      const runCycle = (t * 0.2) % 1;
      const hx = runCycle * (viewW + 160) - 80;
      const hop = Math.abs(Math.sin(runCycle * Math.PI * 8)) * 54;
      const airborne = hop > 6;
      const pose = airborne
        ? 'jump'
        : ['run1', 'run2', 'run3'][Math.floor(t * 12) % 3];
      const mario = sprites.getMario('big', pose, 1, 0, 'mario');
      const footY = GROUND_Y - hop;

      // Contact shadow, exactly like the in-game one.
      const shade = Math.max(0, 1 - hop / 90);
      ctx.save();
      ctx.globalAlpha = 0.3 * shade;
      ctx.fillStyle = '#000000';
      ctx.beginPath();
      ctx.ellipse(hx, GROUND_Y + 2, 13 * (0.55 + shade * 0.45), 4.5, 0, 0, Math.PI * 2);
      ctx.fill();
      ctx.restore();

      ctx.drawImage(
        mario, hx - mario.width * 0.5, footY - mario.height + 2
      );

      // Dust puff on landing.
      if (!airborne && Math.random() < 0.3) {
        ctx.globalAlpha = 0.4;
        ctx.fillStyle = '#f5f3eb';
        ctx.fillRect(hx - 14, GROUND_Y - 5, 5, 5);
        ctx.fillRect(hx + 10, GROUND_Y - 7, 4, 4);
        ctx.globalAlpha = 1;
      }

      // ---- weather, matching the shown world ---------------------------
      const wk = lb.weather;
      ctx.save();
      if (wk === 'rain' || wk === 'storm' || wk === 'typhoon') {
        ctx.strokeStyle = 'rgba(180,210,255,0.5)';
        ctx.lineWidth = 1.5;
        ctx.beginPath();
        for (let i = 0; i < 70; i++) {
          const x = (i * 137.5) % (viewW + 120) - 60;
          const y = (i * 53.7 + t * 820) % LOGICAL_H;
          ctx.moveTo(x, y);
          ctx.lineTo(x + 2.5, y + 18);
        }
        ctx.stroke();
      } else if (wk === 'snow' || wk === 'blizzard' || wk === 'hail') {
        ctx.fillStyle = 'rgba(255,255,255,0.9)';
        for (let i = 0; i < 70; i++) {
          const drift = Math.sin(t * 1.2 + i * 0.7) * 16;
          const x = (i * 149.3) % (viewW + 120) - 60 + drift;
          const y = (i * 61.3 + t * 110) % LOGICAL_H;
          ctx.fillRect(x, y, 2 + (i % 3), 2 + (i % 3));
        }
      } else if (wk === 'petals') {
        for (let i = 0; i < 50; i++) {
          const sway = Math.sin(t * 1.6 + i) * 24;
          const x = (i * 139.1) % (viewW + 120) - 60 + sway;
          const y = (i * 71.3 + t * 86) % LOGICAL_H;
          ctx.save();
          ctx.translate(x, y);
          ctx.rotate(t * 2.4 + i);
          ctx.fillStyle = ['#ff8a3d', '#e8562f', '#ffc24d', '#c4452f'][i % 4];
          ctx.beginPath();
          ctx.ellipse(0, 0, 5.5, 3.2, 0, 0, Math.PI * 2);
          ctx.fill();
          ctx.restore();
        }
      } else if (wk === 'embers') {
        for (let i = 0; i < 50; i++) {
          const x = (i * 113) % (viewW + 80) - 40 + Math.sin(t * 2 + i) * 12;
          const y = LOGICAL_H - ((i * 67 + t * 160) % LOGICAL_H);
          ctx.globalAlpha = 0.4 + 0.5 * Math.sin(t * 5 + i);
          ctx.fillStyle = i % 3 === 0 ? '#fff3c4' : '#ff6a1f';
          ctx.fillRect(x, y, 3, 3);
        }
      } else if (wk === 'sandstorm' || wk === 'fog') {
        for (let b2 = 0; b2 < 3; b2++) {
          ctx.globalAlpha = 0.08 + b2 * 0.04;
          ctx.fillStyle = wk === 'fog' ? '#e2e8f0' : '#e8c478';
          const o = (t * (120 + b2 * 90)) % (viewW + 420);
          ctx.beginPath();
          ctx.ellipse(
            viewW + 200 - o, LOGICAL_H * (0.35 + b2 * 0.2),
            viewW * 0.6, 60 + b2 * 22, 0, 0, Math.PI * 2
          );
          ctx.fill();
        }
      }
      ctx.restore();

      ctx.restore();

      // ---- vignette so the dialog stays readable -----------------------
      if (!vignette || vignetteW !== W || vignetteH !== H) {
        vignetteW = W; vignetteH = H;
        vignette = ctx.createRadialGradient(
          W / 2, H / 2, H * 0.26, W / 2, H / 2, H * 0.86
        );
        vignette.addColorStop(0, 'rgba(0,0,0,0)');
        vignette.addColorStop(1, 'rgba(0,0,0,0.58)');
      }
      ctx.fillStyle = vignette;
      ctx.fillRect(0, 0, W, H);

      raf = requestAnimationFrame(frame);
    };
    raf = requestAnimationFrame(frame);

    return () => {
      cancelAnimationFrame(raf);
      window.removeEventListener('resize', resize);
    };
  }, []);

  return (
    <canvas
      ref={ref}
      className="pointer-events-none absolute inset-0 h-full w-full"
      aria-hidden
    />
  );
};

type Tab = 'login' | 'register' | 'restore';

export const AccountGate: React.FC<Props> = ({ onDone, requireChoice }) => {
  const known = listAccounts();
  const [tab, setTab] = useState<Tab>(known.length > 0 ? 'login' : 'register');
  const [user, setUser] = useState(known[0] ?? '');
  const [pw, setPw] = useState('');
  const [pw2, setPw2] = useState('');
  const [code, setCode] = useState('');
  const [err, setErr] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  const submit = async () => {
    setErr(null);
    setBusy(true);
    try {
      if (tab === 'register') {
        if (pw !== pw2) {
          setErr('Passwords do not match.');
          return;
        }
        const r = await registerAccount(user, pw);
        if (r.ok && r.account) onDone(r.account);
        else setErr(r.error ?? 'Could not create that account.');
      } else {
        const r = await loginAccount(user, pw);
        if (r.ok && r.account) onDone(r.account);
        else setErr(r.error ?? 'Could not sign in.');
      }
    } finally {
      setBusy(false);
    }
  };

  const tabBtn = (id: Tab, label: string) => (
    <button
      key={id}
      type="button"
      onClick={() => { setTab(id); setErr(null); }}
      className={`cursor-pointer rounded-lg border-2 py-2 font-pixel text-[12px] transition ${
        tab === id
          ? 'border-amber-300 bg-amber-400/20 text-white'
          : 'border-white/15 bg-slate-900/70 text-slate-300 hover:border-white/35'
      }`}
    >
      {label}
    </button>
  );

  return (
    <div className="fixed inset-0 z-[55] flex items-center justify-center overflow-y-auto px-4 py-8">
      <LoginBackdrop />
      <div className="arcade-card relative z-10 w-full max-w-md rounded-2xl p-5 shadow-[0_20px_60px_rgba(0,0,0,0.6)]">
        <div className="mb-1 flex justify-center gap-1.5">
          {['#ef2b2d', '#fbbf24', '#22c55e', '#38bdf8'].map((c, i) => (
            <span
              key={c}
              className="inline-block h-1.5 w-8 rounded-full"
              style={{
                background: c,
                animation: `pulse 1.6s ease-in-out ${i * 0.18}s infinite`,
              }}
            />
          ))}
        </div>
        <h2 className="text-center font-pixel text-sm text-amber-300 pixel-text-shadow-sm">
          {tab === 'register' ? 'CREATE ACCOUNT' : tab === 'login' ? 'SIGN IN' : 'RESTORE'}
        </h2>
        <p className="mt-2 text-center text-[11px] leading-relaxed text-slate-300">
          An account keeps your coins, levels and records separate — handy when
          several people share one device. It is completely optional.
        </p>

        <div className="mt-3 grid grid-cols-3 gap-2">
          {tabBtn('login', 'SIGN IN')}
          {tabBtn('register', 'REGISTER')}
          {tabBtn('restore', 'SYNC CODE')}
        </div>

        {err && (
          <p className="mt-3 rounded-lg border border-rose-400/50 bg-rose-500/15 px-3 py-2 text-center text-[11px] font-bold text-rose-200">
            {err}
          </p>
        )}

        {tab !== 'restore' ? (
          <>
            <label className="mt-3 block font-pixel text-[12px] text-slate-400">
              USERNAME
            </label>
            <input
              value={user}
              maxLength={14}
              autoComplete="username"
              onChange={(e) => setUser(e.target.value)}
              onKeyDown={(e) => { if (e.key === 'Enter') submit(); }}
              placeholder="PLAYER1"
              className="mt-1 w-full rounded-lg border-2 border-white/25 bg-slate-950 px-3 py-2.5 font-pixel text-[14px] text-white uppercase focus:border-amber-300 focus:outline-none"
            />

            <label className="mt-3 block font-pixel text-[12px] text-slate-400">
              PASSWORD
            </label>
            <input
              type="password"
              value={pw}
              autoComplete={tab === 'register' ? 'new-password' : 'current-password'}
              onChange={(e) => setPw(e.target.value)}
              onKeyDown={(e) => { if (e.key === 'Enter') submit(); }}
              className="mt-1 w-full rounded-lg border-2 border-white/25 bg-slate-950 px-3 py-2.5 font-pixel text-[14px] text-white focus:border-amber-300 focus:outline-none"
            />

            {tab === 'register' && (
              <>
                <label className="mt-3 block font-pixel text-[12px] text-slate-400">
                  CONFIRM PASSWORD
                </label>
                <input
                  type="password"
                  value={pw2}
                  autoComplete="new-password"
                  onChange={(e) => setPw2(e.target.value)}
                  onKeyDown={(e) => { if (e.key === 'Enter') submit(); }}
                  className="mt-1 w-full rounded-lg border-2 border-white/25 bg-slate-950 px-3 py-2.5 font-pixel text-[14px] text-white focus:border-amber-300 focus:outline-none"
                />
              </>
            )}

            {tab === 'login' && known.length > 0 && (
              <div className="mt-2.5 flex flex-wrap gap-1.5">
                {known.map((n) => (
                  <button
                    key={n}
                    type="button"
                    onClick={() => { setUser(n); setErr(null); }}
                    className="cursor-pointer rounded border border-white/20 bg-slate-900/70 px-2 py-1 font-pixel text-[11px] text-slate-300 hover:border-amber-300"
                  >
                    {n}
                  </button>
                ))}
              </div>
            )}

            <button
              type="button"
              disabled={busy || !user.trim() || !pw}
              onClick={submit}
              className="arcade-btn-primary mt-4 w-full cursor-pointer rounded-xl py-3 font-pixel text-[14px] text-white disabled:opacity-40"
            >
              {busy ? '...' : tab === 'register' ? 'CREATE & PLAY' : 'SIGN IN'}
            </button>
          </>
        ) : (
          <>
            <label className="mt-3 block font-pixel text-[12px] text-slate-400">
              PASTE SYNC CODE FROM YOUR OTHER DEVICE
            </label>
            <textarea
              value={code}
              onChange={(e) => setCode(e.target.value)}
              rows={4}
              className="mt-1.5 w-full resize-none rounded-lg border-2 border-white/25 bg-slate-950 p-2 font-mono text-[10px] break-all text-slate-200 focus:border-amber-300 focus:outline-none"
            />
            <button
              type="button"
              onClick={() => {
                if (importSave(code)) window.location.reload();
                else setErr('That code could not be read.');
              }}
              className="arcade-btn-primary mt-3 w-full cursor-pointer rounded-xl py-3 font-pixel text-[14px] text-white"
            >
              RESTORE ACCOUNT
            </button>
            <p className="mt-2 text-center text-[9px] leading-relaxed text-slate-500">
              Get the code from the pause menu on your other device
              (<span className="text-sky-300">EXPORT SAVE</span>).
            </p>
          </>
        )}

        {!requireChoice && (
          <button
            type="button"
            onClick={() => onDone(null)}
            className="mt-3 w-full cursor-pointer rounded-xl border border-white/15 bg-white/5 py-2.5 font-pixel text-[13px] text-slate-300 hover:bg-white/10"
          >
            SKIP — PLAY WITHOUT ACCOUNT
          </button>
        )}

        <p className="mt-3 text-center text-[9px] leading-relaxed text-slate-500">
          Accounts are stored on this device and passwords are hashed.
          To move an account to another phone, use the sync code.
        </p>
      </div>
    </div>
  );
};

export { exportSave };
