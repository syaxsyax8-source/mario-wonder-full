import React, { useCallback, useMemo, useState } from 'react';
import {
  APK_BASE64,
  APK_FILENAME,
  APK_SIZE_BYTES,
  APK_VERSION,
} from '../generated/apkPayload';

/** The APK payload is stripped inside the Android build itself. */
export const APK_AVAILABLE = APK_BASE64.length > 0;

function base64ToBlob(base64: string): Blob {
  const binary = atob(base64);
  const bytes = new Uint8Array(binary.length);
  for (let i = 0; i < binary.length; i++) {
    bytes[i] = binary.charCodeAt(i);
  }
  return new Blob([bytes], {
    type: 'application/vnd.android.package-archive',
  });
}

interface AndroidDownloadProps {
  variant?: 'primary' | 'compact';
}

export const AndroidDownload: React.FC<AndroidDownloadProps> = ({
  variant = 'primary',
}) => {
  const [open, setOpen] = useState(false);
  const [done, setDone] = useState(false);

  const sizeLabel = useMemo(
    () => `${(APK_SIZE_BYTES / 1024).toFixed(0)} KB`,
    []
  );

  const isAndroid = useMemo(
    () =>
      typeof navigator !== 'undefined' &&
      /android/i.test(navigator.userAgent),
    []
  );

  const handleDownload = useCallback(() => {
    try {
      const blob = base64ToBlob(APK_BASE64);
      const url = URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = url;
      link.download = APK_FILENAME;
      link.rel = 'noopener';
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      setTimeout(() => URL.revokeObjectURL(url), 60_000);
      setDone(true);
    } catch {
      setDone(false);
    }
  }, []);

  if (!APK_AVAILABLE) return null;

  return (
    <>
      <button
        type="button"
        onClick={() => setOpen(true)}
        className={
          variant === 'primary'
            ? 'arcade-btn-secondary flex w-full cursor-pointer items-center justify-center gap-2 rounded-xl border-emerald-300/80 bg-gradient-to-b from-emerald-600 to-emerald-800 px-4 py-3 font-pixel text-[13px] text-emerald-50'
            : 'arcade-btn-secondary cursor-pointer rounded-lg px-3 py-2 font-pixel text-[12px] text-emerald-200'
        }
      >
        <span className="text-sm leading-none">🤖</span>
        <span>DOWNLOAD APK</span>
        <span className="rounded bg-emerald-950/60 px-1 py-0.5 text-[8px] text-emerald-200">
          {sizeLabel}
        </span>
      </button>

      {open && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center overflow-y-auto bg-slate-950/80 px-4 py-6 backdrop-blur-sm"
          onClick={() => setOpen(false)}
        >
          <div
            className="arcade-card w-full max-w-md rounded-2xl p-5"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-start justify-between gap-3">
              <div>
                <h3 className="font-pixel text-xs text-emerald-300 sm:text-sm">
                  🤖 PLAY ON ANDROID
                </h3>
                <p className="mt-1 text-[11px] font-semibold text-slate-400">
                  {APK_FILENAME} · v{APK_VERSION} · {sizeLabel}
                </p>
              </div>
              <button
                type="button"
                onClick={() => setOpen(false)}
                className="arcade-btn-secondary cursor-pointer rounded-lg px-2.5 py-1 font-pixel text-[13px] text-white"
              >
                ✕
              </button>
            </div>

            <p className="mt-3 text-[12px] leading-relaxed text-slate-300">
              A real signed Android app (<code className="text-amber-300">.apk</code>)
              that bundles the <strong>entire game offline</strong> — all 3 worlds,
              every NPC difficulty tier, high scores, and the chiptune soundtrack.
              No internet needed after install.
            </p>

            <div className="mt-3 grid grid-cols-3 gap-2 text-center">
              {[
                { k: 'ANDROID', v: '5.0+' },
                { k: 'SIZE', v: sizeLabel },
                { k: 'OFFLINE', v: 'YES' },
              ].map((s) => (
                <div
                  key={s.k}
                  className="rounded-lg border border-white/10 bg-slate-950/60 px-2 py-2"
                >
                  <div className="font-pixel text-[11px] text-slate-400">
                    {s.k}
                  </div>
                  <div className="mt-1 font-pixel text-[13px] text-emerald-300">
                    {s.v}
                  </div>
                </div>
              ))}
            </div>

            <button
              type="button"
              onClick={handleDownload}
              className="arcade-btn-primary mt-4 w-full cursor-pointer rounded-xl py-3 font-pixel text-xs text-white"
            >
              ⬇ DOWNLOAD {APK_FILENAME}
            </button>

            {done && (
              <p className="mt-2 rounded-lg border border-emerald-400/50 bg-emerald-500/15 px-3 py-2 text-center text-[11px] font-bold text-emerald-200">
                ✓ Download started — check your Downloads folder.
              </p>
            )}

            <div className="mt-4 border-t border-white/10 pt-3">
              <p className="font-pixel text-[12px] text-amber-300">
                INSTALL STEPS
              </p>
              <ol className="mt-2 space-y-1.5 text-[11px] leading-snug text-slate-300">
                <li>
                  <span className="text-amber-300">1.</span> Tap the download
                  button above {isAndroid ? '' : '(on your Android phone)'}.
                </li>
                <li>
                  <span className="text-amber-300">2.</span> Open the file from
                  Downloads / the notification.
                </li>
                <li>
                  <span className="text-amber-300">3.</span> Allow{' '}
                  <em>“Install unknown apps”</em> for your browser when Android
                  asks — this app is sideloaded, not from Play Store.
                </li>
                <li>
                  <span className="text-amber-300">4.</span> Tap{' '}
                  <strong>Install</strong>, then launch{' '}
                  <strong>Super Mario Arcade</strong> and play in landscape.
                </li>
              </ol>
              <p className="mt-3 text-[10px] leading-snug text-slate-500">
                Signed with a self-generated debug key, so Play Protect may show
                a “unknown developer” warning — choose “Install anyway”.
              </p>
            </div>
          </div>
        </div>
      )}
    </>
  );
};
