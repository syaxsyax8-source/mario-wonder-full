import React, { useState } from 'react';
import { ENEMY_STATS, EnemyKind, ItemKind } from '../game/types';
import {
  enemyKills, itemFinds, discoveredEnemies, totalEnemyKinds,
  ENEMY_LORE, ITEM_LORE, ITEM_NAMES,
} from '../utils/bestiary';

const ITEMS: ItemKind[] = [
  'mushroom', 'fire_flower', 'star', 'one_up',
  'clock', 'magnet', 'shadow', 'elixir', 'secret_key',
];

const ITEM_ICON: Record<string, string> = {
  mushroom: '🍄', fire_flower: '🔥', star: '⭐', one_up: '🟢',
  clock: '⏱', magnet: '🧲', shadow: '👤', elixir: '🧪', secret_key: '🗝',
};

export const Bestiary: React.FC<{ onClose: () => void }> = ({ onClose }) => {
  const [tab, setTab] = useState<'foes' | 'items'>('foes');
  const kinds = Object.keys(ENEMY_STATS) as EnemyKind[];
  const found = discoveredEnemies();

  return (
    <div className="fixed inset-0 z-40 overflow-y-auto bg-slate-950/90 px-3 py-6 backdrop-blur-sm">
      <div className="mx-auto w-full max-w-2xl">
        <div className="arcade-card rounded-2xl p-4 sm:p-5">
          <div className="flex items-center justify-between border-b border-white/15 pb-3">
            <h2 className="font-pixel text-xs text-amber-300 sm:text-sm">
              📖 BESTIARY {found}/{totalEnemyKinds()}
            </h2>
            <button
              type="button"
              onClick={onClose}
              className="arcade-btn-secondary cursor-pointer rounded-lg px-3 py-1.5 font-pixel text-[13px] text-white"
            >
              BACK
            </button>
          </div>

          <div className="mt-3 grid grid-cols-2 gap-2">
            {(['foes', 'items'] as const).map((t) => (
              <button
                key={t}
                type="button"
                onClick={() => setTab(t)}
                className={`cursor-pointer rounded-lg border-2 py-2 font-pixel text-[13px] ${
                  tab === t
                    ? 'border-amber-300 bg-amber-400/20 text-white'
                    : 'border-white/15 bg-slate-900/70 text-slate-300'
                }`}
              >
                {t === 'foes' ? 'ENEMIES' : 'POWER-UPS'}
              </button>
            ))}
          </div>

          <div className="mt-3 grid gap-2 sm:grid-cols-2">
            {tab === 'foes'
              ? kinds.map((k) => {
                  const st = ENEMY_STATS[k];
                  const n = enemyKills(k);
                  const seen = n > 0;
                  return (
                    <div
                      key={k}
                      className={`rounded-xl border-2 p-2.5 ${
                        seen
                          ? 'border-white/20 bg-slate-900/70'
                          : 'border-white/10 bg-slate-950/60'
                      }`}
                    >
                      <div className="flex items-center gap-2">
                        <span
                          className="inline-block h-5 w-5 shrink-0 rounded"
                          style={{
                            background: seen ? st.tint : '#334155',
                            opacity: seen ? 1 : 0.4,
                          }}
                        />
                        <span className="min-w-0 flex-1">
                          <span className="block font-pixel text-[13px] text-white">
                            {seen ? st.name : '???'}
                          </span>
                          <span className="block text-[9px] text-slate-400">
                            {seen ? `HP ${st.hp} · defeated ${n}` : 'Not yet encountered'}
                          </span>
                        </span>
                      </div>
                      {seen && (
                        <p className="mt-1.5 text-[10px] leading-snug text-slate-300 italic">
                          “{ENEMY_LORE[k] ?? st.blurb}”
                        </p>
                      )}
                    </div>
                  );
                })
              : ITEMS.map((k) => {
                  const n = itemFinds(k);
                  const seen = n > 0;
                  return (
                    <div
                      key={k}
                      className={`rounded-xl border-2 p-2.5 ${
                        seen
                          ? 'border-white/20 bg-slate-900/70'
                          : 'border-white/10 bg-slate-950/60'
                      }`}
                    >
                      <div className="flex items-center gap-2">
                        <span className={`text-base ${seen ? '' : 'grayscale opacity-40'}`}>
                          {ITEM_ICON[k]}
                        </span>
                        <span className="min-w-0 flex-1">
                          <span className="block font-pixel text-[13px] text-white">
                            {seen ? ITEM_NAMES[k] : '???'}
                          </span>
                          <span className="block text-[9px] text-slate-400">
                            {seen ? `found ${n}×` : 'Not yet found'}
                          </span>
                        </span>
                      </div>
                      {seen && (
                        <p className="mt-1.5 text-[10px] leading-snug text-slate-300 italic">
                          “{ITEM_LORE[k]}”
                        </p>
                      )}
                    </div>
                  );
                })}
          </div>
        </div>
      </div>
    </div>
  );
};
