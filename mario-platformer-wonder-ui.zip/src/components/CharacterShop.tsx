import React from 'react';
import {
  CharacterId,
  CHARACTER_ORDER,
  CHARACTERS,
  PetId,
  PETS,
} from '../game/types';

interface CharacterShopProps {
  coins: number;
  owned: CharacterId[];
  selected: CharacterId;
  onBuy: (id: CharacterId) => void;
  onSelect: (id: CharacterId) => void;
  /** Start a free trial run with a character that is not owned. */
  onTryDemo: (id: CharacterId) => void;
  onClose: () => void;
  notice: string | null;
  /** Companion pets available in the shop. */
  pets: PetId[];
  ownedPets: string[];
  activePet: PetId;
  onBuyPet: (id: PetId) => void;
}

/** Tiny canvas-free portrait built from the character's palette. */
const Portrait: React.FC<{ id: CharacterId }> = ({ id }) => {
  const p = CHARACTERS[id].palette;
  return (
    <div
      className="relative h-11 w-9 shrink-0"
      aria-hidden
      style={{ imageRendering: 'pixelated' }}
    >
      {/* cap */}
      <div
        className="absolute top-0 left-1 h-2 w-7 rounded-t-sm"
        style={{ background: p.R }}
      />
      {/* face */}
      <div
        className="absolute top-2 left-1 h-3 w-7"
        style={{ background: p.S }}
      />
      {/* eyes */}
      <div className="absolute top-[11px] left-[10px] h-1 w-1 bg-slate-900" />
      <div className="absolute top-[11px] left-[20px] h-1 w-1 bg-slate-900" />
      {/* moustache / mouth */}
      <div
        className="absolute top-[16px] left-2 h-1 w-5"
        style={{ background: p.H }}
      />
      {/* body */}
      <div
        className="absolute top-[21px] left-1 h-4 w-7"
        style={{ background: p.R }}
      />
      {/* overalls */}
      <div
        className="absolute top-[25px] left-2 h-4 w-5"
        style={{ background: p.B }}
      />
      {/* boots */}
      <div
        className="absolute bottom-0 left-1 h-1.5 w-2.5"
        style={{ background: p.N }}
      />
      <div
        className="absolute right-1 bottom-0 h-1.5 w-2.5"
        style={{ background: p.N }}
      />
    </div>
  );
};

const Stat: React.FC<{ label: string; value: number }> = ({ label, value }) => {
  // 1.0 is the Mario baseline; render as a 5-pip bar.
  const pips = Math.max(1, Math.min(5, Math.round(value * 3)));
  return (
    <div className="flex items-center gap-1">
      <span className="w-8 text-[8px] font-bold text-slate-400">{label}</span>
      <span className="flex gap-0.5">
        {Array.from({ length: 5 }).map((_, i) => (
          <span
            key={i}
            className={`inline-block h-1.5 w-2 rounded-sm ${
              i < pips ? 'bg-amber-300' : 'bg-white/15'
            }`}
          />
        ))}
      </span>
    </div>
  );
};

export const CharacterShop: React.FC<CharacterShopProps> = ({
  coins,
  owned,
  selected,
  onBuy,
  onSelect,
  onTryDemo,
  onClose,
  notice,
  pets,
  ownedPets,
  activePet,
  onBuyPet,
}) => {
  return (
    <div className="fixed inset-0 z-40 overflow-y-auto bg-slate-950/85 px-3 py-6 backdrop-blur-sm">
      <div className="mx-auto flex min-h-full w-full max-w-2xl flex-col">
        <div className="arcade-card rounded-2xl p-4 sm:p-5">
          <div className="flex items-start justify-between gap-3 border-b border-white/15 pb-3">
            <div>
              <h2 className="font-pixel text-xs text-amber-300 sm:text-sm">
                CHARACTER SHOP
              </h2>
              <p className="mt-1 text-[11px] font-semibold text-slate-400">
                Spend coins collected across every run.
              </p>
            </div>
            <div className="flex shrink-0 items-center gap-2">
              <span className="flex items-center gap-1.5 rounded-lg border border-amber-300/60 bg-amber-400/15 px-2.5 py-1.5">
                <span className="inline-block h-3 w-2.5 rounded-full border border-amber-900 bg-amber-300" />
                <span className="font-pixel text-[14px] text-amber-200">
                  {coins.toLocaleString()}
                </span>
              </span>
              <button
                type="button"
                onClick={onClose}
                className="arcade-btn-secondary cursor-pointer rounded-lg px-3 py-1.5 font-pixel text-[13px] text-white"
              >
                BACK
              </button>
            </div>
          </div>

          {notice && (
            <p className="mt-3 rounded-lg border border-rose-400/50 bg-rose-500/15 px-3 py-2 text-center text-[11px] font-bold text-rose-200">
              {notice}
            </p>
          )}

          <div className="mt-3 grid grid-cols-1 gap-2 sm:grid-cols-2">
            {CHARACTER_ORDER.map((id) => {
              const def = CHARACTERS[id];
              const isOwned = owned.includes(id);
              const isActive = selected === id;
              const canAfford = coins >= def.cost;

              return (
                <div
                  key={id}
                  className={`flex items-start gap-3 rounded-xl border-2 p-2.5 transition ${
                    isActive
                      ? 'border-amber-300 bg-amber-400/15 shadow-[0_0_14px_rgba(251,191,36,0.25)]'
                      : isOwned
                        ? 'border-emerald-400/60 bg-slate-900/70'
                        : 'border-white/15 bg-slate-950/60'
                  }`}
                >
                  <Portrait id={id} />

                  <div className="min-w-0 flex-1">
                    <div className="flex items-center justify-between gap-2">
                      <span className="font-pixel text-[14px] text-white">
                        {def.name}
                      </span>
                      {isActive ? (
                        <span className="rounded bg-amber-300 px-1.5 py-0.5 font-pixel text-[10px] text-slate-950">
                          ACTIVE
                        </span>
                      ) : isOwned ? (
                        <span className="rounded bg-emerald-500/80 px-1.5 py-0.5 font-pixel text-[10px] text-white">
                          OWNED
                        </span>
                      ) : (
                        <span className="flex items-center gap-1 font-pixel text-[12px] text-amber-300">
                          <span className="inline-block h-2.5 w-2 rounded-full bg-amber-300" />
                          {def.cost.toLocaleString()}
                        </span>
                      )}
                    </div>

                    <p className="mt-1 text-[10px] leading-snug text-slate-300">
                      {def.blurb}
                    </p>

                    <div className="mt-1.5 grid grid-cols-2 gap-x-2 gap-y-0.5">
                      <Stat label="SPD" value={def.speed} />
                      <Stat label="JMP" value={def.jump} />
                      <Stat label="GRIP" value={def.grip} />
                      <Stat label="FIRE" value={2 - def.fireRate} />
                    </div>

                    <div className="mt-2 flex items-center gap-2">
                      <span
                        className="rounded px-1.5 py-0.5 text-[8px] font-bold"
                        style={{
                          color: def.palette.R,
                          background: `${def.palette.R}22`,
                        }}
                      >
                        {def.perk}
                      </span>
                      {isOwned ? (
                        <button
                          type="button"
                          disabled={isActive}
                          onClick={() => onSelect(id)}
                          className={`ml-auto cursor-pointer rounded-lg px-3 py-1.5 font-pixel text-[12px] ${
                            isActive
                              ? 'cursor-default border border-white/15 text-slate-500'
                              : 'arcade-btn-secondary text-emerald-200'
                          }`}
                        >
                          {isActive ? 'SELECTED' : 'SELECT'}
                        </button>
                      ) : (
                        <span className="ml-auto flex items-center gap-1.5">
                          <button
                            type="button"
                            onClick={() => onTryDemo(id)}
                            title="Play a free trial run — coins are not banked"
                            className="arcade-btn-secondary cursor-pointer rounded-lg px-2.5 py-1.5 font-pixel text-[12px] text-sky-200"
                          >
                            TRY FREE
                          </button>
                          <button
                            type="button"
                            disabled={!canAfford}
                            onClick={() => onBuy(id)}
                            className={`rounded-lg px-3 py-1.5 font-pixel text-[12px] ${
                              canAfford
                                ? 'arcade-btn-primary cursor-pointer text-white'
                                : 'cursor-not-allowed border border-white/15 text-slate-500'
                            }`}
                          >
                            {canAfford ? 'BUY' : 'LOCKED'}
                          </button>
                        </span>
                      )}
                    </div>
                  </div>
                </div>
              );
            })}
          </div>

          {/* ---- Companion pets ---- */}
          <div className="mt-4 border-t border-white/15 pt-3">
            <p className="mb-2 font-pixel text-[12px] tracking-widest text-sky-200">
              COMPANION PET
            </p>
            <div className="grid grid-cols-2 gap-2 sm:grid-cols-4">
              {pets.map((id) => {
                const d = PETS[id];
                const owned = ownedPets.includes(id) || d.cost === 0;
                const active = activePet === id;
                return (
                  <button
                    key={id}
                    type="button"
                    onClick={() => onBuyPet(id)}
                    className={`cursor-pointer rounded-xl border-2 p-2 text-center transition ${
                      active
                        ? 'border-amber-300 bg-amber-400/20'
                        : owned
                          ? 'border-emerald-400/60 bg-slate-900/70'
                          : 'border-white/15 bg-slate-950/60'
                    }`}
                  >
                    <span className="block text-lg">{d.icon}</span>
                    <span className="mt-0.5 block font-pixel text-[12px] text-white">
                      {d.name}
                    </span>
                    <span className="mt-1 block text-[9px] leading-snug text-slate-400">
                      {d.blurb}
                    </span>
                    <span
                      className="mt-1 block font-pixel text-[11px]"
                      style={{ color: active ? '#fbbf24' : d.color }}
                    >
                      {active ? 'ACTIVE' : owned ? 'SELECT' : `${d.cost} ¢`}
                    </span>
                  </button>
                );
              })}
            </div>
          </div>

          <p className="mt-3 text-center text-[10px] leading-relaxed text-slate-500">
            Coins you pick up are banked permanently and saved automatically.
            <br />
            <span className="text-sky-300/80">TRY FREE</span> lets you test any
            character — but coins from a trial run are not banked.
          </p>
        </div>
      </div>
    </div>
  );
};
