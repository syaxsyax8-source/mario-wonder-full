import React, { useEffect, useRef, useState } from 'react';

interface IntroSplashProps {
  onDone: () => void;
}

/**
 * Boot animation shown once per app launch.
 *
 * Runs on its own canvas so it can do things the game HUD cannot: a starfield
 * warp, bricks flying in to build the logo, a sprinting hero, and a coin
 * shower. Tapping or pressing any key skips straight to the title.
 */
export const IntroSplash: React.FC<IntroSplashProps> = ({ onDone }) => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const doneRef = useRef(false);
  const [phase, setPhase] = useState(0);

  const finish = () => {
    if (doneRef.current) return;
    doneRef.current = true;
    onDone();
  };

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const dpr = Math.min(window.devicePixelRatio || 1, 2);
    const resize = () => {
      canvas.width = Math.floor(window.innerWidth * dpr);
      canvas.height = Math.floor(window.innerHeight * dpr);
    };
    resize();
    window.addEventListener('resize', resize);

    // --- scene data -------------------------------------------------------
    const stars = Array.from({ length: 150 }, () => ({
      x: Math.random(),
      y: Math.random(),
      z: Math.random() * 0.9 + 0.1,
    }));

    // Bricks that fly in and settle into a solid bar behind the logo.
    const bricks = Array.from({ length: 22 }, (_, i) => {
      const angle = (i / 22) * Math.PI * 2;
      return {
        i,
        fromX: Math.cos(angle) * 1.4,
        fromY: Math.sin(angle) * 1.4,
        rot: (Math.random() - 0.5) * 7,
      };
    });

    const coins: Array<{
      x: number; y: number; vx: number; vy: number; r: number; spin: number;
    }> = [];

    const start = performance.now();
    const TOTAL = 4200;
    let raf = 0;

    const ease = (t: number) => 1 - Math.pow(1 - t, 3);
    const clamp01 = (v: number) => Math.max(0, Math.min(1, v));

    const frame = (now: number) => {
      const t = now - start;
      const W = canvas.width;
      const H = canvas.height;
      const S = Math.min(W, H) / 720; // uniform scale factor

      ctx.clearRect(0, 0, W, H);

      // ---- backdrop: deep space gradient ----
      const bg = ctx.createLinearGradient(0, 0, 0, H);
      bg.addColorStop(0, '#05030f');
      bg.addColorStop(0.55, '#0d0a28');
      bg.addColorStop(1, '#1a0f3d');
      ctx.fillStyle = bg;
      ctx.fillRect(0, 0, W, H);

      // ---- phase 1: starfield warp (0 - 1200ms) ----
      const warp = clamp01(t / 1400);
      for (const s of stars) {
        const speed = 0.6 + s.z * 2.4;
        const sx = ((s.x + (t / 1000) * speed * 0.35) % 1) * W;
        const sy = s.y * H;
        const len = 2 + warp * s.z * 46 * S;
        ctx.globalAlpha = 0.25 + s.z * 0.65;
        ctx.strokeStyle = s.z > 0.75 ? '#bdd6ff' : '#7f93c4';
        ctx.lineWidth = Math.max(1, s.z * 2.4 * S);
        ctx.beginPath();
        ctx.moveTo(W - sx, sy);
        ctx.lineTo(W - sx + len, sy);
        ctx.stroke();
      }
      ctx.globalAlpha = 1;

      const cx = W / 2;
      const cy = H / 2;

      // ---- phase 2: bricks assemble (600 - 1800ms) ----
      const bp = clamp01((t - 500) / 1200);
      const be = ease(bp);
      const barW = 320 * S;
      const barH = 52 * S;
      const bw = barW / 11;
      // The bar sits well below the wordmark and doubles as the runway.
      const barTop = cy + 52 * S;

      for (const b of bricks) {
        const col = b.i % 11;
        const row = Math.floor(b.i / 11);
        const tx = cx - barW / 2 + col * bw + bw / 2;
        const ty = barTop + (row === 0 ? 0 : barH / 2);
        const sx = cx + b.fromX * W;
        const sy = cy + b.fromY * H;
        const x = sx + (tx - sx) * be;
        const y = sy + (ty - sy) * be;

        ctx.save();
        ctx.translate(x, y);
        ctx.rotate(b.rot * (1 - be));
        const g = ctx.createLinearGradient(0, -barH / 4, 0, barH / 4);
        g.addColorStop(0, '#ff9b61');
        g.addColorStop(0.35, '#cf571b');
        g.addColorStop(1, '#5c2409');
        ctx.fillStyle = g;
        ctx.fillRect(-bw / 2 + 1, -barH / 4 + 1, bw - 2, barH / 2 - 2);
        ctx.fillStyle = 'rgba(255,255,255,0.3)';
        ctx.fillRect(-bw / 2 + 2, -barH / 4 + 2, bw - 4, 2 * S);
        ctx.restore();
      }

      // Impact flash when the bricks lock into place.
      if (bp > 0.93 && bp < 1) {
        ctx.save();
        ctx.globalCompositeOperation = 'lighter';
        ctx.globalAlpha = (1 - (bp - 0.93) / 0.07) * 0.5;
        ctx.fillStyle = '#ffd166';
        ctx.fillRect(0, 0, W, H);
        ctx.restore();
      }

      // ---- phase 3: title drops in (1500ms+) ----
      const tp = clamp01((t - 1500) / 900);
      if (tp > 0) {
        const te = ease(tp);
        // Overshoot bounce on landing.
        const bounce = tp < 1 ? 0 : Math.sin((t - 2400) / 90) * 2 * S * 0.0;
        const ty = cy - 78 * S - (1 - te) * 220 * S + bounce;

        ctx.save();
        ctx.textAlign = 'center';
        ctx.textBaseline = 'middle';
        ctx.globalAlpha = te;

        ctx.font = `bold ${Math.round(42 * S)}px "Press Start 2P", monospace`;
        // Layered shadow for a chunky arcade look.
        ctx.fillStyle = '#3b0903';
        ctx.fillText('SUPER MARIO', cx + 4 * S, ty + 5 * S);
        const tg = ctx.createLinearGradient(0, ty - 30 * S, 0, ty + 30 * S);
        tg.addColorStop(0, '#fff5cc');
        tg.addColorStop(0.5, '#ffd166');
        tg.addColorStop(1, '#e0821c');
        ctx.fillStyle = tg;
        ctx.fillText('SUPER MARIO', cx, ty);

        ctx.font = `bold ${Math.round(20 * S)}px "Press Start 2P", monospace`;
        ctx.fillStyle = '#3b0903';
        ctx.fillText('BROS.', cx + 3 * S, ty + 46 * S);
        ctx.fillStyle = '#ffe9a8';
        ctx.fillText('BROS.', cx, ty + 43 * S);
        ctx.restore();
      }

      // ---- phase 4: hero sprints across, coins burst (2000ms+) ----
      const rp = clamp01((t - 1900) / 1800);
      if (rp > 0 && rp < 1.05) {
        const groundY = cy + 46 * S;
        const hx = -60 * S + rp * (W + 120 * S);
        // Hop arc, three bounds across the screen.
        const hop = Math.abs(Math.sin(rp * Math.PI * 3)) * 48 * S;
        const hy = groundY - hop;

        // Spawn a coin at the top of each hop.
        if (hop > 44 * S && coins.length < 40 && Math.random() < 0.4) {
          coins.push({
            x: hx, y: hy - 20 * S,
            vx: (Math.random() - 0.3) * 2.4 * S,
            vy: -(3 + Math.random() * 2.5) * S,
            r: 9 * S, spin: Math.random() * 6,
          });
        }

        // Dust puff on landing.
        if (hop < 6 * S) {
          ctx.globalAlpha = 0.35;
          ctx.fillStyle = '#9fb4d6';
          ctx.beginPath();
          ctx.ellipse(hx - 14 * S, groundY + 6 * S, 16 * S, 5 * S, 0, 0, Math.PI * 2);
          ctx.fill();
          ctx.globalAlpha = 1;
        }

        // Simple chunky hero silhouette (cap, face, body, legs).
        ctx.save();
        ctx.translate(hx, hy);
        const u = 8.5 * S;
        ctx.fillStyle = '#ef2b2d';
        ctx.fillRect(-2.5 * u, -5 * u, 5 * u, 1.4 * u); // cap
        ctx.fillStyle = '#ffcc99';
        ctx.fillRect(-2 * u, -3.6 * u, 4 * u, 1.8 * u); // face
        ctx.fillStyle = '#5c2c16';
        ctx.fillRect(-1.6 * u, -2.3 * u, 3.2 * u, 0.6 * u); // moustache
        ctx.fillStyle = '#ef2b2d';
        ctx.fillRect(-2.2 * u, -1.7 * u, 4.4 * u, 1.6 * u); // shirt
        ctx.fillStyle = '#2357e6';
        ctx.fillRect(-1.9 * u, -0.5 * u, 3.8 * u, 2.2 * u); // overalls
        ctx.fillStyle = '#5c2c16';
        const legSwing = Math.sin(rp * Math.PI * 18) * 0.8 * u;
        ctx.fillRect(-1.8 * u + legSwing, 1.7 * u, 1.5 * u, 0.9 * u);
        ctx.fillRect(0.4 * u - legSwing, 1.7 * u, 1.5 * u, 0.9 * u);
        ctx.restore();

        // Speed streaks behind the runner.
        ctx.globalAlpha = 0.35;
        ctx.strokeStyle = '#9fd6ff';
        ctx.lineWidth = 2 * S;
        for (let i = 0; i < 4; i++) {
          const ly = hy - 10 * S + i * 9 * S;
          ctx.beginPath();
          ctx.moveTo(hx - (28 + i * 14) * S, ly);
          ctx.lineTo(hx - (12 + i * 10) * S, ly);
          ctx.stroke();
        }
        ctx.globalAlpha = 1;
      }

      // ---- coins ----
      for (const c of coins) {
        c.vy += 0.14 * S;
        c.x += c.vx;
        c.y += c.vy;
        c.spin += 0.28;
        const sq = Math.abs(Math.cos(c.spin));
        ctx.save();
        ctx.translate(c.x, c.y);
        ctx.scale(Math.max(0.15, sq), 1);
        ctx.fillStyle = '#ffd93d';
        ctx.beginPath();
        ctx.arc(0, 0, c.r, 0, Math.PI * 2);
        ctx.fill();
        ctx.fillStyle = '#b8860b';
        ctx.beginPath();
        ctx.arc(0, 0, c.r * 0.62, 0, Math.PI * 2);
        ctx.fill();
        ctx.restore();
      }

      // ---- phase 5: fade to the title ----
      const fade = clamp01((t - (TOTAL - 650)) / 650);
      if (fade > 0) {
        ctx.fillStyle = `rgba(11,14,26,${fade})`;
        ctx.fillRect(0, 0, W, H);
      }

      setPhase(t < 1500 ? 0 : t < 2400 ? 1 : 2);

      if (t >= TOTAL) {
        finish();
        return;
      }
      raf = requestAnimationFrame(frame);
    };

    raf = requestAnimationFrame(frame);

    const skip = () => finish();
    window.addEventListener('keydown', skip);
    window.addEventListener('pointerdown', skip);

    return () => {
      cancelAnimationFrame(raf);
      window.removeEventListener('resize', resize);
      window.removeEventListener('keydown', skip);
      window.removeEventListener('pointerdown', skip);
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  return (
    <div className="fixed inset-0 z-[60] bg-[#05030f]">
      <canvas ref={canvasRef} className="block h-full w-full" />

      <div className="pointer-events-none absolute inset-x-0 bottom-8 flex flex-col items-center gap-2">
        <p
          className="font-pixel text-[12px] tracking-[0.3em] text-amber-200/90 transition-opacity duration-500"
          style={{ opacity: phase >= 2 ? 1 : 0 }}
        >
          ARCADE DELUXE
        </p>
        <p className="animate-pulse font-pixel text-[11px] text-slate-400">
          TAP TO SKIP
        </p>
      </div>
    </div>
  );
};
