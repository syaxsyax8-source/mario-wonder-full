import React, { useMemo, useState } from 'react';
import {
  getLevelTier,
  LEVEL_TIERS,
  TOTAL_LEVELS,
} from '../game/types';
import { getLevelBiome } from '../game/biomes';

const PAGE_SIZE = 48;

interface LevelSelectProps {
  selected: number;
  unlocked: number;
  cleared: Set<number>;
  onSelect: (level: number) => void;
  onPlay: (level: number) => void;
  onClose: () => void;
}

export const LevelSelect: React.FC<LevelSelectProps> = ({
  selected,
  unlocked,
  cleared,
  onSelect,
  onPlay,
  onClose,
}) => {
  const [page, setPage] = useState(() =>
    Math.floor((selected - 1) / PAGE_SIZE)
  );
  const [jump, setJump] = useState('');

  const totalPages = Math.ceil(TOTAL_LEVELS / PAGE_SIZE);
  const start = page * PAGE_SIZE + 1;

  const levels = useMemo(() => {
    const list: number[] = [];
    for (let i = 0; i < PAGE_SIZE && start + i <= TOTAL_LEVELS; i++) {
      list.push(start + i);
    }
    return list;
  }, [start]);

  const clearedOnPage = levels.filter((lv) => cleared.has(lv)).length;

  const goToLevel = (lv: number) => {
    const clamped = Math.max(1, Math.min(TOTAL_LEVELS, lv));
    setPage(Math.floor((clamped - 1) / PAGE_SIZE));
    onSelect(Math.min(clamped, unlocked));
  };

  const handleJump = () => {
    const n = parseInt(jump, 10);
    if (Number.isFinite(n)) goToLevel(n);
    setJump('');
  };

  return (
    <div className="bg-wonder-map fixed inset-0 z-40 overflow-y-auto px-3 py-6">
      <div className="mx-auto flex min-h-full w-full max-w-2xl flex-col">
        <div className="arcade-card rounded-2xl p-4 sm:p-5">
          {/* Header */}
          <div className="flex items-start justify-between gap-3 border-b border-white/15 pb-3">
            <div>
              <h2 className="font-pixel text-base text-[#ffe16a] sm:text-xl">
                PETA DUNIA
              </h2>
              <p className="mt-1 text-[11px] font-semibold text-slate-400">
                {TOTAL_LEVELS.toLocaleString()} levels · 12 rotating biomes ·
                unlocked up to{' '}
                <span className="text-emerald-300">{unlocked}</span>
              </p>
            </div>
            <button
              type="button"
              onClick={onClose}
              className="arcade-btn-secondary shrink-0 cursor-pointer rounded-lg px-3 py-1.5 font-pixel text-[13px] text-white"
            >
              BACK
            </button>
          </div>

          {/* Jump + quick tier shortcuts */}
          <div className="mt-3 flex flex-wrap items-center gap-2">
            <div className="flex items-center gap-1.5">
              <input
                type="number"
                inputMode="numeric"
                min={1}
                max={TOTAL_LEVELS}
                value={jump}
                placeholder="Lv #"
                onChange={(e) => setJump(e.target.value)}
                onKeyDown={(e) => {
                  if (e.key === 'Enter') {
                    e.preventDefault();
                    handleJump();
                  }
                }}
                className="w-20 rounded-lg border-2 border-white/25 bg-slate-950 px-2 py-1.5 text-center font-pixel text-[13px] text-white focus:border-amber-300 focus:outline-none"
              />
              <button
                type="button"
                onClick={handleJump}
                className="arcade-btn-secondary cursor-pointer rounded-lg px-2.5 py-2 font-pixel text-[12px] text-amber-200"
              >
                GO
              </button>
            </div>
            <div className="flex flex-wrap gap-1">
              {LEVEL_TIERS.map((t) => (
                <button
                  key={t.name}
                  type="button"
                  onClick={() => goToLevel(t.minLevel)}
                  title={`Tier ${t.name} starts at level ${t.minLevel}`}
                  className="cursor-pointer rounded border px-1.5 py-1 text-[9px] font-bold transition hover:brightness-125"
                  style={{
                    borderColor: `${t.color}66`,
                    color: t.color,
                    background: `${t.color}14`,
                  }}
                >
                  {t.name}
                </button>
              ))}
            </div>
          </div>

          {/* Level grid */}
          <div className="mt-3 grid grid-cols-6 gap-1.5 sm:grid-cols-8">
            {levels.map((lv) => {
              const locked = lv > unlocked;
              const meta = getLevelBiome(lv);
              const isSelected = lv === selected;
              const isCleared = cleared.has(lv);
              return (
                <button
                  key={lv}
                  type="button"
                  disabled={locked}
                  onClick={() => onSelect(lv)}
                  onDoubleClick={() => !locked && onPlay(lv)}
                  title={`Level ${lv} — ${meta.name}${locked ? ' (locked)' : ''}`}
                  className={`relative aspect-square rounded-md border-2 text-center transition ${
                    locked
                      ? 'cursor-not-allowed border-white/10 bg-slate-900/60 opacity-45'
                      : isSelected
                        ? 'cursor-pointer border-amber-300 bg-amber-400/25 shadow-[0_0_12px_rgba(251,191,36,0.4)]'
                        : 'cursor-pointer border-white/15 bg-slate-900/70 hover:border-white/45'
                  }`}
                  style={
                    !locked && !isSelected
                      ? { borderColor: `${meta.accent}55` }
                      : undefined
                  }
                >
                  <span className="absolute inset-x-0 top-0.5 text-[11px] leading-none">
                    {locked ? '🔒' : meta.icon}
                  </span>
                  <span
                    className={`absolute inset-x-0 bottom-0.5 font-pixel text-[10px] ${
                      isSelected ? 'text-white' : 'text-slate-300'
                    }`}
                  >
                    {lv}
                  </span>
                  {isCleared && !locked && (
                    <span className="absolute -top-1 -right-1 text-[9px]">
                      ⭐
                    </span>
                  )}
                </button>
              );
            })}
          </div>

          {/* Pager */}
          <div className="mt-3 flex items-center justify-between gap-2">
            <button
              type="button"
              disabled={page === 0}
              onClick={() => setPage((p) => Math.max(0, p - 1))}
              className="arcade-btn-secondary cursor-pointer rounded-lg px-3 py-2 font-pixel text-[12px] text-white disabled:opacity-40"
            >
              ◀ PREV
            </button>
            <span className="font-pixel text-[12px] text-slate-400">
              {start}–{Math.min(start + PAGE_SIZE - 1, TOTAL_LEVELS)} / {TOTAL_LEVELS}
            </span>
            <button
              type="button"
              disabled={page >= totalPages - 1}
              onClick={() => setPage((p) => Math.min(totalPages - 1, p + 1))}
              className="arcade-btn-secondary cursor-pointer rounded-lg px-3 py-2 font-pixel text-[12px] text-white disabled:opacity-40"
            >
              NEXT ▶
            </button>
          </div>

          {/* Progres halaman ini */}
          <div className="mt-3 flex items-center gap-3">
            <span className="font-pixel text-[12px] text-[#c8f6e6]">PROGRES</span>
            <div className="h-[18px] flex-1 overflow-hidden rounded-full bg-[#53607b]">
              <div
                className="h-full rounded-full bg-[#f4c246]"
                style={{ width: `${(clearedOnPage / Math.max(1, levels.length)) * 100}%` }}
              />
            </div>
            <span className="font-pixel text-[12px] text-white">
              {clearedOnPage} / {levels.length} LEVEL
            </span>
          </div>

          {/* Selected level summary */}
          <div className="mt-3 flex items-center justify-between gap-3 rounded-xl border-2 border-[#fff2c6]/40 bg-[#10264a]/70 px-3 py-2.5">
            <div className="min-w-0">
              <p className="font-pixel text-[13px] text-amber-300">
                LV {selected} · {getLevelBiome(selected).icon}{' '}
                {getLevelBiome(selected).name}
              </p>
              <p className="mt-1 text-[10px] font-bold">
                <span style={{ color: getLevelTier(selected).color }}>
                  NPC TIER: {getLevelTier(selected).name}
                </span>
              </p>
            </div>
            <button
              type="button"
              onClick={() => onPlay(selected)}
              className="arcade-btn-primary shrink-0 cursor-pointer rounded-xl px-4 py-2.5 font-pixel text-[13px] text-white"
            >
              LANJUTKAN
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
