import React, { useRef, useState } from 'react';
import { WeaponKind, WEAPONS } from '../game/types';

export interface TouchControlCallbacks {
  onMoveChange: (left: boolean, right: boolean, down: boolean) => void;
  onJumpChange: (held: boolean, justPressed: boolean) => void;
  onRunFireChange: (held: boolean, justPressed: boolean) => void;
  onSwitchWeapon: () => void;
  onDash: () => void;
  onGrapple: () => void;
}

interface TouchControlsProps {
  callbacks: TouchControlCallbacks;
  isFireMario: boolean;
  weapon: WeaponKind | null;
  weaponAmmo: number;
  ownedCount: number;
  /** Height in px reserved at the bottom of the screen for these controls. */
  padHeight: number;
}

/**
 * Edge-anchored touch pad.
 *
 * The buttons live inside a reserved strip at the very bottom of the screen
 * (see `padHeight`), which the renderer letterboxes around. That guarantees
 * the controls can never cover Mario or the ground he is standing on.
 */
export const TouchControls: React.FC<TouchControlsProps> = ({
  callbacks,
  isFireMario,
  weapon,
  weaponAmmo,
  ownedCount,
  padHeight,
}) => {
  const dpadRef = useRef<HTMLDivElement | null>(null);
  const activeDpadPointer = useRef<number | null>(null);

  const [dirState, setDirState] = useState({
    left: false,
    right: false,
    down: false,
  });
  const [jumpActive, setJumpActive] = useState(false);
  const [runActive, setRunActive] = useState(false);

  const vibrate = (ms = 10) => {
    try {
      if (navigator.vibrate) navigator.vibrate(ms);
    } catch {
      // Unsupported browsers simply skip haptics.
    }
  };

  const evaluateDpad = (clientX: number, clientY: number) => {
    const el = dpadRef.current;
    if (!el) return;
    const rect = el.getBoundingClientRect();
    const relX = (clientX - rect.left) / rect.width;
    const relY = (clientY - rect.top) / rect.height;

    const left = relX < 0.42;
    const right = relX > 0.58;
    const down = relY > 0.62;

    setDirState((prev) => {
      if (prev.left !== left || prev.right !== right || prev.down !== down) {
        vibrate(8);
      }
      return { left, right, down };
    });
    callbacks.onMoveChange(left, right, down);
  };

  const handleDpadDown = (e: React.PointerEvent<HTMLDivElement>) => {
    e.preventDefault();
    e.currentTarget.setPointerCapture(e.pointerId);
    activeDpadPointer.current = e.pointerId;
    evaluateDpad(e.clientX, e.clientY);
  };

  const handleDpadMove = (e: React.PointerEvent<HTMLDivElement>) => {
    if (activeDpadPointer.current !== e.pointerId) return;
    e.preventDefault();
    evaluateDpad(e.clientX, e.clientY);
  };

  const handleDpadUp = (e: React.PointerEvent<HTMLDivElement>) => {
    if (activeDpadPointer.current !== e.pointerId) return;
    e.preventDefault();
    activeDpadPointer.current = null;
    setDirState({ left: false, right: false, down: false });
    callbacks.onMoveChange(false, false, false);
  };

  const def = weapon ? WEAPONS[weapon] : null;
  const ammoLabel =
    weaponAmmo < 0 ? '∞' : weaponAmmo > 99 ? '99' : String(weaponAmmo);

  return (
    <div
      className="pointer-events-none fixed inset-x-0 bottom-0 z-30 flex items-center justify-between gap-2 px-3 sm:px-6"
      style={{ height: padHeight }}
    >
      {/* Left: slide-anywhere D-pad */}
      <div
        ref={dpadRef}
        onPointerDown={handleDpadDown}
        onPointerMove={handleDpadMove}
        onPointerUp={handleDpadUp}
        onPointerCancel={handleDpadUp}
        className="pointer-events-auto relative flex h-[88px] w-[150px] shrink-0 touch-none items-center justify-between wonder-pill px-2"
      >
        <div
          className={`flex h-[58px] w-[58px] items-center justify-center rounded-xl border-2 font-pixel text-base transition ${
            dirState.left
              ? 'scale-95 border-amber-300 bg-amber-400/35 text-white'
              : 'border-white/20 bg-white/10 text-white/80'
          }`}
        >
          ◀
        </div>

        {/* Down doubles as the warp-pipe entry button */}
        <div
          className={`flex h-[40px] w-[34px] flex-col items-center justify-center rounded-lg border text-[13px] font-pixel ${
            dirState.down
              ? 'border-emerald-300 bg-emerald-400/35 text-white'
              : 'border-white/15 bg-white/5 text-white/50'
          }`}
        >
          <span>▼</span>
          <span className="mt-0.5 text-[7px] leading-none">PIPE</span>
        </div>

        <div
          className={`flex h-[58px] w-[58px] items-center justify-center rounded-xl border-2 font-pixel text-base transition ${
            dirState.right
              ? 'scale-95 border-amber-300 bg-amber-400/35 text-white'
              : 'border-white/20 bg-white/10 text-white/80'
          }`}
        >
          ▶
        </div>
      </div>

      {/* Centre: weapon readout + switch */}
      <button
        type="button"
        disabled={ownedCount < 2}
        onPointerDown={(e) => {
          e.preventDefault();
          if (ownedCount < 2) return;
          vibrate(8);
          callbacks.onSwitchWeapon();
        }}
        className={`pointer-events-auto flex h-[62px] min-w-[74px] shrink-0 touch-none flex-col items-center justify-center rounded-xl border-2 px-2 transition ${
          def
            ? 'border-white/30 bg-slate-900/80'
            : 'border-white/10 bg-slate-900/50 opacity-60'
        }`}
        style={def ? { borderColor: `${def.color}aa` } : undefined}
      >
        <span className="text-lg leading-none">{def ? def.icon : '—'}</span>
        <span
          className="mt-0.5 font-pixel text-[12px] leading-none"
          style={{ color: def ? def.glow : '#94a3b8' }}
        >
          {def ? ammoLabel : 'NONE'}
        </span>
        {ownedCount > 1 && (
          <span className="mt-0.5 text-[7px] font-bold tracking-wide text-slate-400">
            TAP = SWAP
          </span>
        )}
      </button>

      {/* Dash + grapple */}
      <div className="pointer-events-auto flex shrink-0 touch-none flex-col gap-1.5">
        <button
          type="button"
          onPointerDown={(e) => {
            e.preventDefault();
            vibrate(9);
            callbacks.onDash();
          }}
          className="flex h-[38px] w-[54px] items-center justify-center rounded-lg border-2 border-cyan-300/70 bg-cyan-600/55"
        >
          <span className="font-pixel text-[12px] text-white">DASH</span>
        </button>
        <button
          type="button"
          onPointerDown={(e) => {
            e.preventDefault();
            vibrate(9);
            callbacks.onGrapple();
          }}
          className="flex h-[38px] w-[54px] items-center justify-center rounded-lg border-2 border-amber-300/70 bg-amber-600/55"
        >
          <span className="font-pixel text-[12px] text-white">HOOK</span>
        </button>
      </div>

      {/* Right: B (run / fire) and A (jump) */}
      <div className="pointer-events-auto flex shrink-0 touch-none items-center gap-3">
        <button
          type="button"
          onPointerDown={(e) => {
            e.preventDefault();
            e.currentTarget.setPointerCapture(e.pointerId);
            vibrate(10);
            setRunActive(true);
            callbacks.onRunFireChange(true, true);
          }}
          onPointerUp={(e) => {
            e.preventDefault();
            setRunActive(false);
            callbacks.onRunFireChange(false, false);
          }}
          onPointerCancel={() => {
            setRunActive(false);
            callbacks.onRunFireChange(false, false);
          }}
          className={`flex h-[66px] w-[66px] flex-col items-center justify-center rounded-full border-[3px] transition ${
            runActive
              ? 'scale-95 border-[#fff2c6] bg-[#2b3f6e]'
              : 'border-[#fff2c6] bg-[#172747]/95 shadow-lg'
          }`}
        >
          <span className="font-pixel text-sm text-white pixel-text-shadow-sm">
            B
          </span>
          <span className="mt-0.5 text-[9px] font-bold tracking-wider text-[#c8f6e6] uppercase">
            {weapon ? 'FIRE' : isFireMario ? 'FIRE' : 'RUN'}
          </span>
        </button>

        <button
          type="button"
          onPointerDown={(e) => {
            e.preventDefault();
            e.currentTarget.setPointerCapture(e.pointerId);
            vibrate(12);
            setJumpActive(true);
            callbacks.onJumpChange(true, true);
          }}
          onPointerUp={(e) => {
            e.preventDefault();
            setJumpActive(false);
            callbacks.onJumpChange(false, false);
          }}
          onPointerCancel={() => {
            setJumpActive(false);
            callbacks.onJumpChange(false, false);
          }}
          className={`flex h-[80px] w-[80px] flex-col items-center justify-center rounded-full border-[3px] transition ${
            jumpActive
              ? 'scale-95 border-[#fff2c6] bg-[#e0a92c]'
              : 'border-[#fff2c6] bg-[#f6c343] shadow-xl'
          }`}
        >
          <span className="font-pixel text-base text-[#293252]">
            A
          </span>
          <span className="mt-0.5 text-[9px] font-bold tracking-wider text-[#293252] uppercase">
            LOMPAT
          </span>
        </button>
      </div>
    </div>
  );
};
