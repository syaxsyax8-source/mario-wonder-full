import {
  TOTAL_LEVELS,
  WeatherKind,
  WeatherSchedule,
  WEATHER_DEFS,
  WEATHER_SCHEDULES,
  WEATHERS,
  WorldTheme,
} from './types';

/**
 * Backdrop building blocks. One renderer interprets these recipes, so a new
 * biome only needs data — no bespoke drawing code.
 */
export type LayerKind =
  | 'mountains' | 'snowpeaks' | 'hills' | 'dunes' | 'mesa' | 'pyramids'
  | 'pines' | 'broadleaf' | 'palms' | 'bamboo' | 'deadtrees' | 'mushroomtrees'
  | 'cacti' | 'coral' | 'kelp' | 'vines'
  | 'buildings' | 'neon' | 'towers' | 'ruins' | 'obelisk' | 'windmill'
  | 'gears' | 'pipes' | 'pillars' | 'crystals' | 'stalactites'
  | 'tombstones' | 'lanterns' | 'shipwreck'
  | 'clouds' | 'cloudislands' | 'waves' | 'bubbles' | 'icebergs' | 'geyser'
  | 'stars' | 'planets' | 'nebula' | 'aurora' | 'moonbig' | 'meteors'
  | 'gridfloor' | 'lavaflow' | 'candytrees' | 'lollipops' | 'balloons'
  | 'rainbowarc' | 'fog';

export interface BackdropLayer {
  kind: LayerKind;
  /** 0 = locked to camera, 1 = moves with the world. */
  parallax: number;
  colors: string[];
  /** Horizontal spacing between repeats, in world px. */
  span?: number;
  scale?: number;
  baseY?: number;
  count?: number;
}

export interface BiomeTileColors {
  top: string;
  main: string;
  shade: string;
  crack: string;
  brick: [string, string, string];
  solid: [string, string, string];
  used: [string, string, string];
}

export interface BiomeDef {
  id: string;
  name: string;
  icon: string;
  /** Drives hazards, music and whether pits are lava. */
  family: WorldTheme;
  sky: [string, string, string];
  tiles: BiomeTileColors;
  layers: BackdropLayer[];
  accent: string;
}

// ---------------------------------------------------------------------------
// Catalog helpers
// ---------------------------------------------------------------------------

interface BiomeSpec {
  id: string;
  name: string;
  icon: string;
  family: WorldTheme;
  sky: [string, string, string];
  /** [grassTop, bodyMain, bodyShade, crack] */
  ground: [string, string, string, string];
  /** [base, highlight, mortar] */
  brick: [string, string, string];
  /** [base, light, dark] */
  solid: [string, string, string];
  layers: BackdropLayer[];
  accent?: string;
}

function makeBiome(s: BiomeSpec): BiomeDef {
  return {
    id: s.id,
    name: s.name,
    icon: s.icon,
    family: s.family,
    sky: s.sky,
    accent: s.accent ?? s.ground[0],
    tiles: {
      top: s.ground[0],
      main: s.ground[1],
      shade: s.ground[2],
      crack: s.ground[3],
      brick: s.brick,
      solid: s.solid,
      // Spent blocks are always a desaturated version of the solid block.
      used: ['#8a8d96', '#b9bcc4', '#4a4d55'],
    },
    layers: s.layers,
  };
}

const L = (
  kind: LayerKind,
  parallax: number,
  colors: string[],
  extra: Partial<BackdropLayer> = {}
): BackdropLayer => ({ kind, parallax, colors, ...extra });

// ---------------------------------------------------------------------------
// 100 distinct biomes
// ---------------------------------------------------------------------------

export const BIOMES: BiomeDef[] = [
  // ---- Grasslands / temperate -------------------------------------------
  makeBiome({ id: 'plains', name: 'MUSHROOM PLAINS', icon: '🍄', family: 'overworld',
    sky: ['#3c8dff', '#72bcff', '#b5e3ff'], ground: ['#4be35e', '#c85a17', '#8f3808', '#2b1204'],
    brick: ['#cf571b', '#ff9b61', '#261107'], solid: ['#c7662a', '#ffb178', '#752f09'],
    layers: [L('clouds', 0.2, ['#ffffff', '#cdeaff']), L('mountains', 0.32, ['#5b93d6', '#eef7ff']), L('hills', 0.55, ['#189e4b', '#53e07b'])] }),
  makeBiome({ id: 'meadow', name: 'HONEY MEADOW', icon: '🌼', family: 'overworld',
    sky: ['#7ec8ff', '#c7e9ff', '#fff3c4'], ground: ['#8de05a', '#b8862f', '#7d5a1c', '#2e2008'],
    brick: ['#c69a3c', '#ffd980', '#3a2c0d'], solid: ['#d9a94a', '#ffe59b', '#8a6a1f'],
    layers: [L('clouds', 0.2, ['#fffdf2', '#ffe9b0']), L('hills', 0.45, ['#4fbe4f', '#9ef07a']), L('windmill', 0.6, ['#f5f0e2', '#c0392b'])] }),
  makeBiome({ id: 'orchard', name: 'APPLE ORCHARD', icon: '🍎', family: 'overworld',
    sky: ['#64b5ff', '#a8dcff', '#e8f6ff'], ground: ['#5fd14a', '#8b5a2b', '#5c3a18', '#201206'],
    brick: ['#a4652c', '#d79a5b', '#2d1a09'], solid: ['#b2733a', '#e6a86b', '#6d4418'],
    layers: [L('clouds', 0.2, ['#ffffff', '#d6ecff']), L('broadleaf', 0.5, ['#2f8f3a', '#64d16a', '#e34b4b'])] }),
  makeBiome({ id: 'prairie', name: 'GOLDEN PRAIRIE', icon: '🌾', family: 'overworld',
    sky: ['#58a8f0', '#9ed3ff', '#ffe9a8'], ground: ['#e3c14f', '#a07b2c', '#6d521a', '#241b06'],
    brick: ['#b8902f', '#f0cb6e', '#352709'], solid: ['#c89c36', '#fadd86', '#80631d'],
    layers: [L('clouds', 0.2, ['#fffaf0', '#ffe9b8']), L('hills', 0.5, ['#b8a03a', '#e8d26a'])] }),
  makeBiome({ id: 'redwood', name: 'REDWOOD VALE', icon: '🌲', family: 'jungle',
    sky: ['#2f6f9e', '#64a8cf', '#b8dcea'], ground: ['#3f9e4a', '#7a3f1e', '#4f2712', '#1b0d05'],
    brick: ['#8a4a24', '#c47d48', '#2a1409'], solid: ['#99582c', '#d08f58', '#5e3317'],
    layers: [L('fog', 0.15, ['#cfe4ee']), L('pines', 0.35, ['#13401f', '#1f6b31']), L('pines', 0.6, ['#0c2b15', '#174d24'])] }),
  makeBiome({ id: 'autumn', name: 'AUTUMN WOODS', icon: '🍁', family: 'jungle',
    sky: ['#e8955a', '#f5bd84', '#ffe3bd'], ground: ['#d4722c', '#6b4320', '#452a13', '#180e06'],
    brick: ['#8f5327', '#c98a50', '#2b1909'], solid: ['#a0612f', '#dba06a', '#653a18'],
    layers: [L('broadleaf', 0.35, ['#b8471f', '#e8833a', '#f0b55a']), L('broadleaf', 0.6, ['#8a3414', '#c45f24'])] }),
  makeBiome({ id: 'sakura', name: 'SAKURA GARDEN', icon: '🌸', family: 'candy',
    sky: ['#ffb8d9', '#ffd6e8', '#fff0f6'], ground: ['#ff9ec7', '#8a5a4a', '#5c392e', '#201210'],
    brick: ['#c97a8f', '#f0aec0', '#3d222a'], solid: ['#d98aa0', '#ffc2d2', '#8a4f60'],
    layers: [L('broadleaf', 0.35, ['#ff8ac4', '#ffc2de', '#fff0f6']), L('lanterns', 0.6, ['#e8453a', '#ffd166'])] }),
  makeBiome({ id: 'bamboo', name: 'BAMBOO GROVE', icon: '🎋', family: 'jungle',
    sky: ['#6fc49e', '#a8e0c4', '#dff5ea'], ground: ['#6fd16f', '#5c7a3a', '#3d5125', '#16200d'],
    brick: ['#6b8a3f', '#9fc46e', '#222d12'], solid: ['#7a9a48', '#b4d884', '#4c6228'],
    layers: [L('bamboo', 0.3, ['#4f8a3a', '#8ac45e']), L('bamboo', 0.55, ['#36602a', '#5f9440'])] }),
  makeBiome({ id: 'vineyard', name: 'TERRACE VINEYARD', icon: '🍇', family: 'jungle',
    sky: ['#8f6fd1', '#c4a8e8', '#f0e4ff'], ground: ['#7fc44f', '#8a6b3a', '#5c4624', '#20170c'],
    brick: ['#8a6a3f', '#c49f6e', '#2b2112'], solid: ['#9a7a48', '#d8b484', '#60492a'],
    layers: [L('hills', 0.4, ['#6f9a3f', '#a8d16f']), L('vines', 0.65, ['#5a2f8a', '#9a5fd1'])] }),
  makeBiome({ id: 'greenhouse', name: 'CRYSTAL GREENHOUSE', icon: '🪴', family: 'jungle',
    sky: ['#a8e8d1', '#d6f5e8', '#f5fffc'], ground: ['#4fd18a', '#6b8a7a', '#445c51', '#17211c'],
    brick: ['#5f8a7a', '#92c4b0', '#1e2b26'], solid: ['#6f9a8a', '#a8d8c4', '#406055'],
    layers: [L('pillars', 0.3, ['#cfeee4', '#ffffff']), L('broadleaf', 0.6, ['#2f9a5f', '#6fd18f'])] }),

  // ---- Deserts / arid -----------------------------------------------------
  makeBiome({ id: 'dunes', name: 'DRY DUNES', icon: '🏜️', family: 'desert',
    sky: ['#ff9d4d', '#ffc97a', '#ffe6b0'], ground: ['#ffd98a', '#d9a441', '#a9752a', '#4a2f0d'],
    brick: ['#d4a04a', '#ffe0a0', '#4a3113'], solid: ['#cf9a44', '#ffdc9c', '#8a6020'],
    layers: [L('pyramids', 0.3, ['#c98b3f', '#e3ab5e']), L('dunes', 0.55, ['#e8b268', '#ffd89a']), L('cacti', 0.7, ['#2f9e52'])] }),
  makeBiome({ id: 'mesa', name: 'CRIMSON MESA', icon: '🧱', family: 'desert',
    sky: ['#d9643a', '#f09a64', '#ffd1a8'], ground: ['#e08a4f', '#9a4524', '#6b2d16', '#241008'],
    brick: ['#a85230', '#d98a5f', '#36170c'], solid: ['#b85f35', '#eda16e', '#78331a'],
    layers: [L('mesa', 0.32, ['#8a3f22', '#c4663a']), L('mesa', 0.55, ['#6b2f19', '#a04f2a'])] }),
  makeBiome({ id: 'oasis', name: 'MIRAGE OASIS', icon: '🌴', family: 'beach',
    sky: ['#4fc4e8', '#9fe0f0', '#ffe9b8'], ground: ['#ffe3a0', '#c99a4f', '#946f30', '#3a2910'],
    brick: ['#3fa7c7', '#9fe2f5', '#13394b'], solid: ['#c9a055', '#ffe0a8', '#806429'],
    layers: [L('dunes', 0.4, ['#e8c478', '#ffe6a8']), L('palms', 0.6, ['#8a5a2b', '#2fae5c'])] }),
  makeBiome({ id: 'saltflat', name: 'SALT FLATS', icon: '🧂', family: 'desert',
    sky: ['#b8d6e8', '#dff0f5', '#ffffff'], ground: ['#f0f4f5', '#c4cdd1', '#9aa3a8', '#3d4447'],
    brick: ['#b4bdc2', '#e4ebee', '#3a4044'], solid: ['#c4cdd2', '#f0f6f8', '#7a8287'],
    layers: [L('mountains', 0.28, ['#9fb4c0', '#e8f2f5']), L('waves', 0.5, ['#dff0f5', '#ffffff'])] }),
  makeBiome({ id: 'canyon', name: 'ECHO CANYON', icon: '🪨', family: 'desert',
    sky: ['#e8a05f', '#f5c48f', '#ffe9c4'], ground: ['#d99a5f', '#8a5230', '#5e351c', '#20120a'],
    brick: ['#9a5e35', '#cf9263', '#2e1a0d'], solid: ['#a96a3c', '#e0a273', '#6d3f1f'],
    layers: [L('mesa', 0.25, ['#7a4426', '#b06a3a']), L('obelisk', 0.5, ['#8a5230', '#c98a5f'])] }),
  makeBiome({ id: 'quarry', name: 'SANDSTONE QUARRY', icon: '⛏️', family: 'desert',
    sky: ['#c9a86f', '#e8cf9f', '#fff0d1'], ground: ['#e0c48f', '#a88a52', '#765f35', '#2a2111'],
    brick: ['#a88a52', '#dbbf85', '#332814'], solid: ['#b89a5f', '#ebd199', '#776032'],
    layers: [L('mesa', 0.3, ['#9a7f4f', '#c4a673']), L('obelisk', 0.55, ['#8a7044', '#bfa06a'])] }),

  // ---- Coast / water ------------------------------------------------------
  makeBiome({ id: 'coast', name: 'CORAL COAST', icon: '🐚', family: 'beach',
    sky: ['#1d9bd1', '#5fc8ea', '#bdf0ff'], ground: ['#ffe9ab', '#e9c173', '#b58a42', '#4f3a16'],
    brick: ['#3fa7c7', '#9fe2f5', '#13394b'], solid: ['#46b3d4', '#a9ecff', '#1f6e88'],
    layers: [L('clouds', 0.2, ['#ffffff', '#d6f0ff']), L('waves', 0.45, ['#1f8fc4', '#7fd8f5']), L('palms', 0.6, ['#8a5a2b', '#2fae5c'])] }),
  makeBiome({ id: 'lagoon', name: 'AZURE LAGOON', icon: '🏝️', family: 'beach',
    sky: ['#2fc4d9', '#8fe8ef', '#e0fbff'], ground: ['#fff0c4', '#dcc48a', '#a89258', '#3d3418'],
    brick: ['#2f9ab8', '#7fd6e8', '#0f2e3a'], solid: ['#3fb0c9', '#96e4f2', '#1b6378'],
    layers: [L('waves', 0.4, ['#19a8c4', '#8fe8f5']), L('palms', 0.62, ['#7a4f26', '#35c46a'])] }),
  makeBiome({ id: 'reef', name: 'SUNKEN REEF', icon: '🐠', family: 'beach',
    sky: ['#0a4f78', '#1183b0', '#44c4dd'], ground: ['#4fd6c4', '#1f7a8a', '#115260', '#06222a'],
    brick: ['#1f7a8a', '#52b8c4', '#062029'], solid: ['#248a9a', '#6fd1dd', '#0f4b57'],
    layers: [L('bubbles', 0.25, ['#bdf0ff']), L('kelp', 0.45, ['#0f6b4f', '#2fa87a']), L('coral', 0.65, ['#ff6f91', '#ffb86f', '#6fe8c4'])] }),
  makeBiome({ id: 'shipwreck', name: 'SHIPWRECK COVE', icon: '🏴‍☠️', family: 'beach',
    sky: ['#2a4f6b', '#4f7f9e', '#9fc4d6'], ground: ['#c4a86f', '#6b5230', '#45341c', '#17100a'],
    brick: ['#6b4f30', '#a07a4f', '#221709'], solid: ['#7a5c38', '#b48a5c', '#4a3520'],
    layers: [L('fog', 0.15, ['#9fc4d6']), L('shipwreck', 0.42, ['#4f3a20', '#7a5c38', '#d6c4a0']), L('waves', 0.6, ['#2f5f7a', '#6f9fb8'])] }),
  makeBiome({ id: 'abyss', name: 'ABYSSAL TRENCH', icon: '🦑', family: 'underground',
    sky: ['#02101f', '#052337', '#0a3a52'], ground: ['#1f5f6b', '#0f3a45', '#082530', '#030f14'],
    brick: ['#0f3a45', '#2f7a88', '#02131a'], solid: ['#144a57', '#3f8f9e', '#07262e'],
    layers: [L('bubbles', 0.2, ['#5fd6e8']), L('kelp', 0.4, ['#063a2f', '#0f6b52']), L('crystals', 0.6, ['#2fd6e8', '#9ff2ff'])] }),
  makeBiome({ id: 'geyser', name: 'GEYSER BASIN', icon: '♨️', family: 'snow',
    sky: ['#8fb8cf', '#c4dfe8', '#f0f8fa'], ground: ['#cfe8e0', '#7a9a95', '#4f6b67', '#1b2625'],
    brick: ['#6b8a85', '#a4c4bf', '#232e2c'], solid: ['#7a9a94', '#b4d4ce', '#4a625e'],
    layers: [L('fog', 0.2, ['#e0f0f5']), L('geyser', 0.5, ['#ffffff', '#cfe8f0']), L('mountains', 0.3, ['#7a94a0', '#dfeef5'])] }),
  makeBiome({ id: 'waterfall', name: 'MISTFALL GORGE', icon: '💧', family: 'jungle',
    sky: ['#3f8fb8', '#7fc4dd', '#cfeef5'], ground: ['#4fc47a', '#4f6b5c', '#33463c', '#111915'],
    brick: ['#4f6b5f', '#86a899', '#18211d'], solid: ['#5c7a6c', '#98bfae', '#394d43'],
    layers: [L('fog', 0.18, ['#dff0f5']), L('mountains', 0.3, ['#44708a', '#a8d1e0']), L('geyser', 0.55, ['#cfeef5', '#ffffff'])] }),

  // ---- Jungle / swamp -----------------------------------------------------
  makeBiome({ id: 'jungle', name: 'VINE JUNGLE', icon: '🌴', family: 'jungle',
    sky: ['#0d3b1e', '#1d6b35', '#49a85a'], ground: ['#7cf06a', '#3f7a2c', '#275219', '#0f2409'],
    brick: ['#4b8b33', '#8fd96f', '#16290d'], solid: ['#55953a', '#a3e283', '#2d5a1f'],
    layers: [L('broadleaf', 0.3, ['#124d27', '#1c7a3c']), L('vines', 0.6, ['#3cbe5f'])] }),
  makeBiome({ id: 'swamp', name: 'MURKY SWAMP', icon: '🐸', family: 'jungle',
    sky: ['#3d4a2f', '#5f6b44', '#8a9a6b'], ground: ['#7a9a3f', '#4a5c2a', '#2f3a1a', '#121608'],
    brick: ['#4f5c2f', '#7f9a5f', '#1a2010'], solid: ['#5c6b38', '#92ab72', '#374222'],
    layers: [L('fog', 0.2, ['#8a9a7a']), L('deadtrees', 0.4, ['#2a2f1c', '#454f30']), L('kelp', 0.6, ['#3f5c2a', '#6b8a3f'])] }),
  makeBiome({ id: 'fungal', name: 'FUNGAL HOLLOW', icon: '🍄', family: 'jungle',
    sky: ['#2a1f3d', '#45355f', '#6b5490'], ground: ['#b86fd1', '#5c3f7a', '#3d2a52', '#160f20'],
    brick: ['#5f447a', '#9070b8', '#1d1429'], solid: ['#6b4f8a', '#a584c9', '#422f57'],
    layers: [L('mushroomtrees', 0.35, ['#8a4fc4', '#d18ae8', '#ffd1f5']), L('mushroomtrees', 0.6, ['#5f2f8a', '#9a5fc4'])] }),
  makeBiome({ id: 'mangrove', name: 'MANGROVE MAZE', icon: '🌿', family: 'jungle',
    sky: ['#2f6b5c', '#5f9a88', '#a8cfc4'], ground: ['#5fc49a', '#3f6b5c', '#284438', '#0e1a15'],
    brick: ['#3f6b5c', '#6fa894', '#14241e'], solid: ['#4a7a6a', '#7fbda8', '#2d4f44'],
    layers: [L('kelp', 0.35, ['#1f4f3f', '#3f8a6b']), L('vines', 0.6, ['#2fa87a'])] }),

  // ---- Snow / ice ---------------------------------------------------------
  makeBiome({ id: 'peaks', name: 'FROZEN PEAKS', icon: '❄️', family: 'snow',
    sky: ['#4a6fa5', '#9dc2e8', '#e8f4ff'], ground: ['#ffffff', '#9fc7e8', '#6b96bd', '#2b4258'],
    brick: ['#8fb6d8', '#e4f3ff', '#28415a'], solid: ['#a9cce8', '#eaf7ff', '#5c82a4'],
    layers: [L('snowpeaks', 0.3, ['#6f94c4', '#ffffff']), L('pines', 0.6, ['#2f5d3f', '#eaf6ff'])] }),
  makeBiome({ id: 'tundra', name: 'SILENT TUNDRA', icon: '🧊', family: 'snow',
    sky: ['#6b7f9e', '#a8bdd1', '#e0e8f0'], ground: ['#e8f0f5', '#8a9aa8', '#5f6d7a', '#242b33'],
    brick: ['#7f8f9e', '#bdcdd8', '#262e36'], solid: ['#8f9fae', '#cfdde8', '#55616d'],
    layers: [L('fog', 0.2, ['#dfe8f0']), L('snowpeaks', 0.35, ['#7f94ad', '#f0f6fa'])] }),
  makeBiome({ id: 'glacier', name: 'GLACIER DRIFT', icon: '🏔️', family: 'snow',
    sky: ['#2f6b9e', '#6fa8cf', '#bde0f0'], ground: ['#bdf0ff', '#4f9ac4', '#2f6b8a', '#102a38'],
    brick: ['#3f8ab0', '#8fd6ef', '#0f2a38'], solid: ['#4f9ac4', '#a0e2f5', '#28607c'],
    layers: [L('icebergs', 0.35, ['#8fd6ef', '#e0f8ff']), L('snowpeaks', 0.25, ['#4f7f9e', '#ffffff'])] }),
  makeBiome({ id: 'icepalace', name: 'ICE PALACE', icon: '🏰', family: 'snow',
    sky: ['#1f3f6b', '#4f7fb8', '#a8d1ef'], ground: ['#d6f0ff', '#5f8fc4', '#3a5f8a', '#142437'],
    brick: ['#4f7fb0', '#9fcfef', '#122540'], solid: ['#5f8fc4', '#aedcf5', '#2f5a85'],
    layers: [L('towers', 0.3, ['#3f6b9e', '#9fcfef']), L('crystals', 0.55, ['#8fe0ff', '#e0f8ff'])] }),
  makeBiome({ id: 'aurorafield', name: 'AURORA FIELDS', icon: '🌌', family: 'snow',
    sky: ['#0a1f3d', '#15355f', '#2f5f8a'], ground: ['#cfe8ff', '#5f7f9e', '#3d566b', '#141f29'],
    brick: ['#4f6b85', '#8fadc4', '#17212b'], solid: ['#5f7f9e', '#a0c0d8', '#38505f'],
    layers: [L('aurora', 0.12, ['#49f2c4', '#9f7fff', '#4fd6ff']), L('stars', 0.08, ['#ffffff']), L('snowpeaks', 0.35, ['#2f4f6b', '#cfe8ff'])] }),

  // ---- Sky / cloud --------------------------------------------------------
  makeBiome({ id: 'cloudland', name: 'CLOUD KINGDOM', icon: '☁️', family: 'sky',
    sky: ['#6fa8ff', '#a9ccff', '#e4f0ff'], ground: ['#ffffff', '#b9c9ff', '#8a9ce0', '#3e4a80'],
    brick: ['#8d9df0', '#d6e0ff', '#2f3766'], solid: ['#9aa9f5', '#dbe4ff', '#5b67ad'],
    layers: [L('clouds', 0.18, ['#ffffff', '#d6e4ff']), L('cloudislands', 0.4, ['#ffffff', '#cddbff'])] }),
  makeBiome({ id: 'windtemple', name: 'WIND TEMPLE', icon: '🌬️', family: 'sky',
    sky: ['#8fb8e8', '#c4daf5', '#f0f6ff'], ground: ['#f0f4ff', '#a8b4cf', '#7a86a0', '#2f3645'],
    brick: ['#8f9ab8', '#c4cfe8', '#2a3142'], solid: ['#9faaC4', '#d4dff5', '#5f6a85'],
    layers: [L('pillars', 0.3, ['#dfe6f5', '#ffffff']), L('cloudislands', 0.5, ['#ffffff', '#cfdcf5'])] }),
  makeBiome({ id: 'stormpeak', name: 'STORM SUMMIT', icon: '⛈️', family: 'sky',
    sky: ['#2a3447', '#45526b', '#6b7a94'], ground: ['#8fa0b8', '#4f5c70', '#343d4c', '#131821'],
    brick: ['#495468', '#7f8c9f', '#171c25'], solid: ['#55617a', '#8f9db4', '#2f3745'],
    layers: [L('clouds', 0.2, ['#5f6b80', '#8f9cb0']), L('snowpeaks', 0.35, ['#3f4a5c', '#8fa0b8'])] }),
  makeBiome({ id: 'rainbowroad', name: 'RAINBOW ROAD', icon: '🌈', family: 'sky',
    sky: ['#1f2f6b', '#4f5fa0', '#9f9fd6'], ground: ['#ff6f91', '#6f4fd1', '#4a2f9a', '#1a0f3d'],
    brick: ['#6f4fd1', '#a88ff0', '#1d1240'], solid: ['#8a6fe0', '#c4aaff', '#4a2f9a'],
    layers: [L('stars', 0.1, ['#ffffff']), L('rainbowarc', 0.35, ['#ff5f5f', '#ffbe5f', '#5fff8f', '#5fc4ff', '#bf5fff'])] }),
  makeBiome({ id: 'balloonfair', name: 'BALLOON FAIR', icon: '🎈', family: 'sky',
    sky: ['#5fb8ff', '#9fd6ff', '#e0f2ff'], ground: ['#ffd166', '#c4663f', '#8a4426', '#2f1709'],
    brick: ['#c4663f', '#f0a070', '#30160a'], solid: ['#d1744a', '#ffb088', '#85421f'],
    layers: [L('clouds', 0.2, ['#ffffff', '#d6ecff']), L('balloons', 0.4, ['#ff5f5f', '#5fc4ff', '#ffd166', '#8aff9e'])] }),

  // ---- Space --------------------------------------------------------------
  makeBiome({ id: 'moonbase', name: 'LUNAR BASE', icon: '🌕', family: 'sky',
    sky: ['#05060f', '#0b1024', '#161d3d'], ground: ['#d6d6e0', '#7a7a8a', '#52525f', '#1d1d24'],
    brick: ['#6b6b7a', '#a4a4b4', '#1f1f27'], solid: ['#7a7a8a', '#b8b8c8', '#45454f'],
    layers: [L('stars', 0.06, ['#ffffff', '#cfd6ff']), L('planets', 0.18, ['#4f6bd1', '#8fa8ff']), L('mountains', 0.35, ['#4a4a57', '#9a9aab'])] }),
  makeBiome({ id: 'marsdust', name: 'MARTIAN DUST', icon: '🔴', family: 'desert',
    sky: ['#4a1f14', '#8a3f24', '#d1744a'], ground: ['#e08a5f', '#8a3f24', '#5c2714', '#200d06'],
    brick: ['#8a3f24', '#c4704a', '#2a1109'], solid: ['#9a4a2c', '#d4805a', '#632914'],
    layers: [L('stars', 0.06, ['#ffd6c4']), L('mesa', 0.3, ['#6b2f1a', '#a04f2f']), L('dunes', 0.55, ['#c4704a', '#e8a07a'])] }),
  makeBiome({ id: 'nebula', name: 'NEBULA DRIFT', icon: '🌠', family: 'sky',
    sky: ['#0a0520', '#2a1050', '#5f2f8a'], ground: ['#c48aff', '#5f2f8a', '#3d1f5c', '#140a20'],
    brick: ['#5f2f8a', '#9a5fc4', '#170a24'], solid: ['#6f3f9a', '#ad7fd6', '#3f1f5f'],
    layers: [L('nebula', 0.1, ['#9f4fd1', '#4f6bd1', '#d14f9a']), L('stars', 0.05, ['#ffffff']), L('meteors', 0.25, ['#ffd6ff'])] }),
  makeBiome({ id: 'cometbelt', name: 'COMET BELT', icon: '☄️', family: 'sky',
    sky: ['#040812', '#0d1a33', '#1f3a5c'], ground: ['#9fd6ff', '#3f5f8a', '#283f5c', '#0b1420'],
    brick: ['#3f5f8a', '#7f9fc4', '#0d1724'], solid: ['#4f6f9a', '#8fb0d6', '#2a4160'],
    layers: [L('stars', 0.05, ['#ffffff', '#9fd6ff']), L('meteors', 0.2, ['#9fd6ff', '#ffffff']), L('planets', 0.15, ['#d1a84f'])] }),
  makeBiome({ id: 'observatory', name: 'STAR OBSERVATORY', icon: '🔭', family: 'castle',
    sky: ['#0a0f2a', '#1a2550', '#3a4a85'], ground: ['#bdc9f0', '#4f5c8a', '#343d5c', '#131629'],
    brick: ['#4a5580', '#8590bd', '#161a2e'], solid: ['#5a6590', '#96a2cf', '#333c60'],
    layers: [L('stars', 0.06, ['#ffffff', '#ffe9a8']), L('towers', 0.3, ['#2a3360', '#6b7aad']), L('moonbig', 0.12, ['#f5f0d6'])] }),
  makeBiome({ id: 'voidrift', name: 'VOID RIFT', icon: '🕳️', family: 'haunted',
    sky: ['#05000d', '#13031f', '#2a0a3d'], ground: ['#8a4fd1', '#3d1060', '#280a40', '#0d0318'],
    brick: ['#3d1060', '#6f2fa0', '#120320'], solid: ['#4f1f7a', '#8a4fc4', '#2a0a45'],
    layers: [L('nebula', 0.08, ['#6f0fa0', '#2f0f6b']), L('stars', 0.04, ['#c48aff']), L('crystals', 0.45, ['#9a4fd1', '#d18aff'])] }),
  makeBiome({ id: 'gridspace', name: 'DIGITAL GRID', icon: '🟩', family: 'factory',
    sky: ['#02110d', '#04291f', '#0a4a38'], ground: ['#2fffb8', '#0a5c45', '#073f2f', '#021a13'],
    brick: ['#0a5c45', '#2fa884', '#021812'], solid: ['#0f7a5c', '#4fd1a8', '#064030'],
    layers: [L('gridfloor', 0.3, ['#2fffb8', '#0a5c45']), L('stars', 0.08, ['#5fffd1'])] }),

  // ---- Horror / haunted ---------------------------------------------------
  makeBiome({ id: 'hollow', name: 'HAUNTED HOLLOW', icon: '👻', family: 'haunted',
    sky: ['#0a0718', '#1e1236', '#3a2057'], ground: ['#7b5bb5', '#3d2a5e', '#271a3d', '#120b1e'],
    brick: ['#4a356e', '#8b6cc4', '#1a1029'], solid: ['#55407a', '#937ac4', '#2e2147'],
    layers: [L('moonbig', 0.12, ['#f4ecd0']), L('deadtrees', 0.36, ['#1b1130']), L('tombstones', 0.6, ['#4b3f66'])] }),
  makeBiome({ id: 'graveyard', name: 'MIDNIGHT GRAVEYARD', icon: '🪦', family: 'haunted',
    sky: ['#050510', '#121228', '#272745'], ground: ['#6b6b8a', '#33334f', '#222235', '#0d0d16'],
    brick: ['#3a3a5c', '#6f6f94', '#15151f'], solid: ['#45456b', '#7f7fa8', '#28283f'],
    layers: [L('fog', 0.18, ['#4f4f6b']), L('tombstones', 0.4, ['#5a5a7a']), L('deadtrees', 0.6, ['#1a1a2a'])] }),
  makeBiome({ id: 'cursedmanor', name: 'CURSED MANOR', icon: '🏚️', family: 'haunted',
    sky: ['#120a1f', '#241438', '#3f2456'], ground: ['#8a6ba8', '#44305c', '#2d1f3d', '#110a18'],
    brick: ['#4f3a6b', '#846ba0', '#1b1226'], solid: ['#5c4578', '#9078b0', '#33244a'],
    layers: [L('towers', 0.3, ['#241438', '#6b4f8a']), L('lanterns', 0.55, ['#ffb84f', '#ff7a2f'])] }),
  makeBiome({ id: 'catacombs', name: 'BONE CATACOMBS', icon: '💀', family: 'underground',
    sky: ['#0d0a06', '#1f1810', '#38291a'], ground: ['#d6c9a8', '#6b5c42', '#453a28', '#17120c'],
    brick: ['#5f5238', '#99886a', '#1d1810'], solid: ['#6b5e44', '#a89878', '#413725'],
    layers: [L('pillars', 0.3, ['#4a3f2c', '#8a7a5c']), L('tombstones', 0.55, ['#b8a888'])] }),
  makeBiome({ id: 'bloodmoon', name: 'BLOOD MOON RIDGE', icon: '🌑', family: 'haunted',
    sky: ['#1a0308', '#3d0a14', '#6b1424'], ground: ['#c44f5f', '#5c1f2a', '#3d131c', '#16060a'],
    brick: ['#5c1f2a', '#9a4452', '#17060b'], solid: ['#6b2a35', '#a85564', '#3f1017'],
    layers: [L('moonbig', 0.12, ['#e8485f']), L('deadtrees', 0.38, ['#2a0a10']), L('mountains', 0.28, ['#3d131c', '#7a2f3d'])] }),
  makeBiome({ id: 'phantomfog', name: 'PHANTOM MARSH', icon: '🫧', family: 'haunted',
    sky: ['#101a1f', '#20353d', '#3a5b63'], ground: ['#6fa8a0', '#2f5c57', '#1f3d3a', '#0b1816'],
    brick: ['#2f5c57', '#5f9a92', '#0d1f1d'], solid: ['#3a6b66', '#6fa89f', '#1f4441'],
    layers: [L('fog', 0.2, ['#8fb8b0']), L('deadtrees', 0.42, ['#14262a']), L('lanterns', 0.6, ['#7fffd1'])] }),

  // ---- Underground / crystal ----------------------------------------------
  makeBiome({ id: 'cavern', name: 'CRYSTAL CAVERN', icon: '💎', family: 'underground',
    sky: ['#070d1f', '#102042', '#183261'], ground: ['#5cd1ff', '#1e5b94', '#10365e', '#08172b'],
    brick: ['#2569ad', '#6bb8ff', '#0b1e36'], solid: ['#2f78b8', '#7ac9ff', '#143c66'],
    layers: [L('stalactites', 0.28, ['#162d59', '#1f3f7a']), L('crystals', 0.5, ['#4df3ff', '#bdf6ff'])] }),
  makeBiome({ id: 'amberpit', name: 'AMBER DEPTHS', icon: '🟧', family: 'underground',
    sky: ['#1f1206', '#3d2410', '#6b4420'], ground: ['#ffb84f', '#8a5a1f', '#5c3a12', '#1f1206'],
    brick: ['#8a5a1f', '#c4903f', '#1f1206'], solid: ['#9a6a2a', '#d4a44f', '#60400f'],
    layers: [L('stalactites', 0.28, ['#4a2f10', '#6b4420']), L('crystals', 0.5, ['#ffb84f', '#ffe0a0'])] }),
  makeBiome({ id: 'saltmine', name: 'SALT MINE', icon: '⛏️', family: 'underground',
    sky: ['#14181f', '#262e3d', '#404c63'], ground: ['#e0e8f0', '#6b7585', '#454d5c', '#171c24'],
    brick: ['#5c6575', '#929cae', '#1a1f28'], solid: ['#6b7585', '#a4aebf', '#3f4756'],
    layers: [L('stalactites', 0.3, ['#2f3745', '#4f596b']), L('pipes', 0.52, ['#6b5c3f', '#a89270'])] }),
  makeBiome({ id: 'geode', name: 'GEODE CHAMBER', icon: '🔮', family: 'underground',
    sky: ['#1a0a2a', '#301450', '#50247a'], ground: ['#d18aff', '#5f2f8a', '#3f1f5c', '#170a24'],
    brick: ['#5f2f8a', '#9a5fc4', '#180a26'], solid: ['#6f3f9a', '#ad7fd6', '#40205f'],
    layers: [L('crystals', 0.3, ['#c48aff', '#f0d6ff']), L('crystals', 0.55, ['#8a4fd1', '#d1a8ff'])] }),
  makeBiome({ id: 'lavatube', name: 'LAVA TUBE', icon: '🫗', family: 'volcano',
    sky: ['#1a0604', '#3d0f06', '#6b2510'], ground: ['#ff8d3b', '#6d2a1d', '#451710', '#1d0906'],
    brick: ['#8a3722', '#d4673f', '#2a0e07'], solid: ['#93402a', '#e07a4c', '#55200f'],
    layers: [L('stalactites', 0.3, ['#3a140a', '#5c2010']), L('lavaflow', 0.5, ['#ff6a1f', '#ffd166'])] }),

  // ---- Volcano / fire -----------------------------------------------------
  makeBiome({ id: 'magma', name: 'MAGMA CORE', icon: '🌋', family: 'volcano',
    sky: ['#1a0604', '#4d1008', '#9c2a0c'], ground: ['#ff8d3b', '#6d2a1d', '#451710', '#1d0906'],
    brick: ['#8a3722', '#d4673f', '#2a0e07'], solid: ['#93402a', '#e07a4c', '#55200f'],
    layers: [L('mountains', 0.32, ['#3a0f07', '#8a2f14']), L('lavaflow', 0.55, ['#ff6a1f', '#ffd166'])] }),
  makeBiome({ id: 'ashlands', name: 'ASHEN WASTES', icon: '🜂', family: 'volcano',
    sky: ['#1a1614', '#332b26', '#544842'], ground: ['#a89a92', '#4f4540', '#332c28', '#141110'],
    brick: ['#4a4039', '#7a6d64', '#1a1614'], solid: ['#574c44', '#8a7c72', '#332c28'],
    layers: [L('fog', 0.2, ['#6b5f58']), L('mountains', 0.32, ['#2f2724', '#6b5f58'])] }),
  makeBiome({ id: 'obsidian', name: 'OBSIDIAN SPIRE', icon: '⬛', family: 'volcano',
    sky: ['#0a0610', '#1a0f24', '#331f45'], ground: ['#8a6fd1', '#241533', '#170d22', '#08040d'],
    brick: ['#241533', '#4f3a6b', '#0a0510'], solid: ['#2f1d45', '#5f4785', '#160c20'],
    layers: [L('crystals', 0.3, ['#3d2a5c', '#7f5fb8']), L('lavaflow', 0.55, ['#ff4f1f', '#ffa84f'])] }),
  makeBiome({ id: 'sulfur', name: 'SULFUR SPRINGS', icon: '🟡', family: 'volcano',
    sky: ['#3d3306', '#6b5c0f', '#a89420'], ground: ['#ffe34f', '#8a7415', '#5c4d0d', '#1f1a04'],
    brick: ['#8a7415', '#c4a83f', '#1f1a04'], solid: ['#9a8420', '#d4bc4f', '#60500f'],
    layers: [L('geyser', 0.4, ['#fff4a8', '#ffe34f']), L('mountains', 0.3, ['#5c4d0d', '#a89420'])] }),

  // ---- Factory / city -----------------------------------------------------
  makeBiome({ id: 'factory', name: 'IRON FACTORY', icon: '⚙️', family: 'factory',
    sky: ['#14181f', '#262d3a', '#3d4654'], ground: ['#ffb23d', '#5a6372', '#39404c', '#171a20'],
    brick: ['#5d6675', '#99a4b5', '#1d2128'], solid: ['#6b7484', '#a8b3c4', '#3b424e'],
    layers: [L('buildings', 0.3, ['#2b323f', '#ffb23d']), L('gears', 0.5, ['#94a3b8'])] }),
  makeBiome({ id: 'foundry', name: 'MOLTEN FOUNDRY', icon: '🔥', family: 'factory',
    sky: ['#1f0e06', '#3d1c0c', '#6b3418'], ground: ['#ff9a3d', '#5c3418', '#3d220f', '#150b05'],
    brick: ['#5c3418', '#96603a', '#160b05'], solid: ['#6b3f1f', '#a87048', '#3f2410'],
    layers: [L('buildings', 0.3, ['#2a1a0f', '#ff9a3d']), L('pipes', 0.5, ['#8a5a3a', '#c4906b'])] }),
  makeBiome({ id: 'clockwork', name: 'CLOCKWORK TOWER', icon: '🕰️', family: 'factory',
    sky: ['#2a2010', '#4a3a1c', '#7a6333'], ground: ['#e8c47a', '#7a5f2f', '#523f1f', '#1c150a'],
    brick: ['#7a5f2f', '#b8975c', '#1c150a'], solid: ['#8a6f3a', '#c9a86f', '#5c4722'],
    layers: [L('gears', 0.28, ['#c9a86f']), L('towers', 0.45, ['#4a3a1c', '#a8884f'])] }),
  makeBiome({ id: 'neoncity', name: 'NEON DISTRICT', icon: '🌃', family: 'factory',
    sky: ['#0a0520', '#1f0a45', '#3d1470'], ground: ['#ff2fd1', '#2a1050', '#1a0a33', '#080314'],
    brick: ['#2a1050', '#5f2f9a', '#0a0418'], solid: ['#3a1a6b', '#7a4fc4', '#1f0d3d'],
    layers: [L('neon', 0.3, ['#ff2fd1', '#2fd6ff', '#ffe34f']), L('buildings', 0.5, ['#140833', '#3d1470'])] }),
  makeBiome({ id: 'serverfarm', name: 'DATA VAULT', icon: '💾', family: 'factory',
    sky: ['#040d14', '#0a1f2a', '#133845'], ground: ['#2fd6ff', '#0f3a4a', '#0a2733', '#031016'],
    brick: ['#0f3a4a', '#2f7f9a', '#031016'], solid: ['#154a5c', '#4f9ab8', '#0a2e3a'],
    layers: [L('gridfloor', 0.3, ['#2fd6ff', '#0f3a4a']), L('buildings', 0.5, ['#0a1f2a', '#2fd6ff'])] }),
  makeBiome({ id: 'steamworks', name: 'STEAMWORKS', icon: '🚂', family: 'factory',
    sky: ['#2a2420', '#453a33', '#6b5c50'], ground: ['#c49a6f', '#5c4a3a', '#3d3127', '#151010'],
    brick: ['#5c4a3a', '#947a60', '#151010'], solid: ['#6b5745', '#a88a6b', '#403327'],
    layers: [L('fog', 0.2, ['#8a7a6b']), L('pipes', 0.35, ['#7a6250', '#b89a7a']), L('gears', 0.55, ['#a89078'])] }),
  makeBiome({ id: 'refinery', name: 'TOXIC REFINERY', icon: '☣️', family: 'factory',
    sky: ['#121a0a', '#243314', '#3f5c24'], ground: ['#9aff2f', '#3f5c1f', '#293d14', '#0d1407'],
    brick: ['#3f5c1f', '#74a03f', '#0d1407'], solid: ['#4a6b26', '#86b852', '#2d4216'],
    layers: [L('pipes', 0.32, ['#4f6b2f', '#86a85f']), L('buildings', 0.5, ['#1a2610', '#9aff2f'])] }),

  // ---- Candy / toy --------------------------------------------------------
  makeBiome({ id: 'sugarrush', name: 'SUGAR RUSH', icon: '🍬', family: 'candy',
    sky: ['#ff7ab8', '#ffa8d4', '#ffd9ec'], ground: ['#ffd1ea', '#f06bb0', '#bd3d80', '#5c1639'],
    brick: ['#f277b4', '#ffc4e2', '#60203f'], solid: ['#f58ac2', '#ffd3eb', '#b24a86'],
    layers: [L('lollipops', 0.3, ['#ff5fa2', '#ffd0e6']), L('candytrees', 0.55, ['#ffffff', '#ff4d79'])] }),
  makeBiome({ id: 'chocolate', name: 'COCOA FALLS', icon: '🍫', family: 'candy',
    sky: ['#8a5f3f', '#b88a64', '#e0c4a8'], ground: ['#d19a6f', '#6b4428', '#472c19', '#190f09'],
    brick: ['#6b4428', '#a07450', '#190f09'], solid: ['#7a5030', '#b4845c', '#4f3018'],
    layers: [L('candytrees', 0.35, ['#4a2c18', '#8a5f3f']), L('geyser', 0.55, ['#b88a64', '#e0c4a8'])] }),
  makeBiome({ id: 'gingerbread', name: 'GINGERBREAD LANE', icon: '🍪', family: 'candy',
    sky: ['#ffc48f', '#ffdfb8', '#fff4e0'], ground: ['#e8a85f', '#a06b33', '#6b4620', '#24170a'],
    brick: ['#a06b33', '#d6a066', '#24170a'], solid: ['#b07a3f', '#e8b478', '#755020'],
    layers: [L('buildings', 0.35, ['#a06b33', '#fff0d6']), L('lollipops', 0.6, ['#ff6f91', '#ffffff'])] }),
  makeBiome({ id: 'sodafizz', name: 'SODA FIZZ FALLS', icon: '🥤', family: 'candy',
    sky: ['#5fd6ff', '#a8ecff', '#e0faff'], ground: ['#ff9ec7', '#4fa8c4', '#2f6b80', '#102730'],
    brick: ['#4fa8c4', '#8fd6e8', '#102730'], solid: ['#5fb8d4', '#9fe4f2', '#2f7a94'],
    layers: [L('bubbles', 0.25, ['#ffffff', '#bdf0ff']), L('lollipops', 0.55, ['#ff5fa2', '#5fffd1'])] }),
  makeBiome({ id: 'toybox', name: 'TOY BOX', icon: '🧸', family: 'candy',
    sky: ['#ffd166', '#ffe9a8', '#fff7d6'], ground: ['#5fc4ff', '#c44f6b', '#8a2f45', '#2f0f18'],
    brick: ['#c44f6b', '#f08a9f', '#2f0f18'], solid: ['#d45f7a', '#ff9fb0', '#8a3450'],
    layers: [L('balloons', 0.3, ['#ff5f5f', '#5fc4ff', '#8aff9e']), L('buildings', 0.5, ['#4f8ac4', '#ffd166'])] }),
  makeBiome({ id: 'circus', name: 'BIG TOP CIRCUS', icon: '🎪', family: 'candy',
    sky: ['#d14f6b', '#f08a9f', '#ffd1da'], ground: ['#ffd166', '#a83f55', '#6b2735', '#240d13'],
    brick: ['#a83f55', '#d6758a', '#240d13'], solid: ['#b84f65', '#e88a9f', '#752f42'],
    layers: [L('balloons', 0.25, ['#ffd166', '#5fc4ff', '#ff5f5f']), L('buildings', 0.45, ['#c44f6b', '#fff0d6'])] }),
  makeBiome({ id: 'arcade', name: 'PIXEL ARCADE', icon: '🕹️', family: 'factory',
    sky: ['#120a2a', '#241450', '#3d2480'], ground: ['#5fffd1', '#2a1a5c', '#1a1040', '#080518'],
    brick: ['#2a1a5c', '#5f3fa0', '#080518'], solid: ['#3a2470', '#7a5fc4', '#1f1450'],
    layers: [L('gridfloor', 0.28, ['#5fffd1', '#2a1a5c']), L('neon', 0.5, ['#ff2fd1', '#5fffd1', '#ffe34f'])] }),

  // ---- Castle / ruins -----------------------------------------------------
  makeBiome({ id: 'fortress', name: 'BOWSER FORTRESS', icon: '🏰', family: 'castle',
    sky: ['#130b24', '#2b1644', '#521d38'], ground: ['#a8b2c7', '#586075', '#363c4d', '#151821'],
    brick: ['#686f82', '#9ea7bd', '#1c1f29'], solid: ['#7d859c', '#b8c1d9', '#424759'],
    layers: [L('stars', 0.08, ['#fff6bd']), L('towers', 0.35, ['#241436', '#ff8c3b'])] }),
  makeBiome({ id: 'rampart', name: 'STORM RAMPARTS', icon: '🛡️', family: 'castle',
    sky: ['#1f2433', '#343c54', '#545e7a'], ground: ['#9fa8bd', '#4a5266', '#313848', '#12151d'],
    brick: ['#4a5266', '#7d8699', '#12151d'], solid: ['#575f75', '#8f99ad', '#333a4a'],
    layers: [L('towers', 0.3, ['#262c3d', '#6b7590']), L('clouds', 0.18, ['#4a5266', '#7d8699'])] }),
  makeBiome({ id: 'dungeon', name: 'IRON DUNGEON', icon: '⛓️', family: 'castle',
    sky: ['#0d0d12', '#1c1c26', '#30303f'], ground: ['#7a7a8a', '#3a3a47', '#26262f', '#0e0e13'],
    brick: ['#3a3a47', '#666675', '#0e0e13'], solid: ['#454554', '#757588', '#2a2a35'],
    layers: [L('pillars', 0.3, ['#262630', '#55555f']), L('lanterns', 0.55, ['#ff9f3d', '#ffd166'])] }),
  makeBiome({ id: 'ruins', name: 'LOST RUINS', icon: '🏛️', family: 'castle',
    sky: ['#6b8a9e', '#a0bccf', '#dfeef5'], ground: ['#9ac47a', '#7a8a8a', '#515c5c', '#1f2525'],
    brick: ['#7a8a8a', '#afbdbd', '#1f2525'], solid: ['#8a9a9a', '#bfcdcd', '#566b6b'],
    layers: [L('ruins', 0.3, ['#8a9a9a', '#cfdcdc']), L('broadleaf', 0.6, ['#3f8a4f', '#7fc46f'])] }),
  makeBiome({ id: 'library', name: 'ANCIENT LIBRARY', icon: '📚', family: 'castle',
    sky: ['#2a1f14', '#453524', '#6b543a'], ground: ['#d6b88a', '#6b5238', '#473624', '#18120c'],
    brick: ['#6b5238', '#a0804f', '#18120c'], solid: ['#7a5f42', '#b4906b', '#4f3d28'],
    layers: [L('pillars', 0.3, ['#4a3824', '#8a6b4f']), L('lanterns', 0.55, ['#ffd166', '#ff9f3d'])] }),
  makeBiome({ id: 'skykeep', name: 'FLOATING KEEP', icon: '🗼', family: 'castle',
    sky: ['#3a4f8a', '#6b84bd', '#b8c9e8'], ground: ['#cfd9f0', '#5f6b94', '#404866', '#171b29'],
    brick: ['#5f6b94', '#95a2c4', '#171b29'], solid: ['#6b7aa4', '#a4b2d6', '#3f4a6b'],
    layers: [L('cloudislands', 0.3, ['#ffffff', '#cfd9f0']), L('towers', 0.5, ['#3f4a6b', '#95a2c4'])] }),

  // ---- Extra worlds (brings the catalog to 100) --------------------------
  makeBiome({ id: 'cherryhill', name: 'CHERRY HILLS', icon: '🌳', family: 'overworld',
    sky: ['#79c6ff', '#b4e2ff', '#eaf7ff'], ground: ['#67d957', '#a2663a', '#6d4222', '#24150a'],
    brick: ['#a2663a', '#d69a68', '#271709'], solid: ['#b2764a', '#e4ab80', '#6d4222'],
    layers: [L('clouds', 0.2, ['#ffffff', '#cfeaff']), L('hills', 0.42, ['#2fa84f', '#6fe07f']), L('broadleaf', 0.62, ['#1f7a3a', '#5fd16f'])] }),
  makeBiome({ id: 'highlands', name: 'MISTY HIGHLANDS', icon: '🏞️', family: 'overworld',
    sky: ['#6f90ad', '#a8c4d8', '#e0ecf5'], ground: ['#7fc46f', '#5c6b4a', '#3d4731', '#161a11'],
    brick: ['#5c6b4a', '#8fa377', '#171b10'], solid: ['#6b7a57', '#9fb488', '#404a33'],
    layers: [L('fog', 0.18, ['#cfdce8']), L('mountains', 0.32, ['#56708a', '#cfe0ee']), L('hills', 0.55, ['#4f8a4f', '#86c47a'])] }),
  makeBiome({ id: 'savanna', name: 'SUNSET SAVANNA', icon: '🦒', family: 'desert',
    sky: ['#e8763a', '#f5a764', '#ffd9a8'], ground: ['#d9b44f', '#8a6b2f', '#5c471c', '#201909'],
    brick: ['#8a6b2f', '#c09a5c', '#211a0a'], solid: ['#9a7a3a', '#d1ab6b', '#5f4a1c'],
    layers: [L('broadleaf', 0.35, ['#4a3a1c', '#8a7a3f']), L('hills', 0.58, ['#b8923f', '#e0bf6b'])] }),
  makeBiome({ id: 'badlands', name: 'DUST BADLANDS', icon: '🌵', family: 'desert',
    sky: ['#b8853f', '#d9ad70', '#f0d6a8'], ground: ['#c9a45f', '#7a5a2f', '#523c1c', '#1c1409'],
    brick: ['#7a5a2f', '#ad8a5c', '#1d150a'], solid: ['#8a6a3a', '#bf9a6b', '#56401f'],
    layers: [L('mesa', 0.3, ['#6b4a26', '#a8793f']), L('cacti', 0.6, ['#3f8a4f'])] }),
  makeBiome({ id: 'tidepool', name: 'TIDE POOLS', icon: '🦀', family: 'beach',
    sky: ['#4fb8d6', '#96dbec', '#dff6fc'], ground: ['#ffe8b8', '#9a8a5f', '#6b5f3d', '#241f12'],
    brick: ['#4f9ab0', '#8fd0e0', '#143039'], solid: ['#5fa8be', '#9fdcea', '#2f6b7c'],
    layers: [L('waves', 0.42, ['#2f9ab8', '#8fd6e8']), L('coral', 0.65, ['#ff8aa8', '#ffd16f'])] }),
  makeBiome({ id: 'driftwood', name: 'DRIFTWOOD SHORE', icon: '🪵', family: 'beach',
    sky: ['#86aec4', '#bdd8e4', '#eef6fa'], ground: ['#e8d6a8', '#8a7550', '#5c4e33', '#1f1a11'],
    brick: ['#8a7550', '#b8a07a', '#201b12'], solid: ['#9a8560', '#c9b48f', '#5f5033'],
    layers: [L('fog', 0.16, ['#cfe0e8']), L('waves', 0.45, ['#5f8fa8', '#a8ccd8']), L('shipwreck', 0.62, ['#5c4a30', '#8a7550', '#d6c4a0'])] }),
  makeBiome({ id: 'kelpforest', name: 'KELP FOREST', icon: '🌊', family: 'underground',
    sky: ['#05283d', '#0a4f66', '#16809e'], ground: ['#3fd6a8', '#166b5c', '#0d473d', '#041c18'],
    brick: ['#166b5c', '#3fa88f', '#04201b'], solid: ['#1c7f6b', '#52bfa3', '#0d4f42'],
    layers: [L('bubbles', 0.22, ['#aef0ff']), L('kelp', 0.42, ['#0a5c45', '#2fa87a']), L('coral', 0.66, ['#ff7a9e', '#7fe8d1'])] }),
  makeBiome({ id: 'thundercoast', name: 'THUNDER COAST', icon: '⚡', family: 'beach',
    sky: ['#1f2f45', '#3a4f6b', '#6b85a0'], ground: ['#c4d6e0', '#4f6b7a', '#344752', '#131c21'],
    brick: ['#4f6b7a', '#85a0ad', '#141d22'], solid: ['#5c7a8a', '#95b0bd', '#36484f'],
    layers: [L('waves', 0.44, ['#2f4f6b', '#6b94ad']), L('clouds', 0.2, ['#45526b', '#7f8ea4'])] }),
  makeBiome({ id: 'rainforest', name: 'EMERALD RAINFOREST', icon: '🦜', family: 'jungle',
    sky: ['#145c3a', '#2f8a5c', '#6bbf94'], ground: ['#5fe07a', '#2f6b3a', '#1f4726', '#0b1a0e'],
    brick: ['#2f6b3a', '#5fa066', '#0c1c10'], solid: ['#3a7a45', '#6fb87a', '#214f2a'],
    layers: [L('broadleaf', 0.3, ['#0f4722', '#1f7a3f']), L('vines', 0.58, ['#3fd16f'])] }),
  makeBiome({ id: 'sporecave', name: 'SPORE GARDEN', icon: '🍄', family: 'underground',
    sky: ['#1a2a1f', '#2f4a36', '#4f7a5c'], ground: ['#8ae89a', '#3a5c42', '#263d2c', '#0e1812'],
    brick: ['#3a5c42', '#6b9a76', '#0f1a13'], solid: ['#466b4f', '#7fae8a', '#2a4531'],
    layers: [L('mushroomtrees', 0.35, ['#4f9a6b', '#8ae89a', '#d6ffd6']), L('stalactites', 0.25, ['#2a3f30', '#3f5c47'])] }),
  makeBiome({ id: 'frostforge', name: 'FROST FORGE', icon: '🔨', family: 'snow',
    sky: ['#1f3a52', '#3f6b8a', '#8fb8cf'], ground: ['#cfe8f5', '#4f6b7a', '#344752', '#131c21'],
    brick: ['#4f6b7a', '#85a0ad', '#141d22'], solid: ['#5c7a8a', '#95b0bd', '#36484f'],
    layers: [L('towers', 0.32, ['#2a4557', '#6b94ad']), L('gears', 0.52, ['#9fc4d6'])] }),
  makeBiome({ id: 'avalanche', name: 'AVALANCHE PASS', icon: '🎿', family: 'snow',
    sky: ['#5f7f9e', '#9fbdd1', '#dfeaf2'], ground: ['#ffffff', '#8aa0b0', '#5f7182', '#232c33'],
    brick: ['#7a8f9e', '#b4c7d4', '#232c33'], solid: ['#8aa0ae', '#c4d6e0', '#52636f'],
    layers: [L('snowpeaks', 0.28, ['#5f7f9e', '#ffffff']), L('pines', 0.58, ['#2a4f38', '#e8f4fa'])] }),
  makeBiome({ id: 'skygarden', name: 'SKY GARDEN', icon: '🌷', family: 'sky',
    sky: ['#8fd6ff', '#c4ecff', '#f0fbff'], ground: ['#8ae87a', '#b8a0d1', '#8a74a8', '#342a40'],
    brick: ['#a88ac4', '#d6c0e8', '#3a2f47'], solid: ['#b89ad1', '#e4d1f0', '#6b5585'],
    layers: [L('cloudislands', 0.35, ['#ffffff', '#d6e8ff']), L('broadleaf', 0.6, ['#3fa85f', '#8ae87a'])] }),
  makeBiome({ id: 'zeppelin', name: 'ZEPPELIN LANES', icon: '🎐', family: 'sky',
    sky: ['#7a9ac4', '#aec4de', '#e0ebf5'], ground: ['#d6c4a0', '#7a6b4f', '#524734', '#1c1811'],
    brick: ['#7a6b4f', '#ab9a7a', '#1d1912'], solid: ['#8a7a5c', '#bfae8a', '#55492f'],
    layers: [L('clouds', 0.2, ['#ffffff', '#d6e4f0']), L('balloons', 0.38, ['#c4a06b', '#8a7550', '#d6c4a0'])] }),
  makeBiome({ id: 'saturnring', name: 'RING OF SATURN', icon: '🪐', family: 'sky',
    sky: ['#0a0818', '#1a1433', '#33285c'], ground: ['#d6c48a', '#5c4f33', '#3d3422', '#15110b'],
    brick: ['#5c4f33', '#8f7f5c', '#161209'], solid: ['#6b5c3f', '#a3926b', '#403522'],
    layers: [L('stars', 0.05, ['#ffffff']), L('planets', 0.15, ['#d6a85f', '#f0d6a0']), L('gridfloor', 0.4, ['#8a7550', '#2a2240'])] }),
  makeBiome({ id: 'alienhive', name: 'ALIEN HIVE', icon: '👽', family: 'haunted',
    sky: ['#0a1f0d', '#15381c', '#2a5c33'], ground: ['#7aff8a', '#2a5c33', '#1c3d22', '#0a160c'],
    brick: ['#2a5c33', '#5c9a66', '#0b170d'], solid: ['#346b3d', '#6fae7a', '#1f4527'],
    layers: [L('crystals', 0.3, ['#4fd16b', '#aeffb8']), L('kelp', 0.55, ['#1f4a26', '#3f8a4a'])] }),
  makeBiome({ id: 'crypt', name: 'SUNKEN CRYPT', icon: '⚰️', family: 'underground',
    sky: ['#0d1014', '#1c232b', '#303c47'], ground: ['#8a9aa8', '#3a444f', '#262d35', '#0e1115'],
    brick: ['#3a444f', '#6b7884', '#0e1115'], solid: ['#45515e', '#7a8894', '#2a333c'],
    layers: [L('fog', 0.18, ['#4f5c6b']), L('pillars', 0.32, ['#262d35', '#5c6875']), L('tombstones', 0.58, ['#6b7884'])] }),
  makeBiome({ id: 'witchwood', name: 'WITCHWOOD', icon: '🧙', family: 'haunted',
    sky: ['#160a24', '#2d1540', '#4a2a66'], ground: ['#9a6fd1', '#3f2a5c', '#2a1c3d', '#100a18'],
    brick: ['#3f2a5c', '#705293', '#110a1a'], solid: ['#4a3370', '#7f62a8', '#2d1f47'],
    layers: [L('deadtrees', 0.35, ['#1f1030']), L('lanterns', 0.58, ['#8aff9e', '#5fd16f'])] }),
  makeBiome({ id: 'emberdeep', name: 'EMBER DEEP', icon: '🪨', family: 'volcano',
    sky: ['#140604', '#2f0d06', '#5c1f0d'], ground: ['#ff6f3b', '#5c2415', '#3d150d', '#140705'],
    brick: ['#5c2415', '#96462c', '#150705'], solid: ['#6b2d1c', '#a85539', '#3f1810'],
    layers: [L('stalactites', 0.3, ['#2f0d06', '#4f1a0d']), L('lavaflow', 0.52, ['#ff4f1f', '#ffb84f'])] }),
  makeBiome({ id: 'cindercity', name: 'CINDER CITY', icon: '🏙️', family: 'volcano',
    sky: ['#2a1410', '#4f241a', '#7a3d26'], ground: ['#ff9a6f', '#6b3424', '#472218', '#180b08'],
    brick: ['#6b3424', '#a05f48', '#190c08'], solid: ['#7a402c', '#b47058', '#4f2618'],
    layers: [L('buildings', 0.32, ['#2f1710', '#ff9a6f']), L('lavaflow', 0.55, ['#ff5f2f', '#ffb84f'])] }),
  makeBiome({ id: 'prismvault', name: 'PRISM VAULT', icon: '🔷', family: 'factory',
    sky: ['#0a1430', '#172a5c', '#2f4a94'], ground: ['#6fd6ff', '#26427a', '#182c52', '#08111f'],
    brick: ['#26427a', '#5c7fc4', '#09121f'], solid: ['#2f5294', '#6b94d6', '#1a3160'],
    layers: [L('crystals', 0.3, ['#6fd6ff', '#cfeeff']), L('gridfloor', 0.5, ['#6fd6ff', '#172a5c'])] }),
];

// ---------------------------------------------------------------------------
// Unique per-level identity
// ---------------------------------------------------------------------------

/** Colour grades applied on top of a biome so repeats never look identical. */
export const BIOME_TINTS: Array<{
  name: string; hue: number; sat: number; bright: number;
}> = [
  // Hue shifts stay moderate so every grade still reads as a believable
  // world rather than a garish colour swap.
  { name: '', hue: 0, sat: 1.0, bright: 1.0 },
  { name: 'VERDANT', hue: -22, sat: 1.12, bright: 1.05 },
  { name: 'AMBER', hue: 22, sat: 1.16, bright: 1.04 },
  { name: 'AZURE', hue: 40, sat: 1.08, bright: 0.99 },
  { name: 'VIOLET', hue: 62, sat: 1.06, bright: 0.96 },
  { name: 'CRIMSON', hue: -40, sat: 1.18, bright: 0.98 },
  { name: 'PALE', hue: 8, sat: 0.66, bright: 1.1 },
  { name: 'DUSK', hue: 46, sat: 0.8, bright: 0.86 },
];

/** Time-of-day washes. */
/** Time-of-day washes. Exactly 8 — the third uniqueness dimension. */
export const BIOME_SKIES: Array<{ name: string; tint: string; alpha: number }> = [
  { name: 'NOON', tint: '#ffffff', alpha: 0 },
  { name: 'DAWN', tint: '#ffb27a', alpha: 0.2 },
  { name: 'GOLDEN', tint: '#ffc24d', alpha: 0.18 },
  { name: 'SUNSET', tint: '#ff7a4d', alpha: 0.24 },
  { name: 'TWILIGHT', tint: '#8f6bd1', alpha: 0.24 },
  { name: 'NIGHT', tint: '#1b2a5e', alpha: 0.38 },
  { name: 'MIDNIGHT', tint: '#0b1437', alpha: 0.46 },
  { name: 'BLOOD MOON', tint: '#b3243a', alpha: 0.28 },
];

// ---------------------------------------------------------------------------
// Colour grading (baked, not a runtime canvas filter)
// ---------------------------------------------------------------------------

function hexToRgb(hex: string): [number, number, number] {
  const h = hex.replace('#', '');
  const v = parseInt(
    h.length === 3 ? h.split('').map((c) => c + c).join('') : h, 16
  );
  return [(v >> 16) & 255, (v >> 8) & 255, v & 255];
}

function rgbToHex(r: number, g: number, b: number): string {
  const c = (n: number) =>
    Math.max(0, Math.min(255, Math.round(n))).toString(16).padStart(2, '0');
  return `#${c(r)}${c(g)}${c(b)}`;
}

/**
 * Applies hue rotation, saturation and brightness to a colour.
 *
 * This replaces a per-frame `ctx.filter`, which is catastrophically slow
 * when the browser falls back to software rasterisation. Doing it once per
 * biome+tint and caching the result costs nothing at render time.
 */
function gradeColor(
  hex: string, hueDeg: number, sat: number, bright: number
): string {
  let [r, g, b] = hexToRgb(hex);
  r /= 255; g /= 255; b /= 255;

  // RGB -> HSL
  const max = Math.max(r, g, b), min = Math.min(r, g, b);
  let h = 0;
  const l = (max + min) / 2;
  const d = max - min;
  let sl = 0;
  if (d !== 0) {
    sl = l > 0.5 ? d / (2 - max - min) : d / (max + min);
    if (max === r) h = ((g - b) / d + (g < b ? 6 : 0)) / 6;
    else if (max === g) h = ((b - r) / d + 2) / 6;
    else h = ((r - g) / d + 4) / 6;
  }

  h = (h + hueDeg / 360 + 1) % 1;
  sl = Math.max(0, Math.min(1, sl * sat));
  const nl = Math.max(0, Math.min(1, l * bright));

  // HSL -> RGB
  if (sl === 0) {
    const v = nl * 255;
    return rgbToHex(v, v, v);
  }
  const q = nl < 0.5 ? nl * (1 + sl) : nl + sl - nl * sl;
  const p = 2 * nl - q;
  const hue2 = (t: number) => {
    let x = t;
    if (x < 0) x += 1;
    if (x > 1) x -= 1;
    if (x < 1 / 6) return p + (q - p) * 6 * x;
    if (x < 1 / 2) return q;
    if (x < 2 / 3) return p + (q - p) * (2 / 3 - x) * 6;
    return p;
  };
  return rgbToHex(hue2(h + 1 / 3) * 255, hue2(h) * 255, hue2(h - 1 / 3) * 255);
}

/** Biome with its palette already graded; cached per biome+tint. */
const gradedCache = new Map<string, BiomeDef>();

export function getGradedBiome(biome: BiomeDef, tintIndex: number): BiomeDef {
  if (tintIndex === 0) return biome;
  const key = `${biome.id}|${tintIndex}`;
  const hit = gradedCache.get(key);
  if (hit) return hit;

  const t = BIOME_TINTS[tintIndex];
  const G = (c: string) => gradeColor(c, t.hue, t.sat, t.bright);
  const tiles = biome.tiles;

  const out: BiomeDef = {
    ...biome,
    // Keep the id unique per grade so the tile cache does not collide.
    id: key,
    sky: [G(biome.sky[0]), G(biome.sky[1]), G(biome.sky[2])],
    tiles: {
      top: G(tiles.top),
      main: G(tiles.main),
      shade: G(tiles.shade),
      crack: G(tiles.crack),
      brick: [G(tiles.brick[0]), G(tiles.brick[1]), G(tiles.brick[2])],
      solid: [G(tiles.solid[0]), G(tiles.solid[1]), G(tiles.solid[2])],
      used: [G(tiles.used[0]), G(tiles.used[1]), G(tiles.used[2])],
    },
    layers: biome.layers.map((l) => ({ ...l, colors: l.colors.map(G) })),
  };

  if (gradedCache.size >= 24) {
    const oldest = gradedCache.keys().next().value;
    if (oldest !== undefined) gradedCache.delete(oldest);
  }
  gradedCache.set(key, out);
  return out;
}

export interface LevelBiome {
  biome: BiomeDef;
  biomeIndex: number;
  tintIndex: number;
  skyIndex: number;
  /** Unique display name for this exact level. */
  name: string;
  icon: string;
  accent: string;
  hueShift: number;
  saturation: number;
  brightness: number;
  skyTint: string;
  skyAlpha: number;
  weather: WeatherKind;
  /** When the weather is active during this level. */
  schedule: WeatherSchedule;
  family: WorldTheme;
}

/**
 * Maps a level number to a one-of-a-kind visual identity.
 *
 * With N biomes x 8 tints x 10 skies the combination space covers the whole
 * campaign, and because the biome index advances every level, two
 * consecutive stages never share a biome either.
 */
export function getLevelBiome(level: number): LevelBiome {
  const idx = Math.max(0, Math.min(TOTAL_LEVELS - 1, Math.floor(level) - 1));
  const n = BIOMES.length;
  const W = WEATHERS.length;

  // 100 biomes x 10 weathers x 8 skies = 8000 unique identities.
  //
  // Weather is offset by the biome index so it changes on EVERY level
  // (a plain `cycle % 10` left the first 100 levels all sharing one
  // weather). Adding the biome index keeps the mapping bijective: for a
  // fixed biome, cycle -> (weather, sky) is still one-to-one.
  const biomeIndex = idx % n;
  const cycle = Math.floor(idx / n); // 0..79
  // Both weather AND sky are offset by the biome index so they each change
  // on every level. Without the offset the sky only advanced once per 1000
  // levels, which meant night never appeared before level 5001.
  //
  // For a fixed biome, cycle -> (cycle % 10, floor(cycle / 10)) is injective
  // over cycle 0..79, and adding a constant to each component preserves
  // that, so all 8000 identities stay unique.
  const weatherIndex = (cycle + biomeIndex) % W;
  const skyIndex =
    (Math.floor(cycle / W) + biomeIndex) % BIOME_SKIES.length;
  const tintIndex = (biomeIndex + cycle * 3) % BIOME_TINTS.length;

  // Schedule is cosmetic variety rather than an identity dimension, so it
  // is hashed from the level number for an unpredictable mix.
  const h = (idx * 2654435761) >>> 0;
  const schedule =
    WEATHER_SCHEDULES[(h >>> 7) % WEATHER_SCHEDULES.length];

  const biome = getGradedBiome(BIOMES[biomeIndex], tintIndex);
  const tint = BIOME_TINTS[tintIndex];
  const sky = BIOME_SKIES[skyIndex];
  const weather = WEATHERS[weatherIndex];
  const wdef = WEATHER_DEFS[weather];

  const palName = tint.name ? `${tint.name} ` : '';
  const suffix = sky.name === 'NOON' ? '' : ` · ${sky.name}`;

  return {
    biome,
    biomeIndex,
    tintIndex,
    skyIndex,
    name: `${wdef.prefix}${palName}${biome.name}${suffix}`,
    icon: biome.icon,
    accent: biome.accent,
    hueShift: tint.hue,
    saturation: tint.sat,
    brightness: tint.bright,
    skyTint: sky.tint,
    skyAlpha: sky.alpha,
    weather,
    schedule,
    family: biome.family,
  };
}

/** Total unique visual identities available. */
export const UNIQUE_IDENTITIES =
  BIOMES.length * WEATHERS.length * BIOME_SKIES.length;
