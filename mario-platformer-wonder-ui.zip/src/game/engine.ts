import { getLevel } from './levels';
import { sound } from './sound';
import {
  BlockBump,
  CoinEntity,
  DIFFICULTY_CONFIG,
  Difficulty,
  getLevelTier,
  THEME_META,
  TOTAL_LEVELS,
  Enemy,
  Fireball,
  FloatingText,
  GameScreen,
  HammerProjectile,
  HudSnapshot,
  InputState,
  ItemKind,
  LevelDefinition,
  MovingPlatform,
  Particle,
  Player,
  PowerItem,
  PowerState,
  TILE_SIZE,
  TileType,
  ENEMY_STATS,
  EnemyProjectile,
  WeaponKind,
  WeaponPickup,
  WEAPONS,
  KickedBlock,
  RewindFrame,
  dailyLevelFor,
  WEATHER_DEFS,
  PetId,
  PETS,
  Relic,
  CharacterId,
  CHARACTERS,
} from './types';
import { getLevelBiome } from './biomes';
import { SCHEDULE_LABEL } from './types';
import { discover } from '../utils/discovery';
import { getTopScore } from '../utils/highScores';
import { addCoins, loadCoins } from '../utils/wallet';
import { recordEnemy, recordItem } from '../utils/bestiary';

const COMBO_SCORES = [100, 200, 400, 800, 1000, 2000, 4000, 8000];

export class MarioGameEngine {
  public screen: GameScreen = 'title';
  public levelDef: LevelDefinition = getLevel(1, 'medium');
  public levelIndex = 0;
  public loopCount = 1;
  public difficulty: Difficulty = 'medium';
  /** Character chosen in the shop; drives speed / jump / fire-rate. */
  public character: CharacterId = 'mario';
  /** Coins banked across runs (shop currency), mirrored for the HUD. */
  public bankedCoins = loadCoins();
  /**
   * Free-trial run: the player is driving a character they do not own, so
   * coins collected are shown but deliberately NOT banked.
   */
  public demoMode = false;
  /** Coins collected during a demo run (discarded at the end). */
  public demoCoins = 0;
  /** Set when the current map's world was visited for the first time. */
  public freshDiscovery = false;
  /** Equipped companion. */
  public pet: PetId = 'none';
  /** Pet follow position + attack cooldown. */
  public petX = 0;
  public petY = 0;
  public petCooldown = 0;
  /** This level's hidden collectible. */
  public relic: Relic | null = null;
  /** Buttons currently held down, keyed "col,row". */
  public pressedButtons = new Set<string>();
  /** True once the level's gate puzzle has been solved. */
  public puzzleSolved = false;
  /** Crates the player can shove around. */
  public pushBlocks: Array<{ x: number; y: number; col: number; row: number }> = [];
  /** Night levels: bolder enemies + secret routes. */
  public isNight = false;
  /** Rain / snow / night make the ground slick. */
  public slippery = false;
  /** Shockwaves from ground slams. */
  public shockwaves: Array<{ x: number; y: number; r: number; max: number }> = [];
  /** Blocks kicked at the player by enemies. */
  public kickedBlocks: KickedBlock[] = [];
  /** Rolling history used by the rewind ability. */
  private rewindBuf: RewindFrame[] = [];
  public rewindCharges = 3;
  public rewinding = false;
  private rewindPlay: RewindFrame[] = [];
  /** Arena boss, when this level has one. */
  public boss: Enemy | null = null;
  /** Levels that host a boss fight. */
  public isBossLevel = false;
  /** True when playing today's shared daily challenge. */
  public isDaily = false;
  /** Session counters feeding the achievement system. */
  public stats = {
    dashes: 0, grapples: 0, slamKills: 0, wallRuns: 0,
    puzzles: 0, relics: 0, clears: 0,
  };

  public tiles: number[][] = [];
  public multiCoinCounts = new Map<string, number>();
  public powCharges = new Map<string, number>();
  public springTimers = new Map<string, number>();
  public bumps: BlockBump[] = [];

  public player!: Player;
  public coinsList: CoinEntity[] = [];
  public enemies: Enemy[] = [];
  public items: PowerItem[] = [];
  public fireballs: Fireball[] = [];
  public hammers: HammerProjectile[] = [];
  public platforms: MovingPlatform[] = [];
  public particles: Particle[] = [];
  public floatingTexts: FloatingText[] = [];

  public score = 0;
  public highScore = getTopScore();
  public coins = 0;
  public lives = 3;
  public maxCombo = 1;
  public timeRemaining = 360;
  public stageBonus = 0;
  public timeBonus = 0;

  public cameraX = 0;
  public viewportWidth = 860;
  public viewportHeight = 480;
  public worldTime = 0;
  public hitStopTimer = 0;
  public shakeTime = 0;
  public shakeMagnitude = 0;

  public flagY = 3 * TILE_SIZE;
  public stageClearTimer = 0;
  public fireworkCount = 0;
  public fireworksLaunched = 0;
  private nextEntityId = 1;
  private timeWarned = false;
  private jumpHeldThisStep = false;
  private bulletTimer = 3;
  /** Index into levelDef.checkpoints that Mario has activated (-1 = none). */
  public checkpointIndex = -1;
  /** Crumbling tiles currently counting down: "col,row" -> seconds left. */
  public crumbleTimers = new Map<string, number>();
  /** Crumbled tiles waiting to respawn: "col,row" -> seconds left. */
  private crumbleRespawn = new Map<string, number>();
  /** True while Mario is gripping a vine. */
  public onVine = false;
  /** Weapons collected this run (persisted between maps). */
  public ownedWeapons: WeaponKind[] = [];
  /** Ammo per weapon; Infinity for the fire flower. */
  public weaponAmmo: Partial<Record<WeaponKind, number>> = {};
  /** Index into ownedWeapons of the equipped weapon. */
  public weaponIndex = 0;
  /** Projectiles fired by enemies. */
  public enemyShots: EnemyProjectile[] = [];
  /** Weapon crates lying in the map. */
  public weaponPickups: WeaponPickup[] = [];
  /** Non-blocking pipe-travel animation state. */
  public warpTimer = 0;
  private warpPhase: 'none' | 'in' | 'out' = 'none';
  private warpDest: { col: number; row: number } | null = null;
  private warpCooldown = 0;
  /** Tile Mario is currently standing on (drives ice / conveyor physics). */
  private groundTile: TileType = TileType.EMPTY;
  /** Remaining flutter-hover seconds for characters that can float. */
  private hoverLeft = 0;

  private onHudChange?: (snapshot: HudSnapshot) => void;
  private lastHudHash = '';

  constructor(onHudChange?: (snapshot: HudSnapshot) => void) {
    this.onHudChange = onHudChange;
    this.loadLevel(0, 'small', true);
    this.screen = 'title';
    this.emitHud(true);
  }

  public setViewport(width: number, height: number): void {
    this.viewportWidth = Math.max(320, width);
    this.viewportHeight = Math.max(240, height);
  }

  public startNewGame(
    startLevelIndex = 0,
    difficulty: Difficulty = 'medium',
    character: CharacterId = 'mario',
    demoMode = false,
    pet: PetId = 'none'
  ): void {
    sound.unlock();
    this.score = 0;
    this.coins = 0;
    this.lives = 3 + CHARACTERS[character].bonusLives;
    this.maxCombo = 1;
    this.loopCount = 1;
    this.difficulty = difficulty;
    this.character = character;
    this.pet = pet;
    this.demoMode = demoMode;
    this.stats = {
      dashes: 0, grapples: 0, slamKills: 0, wallRuns: 0,
      puzzles: 0, relics: 0, clears: 0,
    };
    this.demoCoins = 0;
    this.bankedCoins = loadCoins();
    this.rewindCharges = 3;
    this.ownedWeapons = [];
    this.weaponAmmo = {};
    this.weaponIndex = 0;
    this.highScore = Math.max(this.highScore, getTopScore());
    this.loadLevel(startLevelIndex, 'small', false);
    this.screen = 'playing';
    sound.startMusic(THEME_META[this.levelDef.theme].music, false);
    this.emitHud(true);
  }

  /**
   * Continue a lost run from the last checkpoint of the current map with a
   * fresh set of lives, instead of being sent back to level 1.
   */
  public continueFromCheckpoint(): void {
    sound.unlock();
    this.lives = 3;
    this.coins = 0;
    this.loadLevel(this.levelIndex, 'small', false, this.checkpointIndex);
    this.screen = 'playing';
    sound.startMusic(THEME_META[this.levelDef.theme].music, false);
    this.emitHud(true);
  }

  public continueNextLoop(): void {
    sound.unlock();
    this.loopCount += 1;
    const keepPower = this.player.dead ? 'small' : this.player.power;
    this.loadLevel(0, keepPower, false);
    this.screen = 'playing';
    sound.startMusic(THEME_META[this.levelDef.theme].music, false);
    this.emitHud(true);
  }

  public quitToTitle(): void {
    sound.stopMusic();
    this.loadLevel(0, 'small', true);
    this.screen = 'title';
    this.emitHud(true);
  }

  public togglePause(): void {
    if (this.screen === 'playing') {
      sound.setMood('normal', 0.5);
      this.screen = 'paused';
      sound.stopMusic();
      this.emitHud(true);
    } else if (this.screen === 'paused') {
      this.screen = 'playing';
      sound.startMusic(THEME_META[this.levelDef.theme].music, this.player.starTimer > 0);
      this.emitHud(true);
    }
  }

  public toggleSound(): void {
    sound.toggleSound();
    this.emitHud(true);
  }

  public toggleMusic(): void {
    sound.toggleMusic();
    this.emitHud(true);
  }

  public loadLevel(
    idx: number,
    initialPower: PowerState = 'small',
    isAttract = false,
    fromCheckpoint = -1
  ): void {
    const activeDiff: Difficulty = isAttract ? 'easy' : this.difficulty;
    this.levelIndex = Math.max(0, Math.min(TOTAL_LEVELS - 1, Math.floor(idx)));
    this.levelDef = getLevel(this.levelIndex + 1, activeDiff);
    this.tiles = this.levelDef.tiles.map((row) => [...row]);
    this.multiCoinCounts.clear();
    this.powCharges.clear();
    this.springTimers.clear();
    this.bumps = [];
    this.items = [];
    this.fireballs = [];
    this.hammers = [];
    this.particles = [];
    this.floatingTexts = [];
    this.crumbleTimers.clear();
    this.crumbleRespawn.clear();
    this.onVine = false;
    this.enemyShots = [];
    this.warpTimer = 0;
    this.warpPhase = 'none';
    this.warpDest = null;
    this.warpCooldown = 0.6;
    this.nextEntityId = 1;

    // Weapon crates for this map.
    this.weaponPickups = (this.levelDef.weaponCrates ?? []).map((c) => ({
      id: this.nextEntityId++,
      weapon: c.weapon,
      x: c.col * TILE_SIZE + 3,
      y: c.row * TILE_SIZE,
      vy: 0,
      bob: Math.random() * Math.PI * 2,
      active: true,
    }));

    // Respawning at a checkpoint keeps every earlier flag lit.
    const checkpointList = this.levelDef.checkpoints ?? [];
    this.checkpointIndex = Math.min(fromCheckpoint, checkpointList.length - 1);
    const spawnCol =
      this.checkpointIndex >= 0 ? checkpointList[this.checkpointIndex] : 3;

    for (let r = 0; r < this.tiles.length; r++) {
      for (let c = 0; c < this.tiles[r].length; c++) {
        if (this.tiles[r][c] === TileType.MULTI_COIN_BRICK) {
          this.multiCoinCounts.set(`${c},${r}`, 5);
        } else if (this.tiles[r][c] === TileType.POW_BLOCK) {
          this.powCharges.set(`${c},${r}`, 3);
        }
      }
    }

    this.coinsList = this.levelDef.coins.map((c, i) => ({
      id: this.nextEntityId++,
      x: c.col * TILE_SIZE + TILE_SIZE * 0.5,
      y: c.row * TILE_SIZE + TILE_SIZE * 0.5,
      collected: false,
      bobOffset: i * 0.45,
    }));

    const diffConfig = DIFFICULTY_CONFIG[activeDiff];
    // NPCs get faster both with the chosen difficulty AND the level number.
    const levelSpeed = 1 + Math.min(0.55, (this.levelIndex / TOTAL_LEVELS) * 1.7);
    const speedScale =
      (1 + (this.loopCount - 1) * 0.18) * diffConfig.speed * levelSpeed;
    const enemySpawns = this.levelDef.enemies;

    this.enemies = enemySpawns.map((e) => {
      const isPiranha = e.kind === 'piranha';
      const isBro =
        e.kind === 'hammer_bro' || e.kind === 'fire_bro' ||
        e.kind === 'sniper_bro';
      const isLakitu = e.kind === 'lakitu';
      const stats = ENEMY_STATS[e.kind];
      // Bigger, meaner archetypes read as more dangerous at a glance.
      const w = e.kind === 'armored_goomba' ? 30 : 26;
      const h = isPiranha ? 32 : isBro ? 34 : isLakitu ? 36
        : e.kind === 'armored_goomba' ? 30 : 28;
      const spawnX = isPiranha
        ? (e.col + 1) * TILE_SIZE - w * 0.5
        : e.col * TILE_SIZE + (TILE_SIZE - w) * 0.5;
      const spawnY = isPiranha
        ? e.row * TILE_SIZE + 8
        : isLakitu
          ? e.row * TILE_SIZE
          : (e.row + 1) * TILE_SIZE - h;
      const basePatrol = isBro ? 44 : e.kind === 'spiny' ? 74
        : e.kind === 'dry_bones' ? 64 : 62;
      const patrolSpeed = basePatrol * speedScale * stats.speed;
      // Harder difficulties / deeper levels field elite recolours.
      const eliteChance =
        (activeDiff === 'nightmare' ? 0.3 : activeDiff === 'hard' ? 0.18 : 0.07) +
        Math.min(0.25, this.levelIndex / TOTAL_LEVELS);
      const variant = Math.random() < eliteChance ? 1 : 0;
      const hp = stats.hp + variant;

      return {
        id: this.nextEntityId++,
        kind: e.kind,
        state: 'walk',
        x: spawnX,
        y: spawnY,
        vx: isPiranha || isLakitu ? 0 : -patrolSpeed,
        vy: 0,
        width: w,
        height: h,
        facing: -1,
        onGround: false,
        animTimer: Math.random() * 2,
        stateTimer: isPiranha ? 1.2 : 0,
        kickGraceTimer: 0,
        shellCombo: 0,
        throwCooldown:
          stats.attack !== 'none' && stats.attack !== 'contact'
            ? (stats.attackRate || diffConfig.throwInterval) *
              (0.6 + Math.random() * 0.6)
            : 0,
        throwWindup: 0,
        anchorY: e.row * TILE_SIZE,
        active: isAttract, // Enemies wake up as camera approaches!
        hp,
        maxHp: hp,
        hitFlash: 0,
        frozenTimer: 0,
        variant,
        phase: 0,
        aiTimer: 0,
        kicking: false,
      };
    });

    this.platforms = this.levelDef.platforms.map((p) => ({
      id: this.nextEntityId++,
      x: p.col * TILE_SIZE,
      y: p.row * TILE_SIZE,
      width: p.widthTiles * TILE_SIZE,
      height: 14,
      startX: p.col * TILE_SIZE,
      startY: p.row * TILE_SIZE,
      rangeX: p.rangeCols * TILE_SIZE,
      rangeY: p.rangeRows * TILE_SIZE,
      speed: p.speed,
      phase: p.phase ?? 0,
      vx: 0,
      vy: 0,
    }));

    const pHeight = initialPower === 'small' ? 28 : 50;
    const pWidth = initialPower === 'small' ? 22 : 24;
    this.player = {
      x: spawnCol * TILE_SIZE,
      y: 13 * TILE_SIZE - pHeight,
      vx: 0,
      vy: 0,
      width: pWidth,
      height: pHeight,
      facing: 1,
      power: initialPower,
      onGround: true,
      crouching: false,
      skidding: false,
      coyoteTimer: 0,
      jumpBufferTimer: 0,
      invulnTimer: 0,
      starTimer: 0,
      transformTimer: 0,
      fireCooldown: 0,
      stompCombo: 0,
      animFrame: 0,
      animTimer: 0,
      scaleX: 1,
      scaleY: 1,
      dead: false,
      deathTimer: 0,
      flagSlide: false,
      victoryWalk: false,
      dashTimer: 0,
      dashCooldown: 0,
      airDashesUsed: 0,
      dashDirX: 0,
      dashDirY: 0,
      wallSide: 0,
      wallRunTimer: 0,
      wallCoyote: 0,
      wallClingTime: 0,
      slamming: false,
      slamCharge: 0,
      grappleActive: false,
      grappleX: 0,
      grappleY: 0,
      ropeLen: 0,
      grappleShoot: 0,
      timeSlowTimer: 0,
      magnetTimer: 0,
      shadowTimer: 0,
    };

    // Brief spawn protection so a respawn is never an instant death.
    this.player.invulnTimer = this.checkpointIndex >= 0 ? 2.4 : 1.2;

    // Clear the immediate spawn area of ground enemies.
    const spawnX = spawnCol * TILE_SIZE;
    for (const e of this.enemies) {
      if (e.kind === 'lakitu') continue;
      if (Math.abs(e.x - spawnX) < 2.5 * TILE_SIZE) {
        e.active = false;
        e.x = -9999;
      }
    }

    // Reset per-level feature state.
    this.pressedButtons.clear();
    this.puzzleSolved = false;
    this.shockwaves = [];
    this.petX = this.player?.x ?? 0;
    this.petY = this.player?.y ?? 0;
    this.petCooldown = 0;
    const rl = this.levelDef.relic;
    this.relic = rl
      ? { x: rl.col * TILE_SIZE + 16, y: rl.row * TILE_SIZE + 16,
          collected: false, bob: 0 }
      : null;
    this.pushBlocks = [];
    for (let r = 0; r < this.tiles.length; r++) {
      for (let c = 0; c < this.tiles[r].length; c++) {
        if (this.tiles[r][c] === TileType.PUSH_BLOCK) {
          this.pushBlocks.push({
            x: c * TILE_SIZE, y: r * TILE_SIZE, col: c, row: r,
          });
          this.tiles[r][c] = TileType.EMPTY;
        }
      }
    }

    // Night + slick-floor flags come from the level's sky and weather.
    {
      const lb = getLevelBiome(this.levelIndex + 1);
      this.isNight = lb.skyIndex >= 5;
      const wk = lb.weather;
      this.slippery =
        wk === 'rain' || wk === 'storm' || wk === 'typhoon' ||
        wk === 'snow' || wk === 'blizzard' || wk === 'hail';
    }

    // Every 25th level is a boss arena.
    this.isBossLevel = !isAttract && (this.levelIndex + 1) % 25 === 0;
    this.boss = null;
    this.kickedBlocks = [];
    this.rewindBuf = [];
    this.rewindPlay = [];
    this.rewinding = false;

    // First visit to this world? Celebrate it (and pay a small bounty).
    this.freshDiscovery = false;
    if (!isAttract) {
      const lb = getLevelBiome(this.levelIndex + 1);
      if (discover(lb.biome.id)) {
        this.freshDiscovery = true;
        if (!this.demoMode) this.bankedCoins = addCoins(25);
      }
    }

    this.cameraX = Math.max(0, (spawnCol - 6) * TILE_SIZE);
    if (this.isBossLevel) this.spawnBoss();
    this.timeRemaining = this.levelDef.timeLimit;
    this.timeWarned = false;
    this.flagY = 3.2 * TILE_SIZE;
    this.stageClearTimer = 0;
    this.stageBonus = 0;
    this.timeBonus = 0;
    this.fireworkCount = 0;
    this.fireworksLaunched = 0;
    this.hitStopTimer = 0;
    this.shakeTime = 0;
    this.bulletTimer = 3.5;
  }

  public step(dt: number, rawInput: InputState): void {
    this.worldTime += dt;

    if (this.screen === 'paused' || this.screen === 'gameover' || this.screen === 'victory') {
      this.updateParticles(dt);
      this.updateFloatingTexts(dt);
      return;
    }

    if (this.shakeTime > 0) {
      this.shakeTime = Math.max(0, this.shakeTime - dt);
    }

    if (this.hitStopTimer > 0) {
      this.hitStopTimer = Math.max(0, this.hitStopTimer - dt);
      this.updateParticles(dt);
      this.updateFloatingTexts(dt);
      return;
    }

    // Attract mode AI input on title screen!
    const input: InputState =
      this.screen === 'title' ? this.buildAttractInput() : rawInput;
    this.jumpHeldThisStep = input.jumpHeld;

    if (this.screen === 'stage_clear') {
      this.updateStageClear(dt);
      this.updateParticles(dt);
      this.updateFloatingTexts(dt);
      this.updateBumps(dt);
      this.emitHud(false);
      return;
    }

    // Countdown timer during active gameplay
    if (this.screen === 'playing' && !this.player.dead) {
      this.timeRemaining -= dt * 1.35;
      if (this.timeRemaining <= 100 && !this.timeWarned) {
        this.timeWarned = true;
        sound.timeWarning();
      }
      if (this.timeRemaining <= 0) {
        this.timeRemaining = 0;
        this.killPlayer();
      }
    }

    // The clock costume slows the world but not the player.
    const slow = this.player.timeSlowTimer > 0 ? 0.42 : 1;
    const wdt = dt * slow;

    // Rewind takes over the whole simulation while it plays.
    if (this.rewinding) {
      this.updateRewind();
      this.updateParticles(dt);
      this.emitHud(false);
      return;
    }
    if (this.screen === 'playing' && !this.player.dead) this.recordRewind();

    this.updateBumps(dt);
    this.updateCrumbles(dt);
    this.updateSpringTimers(dt);
    this.updatePlatforms(dt);
    this.updatePlayer(dt, input);
    this.updateItems(dt);
    this.updateWeaponPickups(dt);
    this.updateFireballs(dt);
    this.updateEnemies(wdt);
    this.updateHammers(wdt);
    this.updateEnemyShots(wdt);
    this.updateWarps(dt, input);
    this.updatePuzzle();
    this.updatePushBlocks(dt);
    this.updateRelic();
    this.updatePet(dt);
    this.updateMagnet(dt);
    this.updateShockwaves(dt);
    this.updateMusicMood();
    this.updateKickedBlocks(dt);
    this.updateBoss(wdt);
    this.updateCoins();
    this.updateHazardContacts();
    this.updateParticles(dt);
    this.updateFloatingTexts(dt);
    this.updateCamera(dt);

    // Loop attract mode cleanly if Mario reaches mid-stage or dies
    if (this.screen === 'title') {
      if (this.player.dead || this.player.x > 42 * TILE_SIZE || this.player.y > 520) {
        this.loadLevel(0, 'big', true);
      }
    }

    this.emitHud(false);
  }

  private buildAttractInput(): InputState {
    const p = this.player;
    const aheadCol = Math.floor((p.x + p.width + 26) / TILE_SIZE);
    const footRow = 13;
    const pitAhead =
      aheadCol < this.levelDef.widthCols &&
      this.getTile(aheadCol, footRow) === TileType.EMPTY;

    const wallAhead =
      this.isSolidTile(this.getTile(aheadCol, 12)) ||
      this.isSolidTile(this.getTile(aheadCol, 11));

    const enemyNear = this.enemies.some(
      (e) =>
        e.state === 'walk' &&
        e.x > p.x &&
        e.x - p.x < 78 &&
        Math.abs(e.y - p.y) < 42
    );

    const qBlockAbove =
      this.isQuestionOrPower(this.getTile(Math.floor((p.x + 12) / TILE_SIZE), 9));

    const wantJump = (pitAhead || wallAhead || enemyNear || qBlockAbove) && p.onGround;

    return {
      left: false,
      right: true,
      up: false,
      down: false,
      jumpHeld: wantJump || p.vy < -120,
      jumpPressed: wantJump,
      runHeld: false,
      firePressed: false,
      switchPressed: false,
      enterPipe: false,
      dashPressed: false,
      grapplePressed: false,
    };
  }

  private isQuestionOrPower(t: TileType): boolean {
    return (
      t === TileType.Q_COIN ||
      t === TileType.Q_POWER ||
      t === TileType.Q_STAR ||
      t === TileType.Q_1UP
    );
  }

  /** Solid for movement, but Shadow form phases through thin walls. */
  private blocksPlayer(t: TileType): boolean {
    if (t === TileType.PHASE_WALL) return this.player.shadowTimer <= 0;
    if (t === TileType.GATE) return !this.puzzleSolved;
    return this.isSolidTile(t);
  }

  /** Air-dash: a short burst of invulnerable speed in 8 directions. */
  private tryDash(input: InputState): void {
    const p = this.player;
    if (p.dashCooldown > 0 || p.dashTimer > 0) return;
    const maxAir = this.character === 'rosalina' ? 2 : 1;
    if (!p.onGround && p.airDashesUsed >= maxAir) return;

    let dx = (input.right ? 1 : 0) - (input.left ? 1 : 0);
    let dy = (input.down ? 1 : 0) - (input.up ? 1 : 0);
    if (dx === 0 && dy === 0) dx = p.facing;
    const len = Math.hypot(dx, dy) || 1;
    dx /= len; dy /= len;

    p.dashDirX = dx;
    p.dashDirY = dy;
    p.dashTimer = 0.17;
    p.dashCooldown = 0.42;
    if (!p.onGround) p.airDashesUsed += 1;
    p.grappleActive = false;
    this.stats.dashes += 1;
    this.triggerShake(0.08, 2.6);
    if (this.screen === 'playing') sound.dash();

    for (let i = 0; i < 10; i++) {
      this.spawnParticle({
        kind: 'sparkle',
        x: p.x + p.width * 0.5, y: p.y + p.height * 0.5,
        vx: -dx * (90 + Math.random() * 120) + (Math.random() - 0.5) * 40,
        vy: -dy * (90 + Math.random() * 120) + (Math.random() - 0.5) * 40,
        size: 5, color: i % 2 ? '#a5f3fc' : '#ffffff',
        life: 0.24, gravity: 0,
      });
    }
  }

  /** Fire the grappling hook at the nearest anchor ahead and above. */
  private tryGrapple(): void {
    const p = this.player;
    if (p.grappleActive) { p.grappleActive = false; return; }

    const px = p.x + p.width * 0.5;
    const py = p.y + p.height * 0.5;
    let best: { x: number; y: number; d: number } | null = null;

    const c0 = Math.floor((px - 260) / TILE_SIZE);
    const c1 = Math.floor((px + 260) / TILE_SIZE);
    for (let c = c0; c <= c1; c++) {
      for (let r = 0; r < 13; r++) {
        if (this.getTile(c, r) !== TileType.GRAPPLE_POINT) continue;
        const ax = c * TILE_SIZE + 16;
        const ay = r * TILE_SIZE + 16;
        if (ay > py - 20) continue;            // must be overhead
        const d = Math.hypot(ax - px, ay - py);
        if (d > 250) continue;
        // Prefer anchors in front of the player.
        const score = d - (Math.sign(ax - px) === p.facing ? 40 : 0);
        if (!best || score < best.d) best = { x: ax, y: ay, d: score };
      }
    }
    if (!best) {
      if (this.screen === 'playing') sound.bump();
      return;
    }

    p.grappleActive = true;
    p.grappleX = best.x;
    p.grappleY = best.y;
    p.ropeLen = Math.max(44, Math.hypot(best.x - px, best.y - py));
    p.grappleShoot = 1;
    p.onGround = false;
    this.stats.grapples += 1;
    if (this.screen === 'playing') sound.grapple();
  }

  /** Pendulum physics while swinging on the rope. */
  private updateGrapple(dt: number, input: InputState): void {
    const p = this.player;
    if (!p.grappleActive) return;
    if (p.grappleShoot > 0) p.grappleShoot = Math.max(0, p.grappleShoot - dt * 6);

    // Reel in / pay out.
    if (input.up) p.ropeLen = Math.max(40, p.ropeLen - 150 * dt);
    if (input.down) p.ropeLen = Math.min(260, p.ropeLen + 150 * dt);

    const px = p.x + p.width * 0.5;
    const py = p.y + p.height * 0.5;
    let dx = px - p.grappleX;
    let dy = py - p.grappleY;
    const dist = Math.hypot(dx, dy) || 1;

    // Gravity plus a player-driven pump for building swing speed.
    p.vy += 1500 * dt;
    p.vx += (input.right ? 320 : input.left ? -320 : 0) * dt;

    if (dist > p.ropeLen) {
      // Constrain to the rope and keep only the tangential velocity.
      const nx = dx / dist;
      const ny = dy / dist;
      const corr = dist - p.ropeLen;
      p.x -= nx * corr;
      p.y -= ny * corr;
      const radial = p.vx * nx + p.vy * ny;
      if (radial > 0) {
        p.vx -= nx * radial * 0.96;
        p.vy -= ny * radial * 0.96;
      }
      dx = p.x + p.width * 0.5 - p.grappleX;
      dy = p.y + p.height * 0.5 - p.grappleY;
    }

    // Light damping so the swing settles instead of oscillating forever.
    p.vx *= 0.995;

    if (Math.random() < 0.3) {
      this.spawnParticle({
        kind: 'sparkle', x: px, y: py,
        vx: (Math.random() - 0.5) * 20, vy: 10,
        size: 3, color: '#fcd34d', life: 0.18, gravity: 40,
      });
    }

    // Release with jump for a boosted launch.
    if (input.jumpPressed) {
      p.grappleActive = false;
      p.vy = Math.min(p.vy, -300);
      p.vx *= 1.15;
      if (this.screen === 'playing') sound.jump(true);
    }
  }

  /** Ground slam: dive, then burst with a stunning shockwave. */
  private slamImpact(): void {
    const p = this.player;
    const cx = p.x + p.width * 0.5;
    const cy = p.y + p.height;
    const power = 1 + Math.min(1.4, p.slamCharge);
    const radius = 70 * power;

    this.shockwaves.push({ x: cx, y: cy, r: 8, max: radius });
    this.triggerShake(0.3, 7 * power);
    this.hitStopTimer = 0.05;
    if (this.screen === 'playing') sound.explosion();

    for (let i = 0; i < 18; i++) {
      const a = (Math.PI * i) / 18;
      this.spawnParticle({
        kind: 'dust', x: cx, y: cy,
        vx: Math.cos(a) * (120 + Math.random() * 150) * (i % 2 ? 1 : -1),
        vy: -Math.abs(Math.sin(a)) * (60 + Math.random() * 90),
        size: 7, color: '#e2e8f0', life: 0.4, gravity: 700,
      });
    }

    // Break blocks directly underneath.
    const col = Math.floor(cx / TILE_SIZE);
    const row = Math.floor((cy + 4) / TILE_SIZE);
    for (let d = -1; d <= 1; d++) {
      if (this.getTile(col + d, row) === TileType.BRICK) {
        this.tiles[row][col + d] = TileType.EMPTY;
        this.addScore(50);
      }
    }

    // Shockwave stuns / flips everything standing nearby.
    for (const e of this.enemies) {
      if (!e.active || e.state === 'squished' || e.state === 'flipped') continue;
      const d = Math.hypot(e.x + e.width * 0.5 - cx, e.y + e.height - cy);
      if (d > radius) continue;
      const stats = ENEMY_STATS[e.kind];
      if (stats.hp <= 3 || power > 2) {
        this.flipEnemy(e, stats.score);
        this.stats.slamKills += 1;
      } else {
        e.frozenTimer = Math.max(e.frozenTimer, 1.4);
        e.state = 'frozen';
        e.hitFlash = 0.2;
      }
    }
  }

  /**
   * Picks the music layer from live gameplay state and pushes it to the
   * sound engine. Called every frame; the engine ignores no-op changes.
   */
  private updateMusicMood(): void {
    if (this.screen !== 'playing') return;
    const p = this.player;

    let mood: 'normal' | 'tense' | 'boss' | 'hurry' | 'calm' = 'normal';
    let intensity = 0.5;

    if (this.boss && this.boss.active) {
      mood = 'boss';
      // Ramps up as the boss loses armour.
      intensity = 1 - this.boss.hp / this.boss.maxHp;
    } else if (this.timeRemaining <= 100) {
      mood = 'hurry';
      intensity = 1 - this.timeRemaining / 100;
    } else {
      // Count real threats near the player.
      const px = p.x + p.width * 0.5;
      let near = 0;
      for (const e of this.enemies) {
        if (!e.active || e.state === 'flipped' || e.state === 'squished') continue;
        if (Math.abs(e.x - px) < 300) near++;
      }
      const danger = near + (p.power === 'small' ? 1 : 0) + (this.isNight ? 1 : 0);
      if (danger >= 4) { mood = 'tense'; intensity = Math.min(1, danger / 8); }
      else if (near === 0 && p.power !== 'small') { mood = 'calm'; intensity = 0.4; }
    }

    sound.setMood(mood, intensity);
  }

  private updateShockwaves(dt: number): void {
    for (const sw of this.shockwaves) sw.r += dt * 620;
    this.shockwaves = this.shockwaves.filter((sw) => sw.r < sw.max);
  }

  /** Buttons, gates and pushable crates. */
  private updatePuzzle(): void {
    const pz = this.levelDef.puzzle;
    if (!pz) return;
    const p = this.player;

    this.pressedButtons.clear();
    for (const bt of pz.buttons) {
      const bx = bt.col * TILE_SIZE;
      const by = bt.row * TILE_SIZE;
      // Pressed by the player standing on it...
      const byPlayer =
        p.x + p.width > bx + 4 && p.x < bx + TILE_SIZE - 4 &&
        Math.abs(p.y + p.height - (by + TILE_SIZE)) < 14;
      // ...or by a crate parked on top.
      const byCrate = this.pushBlocks.some(
        (pb) => Math.abs(pb.x - bx) < 20 && Math.abs(pb.y - by) < 20
      );
      if (byPlayer || byCrate) this.pressedButtons.add(`${bt.col},${bt.row}`);
    }

    const solved = this.pressedButtons.size >= pz.buttons.length;
    if (solved && !this.puzzleSolved) {
      this.puzzleSolved = true;
      this.stats.puzzles += 1;
      this.addScore(500);
      const g = pz.gates[0];
      if (g) {
        this.addFloatingText(
          g.col * TILE_SIZE + 16, g.row * TILE_SIZE, 'GATE OPEN!', '#4ade80', 1.2
        );
        this.spawnSparkleBurst(g.col * TILE_SIZE + 16, g.row * TILE_SIZE, '#4ade80', 18);
      }
      this.triggerShake(0.16, 3.5);
      if (this.screen === 'playing') sound.checkpoint();
    }
  }

  /** Crates are shoved along the ground when the player walks into them. */
  private updatePushBlocks(dt: number): void {
    const p = this.player;
    for (const pb of this.pushBlocks) {
      // Gravity.
      const footRow = Math.floor((pb.y + TILE_SIZE + 2) / TILE_SIZE);
      const cc = Math.floor((pb.x + 16) / TILE_SIZE);
      if (!this.isSolidOrBridge(this.getTile(cc, footRow))) {
        pb.y = Math.min(pb.y + 320 * dt, footRow * TILE_SIZE - TILE_SIZE);
      }

      const overlap =
        p.x + p.width > pb.x && p.x < pb.x + TILE_SIZE &&
        p.y + p.height > pb.y + 6 && p.y < pb.y + TILE_SIZE;
      if (!overlap) continue;

      const fromLeft = p.x + p.width * 0.5 < pb.x + 16;
      const dir = fromLeft ? 1 : -1;
      // Only push when actually walking into it.
      if ((dir === 1 && p.vx <= 10) || (dir === -1 && p.vx >= -10)) {
        p.x = fromLeft ? pb.x - p.width - 0.5 : pb.x + TILE_SIZE + 0.5;
        continue;
      }
      const nx = pb.x + dir * 58 * dt;
      const edge = Math.floor((nx + (dir > 0 ? TILE_SIZE : 0)) / TILE_SIZE);
      const midRow = Math.floor((pb.y + 16) / TILE_SIZE);
      if (!this.isSolidTile(this.getTile(edge, midRow))) {
        pb.x = nx;
        pb.col = Math.round(pb.x / TILE_SIZE);
        pb.row = Math.round(pb.y / TILE_SIZE);
        p.vx *= 0.45;
        if (Math.random() < 0.2) this.spawnDust(pb.x + 16, pb.y + TILE_SIZE);
      } else {
        p.x = fromLeft ? pb.x - p.width - 0.5 : pb.x + TILE_SIZE + 0.5;
      }
    }
  }

  /** The hidden relic: a long-term collection goal in every level. */
  private updateRelic(): void {
    const r = this.relic;
    if (!r || r.collected) return;
    const p = this.player;
    if (
      p.x + p.width > r.x - 16 && p.x < r.x + 16 &&
      p.y + p.height > r.y - 16 && p.y < r.y + 16
    ) {
      r.collected = true;
      this.stats.relics += 1;
      this.addScore(2000);
      if (!this.demoMode) this.bankedCoins = addCoins(50);
      this.addFloatingText(r.x, r.y - 16, 'RELIC!', '#fcd34d', 1.4);
      this.spawnSparkleBurst(r.x, r.y, '#fcd34d', 26);
      this.triggerShake(0.18, 4);
      if (this.screen === 'playing') sound.oneUp();
      this.emitHud(true);
    }
  }

  /** Companion pet: trails the player and helps out passively. */
  private updatePet(dt: number): void {
    if (this.pet === 'none') return;
    const def = PETS[this.pet];
    const p = this.player;

    const tx = p.x + p.width * 0.5 - p.facing * 34;
    const ty = p.y - 20 + Math.sin(this.worldTime * 3) * 6;
    this.petX += (tx - this.petX) * Math.min(1, dt * 4.5);
    this.petY += (ty - this.petY) * Math.min(1, dt * 4.5);

    if (def.attacks) {
      this.petCooldown -= dt;
      if (this.petCooldown <= 0) {
        for (const e of this.enemies) {
          if (!e.active || e.state === 'flipped' || e.state === 'squished') continue;
          if (ENEMY_STATS[e.kind].hp > 2) continue;   // weak enemies only
          const d = Math.hypot(
            e.x + e.width * 0.5 - this.petX, e.y + e.height * 0.5 - this.petY
          );
          if (d < 110) {
            this.petCooldown = 2.2;
            this.damageEnemy(e, 1, 'laser', e.x + e.width * 0.5, e.y);
            for (let i = 0; i < 6; i++) {
              this.spawnParticle({
                kind: 'sparkle', x: this.petX, y: this.petY,
                vx: (e.x - this.petX) * 2.5, vy: (e.y - this.petY) * 2.5,
                size: 4, color: def.color, life: 0.18, gravity: 0,
              });
            }
            break;
          }
        }
      }
    }

    // Secret-finders sparkle when the relic is close by.
    if (def.findsSecrets && this.relic && !this.relic.collected) {
      const d = Math.hypot(this.relic.x - p.x, this.relic.y - p.y);
      if (d < 260 && Math.random() < 0.25) {
        this.spawnParticle({
          kind: 'sparkle', x: this.petX, y: this.petY - 8,
          vx: (this.relic.x - this.petX) * 0.5,
          vy: (this.relic.y - this.petY) * 0.5,
          size: 4, color: '#fcd34d', life: 0.4, gravity: 0,
        });
      }
    }
  }

  /** Magnet costume + pet bonus pull nearby coins toward the player. */
  private updateMagnet(dt: number): void {
    const p = this.player;
    const petBonus = PETS[this.pet].magnetBonus;
    const radius = (p.magnetTimer > 0 ? 170 : 0) + petBonus;
    if (radius <= 0) return;

    const px = p.x + p.width * 0.5;
    const py = p.y + p.height * 0.5;
    for (const coin of this.coinsList) {
      if (coin.collected) continue;
      const dx = px - coin.x;
      const dy = py - coin.y;
      const d = Math.hypot(dx, dy);
      if (d > radius || d < 1) continue;
      const pull = (1 - d / radius) * 620 * dt;
      coin.x += (dx / d) * pull;
      coin.y += (dy / d) * pull;
    }
  }

  // ---- Rewind -----------------------------------------------------------

  /** Record one frame of state (~5 seconds of history at 60fps). */
  private recordRewind(): void {
    const p = this.player;
    this.rewindBuf.push({
      px: p.x, py: p.y, vx: p.vx, vy: p.vy, facing: p.facing,
      power: p.power, lives: this.lives, score: this.score,
      camX: this.cameraX, time: this.timeRemaining,
    });
    if (this.rewindBuf.length > 320) this.rewindBuf.shift();
  }

  /** Start rewinding roughly 4 seconds of play. */
  public startRewind(): boolean {
    if (this.rewinding || this.rewindCharges <= 0) return false;
    if (this.rewindBuf.length < 30) return false;
    this.rewindCharges -= 1;
    this.rewinding = true;
    // Play the buffer backwards; 4x speed keeps it snappy.
    this.rewindPlay = this.rewindBuf.slice(-250).reverse();
    this.rewindBuf = [];
    if (this.screen === 'playing') sound.rewind();
    return true;
  }

  private updateRewind(): void {
    const steps = 4;
    for (let i = 0; i < steps; i++) {
      const f = this.rewindPlay.shift();
      if (!f) break;
      const p = this.player;
      p.x = f.px; p.y = f.py; p.vx = 0; p.vy = 0;
      p.facing = f.facing; p.power = f.power;
      this.cameraX = f.camX;
      this.timeRemaining = f.time;
      if (i === 0 && Math.random() < 0.6) {
        this.spawnParticle({
          kind: 'sparkle', x: p.x + p.width * 0.5, y: p.y + p.height * 0.5,
          vx: (Math.random() - 0.5) * 60, vy: (Math.random() - 0.5) * 60,
          size: 6, color: '#a5b4fc', life: 0.3, gravity: 0,
        });
      }
    }
    if (this.rewindPlay.length === 0) {
      // Land safely: cancel the death and give a moment of grace.
      const p = this.player;
      this.rewinding = false;
      p.dead = false;
      p.deathTimer = 0;
      p.vy = 0;
      p.invulnTimer = Math.max(p.invulnTimer, 1.6);
      this.emitHud(true);
    }
  }

  // ---- Stomp-chain rewards ----------------------------------------------

  /** Drop a rare item when the player chains four stomps in one jump. */
  private dropComboReward(x: number, y: number): void {
    const kind: ItemKind = this.player.stompCombo >= 6 ? 'secret_key' : 'elixir';
    this.items.push({
      id: this.nextEntityId++,
      kind,
      x, y: y - 10,
      vx: 0, vy: -280,
      width: 26, height: 26,
      emerging: false,
      emergeTargetY: y,
      animTimer: 0,
      active: true,
    });
    this.addFloatingText(
      x, y - 26,
      kind === 'secret_key' ? 'SECRET KEY!' : 'RARE ELIXIR!',
      kind === 'secret_key' ? '#f0abfc' : '#6ee7b7', 1.3
    );
    this.spawnSparkleBurst(x, y, '#fef08a', 24);
    this.triggerShake(0.2, 5);
    if (this.screen === 'playing') sound.oneUp();
  }

  // ---- Enemies that use the environment ---------------------------------

  /** An enemy boots a loose block along the ground at the player. */
  private enemyKickBlock(e: Enemy): void {
    const dir: 1 | -1 = this.player.x > e.x ? 1 : -1;
    this.kickedBlocks.push({
      id: this.nextEntityId++,
      x: e.x + dir * 20,
      y: e.y + e.height - 26,
      vx: dir * 250,
      vy: -90,
      rot: 0,
      life: 4,
      active: true,
    });
    this.spawnSparkleBurst(e.x + dir * 20, e.y + e.height - 12, '#d6a35c', 8);
    if (this.screen === 'playing') sound.kick();
  }

  private updateKickedBlocks(dt: number): void {
    const p = this.player;
    for (const k of this.kickedBlocks) {
      if (!k.active) continue;
      k.life -= dt;
      k.vy += 1500 * dt;
      k.x += k.vx * dt;
      k.y += k.vy * dt;
      k.rot += (k.vx > 0 ? 7 : -7) * dt;

      const col = Math.floor((k.x + 13) / TILE_SIZE);
      const footRow = Math.floor((k.y + 26) / TILE_SIZE);
      if (k.vy > 0 && this.isSolidOrBridge(this.getTile(col, footRow))) {
        k.y = footRow * TILE_SIZE - 26;
        k.vy = -150;                       // bounce along the ground
      }
      const sideCol = Math.floor((k.x + (k.vx > 0 ? 26 : 0)) / TILE_SIZE);
      const midRow = Math.floor((k.y + 13) / TILE_SIZE);
      if (this.isSolidTile(this.getTile(sideCol, midRow))) {
        k.active = false;
        this.spawnSparkleBurst(k.x + 13, k.y + 13, '#c8a165', 10);
        continue;
      }
      if (k.life <= 0 || k.y > 540 || k.x < this.cameraX - 200) {
        k.active = false;
        continue;
      }

      if (
        !p.dead && p.shadowTimer <= 0 &&
        k.x + 24 > p.x && k.x + 2 < p.x + p.width &&
        k.y + 24 > p.y && k.y + 2 < p.y + p.height
      ) {
        k.active = false;
        if (p.starTimer > 0 || p.dashTimer > 0) {
          this.addScore(200);
          this.spawnSparkleBurst(k.x + 13, k.y + 13, '#ffe94d', 12);
        } else {
          this.damagePlayer();
        }
      }
    }
    this.kickedBlocks = this.kickedBlocks.filter((k) => k.active);
  }

  // ---- Multi-phase boss ---------------------------------------------------

  /** Spawn the arena boss for levels that host one. */
  private spawnBoss(): void {
    const col = this.levelDef.flagCol - 26;
    const stats = ENEMY_STATS.boss;
    const hp = stats.hp + Math.floor(this.levelIndex / 400) * 4;
    const e: Enemy = {
      id: this.nextEntityId++,
      kind: 'boss', state: 'walk',
      x: col * TILE_SIZE, y: 11 * TILE_SIZE - 28,
      vx: -70, vy: 0, width: 52, height: 56,
      facing: -1, onGround: false,
      animTimer: 0, stateTimer: 0, kickGraceTimer: 0, shellCombo: 0,
      throwCooldown: 1.6, throwWindup: 0,
      anchorY: 11 * TILE_SIZE, active: true,
      hp, maxHp: hp, hitFlash: 0, frozenTimer: 0, variant: 1,
      phase: 1, aiTimer: 0, kicking: false,
    };
    this.enemies.push(e);
    this.boss = e;
  }

  /** Boss AI: stomps on the ground, then flies, then cracks the floor. */
  private updateBoss(dt: number): void {
    const e = this.boss;
    if (!e || !e.active || e.state === 'flipped') {
      if (e && (!e.active || e.state === 'flipped')) this.boss = null;
      return;
    }
    const p = this.player;
    const ratio = e.hp / e.maxHp;
    const newPhase = ratio > 0.66 ? 1 : ratio > 0.33 ? 2 : 3;
    if (newPhase !== e.phase) {
      e.phase = newPhase;
      e.hitFlash = 0.5;
      this.triggerShake(0.4, 8);
      this.addFloatingText(
        e.x + e.width * 0.5, e.y - 18, `PHASE ${newPhase}!`, '#f97316', 1.5
      );
      if (this.screen === 'playing') sound.bossPhase(newPhase);
      this.spawnSparkleBurst(e.x + e.width * 0.5, e.y + 20, '#f97316', 30);
      if (this.screen === 'playing') sound.explosion();
    }

    e.animTimer += dt;
    e.aiTimer -= dt;
    e.throwCooldown -= dt;
    const dir: 1 | -1 = p.x > e.x ? 1 : -1;
    e.facing = dir;

    if (e.phase === 1) {
      // Ground charge: walks the arena and lobs fire.
      e.vy = Math.min(600, e.vy + 1500 * dt);
      e.x += e.vx * dt;
      e.y += e.vy * dt;
      const fr = Math.floor((e.y + e.height) / TILE_SIZE);
      const cc = Math.floor((e.x + e.width * 0.5) / TILE_SIZE);
      if (e.vy >= 0 && this.isSolidOrBridge(this.getTile(cc, fr))) {
        e.y = fr * TILE_SIZE - e.height;
        e.vy = 0;
      }
      if (e.aiTimer <= 0) { e.vx = dir * 110; e.aiTimer = 1.4; }
      if (e.throwCooldown <= 0) { e.throwCooldown = 1.9; this.enemyAttack(e); }
    } else if (e.phase === 2) {
      // Airborne: hovers above the player and strafes.
      const tx = p.x - 30;
      const ty = 5 * TILE_SIZE + Math.sin(this.worldTime * 2) * 40;
      e.x += (tx - e.x) * Math.min(1, dt * 1.1);
      e.y += (ty - e.y) * Math.min(1, dt * 1.8);
      e.vy = 0;
      if (e.throwCooldown <= 0) {
        e.throwCooldown = 1.0;
        this.enemyAttack(e);
      }
    } else {
      // Final phase: slams down and shatters the arena floor.
      e.vy += 2200 * dt;
      e.y += e.vy * dt;
      e.x += (p.x - e.x) * Math.min(1, dt * 0.8);
      const fr = Math.floor((e.y + e.height) / TILE_SIZE);
      const cc = Math.floor((e.x + e.width * 0.5) / TILE_SIZE);
      if (e.vy > 240 && this.isSolidOrBridge(this.getTile(cc, fr))) {
        e.y = fr * TILE_SIZE - e.height;
        e.vy = -520;
        this.shockwaves.push({
          x: e.x + e.width * 0.5, y: e.y + e.height, r: 10, max: 150,
        });
        this.triggerShake(0.3, 7);
        if (this.screen === 'playing') sound.explosion();
        // Punch holes in the floor to shrink the safe ground.
        for (let d = -1; d <= 1; d++) {
          const hc = cc + d;
          if (this.getTile(hc, fr) === TileType.BRICK) {
            this.tiles[fr][hc] = TileType.EMPTY;
          }
        }
        if (!p.dead && Math.abs(p.x - e.x) < 150 && p.onGround) {
          this.damagePlayer();
        }
      }
      if (e.throwCooldown <= 0) { e.throwCooldown = 0.8; this.enemyAttack(e); }
    }

    if (!p.dead && this.rectsOverlap(p, e) && p.shadowTimer <= 0) {
      this.handlePlayerEnemyCollision(e);
    }
  }

  private updatePlayer(dt: number, input: InputState): void {
    const p = this.player;

    // The warp animation drives the player directly.
    if (this.warpPhase !== 'none') return;

    if (p.dead) {
      p.deathTimer += dt;
      if (p.deathTimer > 0.32) {
        p.vy += 1450 * dt;
        p.y += p.vy * dt;
      }
      if (p.deathTimer > 2.2 && this.screen === 'playing') {
        this.lives -= 1;
        if (this.lives <= 0) {
          this.lives = 0;
          this.screen = 'gameover';
          if (this.score > this.highScore) this.highScore = this.score;
          sound.gameOver();
          this.emitHud(true);
        } else {
          // Resume from the last checkpoint reached on this map.
          this.loadLevel(
            this.levelIndex,
            'small',
            false,
            this.checkpointIndex
          );
          sound.startMusic(THEME_META[this.levelDef.theme].music, false);
          this.emitHud(true);
        }
      }
      return;
    }

    if (p.transformTimer > 0) {
      p.transformTimer = Math.max(0, p.transformTimer - dt);
    }
    if (p.invulnTimer > 0) {
      p.invulnTimer = Math.max(0, p.invulnTimer - dt);
    }
    if (p.starTimer > 0) {
      p.starTimer = Math.max(0, p.starTimer - dt);
      if (Math.random() < 0.55) {
        this.spawnParticle({
          kind: 'sparkle',
          x: p.x + Math.random() * p.width,
          y: p.y + Math.random() * p.height,
          vx: (Math.random() - 0.5) * 40,
          vy: -30 - Math.random() * 40,
          size: 4 + Math.random() * 3,
          color: ['#ffe94d', '#4df3ff', '#ff4dd8', '#ffffff'][
            Math.floor(Math.random() * 4)
          ],
          life: 0.35,
          gravity: 0,
        });
      }
      if (p.starTimer === 0 && this.screen === 'playing') {
        sound.setStarMusic(false);
      }
    }
    if (p.fireCooldown > 0) {
      p.fireCooldown = Math.max(0, p.fireCooldown - dt);
    }

    // Spring squash/stretch back toward 1.0
    p.scaleX += (1 - p.scaleX) * Math.min(1, dt * 16);
    p.scaleY += (1 - p.scaleY) * Math.min(1, dt * 16);

    // Crouch handling for Big/Fire Mario
    const wantCrouch =
      p.power !== 'small' && input.down && p.onGround && !input.left && !input.right;
    if (wantCrouch && !p.crouching) {
      p.y += p.height - 30;
      p.height = 30;
      p.crouching = true;
    } else if (!wantCrouch && p.crouching) {
      // Ensure ceiling isn't blocking stand-up
      const headClear = !this.rectHitsSolid(p.x + 2, p.y - 20, p.width - 4, 18);
      if (headClear) {
        p.y -= 50 - p.height;
        p.height = 50;
        p.crouching = false;
      }
    }

    // Horizontal acceleration & momentum (ice is slippery, belts push).
    const onIce =
      p.onGround &&
      (this.groundTile === TileType.ICE ||
        (this.slippery && this.groundTile === TileType.GROUND));
    const chr = CHARACTERS[this.character];
    const maxSpeed = (input.runHeld ? 345 : 240) * chr.speed;
    const accel =
      (onIce
        ? 330
        : p.onGround
          ? input.runHeld
            ? 1750
            : 1380
          : 1080) * chr.grip;
    const decel = (onIce ? 110 : p.onGround ? 1480 : 320) * chr.grip;
    const skidDecel = (onIce ? 420 : 2550) * chr.grip;

    p.skidding = false;
    if (!p.crouching) {
      if (input.right && !input.left) {
        p.facing = 1;
        if (p.vx < -45 && p.onGround) {
          p.skidding = true;
          p.vx += skidDecel * dt;
          if (Math.random() < 0.45) this.spawnDust(p.x + p.width, p.y + p.height);
          if (Math.floor(this.worldTime * 20) % 4 === 0 && this.screen === 'playing') {
            sound.skid();
          }
        } else {
          p.vx = Math.min(maxSpeed, p.vx + accel * dt);
        }
      } else if (input.left && !input.right) {
        p.facing = -1;
        if (p.vx > 45 && p.onGround) {
          p.skidding = true;
          p.vx -= skidDecel * dt;
          if (Math.random() < 0.45) this.spawnDust(p.x, p.y + p.height);
          if (Math.floor(this.worldTime * 20) % 4 === 0 && this.screen === 'playing') {
            sound.skid();
          }
        } else {
          p.vx = Math.max(-maxSpeed, p.vx - accel * dt);
        }
      } else {
        if (p.vx > 0) p.vx = Math.max(0, p.vx - decel * dt);
        else if (p.vx < 0) p.vx = Math.min(0, p.vx + decel * dt);
      }
    } else {
      if (p.vx > 0) p.vx = Math.max(0, p.vx - decel * 1.2 * dt);
      else if (p.vx < 0) p.vx = Math.min(0, p.vx + decel * 1.2 * dt);
    }

    // --- Costume timers --------------------------------------------------
    if (p.timeSlowTimer > 0) p.timeSlowTimer = Math.max(0, p.timeSlowTimer - dt);
    if (p.magnetTimer > 0) p.magnetTimer = Math.max(0, p.magnetTimer - dt);
    if (p.shadowTimer > 0) p.shadowTimer = Math.max(0, p.shadowTimer - dt);
    if (p.dashCooldown > 0) p.dashCooldown = Math.max(0, p.dashCooldown - dt);
    if (p.wallCoyote > 0) p.wallCoyote = Math.max(0, p.wallCoyote - dt);
    if (p.onGround) { p.airDashesUsed = 0; p.wallRunTimer = 0.42; }

    // --- Grapple ----------------------------------------------------------
    if (input.grapplePressed) this.tryGrapple();
    if (p.grappleActive) {
      this.updateGrapple(dt, input);
      p.x += p.vx * dt;
      p.y += p.vy * dt;
      this.resolvePlayerX();
      if (p.y > 15.6 * TILE_SIZE) { this.killPlayer(); return; }
      p.animFrame = 1;
      return;
    }

    // --- Dash -------------------------------------------------------------
    if (input.dashPressed) this.tryDash(input);
    if (p.dashTimer > 0) {
      p.dashTimer -= dt;
      const SPD = 640;
      p.vx = p.dashDirX * SPD;
      p.vy = p.dashDirY * SPD * 0.8;
      p.invulnTimer = Math.max(p.invulnTimer, 0.08);
      // Afterimages.
      if (Math.random() < 0.8) {
        this.spawnParticle({
          kind: 'sparkle', x: p.x + p.width * 0.5, y: p.y + p.height * 0.5,
          vx: 0, vy: 0, size: 9, color: '#67e8f9', life: 0.16, gravity: 0,
        });
      }
      p.x += p.vx * dt;
      p.y += p.vy * dt;
      this.resolvePlayerX();
      const pb = p.y + p.height;
      p.y += 0;
      this.resolvePlayerY(pb);
      if (p.dashTimer <= 0) { p.vx *= 0.42; p.vy *= 0.3; }
      return;
    }

    // --- Weapon switching & firing ---------------------------------------
    if (input.switchPressed && this.ownedWeapons.length > 1) {
      this.cycleWeapon();
    }
    if (input.firePressed) {
      this.fireWeapon();
    }

    // Coyote time & Jump buffer
    if (p.onGround) {
      p.coyoteTimer = 0.095;
      p.stompCombo = 0;
    } else {
      p.coyoteTimer = Math.max(0, p.coyoteTimer - dt);
    }

    if (input.jumpPressed) {
      p.jumpBufferTimer = 0.11;
    } else {
      p.jumpBufferTimer = Math.max(0, p.jumpBufferTimer - dt);
    }

    if (p.jumpBufferTimer > 0 && p.coyoteTimer > 0) {
      const speedBonus = Math.abs(p.vx) * 0.15;
      p.vy = -(550 + speedBonus) * CHARACTERS[this.character].jump;
      p.onGround = false;
      p.coyoteTimer = 0;
      p.jumpBufferTimer = 0;
      p.scaleX = 0.82;
      p.scaleY = 1.22;
      this.spawnDust(p.x + p.width * 0.5, p.y + p.height);
      if (this.screen === 'playing') sound.jump(p.power !== 'small');
    }

    // --- Vine climbing (jungle parkour) ---
    const vineCol = Math.floor((p.x + p.width * 0.5) / TILE_SIZE);
    const vineRowTop = Math.floor((p.y + 4) / TILE_SIZE);
    const vineRowMid = Math.floor((p.y + p.height * 0.5) / TILE_SIZE);
    const touchingVine =
      this.getTile(vineCol, vineRowTop) === TileType.VINE ||
      this.getTile(vineCol, vineRowMid) === TileType.VINE;

    if (touchingVine && (input.up || input.down || this.onVine)) {
      if (!this.onVine) {
        this.onVine = true;
        p.vy = 0;
      }
      // Jumping off a vine releases the grip.
      if (input.jumpPressed) {
        this.onVine = false;
        p.vy = -520;
        p.vx = p.facing * 180;
        p.jumpBufferTimer = 0;
        if (this.screen === 'playing') sound.jump(p.power !== 'small');
      } else {
        p.vy = input.up ? -145 : input.down ? 185 : 0;
        p.vx *= 0.6;
        p.x += p.vx * dt;
        p.y += p.vy * dt;
        p.onGround = false;
        p.animTimer += dt * 6;
        p.animFrame = Math.floor(p.animTimer) % 3;
        if (Math.random() < 0.25) {
          this.spawnParticle({
            kind: 'sparkle',
            x: p.x + p.width * 0.5,
            y: p.y + p.height * 0.5,
            vx: (Math.random() - 0.5) * 20,
            vy: 20,
            size: 4,
            color: '#7bf78f',
            life: 0.2,
            gravity: 60,
          });
        }
        return;
      }
    } else if (this.onVine && !touchingVine) {
      this.onVine = false;
    }

    // --- Ground slam ------------------------------------------------------
    if (!p.onGround && input.down && !p.slamming && p.vy > -120) {
      p.slamming = true;
      p.slamCharge = 0;
      p.vx *= 0.3;
      p.vy = 60;
    }
    if (p.slamming) {
      p.vy = Math.min(900, p.vy + 2600 * dt);
      p.slamCharge += dt;
      if (Math.random() < 0.6) {
        this.spawnParticle({
          kind: 'sparkle', x: p.x + Math.random() * p.width, y: p.y,
          vx: 0, vy: -140, size: 5, color: '#fca5a5', life: 0.2, gravity: 0,
        });
      }
      if (p.onGround) {
        this.slamImpact();
        p.slamming = false;
        p.slamCharge = 0;
      }
    }

    // --- Wall cling / wall run / wall jump ---------------------------------
    if (!p.onGround && !p.slamming) {
      const midRow = Math.floor((p.y + p.height * 0.5) / TILE_SIZE);
      const lc = Math.floor((p.x - 3) / TILE_SIZE);
      const rc = Math.floor((p.x + p.width + 3) / TILE_SIZE);
      const lt = this.getTile(lc, midRow);
      const rt = this.getTile(rc, midRow);
      const lWall = this.blocksPlayer(lt);
      const rWall = this.blocksPlayer(rt);

      /**
       * Only treat a wall as climbable when it is genuinely tall.
       *
       * Previously ANY blocked tile counted, so brushing a single crate or
       * a one-tile step turned the next jump into a wall-jump and flung the
       * player backwards. Requiring real height means bumping into ordinary
       * scenery now behaves like a normal jump.
       */
      const tallEnough = (col: number): boolean => {
        // Must be unbroken from the player's middle up past their head, and
        // continue below their feet. Anything shorter is scenery you simply
        // jump over, so it must never trigger a wall-jump.
        const headRow = Math.floor((p.y + 2) / TILE_SIZE);
        const footRow = Math.floor((p.y + p.height - 2) / TILE_SIZE);
        for (let r = headRow - 1; r <= footRow + 1; r++) {
          if (!this.blocksPlayer(this.getTile(col, r))) return false;
        }
        return true;
      };

      const lClimb = lWall && tallEnough(lc);
      const rClimb = rWall && tallEnough(rc);

      p.wallSide = rClimb && input.right ? 1 : lClimb && input.left ? -1 : 0;

      if (p.wallSide !== 0) {
        p.wallCoyote = 0.14;
        const runnable =
          (p.wallSide === 1 ? rt : lt) === TileType.WALL_RUN;
        if (runnable && p.wallRunTimer > 0) {
          p.wallRunTimer -= dt;
          p.vy = -40;                    // hold height while running
          p.vx = p.wallSide * 300;
          if (p.wallRunTimer > 0.4 - dt) this.stats.wallRuns += 1;
          if (Math.random() < 0.5) {
            this.spawnParticle({
              kind: 'dust',
              x: p.x + (p.wallSide === 1 ? p.width : 0), y: p.y + p.height * 0.6,
              vx: -p.wallSide * 70, vy: -20, size: 5,
              color: '#e2e8f0', life: 0.22, gravity: 120,
            });
          }
        } else {
          // Otherwise slide down slowly.
          p.vy = Math.min(p.vy, 120);
        }
      }

      // A wall-jump only fires while actually clinging to a tall wall and
      // still holding into it. Otherwise the normal jump handler runs.
      // `wallCling` only becomes true after a few frames of genuine contact
      // while airborne. Jumping on the same frame you leave the ground next
      // to a block must stay an ordinary jump.
      if (p.wallSide !== 0) p.wallClingTime += dt;
      else p.wallClingTime = 0;

      if (input.jumpPressed && p.wallSide !== 0 && p.wallClingTime > 0.1) {
        const side = p.wallSide;
        p.vy = -520 * CHARACTERS[this.character].jump;
        // Push off gently and keep some forward intent instead of a hard
        // reversal, so a mistimed wall-jump never throws you across the map.
        p.vx = -side * 190;
        p.facing = side === 1 ? -1 : 1;
        p.wallSide = 0;
        p.wallCoyote = 0;
        p.jumpBufferTimer = 0;
        p.airDashesUsed = 0;
        this.spawnDust(p.x + p.width * 0.5, p.y + p.height * 0.6);
        if (this.screen === 'playing') sound.jump(p.power !== 'small');
      }
    } else {
      p.wallSide = 0;
      p.wallClingTime = 0;
    }

    // Flutter-hover: some characters can hang in the air near the apex.
    const hoverMax = CHARACTERS[this.character].hoverTime;
    if (p.onGround) {
      this.hoverLeft = hoverMax;
    }
    let hovering = false;
    if (
      hoverMax > 0 && !p.onGround && input.jumpHeld &&
      p.vy > -40 && this.hoverLeft > 0
    ) {
      hovering = true;
      this.hoverLeft = Math.max(0, this.hoverLeft - dt);
      p.vy = Math.min(p.vy, 48);
      if (Math.random() < 0.4) {
        this.spawnParticle({
          kind: 'sparkle',
          x: p.x + Math.random() * p.width,
          y: p.y + p.height,
          vx: (Math.random() - 0.5) * 30,
          vy: 45,
          size: 4,
          color: '#fef3c7',
          life: 0.22,
          gravity: 60,
        });
      }
    }

    // Variable Mario Gravity with Apex Hang-Time
    let gravity = hovering ? 220 : 1950;
    if (p.vy < 0) {
      if (Math.abs(p.vy) < 95 && input.jumpHeld) {
        gravity = 880;
      } else if (input.jumpHeld) {
        gravity = 1180;
      } else {
        gravity = 2580; // Crisp short-hop cut
      }
    } else if (Math.abs(p.vy) < 85 && input.jumpHeld) {
      gravity = 980;
    }

    p.vy = Math.min(680, p.vy + gravity * dt);

    // Conveyor belts drag Mario along while he is standing on them.
    let beltDrift = 0;
    if (p.onGround) {
      if (this.groundTile === TileType.CONVEYOR_RIGHT) beltDrift = 95;
      else if (this.groundTile === TileType.CONVEYOR_LEFT) beltDrift = -95;
    }

    // Move X & resolve tile collisions
    p.x += (p.vx + beltDrift) * dt;
    const minX = Math.max(0, this.cameraX);
    if (p.x < minX) {
      p.x = minX;
      if (p.vx < 0) p.vx = 0;
    }
    this.resolvePlayerX();

    // Move Y & resolve tile + moving platform + bridge collisions
    const wasOnGround = p.onGround;
    const prevBottom = p.y + p.height;
    p.y += p.vy * dt;
    p.onGround = false;
    this.groundTile = TileType.EMPTY;
    this.resolvePlayerY(prevBottom);
    this.resolvePlayerPlatforms(prevBottom);

    if (!wasOnGround && p.onGround) {
      p.scaleX = 1.2;
      p.scaleY = 0.82;
      this.spawnDust(p.x + p.width * 0.5, p.y + p.height);
    }

    // Check Lava & Pit Death
    const centerCol = Math.floor((p.x + p.width * 0.5) / TILE_SIZE);
    const footRow = Math.floor((p.y + p.height - 2) / TILE_SIZE);
    if (this.getTile(centerCol, footRow) === TileType.LAVA || p.y > 15.6 * TILE_SIZE) {
      this.killPlayer();
      return;
    }

    // Check Flagpole Goal!
    const flagX = this.levelDef.flagCol * TILE_SIZE + TILE_SIZE * 0.5;
    if (this.screen === 'playing' && p.x + p.width >= flagX - 6) {
      this.triggerFlagpole(flagX);
      return;
    }

    // Walk animation frame update
    if (Math.abs(p.vx) > 12 && p.onGround) {
      p.animTimer += dt * (Math.abs(p.vx) / 36);
      p.animFrame = Math.floor(p.animTimer) % 3;
    } else {
      p.animFrame = 0;
      p.animTimer = 0;
    }
  }

  private resolvePlayerX(): void {
    const p = this.player;
    const topRow = Math.floor((p.y + 3) / TILE_SIZE);
    const bottomRow = Math.floor((p.y + p.height - 3) / TILE_SIZE);

    /**
     * Step-up assist.
     *
     * Walking or jumping into a ledge that is only a little taller than the
     * player used to stop them dead (and a ceiling bump could then shove
     * them backwards). Instead, if the obstacle's top edge is within a small
     * threshold of the player's feet and there is headroom above it, lift
     * the player onto it and keep their momentum.
     */
    const tryStepUp = (col: number): boolean => {
      const feet = p.y + p.height;
      for (let r = bottomRow; r >= bottomRow - 1; r--) {
        if (!this.blocksPlayer(this.getTile(col, r))) continue;
        const ledgeTop = r * TILE_SIZE;
        const rise = feet - ledgeTop;
        // Only auto-climb small lips, never a real wall.
        if (rise <= 0 || rise > 14) return false;
        // Need clear space for the whole body above the ledge.
        const needRows = Math.ceil(p.height / TILE_SIZE);
        for (let k = 1; k <= needRows; k++) {
          if (this.blocksPlayer(this.getTile(col, r - k))) return false;
        }
        p.y = ledgeTop - p.height;
        if (p.vy > 0) p.vy = 0;
        p.onGround = true;
        return true;
      }
      return false;
    };

    if (p.vx > 0) {
      const rightCol = Math.floor((p.x + p.width) / TILE_SIZE);
      for (let r = topRow; r <= bottomRow; r++) {
        if (this.blocksPlayer(this.getTile(rightCol, r))) {
          if (tryStepUp(rightCol)) return;
          p.x = rightCol * TILE_SIZE - p.width - 0.01;
          p.vx = 0;
          break;
        }
      }
    } else if (p.vx < 0) {
      const leftCol = Math.floor(p.x / TILE_SIZE);
      for (let r = topRow; r <= bottomRow; r++) {
        if (this.blocksPlayer(this.getTile(leftCol, r))) {
          if (tryStepUp(leftCol)) return;
          p.x = (leftCol + 1) * TILE_SIZE + 0.01;
          p.vx = 0;
          break;
        }
      }
    }
  }

  private resolvePlayerY(prevBottom: number): void {
    const p = this.player;
    const leftCol = Math.floor((p.x + 2) / TILE_SIZE);
    const rightCol = Math.floor((p.x + p.width - 2) / TILE_SIZE);

    if (p.vy >= 0) {
      const bottomRow = Math.floor((p.y + p.height) / TILE_SIZE);
      for (let c = leftCol; c <= rightCol; c++) {
        const tile = this.getTile(c, bottomRow);
        const tileTop = bottomRow * TILE_SIZE;

        if (tile === TileType.SPRING) {
          p.y = tileTop - p.height;
          const superJump = Math.abs(p.vy) > 60;
          p.vy = -755;
          p.onGround = false;
          p.scaleX = 0.76;
          p.scaleY = 1.32;
          this.springTimers.set(`${c},${bottomRow}`, 0.18);
          if (superJump && this.screen === 'playing') sound.spring();
          this.spawnDust(p.x + p.width * 0.5, tileTop);
          return;
        }

        // Jelly pads auto-bounce Mario without needing a jump press.
        if (tile === TileType.JELLY) {
          p.y = tileTop - p.height;
          p.vy = -(this.jumpHeldThisStep ? 640 : 470);
          p.onGround = false;
          p.scaleX = 0.84;
          p.scaleY = 1.24;
          this.springTimers.set(`${c},${bottomRow}`, 0.16);
          if (this.screen === 'playing' && Math.abs(p.vy) > 300) sound.spring();
          this.spawnDust(p.x + p.width * 0.5, tileTop);
          return;
        }

        const oneWayHit =
          (tile === TileType.BRIDGE || tile === TileType.CLOUD) &&
          prevBottom <= tileTop + 8;

        if (this.isSolidTile(tile) || oneWayHit) {
          p.y = tileTop - p.height;
          p.vy = 0;
          p.onGround = true;
          this.groundTile = tile;

          if (tile === TileType.SPIKE) {
            this.damagePlayer();
          } else if (tile === TileType.CRUMBLE) {
            const key = `${c},${bottomRow}`;
            if (!this.crumbleTimers.has(key)) {
              // Long enough to read the shake and react, short enough to rush.
              this.crumbleTimers.set(key, 0.85);
            }
          } else if (tile === TileType.CLOUD) {
            const key = `${c},${bottomRow}`;
            if (!this.crumbleTimers.has(key)) {
              this.crumbleTimers.set(key, 0.8);
            }
          }
          return;
        }
      }
    } else if (p.vy < 0) {
      const topRow = Math.floor(p.y / TILE_SIZE);
      const hitCols: number[] = [];
      for (let c = leftCol; c <= rightCol; c++) {
        if (this.isSolidTile(this.getTile(c, topRow))) {
          hitCols.push(c);
        }
      }

      if (hitCols.length === 0) return;

      // Corner correction: when the player only clips the edge of a block
      // on the way up, slide them around it instead of killing the jump.
      // The window is generous (12px) because being bounced off a ledge you
      // clearly cleared feels like the game cheating.
      if (hitCols.length === 1) {
        const hc = hitCols[0];
        const blockLeft = hc * TILE_SIZE;
        const blockRight = (hc + 1) * TILE_SIZE;
        const overlapRight = p.x + p.width - blockLeft;
        const overlapLeft = blockRight - p.x;

        if (
          overlapRight > 0 &&
          overlapRight <= 12 &&
          !this.isSolidTile(this.getTile(hc - 1, topRow))
        ) {
          p.x = blockLeft - p.width - 0.5;
          return;
        }
        if (
          overlapLeft > 0 &&
          overlapLeft <= 12 &&
          !this.isSolidTile(this.getTile(hc + 1, topRow))
        ) {
          p.x = blockRight + 0.5;
          return;
        }
      }

      // Pick the block closest to Mario's horizontal center to bump!
      const centerX = p.x + p.width * 0.5;
      let bestCol = hitCols[0];
      let bestDist = Infinity;
      for (const hc of hitCols) {
        const dist = Math.abs((hc + 0.5) * TILE_SIZE - centerX);
        if (dist < bestDist) {
          bestDist = dist;
          bestCol = hc;
        }
      }

      p.y = (topRow + 1) * TILE_SIZE + 0.5;
      // Stop the rise but do not shove the player back down — gravity will
      // take over naturally on the next frame.
      p.vy = 0;
      this.hitBlockFromBelow(bestCol, topRow);
    }
  }

  private resolvePlayerPlatforms(prevBottom: number): void {
    const p = this.player;
    if (p.vy < 0) return;
    for (const plat of this.platforms) {
      const horizOverlap =
        p.x + p.width - 3 > plat.x && p.x + 3 < plat.x + plat.width;
      if (!horizOverlap) continue;

      if (
        prevBottom <= plat.y + 10 &&
        p.y + p.height >= plat.y &&
        p.y + p.height <= plat.y + plat.height + 12
      ) {
        p.y = plat.y - p.height;
        p.vy = 0;
        p.onGround = true;
        p.x += plat.vx;
        return;
      }
    }
  }

  private hitBlockFromBelow(col: number, row: number): void {
    const tile = this.getTile(col, row);
    if (!this.isSolidTile(tile)) return;

    const blockCenterX = (col + 0.5) * TILE_SIZE;
    const blockTopY = row * TILE_SIZE;

    // Flip any enemy standing on top of this block!
    for (const enemy of this.enemies) {
      if (
        enemy.active &&
        enemy.kind !== 'piranha' &&
        enemy.state !== 'flipped' &&
        enemy.state !== 'squished'
      ) {
        const ex = enemy.x + enemy.width * 0.5;
        const ey = enemy.y + enemy.height;
        if (
          Math.abs(ex - blockCenterX) < TILE_SIZE * 0.9 &&
          Math.abs(ey - blockTopY) < 12
        ) {
          this.flipEnemy(enemy, 200);
        }
      }
    }

    // Auto-collect any coin resting right above this block
    for (const coin of this.coinsList) {
      if (
        !coin.collected &&
        Math.abs(coin.x - blockCenterX) < TILE_SIZE * 0.7 &&
        Math.abs(coin.y - (blockTopY - TILE_SIZE * 0.5)) < TILE_SIZE * 0.7
      ) {
        this.collectCoin(coin.x, coin.y);
        coin.collected = true;
      }
    }

    if (tile === TileType.Q_COIN) {
      this.tiles[row][col] = TileType.USED_BLOCK;
      this.addBump(col, row, TileType.USED_BLOCK);
      this.collectCoin(blockCenterX, blockTopY - 8, true);
      return;
    }

    if (tile === TileType.MULTI_COIN_BRICK) {
      const key = `${col},${row}`;
      const left = (this.multiCoinCounts.get(key) ?? 1) - 1;
      this.multiCoinCounts.set(key, left);
      if (left <= 0) {
        this.tiles[row][col] = TileType.USED_BLOCK;
        this.addBump(col, row, TileType.USED_BLOCK);
      } else {
        this.addBump(col, row, TileType.BRICK);
      }
      this.collectCoin(blockCenterX, blockTopY - 8, true);
      return;
    }

    if (tile === TileType.Q_POWER) {
      this.tiles[row][col] = TileType.USED_BLOCK;
      this.addBump(col, row, TileType.USED_BLOCK);
      const itemKind: ItemKind =
        this.player.power === 'small' ? 'mushroom' : 'fire_flower';
      this.spawnPowerItem(col, row, itemKind);
      return;
    }

    if (tile === TileType.Q_STAR) {
      this.tiles[row][col] = TileType.USED_BLOCK;
      this.addBump(col, row, TileType.USED_BLOCK);
      // Star blocks also hand out the three costumes.
      const roll = (col * 7 + row * 13 + this.levelIndex) % 4;
      const kind: ItemKind =
        roll === 0 ? 'star' : roll === 1 ? 'clock'
          : roll === 2 ? 'magnet' : 'shadow';
      this.spawnPowerItem(col, row, kind);
      return;
    }

    if (tile === TileType.Q_1UP) {
      this.tiles[row][col] = TileType.USED_BLOCK;
      this.addBump(col, row, TileType.USED_BLOCK);
      this.spawnPowerItem(col, row, 'one_up');
      return;
    }

    if (tile === TileType.POW_BLOCK) {
      this.triggerPowBlock(col, row);
      return;
    }

    if (tile === TileType.BRICK) {
      if (this.player.power !== 'small') {
        // Shatter brick!
        this.tiles[row][col] = TileType.EMPTY;
        this.addScore(50);
        this.triggerShake(0.12, 3.2);
        if (this.screen === 'playing') sound.brickBreak();

        const brickColor =
          this.levelDef.theme === 'underground'
            ? '#3988db'
            : this.levelDef.theme === 'castle'
              ? '#858ea6'
              : '#d96226';

        const dirs = [
          { vx: -135, vy: -340 },
          { vx: 135, vy: -340 },
          { vx: -95, vy: -210 },
          { vx: 95, vy: -210 },
        ];
        for (const d of dirs) {
          this.spawnParticle({
            kind: 'brick',
            x: blockCenterX,
            y: blockTopY + 14,
            vx: d.vx,
            vy: d.vy,
            size: 10,
            color: brickColor,
            life: 0.75,
            gravity: 1350,
            rotSpeed: d.vx > 0 ? 11 : -11,
          });
        }
      } else {
        this.addBump(col, row, TileType.BRICK);
        if (this.screen === 'playing') sound.bump();
      }
      return;
    }

    if (this.screen === 'playing') sound.bump();
  }

  private triggerPowBlock(col: number, row: number): void {
    const key = `${col},${row}`;
    const remaining = (this.powCharges.get(key) ?? 1) - 1;
    if (remaining <= 0) {
      this.tiles[row][col] = TileType.EMPTY;
      this.powCharges.delete(key);
    } else {
      this.powCharges.set(key, remaining);
      this.addBump(col, row, TileType.POW_BLOCK);
    }

    if (this.screen === 'playing') sound.pow();
    this.triggerShake(0.32, 7.5);
    this.hitStopTimer = 0.045;

    const cx = (col + 0.5) * TILE_SIZE;
    const cy = (row + 0.5) * TILE_SIZE;

    this.spawnParticle({
      kind: 'ring',
      x: cx,
      y: cy,
      vx: 0,
      vy: 0,
      size: 16,
      color: '#5ec8ff',
      life: 0.42,
      gravity: 0,
    });
    this.addFloatingText(cx, cy - 20, 'POW!', '#5ec8ff', 1.25);

    let powHits = 0;
    for (const enemy of this.enemies) {
      if (
        !enemy.active ||
        enemy.kind === 'piranha' ||
        enemy.state === 'flipped' ||
        enemy.state === 'squished'
      ) {
        continue;
      }
      if (Math.abs(enemy.x - cx) < 420 && enemy.onGround) {
        powHits++;
        const pts = COMBO_SCORES[Math.min(COMBO_SCORES.length - 1, powHits)];
        this.flipEnemy(enemy, pts);
      }
    }

    // Drop floating coins nearby for extra arcade thrill!
    for (const coin of this.coinsList) {
      if (!coin.collected && Math.abs(coin.x - cx) < 260) {
        coin.collected = true;
        this.collectCoin(coin.x, coin.y, false);
      }
    }
  }

  private spawnPowerItem(col: number, row: number, kind: ItemKind): void {
    if (this.screen === 'playing') sound.powerUpSpawn();
    const x = col * TILE_SIZE + 3;
    const y = row * TILE_SIZE;
    this.items.push({
      id: this.nextEntityId++,
      kind,
      x,
      y,
      vx: kind === 'fire_flower' ? 0 : 82,
      vy: kind !== 'mushroom' && kind !== 'fire_flower' ? -260 : 0,
      width: 26,
      height: 26,
      emerging: true,
      emergeTargetY: (row - 1) * TILE_SIZE + 5,
      animTimer: 0,
      active: true,
    });
  }

  private updateItems(dt: number): void {
    for (const item of this.items) {
      if (!item.active) continue;
      item.animTimer += dt;

      if (item.emerging) {
        item.y -= 48 * dt;
        if (item.y <= item.emergeTargetY) {
          item.y = item.emergeTargetY;
          item.emerging = false;
        }
        continue;
      }

      if (item.kind !== 'fire_flower') {
        item.vy = Math.min(540, item.vy + 1450 * dt);
        item.x += item.vx * dt;

        // Horizontal bounce off solid tiles
        const checkCol =
          item.vx > 0
            ? Math.floor((item.x + item.width) / TILE_SIZE)
            : Math.floor(item.x / TILE_SIZE);
        const midRow = Math.floor((item.y + item.height * 0.5) / TILE_SIZE);
        if (this.isSolidTile(this.getTile(checkCol, midRow))) {
          item.vx = -item.vx;
          item.x += item.vx * dt * 2;
        }

        // Vertical ground/bounce
        item.y += item.vy * dt;
        const footRow = Math.floor((item.y + item.height) / TILE_SIZE);
        const c1 = Math.floor((item.x + 3) / TILE_SIZE);
        const c2 = Math.floor((item.x + item.width - 3) / TILE_SIZE);
        if (
          item.vy >= 0 &&
          (this.isSolidOrBridge(this.getTile(c1, footRow)) ||
            this.isSolidOrBridge(this.getTile(c2, footRow)))
        ) {
          item.y = footRow * TILE_SIZE - item.height;
          item.vy =
            item.kind === 'star' || item.kind === 'clock' ||
            item.kind === 'magnet' || item.kind === 'shadow' ? -410 : 0;
        }
      }

      if (item.y > 540) {
        item.active = false;
        continue;
      }

      // Check player pickup
      if (!this.player.dead && this.rectsOverlap(this.player, item)) {
        item.active = false;
        this.applyPowerItem(item);
      }
    }
  }

  private applyPowerItem(item: PowerItem): void {
    const p = this.player;
    recordItem(item.kind);
    const cx = p.x + p.width * 0.5;
    const cy = p.y;

    if (item.kind === 'one_up') {
      this.lives += 1;
      if (this.screen === 'playing') sound.oneUp();
      this.addFloatingText(cx, cy - 10, '1UP!', '#4ade80', 1.2);
      this.spawnSparkleBurst(cx, cy + 16, '#4ade80', 14);
      return;
    }

    if (item.kind === 'elixir' || item.kind === 'secret_key') {
      if (item.kind === 'elixir') {
        // Full heal + a rewind charge.
        if (p.power === 'small') {
          p.y -= 50 - p.height; p.height = 50; p.width = 24;
        }
        p.power = 'fire';
        this.grantWeapon('fireball', false);
        this.rewindCharges = Math.min(9, this.rewindCharges + 1);
        this.addFloatingText(cx, cy - 10, 'ELIXIR!', '#6ee7b7', 1.3);
      } else {
        // Secret key: instant relic credit plus a big coin bounty.
        if (this.relic && !this.relic.collected) {
          this.relic.collected = true;
          this.stats.relics += 1;
        }
        this.lives += 1;
        if (!this.demoMode) this.bankedCoins = addCoins(100);
        this.addFloatingText(cx, cy - 10, 'SECRET KEY!', '#f0abfc', 1.3);
      }
      this.addScore(3000);
      this.spawnSparkleBurst(cx, cy + 16, '#fef08a', 24);
      if (this.screen === 'playing') sound.costume();
      this.emitHud(true);
      return;
    }

    if (item.kind === 'clock' || item.kind === 'magnet' || item.kind === 'shadow') {
      const DUR = 9;
      if (item.kind === 'clock') {
        p.timeSlowTimer = DUR;
        this.addFloatingText(cx, cy - 10, 'SLOW-MO!', '#a5b4fc', 1.25);
        this.spawnSparkleBurst(cx, cy + 16, '#a5b4fc', 20);
      } else if (item.kind === 'magnet') {
        p.magnetTimer = DUR + 3;
        this.addFloatingText(cx, cy - 10, 'MAGNET!', '#fbbf24', 1.25);
        this.spawnSparkleBurst(cx, cy + 16, '#fbbf24', 20);
      } else {
        p.shadowTimer = DUR - 2;
        this.addFloatingText(cx, cy - 10, 'SHADOW!', '#c084fc', 1.25);
        this.spawnSparkleBurst(cx, cy + 16, '#c084fc', 20);
      }
      this.addScore(1200);
      if (this.screen === 'playing') sound.costume();
      this.emitHud(true);
      return;
    }

    if (item.kind === 'star') {
      p.starTimer = 10.0;
      this.addScore(1000);
      this.addFloatingText(cx, cy - 10, 'STARMAN!', '#ffe94d', 1.2);
      this.spawnSparkleBurst(cx, cy + 16, '#ffe94d', 18);
      if (this.screen === 'playing') {
        sound.powerUpCollect();
        sound.setStarMusic(true);
      }
      return;
    }

    this.addScore(1000);
    this.addFloatingText(cx, cy - 10, '1000', '#ffd93d', 1.1);
    if (this.screen === 'playing') sound.powerUpCollect();

    if (item.kind === 'mushroom') {
      if (p.power === 'small') {
        p.y -= 50 - p.height;
        p.height = 50;
        p.width = 24;
        p.power = 'big';
        p.transformTimer = 0.45;
        p.scaleX = 1.25;
        p.scaleY = 1.25;
      }
      this.spawnSparkleBurst(cx, cy + 20, '#ff5959', 14);
    } else if (item.kind === 'fire_flower') {
      if (p.power === 'small') {
        p.y -= 50 - p.height;
        p.height = 50;
        p.width = 24;
      }
      p.power = 'fire';
      this.grantWeapon('fireball', false);
      p.transformTimer = 0.45;
      p.scaleX = 1.2;
      p.scaleY = 1.2;
      this.spawnSparkleBurst(cx, cy + 20, '#ff9f2e', 16);
    }
  }

  /** Currently equipped weapon, or null when the player owns nothing. */
  public get currentWeapon(): WeaponKind | null {
    if (this.ownedWeapons.length === 0) return null;
    const i = Math.min(this.weaponIndex, this.ownedWeapons.length - 1);
    return this.ownedWeapons[i];
  }

  /** Ammo left for a weapon (-1 means unlimited). */
  public ammoFor(w: WeaponKind): number {
    const a = this.weaponAmmo[w];
    if (a === undefined) return 0;
    return a === Infinity ? -1 : a;
  }

  public cycleWeapon(): void {
    if (this.ownedWeapons.length < 2) return;
    // Skip over weapons that have run dry.
    for (let i = 1; i <= this.ownedWeapons.length; i++) {
      const next = (this.weaponIndex + i) % this.ownedWeapons.length;
      const w = this.ownedWeapons[next];
      const ammo = this.weaponAmmo[w] ?? 0;
      if (ammo > 0) {
        this.weaponIndex = next;
        if (this.screen === 'playing') sound.weaponSwitch();
        this.addFloatingText(
          this.player.x + this.player.width * 0.5,
          this.player.y - 12,
          WEAPONS[w].name,
          WEAPONS[w].glow,
          0.95
        );
        this.emitHud(true);
        return;
      }
    }
  }

  /** Grant a weapon (from a crate or a Fire Flower) and equip it. */
  public grantWeapon(kind: WeaponKind, announce = true): void {
    const def = WEAPONS[kind];
    const have = this.ownedWeapons.includes(kind);
    if (!have) this.ownedWeapons.push(kind);

    const cur = this.weaponAmmo[kind] ?? 0;
    this.weaponAmmo[kind] =
      def.ammoPerPickup === Infinity
        ? Infinity
        : Math.min(99, cur + def.ammoPerPickup);

    this.weaponIndex = this.ownedWeapons.indexOf(kind);

    if (announce) {
      this.addFloatingText(
        this.player.x + this.player.width * 0.5,
        this.player.y - 16,
        have ? `+${def.ammoPerPickup} ${def.name}` : `${def.name}!`,
        def.glow,
        1.15
      );
      this.spawnSparkleBurst(
        this.player.x + this.player.width * 0.5,
        this.player.y + 10,
        def.glow,
        16
      );
      if (this.screen === 'playing') sound.powerUpCollect();
    }
    this.emitHud(true);
  }

  private fireWeapon(): void {
    const p = this.player;
    if (p.dead || p.fireCooldown > 0) return;

    const kind = this.currentWeapon;
    if (!kind) return;
    const def = WEAPONS[kind];

    const ammo = this.weaponAmmo[kind] ?? 0;
    if (ammo <= 0) {
      if (this.screen === 'playing') sound.bump();
      return;
    }
    // Fire Flower shots require the fire power-up to still be active.
    if (kind === 'fireball' && p.power !== 'fire') {
      if (this.screen === 'playing') sound.bump();
      return;
    }

    const live = this.fireballs.filter(
      (f) => f.active && f.weapon === kind
    ).length;
    if (live >= def.maxLive) return;

    p.fireCooldown = def.cooldown * CHARACTERS[this.character].fireRate;
    if (ammo !== Infinity) this.weaponAmmo[kind] = ammo - 1;

    const dir = p.facing;
    this.fireballs.push({
      id: this.nextEntityId++,
      weapon: kind,
      damage: def.damage,
      x: dir === 1 ? p.x + p.width + 2 : p.x - 10,
      y: p.y + p.height * 0.42,
      vx: dir * def.speed + p.vx * 0.2,
      // Arcing weapons get an upward kick; flat ones fly level.
      vy: def.returns || def.gravity === 0 ? 0 : def.explodes ? -290 : 140,
      bounces: 0,
      life: def.returns ? 3.0 : 2.6,
      active: true,
      rotation: 0,
      returning: false,
      hitIds: [],
      travelled: 0,
    });

    // Recoil + muzzle flash make shooting feel punchy.
    // Recoil is a visual nudge only — a heavy weapon should not push the
    // player back into the gap they just jumped over.
    if (!p.onGround) p.vx -= dir * (def.damage >= 3 ? 14 : 6);
    this.spawnParticle({
      kind: 'sparkle',
      x: dir === 1 ? p.x + p.width + 6 : p.x - 6,
      y: p.y + p.height * 0.42,
      vx: dir * 60,
      vy: -20,
      size: 7,
      color: def.glow,
      life: 0.16,
      gravity: 0,
    });

    if (this.screen === 'playing') sound.weaponFire(kind);
    this.emitHud(true);
  }

  private updateFireballs(dt: number): void {
    const p = this.player;

    for (const fb of this.fireballs) {
      if (!fb.active) continue;
      const def = WEAPONS[fb.weapon];

      fb.life -= dt;
      if (fb.life <= 0) {
        if (def.explodes) this.detonate(fb.x, fb.y, fb.damage);
        fb.active = false;
        continue;
      }

      // --- movement ------------------------------------------------------
      if (def.returns) {
        // Boomerang: fly out, stall, then home back to the player.
        fb.travelled += Math.abs(fb.vx) * dt;
        if (!fb.returning && fb.travelled > 210) fb.returning = true;
        if (fb.returning) {
          const dx = p.x + p.width * 0.5 - fb.x;
          const dy = p.y + p.height * 0.45 - fb.y;
          const d = Math.hypot(dx, dy) || 1;
          fb.vx += (dx / d) * 2100 * dt;
          fb.vy += (dy / d) * 2100 * dt;
          const sp = Math.hypot(fb.vx, fb.vy);
          const cap = def.speed * 1.25;
          if (sp > cap) { fb.vx = (fb.vx / sp) * cap; fb.vy = (fb.vy / sp) * cap; }
          // Caught again — recycle it.
          if (d < 22) {
            fb.active = false;
            const a = this.weaponAmmo[fb.weapon];
            if (a !== undefined && a !== Infinity) {
              this.weaponAmmo[fb.weapon] = Math.min(99, a + 1);
            }
            continue;
          }
        }
      } else {
        fb.vy += def.gravity * dt;
      }

      fb.x += fb.vx * dt;
      fb.y += fb.vy * dt;
      fb.rotation += (def.returns ? 22 : def.explodes ? 9 : 18) * dt;

      // --- trail ---------------------------------------------------------
      if (Math.random() < (def.piercing ? 0.9 : 0.55)) {
        this.spawnParticle({
          kind: 'flame',
          x: fb.x,
          y: fb.y,
          vx: (Math.random() - 0.5) * 26,
          vy: -18 - Math.random() * 22,
          size: def.explodes ? 6 : 5,
          color: Math.random() < 0.5 ? def.color : def.glow,
          life: 0.2,
          gravity: 0,
        });
      }

      if (fb.x < this.cameraX - 260 || fb.y > 540) { fb.active = false; continue; }

      // --- terrain -------------------------------------------------------
      const col = Math.floor(fb.x / TILE_SIZE);
      const row = Math.floor(fb.y / TILE_SIZE);
      const footRow = Math.floor((fb.y + 6) / TILE_SIZE);

      if (!def.returns && fb.vy > 0 && this.isSolidOrBridge(this.getTile(col, footRow))) {
        if (def.bouncy) {
          fb.y = footRow * TILE_SIZE - 6;
          fb.vy = def.explodes ? -250 : -305;
          fb.bounces += 1;
          if (def.explodes && fb.bounces >= 2) {
            this.detonate(fb.x, fb.y, fb.damage);
            fb.active = false;
            continue;
          }
        } else {
          if (def.explodes) this.detonate(fb.x, fb.y, fb.damage);
          else this.spawnSparkleBurst(fb.x, fb.y, def.color, 8);
          fb.active = false;
          if (this.screen === 'playing') sound.bump();
          continue;
        }
      } else if (!def.returns && this.isSolidTile(this.getTile(col, row))) {
        // Laser punches through one block of scenery; everything else stops.
        if (def.explodes) this.detonate(fb.x, fb.y, fb.damage);
        else this.spawnSparkleBurst(fb.x, fb.y, def.color, 8);
        fb.active = false;
        if (this.screen === 'playing') sound.bump();
        continue;
      }

      // --- intercept enemy fire -------------------------------------------
      for (const shot of this.enemyShots) {
        if (!shot.active) continue;
        if (Math.abs(fb.x - shot.x) < 16 && Math.abs(fb.y - shot.y) < 16) {
          shot.active = false;
          this.spawnSparkleBurst(shot.x, shot.y, def.glow, 9);
          this.addScore(50);
          if (!def.piercing) fb.active = false;
          if (this.screen === 'playing') sound.bump();
          break;
        }
      }
      if (!fb.active) continue;

      for (const hammer of this.hammers) {
        if (!hammer.active) continue;
        if (Math.abs(fb.x - hammer.x) < 16 && Math.abs(fb.y - hammer.y) < 16) {
          hammer.active = false;
          this.spawnSparkleBurst(hammer.x, hammer.y, def.glow, 9);
          if (!def.piercing) fb.active = false;
          if (this.screen === 'playing') sound.bump();
          break;
        }
      }
      if (!fb.active) continue;

      // --- enemy hits ------------------------------------------------------
      for (const enemy of this.enemies) {
        if (!enemy.active || enemy.state === 'squished' || enemy.state === 'flipped') {
          continue;
        }
        if (def.piercing && fb.hitIds.includes(enemy.id)) continue;
        if (
          fb.x + 7 > enemy.x && fb.x - 7 < enemy.x + enemy.width &&
          fb.y + 7 > enemy.y && fb.y - 7 < enemy.y + enemy.height
        ) {
          if (def.explodes) {
            this.detonate(fb.x, fb.y, fb.damage);
            fb.active = false;
          } else {
            this.damageEnemy(enemy, fb.damage, fb.weapon, fb.x, fb.y);
            if (def.piercing) fb.hitIds.push(enemy.id);
            else fb.active = false;
          }
          break;
        }
      }
    }

    this.fireballs = this.fireballs.filter((f) => f.active);
  }

  /** Bob-omb blast: damages everything in a radius. */
  private detonate(x: number, y: number, damage: number): void {
    const RADIUS = 86;
    this.triggerShake(0.3, 7);
    this.hitStopTimer = 0.05;
    if (this.screen === 'playing') sound.explosion();

    this.spawnParticle({
      kind: 'ring', x, y, vx: 0, vy: 0, size: 12,
      color: '#ff9f43', life: 0.4, gravity: 0,
    });
    for (let i = 0; i < 22; i++) {
      const a = (Math.PI * 2 * i) / 22;
      this.spawnParticle({
        kind: 'flame',
        x, y,
        vx: Math.cos(a) * (120 + Math.random() * 150),
        vy: Math.sin(a) * (120 + Math.random() * 150),
        size: 7 + Math.random() * 4,
        color: i % 3 === 0 ? '#fff3c4' : i % 3 === 1 ? '#ff9f43' : '#ff4d20',
        life: 0.42 + Math.random() * 0.2,
        gravity: 420,
      });
    }

    for (const e of this.enemies) {
      if (!e.active || e.state === 'squished' || e.state === 'flipped') continue;
      const dx = e.x + e.width * 0.5 - x;
      const dy = e.y + e.height * 0.5 - y;
      if (Math.hypot(dx, dy) <= RADIUS) {
        this.damageEnemy(e, damage, 'bomb', e.x + e.width * 0.5, e.y);
      }
    }
    for (const shot of this.enemyShots) {
      if (!shot.active) continue;
      if (Math.hypot(shot.x - x, shot.y - y) <= RADIUS) shot.active = false;
    }
    // Blasts also shatter nearby breakable bricks.
    const c0 = Math.floor((x - RADIUS) / TILE_SIZE);
    const c1 = Math.floor((x + RADIUS) / TILE_SIZE);
    const r0 = Math.floor((y - RADIUS) / TILE_SIZE);
    const r1 = Math.floor((y + RADIUS) / TILE_SIZE);
    for (let r = r0; r <= r1; r++) {
      for (let c = c0; c <= c1; c++) {
        if (this.getTile(c, r) === TileType.BRICK) {
          this.tiles[r][c] = TileType.EMPTY;
          this.addScore(50);
        }
      }
    }
  }

  /**
   * Apply weapon damage to an enemy, honouring its resistances.
   * Returns true when the hit actually landed.
   */
  public damageEnemy(
    enemy: Enemy,
    amount: number,
    weapon: WeaponKind,
    hx: number,
    hy: number
  ): boolean {
    const stats = ENEMY_STATS[enemy.kind];
    const def = WEAPONS[weapon];

    // Resistances: armour shrugs off the wrong element.
    const isFire = weapon === 'fireball';
    const isIce = weapon === 'iceball';
    if ((isFire && stats.fireProof) || (isIce && stats.freezeProof)) {
      this.spawnSparkleBurst(hx, hy, '#9ec5ff', 7);
      this.addFloatingText(hx, hy - 10, 'BLOCK', '#9ec5ff', 0.85);
      if (this.screen === 'playing') sound.bump();
      return false;
    }

    enemy.hp -= amount;
    enemy.hitFlash = 0.18;
    this.spawnSparkleBurst(hx, hy, def.glow, 8);
    this.triggerShake(0.06, 1.8);

    if (def.freezes && !stats.freezeProof) {
      enemy.frozenTimer = 4.5;
      enemy.state = 'frozen';
      enemy.vx = 0;
      this.spawnSparkleBurst(hx, hy, '#bae6fd', 12);
    }

    if (enemy.hp > 0) {
      // Knockback reads as a solid hit even when the enemy survives.
      enemy.x += Math.sign(enemy.x + enemy.width * 0.5 - hx) * 3;
      this.addFloatingText(hx, hy - 8, `-${amount}`, def.glow, 0.8);
      if (this.screen === 'playing') sound.enemyHurt();
      return true;
    }

    recordEnemy(enemy.kind);
    this.flipEnemy(enemy, stats.score);
    return true;
  }

  private updateHammers(dt: number): void {
    const p = this.player;

    for (const hammer of this.hammers) {
      if (!hammer.active) continue;

      hammer.life -= dt;
      hammer.vy += 1080 * dt;
      hammer.x += hammer.vx * dt;
      hammer.y += hammer.vy * dt;
      hammer.rotation += hammer.rotSpeed * dt;

      if (hammer.life <= 0 || hammer.y > 540) {
        hammer.active = false;
        continue;
      }

      // Hammer shatters against solid terrain / bridge planks.
      const col = Math.floor(hammer.x / TILE_SIZE);
      const footRow = Math.floor((hammer.y + 8) / TILE_SIZE);
      if (
        hammer.vy > 0 &&
        this.isSolidOrBridge(this.getTile(col, footRow))
      ) {
        hammer.active = false;
        this.spawnSparkleBurst(hammer.x, hammer.y, '#ffb020', 6);
        continue;
      }

      if (
        !p.dead &&
        hammer.x + 9 > p.x &&
        hammer.x - 9 < p.x + p.width &&
        hammer.y + 9 > p.y &&
        hammer.y - 9 < p.y + p.height
      ) {
        hammer.active = false;
        if (p.starTimer > 0) {
          this.spawnSparkleBurst(hammer.x, hammer.y, '#ffe94d', 10);
          this.addFloatingText(hammer.x, hammer.y - 8, '500', '#ffe94d', 0.95);
          this.addScore(500);
        } else {
          this.spawnSparkleBurst(hammer.x, hammer.y, '#ffb020', 10);
          this.damagePlayer();
        }
      }
    }

    this.hammers = this.hammers.filter((h) => h.active);
  }

  /** Fire an enemy projectile at the player. */
  private enemyAttack(e: Enemy): void {
    const stats = ENEMY_STATS[e.kind];
    const p = this.player;
    const sx = e.x + e.width * 0.5;
    const sy = e.y + e.height * 0.35;
    const dx = p.x + p.width * 0.5 - sx;
    const dy = p.y + p.height * 0.5 - sy;
    const dir: 1 | -1 = dx >= 0 ? 1 : -1;
    e.facing = dir;

    let vx = 0, vy = 0, gravity = 0, rotSpeed = 0, life = 3;
    switch (stats.attack) {
      case 'hammer':
        vx = Math.max(-250, Math.min(250, dx * 0.72 + p.vx * 0.1));
        vy = -365; gravity = 1080; rotSpeed = dir * 11;
        break;
      case 'fire': {
        const d = Math.hypot(dx, dy) || 1;
        vx = (dx / d) * 265; vy = (dy / d) * 265 - 40;
        gravity = 190; rotSpeed = dir * 14;
        break;
      }
      case 'bone':
        vx = Math.max(-230, Math.min(230, dx * 0.66));
        vy = -320; gravity = 980; rotSpeed = dir * 16;
        break;
      case 'spit': {
        const d = Math.hypot(dx, dy) || 1;
        vx = (dx / d) * 230; vy = (dy / d) * 230;
        gravity = 260; life = 2.2;
        break;
      }
      case 'laser': {
        const d = Math.hypot(dx, dy) || 1;
        vx = (dx / d) * 500; vy = (dy / d) * 500;
        gravity = 0; life = 2.0;
        break;
      }
      default:
        return;
    }

    this.enemyShots.push({
      id: this.nextEntityId++,
      kind: stats.attack,
      x: sx + dir * 10,
      y: sy,
      vx, vy, gravity,
      rotation: 0,
      rotSpeed,
      life,
      power: stats.power,
      active: true,
    });

    this.spawnParticle({
      kind: 'sparkle', x: sx + dir * 10, y: sy,
      vx: dir * 40, vy: -20, size: 6,
      color: stats.tint, life: 0.2, gravity: 0,
    });
    if (this.screen === 'playing') sound.enemyShoot(stats.attack);
  }

  /** Move enemy projectiles and resolve hits on the player. */
  private updateEnemyShots(dt: number): void {
    const p = this.player;
    for (const s of this.enemyShots) {
      if (!s.active) continue;
      s.life -= dt;
      s.vy += s.gravity * dt;
      s.x += s.vx * dt;
      s.y += s.vy * dt;
      s.rotation += s.rotSpeed * dt;

      if (s.kind === 'fire' || s.kind === 'laser') {
        this.spawnParticle({
          kind: 'flame', x: s.x, y: s.y,
          vx: (Math.random() - 0.5) * 20, vy: -14,
          size: 4, color: s.kind === 'laser' ? '#d8b4fe' : '#ff9f43',
          life: 0.18, gravity: 0,
        });
      }

      if (s.life <= 0 || s.y > 540 || s.x < this.cameraX - 220) {
        s.active = false;
        continue;
      }

      const col = Math.floor(s.x / TILE_SIZE);
      const row = Math.floor(s.y / TILE_SIZE);
      if (this.isSolidTile(this.getTile(col, row))) {
        s.active = false;
        this.spawnSparkleBurst(s.x, s.y, '#ffb020', 6);
        continue;
      }

      if (
        !p.dead &&
        s.x + 8 > p.x && s.x - 8 < p.x + p.width &&
        s.y + 8 > p.y && s.y - 8 < p.y + p.height
      ) {
        s.active = false;
        if (p.starTimer > 0) {
          this.spawnSparkleBurst(s.x, s.y, '#ffe94d', 10);
          this.addScore(100);
        } else {
          this.spawnSparkleBurst(s.x, s.y, '#ff6b6b', 12);
          // Heavy hitters strip a full power level extra.
          if (s.power >= 2 && p.power === 'fire') p.power = 'big';
          this.damagePlayer();
        }
      }
    }
    this.enemyShots = this.enemyShots.filter((s) => s.active);
  }

  /** Pick up weapon crates lying in the level. */
  private updateWeaponPickups(dt: number): void {
    const p = this.player;
    for (const w of this.weaponPickups) {
      if (!w.active) continue;
      w.bob += dt * 3;
      // Settle onto the ground if it was placed in mid-air.
      const footRow = Math.floor((w.y + 28) / TILE_SIZE);
      const cc = Math.floor((w.x + 13) / TILE_SIZE);
      if (!this.isSolidOrBridge(this.getTile(cc, footRow))) {
        w.vy = Math.min(420, w.vy + 1300 * dt);
        w.y += w.vy * dt;
      } else {
        w.vy = 0;
        w.y = footRow * TILE_SIZE - 28;
      }

      if (
        !p.dead &&
        p.x + p.width > w.x && p.x < w.x + 26 &&
        p.y + p.height > w.y && p.y < w.y + 26
      ) {
        w.active = false;
        this.grantWeapon(w.weapon, true);
        this.addScore(300);
      }
    }
  }

  /**
   * Warp pipes: hold Down on an enterable pipe lip to travel to its partner.
   * Plays a short non-blocking suck-in / rise-out animation.
   */
  private updateWarps(dt: number, input: InputState): void {
    const p = this.player;
    if (this.warpCooldown > 0) this.warpCooldown -= dt;

    if (this.warpPhase === 'in') {
      this.warpTimer -= dt;
      p.y += 58 * dt;
      p.vx = 0;
      if (this.warpTimer <= 0 && this.warpDest) {
        // Emerge from the destination pipe.
        p.x = this.warpDest.col * TILE_SIZE + TILE_SIZE - p.width * 0.5;
        p.y = this.warpDest.row * TILE_SIZE;
        this.cameraX = Math.max(0, p.x - 220);
        this.warpPhase = 'out';
        this.warpTimer = 0.42;
        this.spawnSparkleBurst(p.x + p.width * 0.5, p.y + 16, '#7bf78f', 18);
        if (this.screen === 'playing') sound.warp();
      }
      return;
    }

    if (this.warpPhase === 'out') {
      this.warpTimer -= dt;
      p.y -= 54 * dt;
      p.vx = 0;
      p.vy = 0;
      if (this.warpTimer <= 0) {
        this.warpPhase = 'none';
        this.warpCooldown = 0.7;
        p.invulnTimer = Math.max(p.invulnTimer, 0.8);
      }
      return;
    }

    if (!input.enterPipe || !p.onGround || this.warpCooldown > 0) return;

    const warps = this.levelDef.warps ?? [];
    if (warps.length < 2) return;

    const feetRow = Math.floor((p.y + p.height + 2) / TILE_SIZE);
    const centreCol = Math.floor((p.x + p.width * 0.5) / TILE_SIZE);

    for (let i = 0; i < warps.length; i++) {
      const wp = warps[i];
      if (feetRow !== wp.row) continue;
      if (centreCol !== wp.col && centreCol !== wp.col + 1) continue;

      const dest = warps[wp.destIndex];
      if (!dest) continue;

      this.warpPhase = 'in';
      this.warpTimer = 0.45;
      this.warpDest = { col: dest.col, row: dest.row };
      p.vy = 0;
      this.addFloatingText(
        p.x + p.width * 0.5, p.y - 10, 'WARP!', '#7bf78f', 1.1
      );
      this.spawnSparkleBurst(p.x + p.width * 0.5, p.y + p.height, '#7bf78f', 16);
      if (this.screen === 'playing') sound.warp();
      return;
    }
  }

  /** True while the pipe-travel animation is playing. */
  public get isWarping(): boolean {
    return this.warpPhase !== 'none';
  }

  private updateEnemies(dt: number): void {
    const p = this.player;
    const scale = Math.min(
      this.viewportHeight / (15 * TILE_SIZE),
      this.viewportWidth / 448
    );
    const logicalViewWidth = this.viewportWidth / Math.max(0.25, scale);
    const wakeEdge = this.cameraX + logicalViewWidth + 128;
    const baseDiff = DIFFICULTY_CONFIG[this.difficulty];
    // At night (and in storms) the NPCs hunt harder.
    const diffConfig = this.isNight
      ? { ...baseDiff, speed: baseDiff.speed * 1.18,
          aggroRange: baseDiff.aggroRange * 1.5 + 60 }
      : baseDiff;
    const loopSpeed = 1 + (this.loopCount - 1) * 0.18;
    this.updateBulletBillSpawner(dt, logicalViewWidth);

    for (const e of this.enemies) {
      if (!e.active && e.x < wakeEdge) {
        e.active = true;
      }
      if (!e.active) continue;

      e.animTimer += dt;
      if (e.kickGraceTimer > 0) {
        e.kickGraceTimer = Math.max(0, e.kickGraceTimer - dt);
      }
      if (e.hitFlash > 0) e.hitFlash = Math.max(0, e.hitFlash - dt);

      // Frozen enemies are inert platforms until the ice cracks.
      if (e.frozenTimer > 0) {
        e.frozenTimer -= dt;
        e.vx = 0;
        if (e.frozenTimer <= 0) {
          e.state = 'walk';
          e.vx = e.facing * 60;
          this.spawnSparkleBurst(
            e.x + e.width * 0.5, e.y + e.height * 0.5, '#bae6fd', 10
          );
        } else {
          // Still obey gravity so a frozen foe can fall into a pit.
          e.vy = Math.min(620, e.vy + 1650 * dt);
          e.y += e.vy * dt;
          const fr = Math.floor((e.y + e.height) / TILE_SIZE);
          const cc = Math.floor((e.x + e.width * 0.5) / TILE_SIZE);
          if (e.vy >= 0 && this.isSolidOrBridge(this.getTile(cc, fr))) {
            e.y = fr * TILE_SIZE - e.height;
            e.vy = 0;
          }
          if (e.y > 560) e.active = false;
          // Mario can stand on the ice block.
          if (!p.dead && this.rectsOverlap(p, e) && p.vy > 0 &&
              p.y + p.height < e.y + 14) {
            p.y = e.y - p.height;
            p.vy = 0;
            p.onGround = true;
          }
          continue;
        }
      }

      if (e.state === 'squished') {
        e.stateTimer -= dt;
        if (e.stateTimer <= 0) {
          e.y = 9999;
          e.active = false;
        }
        continue;
      }

      if (e.state === 'flipped') {
        e.vy += 1450 * dt;
        e.x += e.vx * dt;
        e.y += e.vy * dt;
        if (e.y > 600) e.active = false;
        continue;
      }

      if (e.kind === 'piranha') {
        this.updatePiranha(e, dt);
        continue;
      }

      if (e.kind === 'lakitu') {
        this.updateLakitu(e, dt, diffConfig.speed * loopSpeed);
        continue;
      }

      if (e.kind === 'bullet_bill') {
        this.updateBulletBill(e, dt, logicalViewWidth);
        continue;
      }

      // Dry Bones rebuilds itself after being stomped.
      if (e.state === 'collapsed') {
        e.stateTimer -= dt;
        if (e.stateTimer <= 0) {
          e.state = 'walk';
          e.vx = e.facing * 64 * diffConfig.speed * loopSpeed;
        }
        continue;
      }

      // Medium / Hard NPCs hunt Mario when he enters their alert range.
      // This stops players from simply sprinting past every patrol.
      if (
        e.state === 'walk' &&
        e.kind !== 'hammer_bro' &&
        !p.dead &&
        this.screen === 'playing' &&
        diffConfig.aggroRange > 0
      ) {
        const playerCenterX = p.x + p.width * 0.5;
        const enemyCenterX = e.x + e.width * 0.5;
        const sameLane =
          Math.abs(p.y + p.height - (e.y + e.height)) < 68;
        if (
          sameLane &&
          Math.abs(playerCenterX - enemyCenterX) < diffConfig.aggroRange
        ) {
          const dir: 1 | -1 = playerCenterX >= enemyCenterX ? 1 : -1;
          e.facing = dir;
          const base =
            e.kind === 'goomba' ? 72 : e.kind === 'koopa_red' ? 58 : 66;
          e.vx = dir * base * diffConfig.speed * loopSpeed;
        }
      }

      // Shell recovery if left idle too long
      if (e.state === 'shell_idle') {
        e.stateTimer += dt;
        if (e.stateTimer > 6.5) {
          e.state = 'walk';
          e.stateTimer = 0;
          e.vx = e.facing * 62;
        }
      }

      // Gravity & movement
      e.vy = Math.min(620, e.vy + 1650 * dt);
      e.x += e.vx * dt;

      // Wall bounce
      if (e.vx !== 0) {
        const edgeCol =
          e.vx > 0
            ? Math.floor((e.x + e.width) / TILE_SIZE)
            : Math.floor(e.x / TILE_SIZE);
        const rTop = Math.floor((e.y + 4) / TILE_SIZE);
        const rBot = Math.floor((e.y + e.height - 4) / TILE_SIZE);
        let hitWall = false;
        for (let r = rTop; r <= rBot; r++) {
          if (this.isSolidTile(this.getTile(edgeCol, r))) {
            hitWall = true;
            if (e.state === 'shell_spin') {
              // Spinning shells can smash bricks or trigger ? blocks!
              const t = this.getTile(edgeCol, r);
              if (
                t === TileType.BRICK ||
                this.isQuestionOrPower(t) ||
                t === TileType.POW_BLOCK
              ) {
                this.hitBlockFromBelow(edgeCol, r);
              } else if (this.screen === 'playing' && Math.abs(e.x - p.x) < 420) {
                sound.bump();
              }
              this.spawnSparkleBurst(
                e.vx > 0 ? e.x + e.width : e.x,
                e.y + e.height * 0.5,
                '#ffd93d',
                5
              );
            }
            break;
          }
        }
        if (hitWall) {
          e.vx = -e.vx;
          e.facing = e.vx >= 0 ? 1 : -1;
          e.x += e.vx * dt * 2;
        }
      }

      // Ground check
      e.y += e.vy * dt;
      e.onGround = false;
      const footRow = Math.floor((e.y + e.height) / TILE_SIZE);
      const cL = Math.floor((e.x + 3) / TILE_SIZE);
      const cR = Math.floor((e.x + e.width - 3) / TILE_SIZE);
      if (
        e.vy >= 0 &&
        (this.isSolidOrBridge(this.getTile(cL, footRow)) ||
          this.isSolidOrBridge(this.getTile(cR, footRow)))
      ) {
        e.y = footRow * TILE_SIZE - e.height;
        e.vy = 0;
        e.onGround = true;

        // Red Koopas & Hammer Bros smartly turn around at ledges!
        if (
          (e.kind === 'koopa_red' || e.kind === 'hammer_bro' ||
           e.kind === 'fire_bro' || e.kind === 'sniper_bro' ||
           e.kind === 'armored_goomba') &&
          e.state === 'walk' &&
          e.vx !== 0
        ) {
          const probeCol =
            e.vx > 0
              ? Math.floor((e.x + e.width + 2) / TILE_SIZE)
              : Math.floor((e.x - 2) / TILE_SIZE);
          if (!this.isSolidOrBridge(this.getTile(probeCol, footRow))) {
            e.vx = -e.vx;
            e.facing = e.vx >= 0 ? 1 : -1;
          }
        }
      }

      // --- Environment-aware behaviour ------------------------------------
      // Ground troops hop over pits instead of marching into them, and
      // bruisers boot loose blocks at the player.
      if (e.state === 'walk' && e.onGround) {
        const ahead = Math.floor(
          (e.vx > 0 ? e.x + e.width + 6 : e.x - 6) / TILE_SIZE
        );
        const footRow = Math.floor((e.y + e.height + 2) / TILE_SIZE);
        const gapAhead =
          !this.isSolidOrBridge(this.getTile(ahead, footRow)) &&
          !this.isSolidOrBridge(this.getTile(ahead, footRow + 1));
        if (gapAhead && Math.abs(e.vx) > 10) {
          // Lift clear of the floor first, otherwise the ground snap that
          // already ran this frame would cancel the jump immediately.
          e.y -= 3;
          e.vy = -430;
          e.onGround = false;
        }

        const stats2 = ENEMY_STATS[e.kind];
        if (stats2.hp >= 3 && stats2.attack === 'contact') {
          e.aiTimer -= dt;
          const dxp = p.x - e.x;
          if (
            e.aiTimer <= 0 && !p.dead &&
            Math.abs(dxp) < 230 && Math.abs(p.y - e.y) < 60
          ) {
            e.aiTimer = 3.4;
            e.kicking = true;
            this.enemyKickBlock(e);
          } else if (e.kicking && e.aiTimer < 3.1) {
            e.kicking = false;
          }
        }
      }

      // --- Ranged attackers: telegraph, then fire --------------------------
      const atkStats = ENEMY_STATS[e.kind];
      const ranged =
        atkStats.attack !== 'none' &&
        atkStats.attack !== 'contact' &&
        atkStats.attack !== 'spike';

      if (ranged && e.state === 'walk' && e.onGround) {
        const playerCentreX = p.x + p.width * 0.5;
        const enemyCentreX = e.x + e.width * 0.5;
        const dx = playerCentreX - enemyCentreX;
        const onScreen =
          e.x + e.width > this.cameraX - 40 &&
          e.x < this.cameraX + logicalViewWidth + 40;

        if (e.throwWindup > 0) {
          e.vx = 0;
          e.throwWindup = Math.max(0, e.throwWindup - dt);
          if (e.throwWindup === 0) {
            this.enemyAttack(e);
            e.throwCooldown =
              (atkStats.attackRate || diffConfig.throwInterval) /
              Math.max(0.6, diffConfig.speed);
            e.vx = e.facing * 44 * diffConfig.speed * loopSpeed;
          }
        } else {
          e.throwCooldown = Math.max(0, e.throwCooldown - dt);
          if (
            e.throwCooldown === 0 && onScreen && !p.dead &&
            Math.abs(dx) < atkStats.attackRange
          ) {
            e.facing = dx >= 0 ? 1 : -1;
            e.throwWindup = this.difficulty === 'nightmare' ? 0.34 : 0.5;
            e.vx = 0;
            if (this.screen === 'playing') sound.hammerWindup();
          } else if (e.vx === 0) {
            e.vx = e.facing * 44 * diffConfig.speed * loopSpeed;
          }
        }
      }

      if (e.y > 560) {
        e.active = false;
        continue;
      }

      // Spinning shell bowling through other enemies!
      if (e.state === 'shell_spin') {
        for (const other of this.enemies) {
          if (
            other === e ||
            !other.active ||
            other.state === 'squished' ||
            other.state === 'flipped'
          ) {
            continue;
          }
          if (this.rectsOverlap(e, other)) {
            e.shellCombo += 1;
            this.maxCombo = Math.max(this.maxCombo, e.shellCombo);
            if (e.shellCombo >= 7) {
              this.lives += 1;
              if (this.screen === 'playing') sound.oneUp();
              this.flipEnemy(other, 0, '1UP!');
            } else {
              const pts =
                COMBO_SCORES[
                  Math.min(COMBO_SCORES.length - 1, e.shellCombo - 1)
                ];
              this.flipEnemy(other, pts);
            }
          }
        }
      }

      // Check collision with Mario!
      if (!p.dead && this.rectsOverlap(p, e)) {
        this.handlePlayerEnemyCollision(e);
      }
    }

    // Keep the dynamic spawn list bounded (Spiny rain + Bullet Bill barrage).
    if (this.enemies.length > 90) {
      this.enemies = this.enemies.filter(
        (e) => e.active || e.state === 'collapsed'
      );
    }
  }

  /** Lakitu hovers above Mario and rains Spinies down on him. */
  private updateLakitu(e: Enemy, dt: number, speedScale: number): void {
    const p = this.player;
    const targetX = p.x - 26 + p.vx * 0.25;
    const targetY = Math.max(40, p.y - 165);

    e.x += (targetX - e.x) * Math.min(1, dt * 1.25 * speedScale);
    e.y += (targetY - e.y) * Math.min(1, dt * 2.0);
    e.vx = 0;
    e.vy = 0;
    e.facing = p.x >= e.x ? 1 : -1;

      e.throwCooldown -= dt;
    if (e.throwCooldown <= 0 && !p.dead && this.screen === 'playing') {
      e.throwCooldown = 2.5 / speedScale;
      this.spawnSpiny(e.x + e.width * 0.5 - 13, e.y + e.height);
      sound.spinyDrop();
    }

    if (!p.dead && this.rectsOverlap(p, e)) {
      this.handlePlayerEnemyCollision(e);
    }
  }

  /** Spiny dropped from a Lakitu cloud. */
  private spawnSpiny(x: number, y: number): void {
    const diffConfig = DIFFICULTY_CONFIG[this.difficulty];
    this.enemies.push({
      id: this.nextEntityId++,
      kind: 'spiny',
      state: 'walk',
      x,
      y,
      vx: (this.player.x > x ? 1 : -1) * 70 * diffConfig.speed,
      vy: 40,
      width: 26,
      height: 26,
      facing: this.player.x > x ? 1 : -1,
      onGround: false,
      animTimer: 0,
      stateTimer: 0,
      kickGraceTimer: 0,
      shellCombo: 0,
      throwCooldown: 0,
      throwWindup: 0,
      anchorY: y,
      active: true,
      hp: ENEMY_STATS.spiny.hp,
      maxHp: ENEMY_STATS.spiny.hp,
      hitFlash: 0,
      frozenTimer: 0,
      variant: 0,
      phase: 0,
      aiTimer: 0,
      kicking: false,
    });
    this.spawnSparkleBurst(x + 13, y, '#ff8a1f', 7);
  }

  /** Bullet Bill flies in a dead straight line, ignoring gravity. */
  private updateBulletBill(e: Enemy, dt: number, viewWidth: number): void {
    const p = this.player;
    e.x += e.vx * dt;

    if (Math.random() < 0.5) {
      this.spawnParticle({
        kind: 'dust',
        x: e.x + (e.vx > 0 ? -4 : e.width + 4),
        y: e.y + e.height * 0.5,
        vx: -e.vx * 0.06,
        vy: (Math.random() - 0.5) * 24,
        size: 5 + Math.random() * 3,
        color: '#d7dbe8',
        life: 0.26,
        gravity: -30,
      });
    }

    if (
      e.x < this.cameraX - 220 ||
      e.x > this.cameraX + viewWidth + 260
    ) {
      e.active = false;
      return;
    }

    if (!p.dead && this.rectsOverlap(p, e)) {
      this.handlePlayerEnemyCollision(e);
    }
  }

  /** Nightmare-mode Bullet Bill barrage fired from ahead of the camera. */
  private updateBulletBillSpawner(dt: number, viewWidth: number): void {
    const interval = DIFFICULTY_CONFIG[this.difficulty].bulletBillInterval;
    if (interval <= 0 || this.screen !== 'playing' || this.player.dead) return;

    this.bulletTimer -= dt;
    if (this.bulletTimer > 0) return;
    this.bulletTimer = interval * (0.75 + Math.random() * 0.55);

    const p = this.player;
    const flightRow = 9 + Math.floor(Math.random() * 3); // rows 9..11
    const y = flightRow * TILE_SIZE + 3;
    const fromRight = Math.random() < 0.78;
    const x = fromRight
      ? this.cameraX + viewWidth + 40
      : this.cameraX - 60;
    const speed = 210 + Math.random() * 70;

    // Don't fire a bullet straight into terrain.
    const col = Math.floor(x / TILE_SIZE);
    if (this.isSolidTile(this.getTile(col, flightRow))) return;

    this.enemies.push({
      id: this.nextEntityId++,
      kind: 'bullet_bill',
      state: 'walk',
      x,
      y,
      vx: fromRight ? -speed : speed,
      vy: 0,
      width: 30,
      height: 26,
      facing: fromRight ? -1 : 1,
      onGround: false,
      animTimer: 0,
      stateTimer: 0,
      kickGraceTimer: 0,
      shellCombo: 0,
      throwCooldown: 0,
      throwWindup: 0,
      anchorY: y,
      active: true,
      hp: ENEMY_STATS.bullet_bill.hp,
      maxHp: ENEMY_STATS.bullet_bill.hp,
      hitFlash: 0,
      frozenTimer: 0,
      variant: 0,
      phase: 0,
      aiTimer: 0,
      kicking: false,
    });

    if (Math.abs(x - p.x) < viewWidth) sound.bulletBill();
  }

  private updatePiranha(e: Enemy, dt: number): void {
    const p = this.player;
    // Cycle: 0..0.9 rise, 0.9..2.0 open/chomp at top, 2.0..2.9 sink, 2.9..4.1 hidden
    const prevT = e.stateTimer;
    e.stateTimer = (e.stateTimer + dt) % 4.1;

    // Wait safely inside pipe if Mario is right next to or standing on pipe!
    if (prevT > 3.8 && e.stateTimer < 0.5) {
      if (Math.abs(p.x + p.width * 0.5 - (e.x + e.width * 0.5)) < 56) {
        e.stateTimer = 3.5;
      }
    }

    let offset = 32; // Hidden inside pipe
    if (e.stateTimer < 0.9) {
      offset = 32 * (1 - e.stateTimer / 0.9);
    } else if (e.stateTimer < 2.0) {
      offset = 0;
    } else if (e.stateTimer < 2.9) {
      offset = 32 * ((e.stateTimer - 2.0) / 0.9);
    } else {
      offset = 34;
    }

    e.y = e.anchorY - 30 + offset;

    // Venom spit while fully emerged.
    if (offset < 6) {
      e.throwCooldown -= dt;
      if (
        e.throwCooldown <= 0 && !p.dead && this.screen === 'playing' &&
        Math.abs(p.x - e.x) < ENEMY_STATS.piranha.attackRange
      ) {
        e.throwCooldown = ENEMY_STATS.piranha.attackRate;
        this.enemyAttack(e);
      }
    }

    // Only collide when emerged out of pipe
    if (offset < 24 && !p.dead && this.rectsOverlap(p, e)) {
      if (p.starTimer > 0) {
        this.flipEnemy(e, 200);
      } else {
        this.damagePlayer();
      }
    }
  }

  private handlePlayerEnemyCollision(e: Enemy): void {
    const p = this.player;

    // Shadow costume phases straight through enemies.
    if (p.shadowTimer > 0) return;

    // Starman Invincibility plows right through!
    if (p.starTimer > 0) {
      p.stompCombo += 1;
      this.maxCombo = Math.max(this.maxCombo, p.stompCombo);
      const pts =
        COMBO_SCORES[Math.min(COMBO_SCORES.length - 1, p.stompCombo - 1)];
      this.flipEnemy(e, pts);
      return;
    }

    // Touching an idle shell kicks it immediately!
    if (e.state === 'shell_idle') {
      const kickRight = p.x + p.width * 0.5 <= e.x + e.width * 0.5;
      e.state = 'shell_spin';
      e.vx = kickRight ? 430 : -430;
      e.facing = kickRight ? 1 : -1;
      e.shellCombo = 0;
      e.stateTimer = 0;
      e.kickGraceTimer = 0.2;
      // Nudge shell slightly clear so it doesn't hurt player on kick frame
      e.x += kickRight ? 6 : -6;
      this.addScore(400);
      this.addFloatingText(e.x + 12, e.y - 8, '400', '#ffd93d', 1.0);
      this.triggerShake(0.08, 2.5);
      if (this.screen === 'playing') sound.kick();
      return;
    }

    if (e.kickGraceTimer > 0) {
      return;
    }

    // Check if Mario is stomping from above!
    const playerBottom = p.y + p.height;
    const isFallingOnTop =
      p.vy > -40 && playerBottom - p.vy * (1 / 60) <= e.y + e.height * 0.62;

    // Spiny spikes punish every stomp — use fireballs, shells or a Star!
    if (e.kind === 'spiny') {
      if (isFallingOnTop) {
        p.vy = -250;
        this.spawnSparkleBurst(e.x + e.width * 0.5, e.y, '#ff8a1f', 9);
        this.addFloatingText(
          e.x + e.width * 0.5,
          e.y - 12,
          'OUCH!',
          '#ff8a1f',
          1.0
        );
      }
      this.damagePlayer();
      return;
    }

    if (isFallingOnTop) {
      p.stompCombo += 1;
      this.maxCombo = Math.max(this.maxCombo, p.stompCombo);

      // Bounce Mario upward (Super Stomp Bounce if holding Jump!)
      p.y = e.y - p.height - 1;
      p.vy = this.jumpHeldThisStep ? -575 : -410;
      p.coyoteTimer = 0;
      p.scaleX = 1.24;
      p.scaleY = 0.78;
      this.hitStopTimer = 0.028;
      this.triggerShake(0.08, 2.2);

      let label = '';
      if (p.stompCombo >= 8) {
        this.lives += 1;
        label = '1UP!';
        if (this.screen === 'playing') sound.oneUp();
      } else {
        const pts =
          COMBO_SCORES[Math.min(COMBO_SCORES.length - 1, p.stompCombo - 1)];
        this.addScore(pts);
        label = String(pts);
        if (this.screen === 'playing') {
          sound.stomp(p.stompCombo);
          if (p.stompCombo >= 2) sound.comboStep(p.stompCombo);
        }
      }

      this.addFloatingText(
        e.x + e.width * 0.5,
        e.y - 8,
        label,
        label === '1UP!' ? '#4ade80' : '#ffffff',
        p.stompCombo > 1 ? 1.15 : 1.0
      );

      // Four enemies without touching the ground drops a rare item.
      if (p.stompCombo === 4 || p.stompCombo === 6) {
        this.dropComboReward(e.x + e.width * 0.5, e.y);
      }
      this.spawnSparkleBurst(e.x + e.width * 0.5, e.y + 8, '#ffffff', 9);

      recordEnemy(e.kind);
      if (e.kind === 'goomba') {
        e.state = 'squished';
        e.stateTimer = 0.45;
        e.vx = 0;
      } else if (e.kind === 'dry_bones') {
        // Dry Bones only collapses — it rebuilds itself a moment later!
        e.state = 'collapsed';
        e.stateTimer = this.difficulty === 'nightmare' ? 2.6 : 3.4;
        e.vx = 0;
        this.addFloatingText(
          e.x + e.width * 0.5,
          e.y - 18,
          'REBUILDS!',
          '#dbeafe',
          0.9
        );
      } else if (e.kind === 'lakitu' || e.kind === 'bullet_bill') {
        this.flipEnemy(e, e.kind === 'lakitu' ? 1200 : 800);
        this.spawnSparkleBurst(e.x + e.width * 0.5, e.y + 8, '#ffe94d', 13);
      } else if (e.kind === 'hammer_bro') {
        // Helmet guard is defeated by a brave stomp (medium-risk reward).
        this.flipEnemy(e, 600);
        this.spawnSparkleBurst(e.x + e.width * 0.5, e.y + 8, '#ffe94d', 14);
      } else if (e.state === 'walk' || e.state === 'shell_spin') {
        e.state = 'shell_idle';
        e.vx = 0;
        e.stateTimer = 0;
      }
      return;
    }

    // Otherwise Mario takes damage (unless invulnerable)
    this.damagePlayer();
  }

  private flipEnemy(e: Enemy, points: number, customLabel?: string): void {
    e.state = 'flipped';
    e.vy = -360;
    e.vx = (Math.random() < 0.5 ? -1 : 1) * 95;
    if (points > 0) this.addScore(points);
    const text = customLabel || String(points);
    this.addFloatingText(
      e.x + e.width * 0.5,
      e.y - 6,
      text,
      customLabel === '1UP!' ? '#4ade80' : '#ffd93d',
      1.1
    );
    this.spawnSparkleBurst(e.x + e.width * 0.5, e.y + 12, '#ffd93d', 10);
    if (this.screen === 'playing' && !customLabel) sound.kick();
  }

  private damagePlayer(): void {
    const p = this.player;
    if (p.invulnTimer > 0 || p.starTimer > 0 || p.dead) return;

    if (p.power === 'fire' || p.power === 'big') {
      p.power = 'small';
      p.y += p.height - 28;
      p.height = 28;
      p.width = 22;
      p.crouching = false;
      p.invulnTimer = 2.0;
      p.transformTimer = 0.45;
      this.hitStopTimer = 0.06;
      this.triggerShake(0.22, 5.5);
      this.spawnSparkleBurst(p.x + 12, p.y + 14, '#ffffff', 12);
      if (this.screen === 'playing') sound.powerDown();
    } else {
      this.killPlayer();
    }
  }

  private killPlayer(): void {
    const p = this.player;
    if (p.dead) return;
    p.dead = true;
    p.deathTimer = 0;
    p.vx = 0;
    p.vy = -510;
    this.triggerShake(0.28, 6.5);
    if (this.screen === 'playing') sound.die();
  }

  private updateCoins(): void {
    const p = this.player;
    if (p.dead) return;

    for (const coin of this.coinsList) {
      if (coin.collected) continue;
      if (
        p.x + p.width > coin.x - 11 &&
        p.x < coin.x + 11 &&
        p.y + p.height > coin.y - 12 &&
        p.y < coin.y + 12
      ) {
        coin.collected = true;
        this.collectCoin(coin.x, coin.y, false);
      }
    }
  }

  private collectCoin(x: number, y: number, fromBlock = false): void {
    this.coins += 1;
    // Coins accumulate in the persistent wallet — except during a free
    // character trial, where they are counted for the run only.
    if (this.screen === 'playing' || this.screen === 'stage_clear') {
      if (this.demoMode) this.demoCoins += 1;
      else this.bankedCoins = addCoins(1);
    }
    this.addScore(200);
    if (this.screen === 'playing') sound.coin();

    if (this.coins >= 100) {
      this.coins -= 100;
      this.lives += 1;
      if (this.screen === 'playing') sound.oneUp();
      this.addFloatingText(x, y - 24, '1UP!', '#4ade80', 1.25);
    } else {
      this.addFloatingText(x, y - 14, '200', '#ffe94d', 0.95);
    }

    if (fromBlock) {
      this.spawnParticle({
        kind: 'coin_pop',
        x,
        y: y - 6,
        vx: 0,
        vy: -310,
        size: 20,
        color: '#ffd93d',
        life: 0.42,
        gravity: 1200,
      });
    }
    this.spawnSparkleBurst(x, y, '#ffe94d', 7);
  }

  private triggerFlagpole(flagX: number): void {
    const p = this.player;
    this.stats.clears += 1;
    this.screen = 'stage_clear';
    this.stageClearTimer = 0;
    sound.stopMusic();
    sound.flagpole();

    p.x = flagX - p.width * 0.5;
    p.vx = 0;
    p.vy = 0;
    this.hammers = [];
    p.flagSlide = true;
    p.victoryWalk = false;
    p.facing = 1;

    // Compute flagpole height bonus!
    const heightRatio = 1 - Math.min(1, Math.max(0, (p.y - 3 * TILE_SIZE) / (9 * TILE_SIZE)));
    if (heightRatio > 0.85) this.stageBonus = 5000;
    else if (heightRatio > 0.65) this.stageBonus = 2000;
    else if (heightRatio > 0.4) this.stageBonus = 1000;
    else if (heightRatio > 0.2) this.stageBonus = 400;
    else this.stageBonus = 200;

    this.addScore(this.stageBonus);
    this.addFloatingText(flagX + 18, p.y, `${this.stageBonus}`, '#ffe94d', 1.3);

    const remSecs = Math.ceil(this.timeRemaining);
    this.timeBonus = remSecs * 10;
    const lastDigit = remSecs % 10;
    this.fireworkCount = lastDigit === 6 ? 6 : lastDigit === 3 ? 3 : 3;
    this.fireworksLaunched = 0;
    this.emitHud(true);
  }

  private updateStageClear(dt: number): void {
    this.stageClearTimer += dt;
    const p = this.player;
    const groundY = 12 * TILE_SIZE - p.height; // Base block of flagpole is at row 12
    const walkFloorY = 13 * TILE_SIZE - p.height;
    const castleDoorX = (this.levelDef.castleCol + 1.5) * TILE_SIZE;

    // Slide Mario and Flag down
    if (p.flagSlide) {
      p.y = Math.min(groundY, p.y + 220 * dt);
      this.flagY = Math.min(11 * TILE_SIZE, this.flagY + 210 * dt);
      if (p.y >= groundY && this.flagY >= 11 * TILE_SIZE) {
        p.flagSlide = false;
        p.victoryWalk = true;
        sound.stageClear();
      }
    } else if (p.victoryWalk) {
      if (p.x < castleDoorX) {
        p.x += 125 * dt;
        p.y = Math.min(walkFloorY, p.y + 320 * dt);
        p.animTimer += dt * 8;
        p.animFrame = Math.floor(p.animTimer) % 3;
      } else {
        p.vx = 0;
      }
    }

    // Rapidly drain remaining time into bonus score + launch celebratory fireworks!
    if (this.stageClearTimer > 0.9 && this.timeRemaining > 0) {
      const drain = Math.min(this.timeRemaining, dt * 180);
      this.timeRemaining -= drain;
      this.addScore(Math.round(drain * 10));
    }

    if (
      this.stageClearTimer > 1.2 &&
      this.fireworksLaunched < this.fireworkCount &&
      this.stageClearTimer >= 1.2 + this.fireworksLaunched * 0.42
    ) {
      this.fireworksLaunched++;
      const fx =
        (this.levelDef.flagCol + 1 + (Math.random() - 0.3) * 5) * TILE_SIZE;
      const fy = (2.5 + Math.random() * 3) * TILE_SIZE;
      sound.firework();
      this.addScore(500);
      this.spawnFirework(fx, fy);
    }

    this.updateCamera(dt);

    if (this.stageClearTimer > 3.5) {
      if (this.levelIndex < TOTAL_LEVELS - 1) {
        // Advance seamlessly to next World!
        this.loadLevel(this.levelIndex + 1, p.power, false);
        this.screen = 'playing';
        sound.startMusic(THEME_META[this.levelDef.theme].music, false);
        this.emitHud(true);
      } else {
        // Cleared final fortress! Award Kingdom Clear bonus & show Victory High-Score celebration!
        this.addScore(5000);
        if (this.score > this.highScore) this.highScore = this.score;
        this.screen = 'victory';
        this.emitHud(true);
      }
    }
  }

  private spawnFirework(x: number, y: number): void {
    const colors = ['#ffe94d', '#ff4d6d', '#4df3ff', '#7bf1a8', '#ffffff'];
    const baseColor = colors[Math.floor(Math.random() * colors.length)];
    for (let i = 0; i < 24; i++) {
      const angle = (Math.PI * 2 * i) / 24;
      const speed = 90 + Math.random() * 120;
      this.spawnParticle({
        kind: 'firework',
        x,
        y,
        vx: Math.cos(angle) * speed,
        vy: Math.sin(angle) * speed,
        size: 5 + Math.random() * 3,
        color: i % 3 === 0 ? '#ffffff' : baseColor,
        life: 0.65 + Math.random() * 0.25,
        gravity: 220,
      });
    }
  }

  private updatePlatforms(dt: number): void {
    for (const plat of this.platforms) {
      const prevX = plat.x;
      const prevY = plat.y;
      const t = this.worldTime * plat.speed + plat.phase;
      plat.x = plat.startX + Math.sin(t) * plat.rangeX;
      plat.y = plat.startY + Math.sin(t) * plat.rangeY;
      plat.vx = plat.x - prevX;
      plat.vy = plat.y - prevY;
      void dt;
    }
  }

  /** Crumbling / vanishing platforms and their respawn cycle. */
  private updateCrumbles(dt: number): void {
    for (const [key, left] of [...this.crumbleTimers.entries()]) {
      const next = left - dt;
      if (next > 0) {
        this.crumbleTimers.set(key, next);
        continue;
      }
      this.crumbleTimers.delete(key);
      const [cs, rs] = key.split(',');
      const col = parseInt(cs, 10);
      const row = parseInt(rs, 10);
      const tile = this.getTile(col, row);
      if (tile !== TileType.CRUMBLE && tile !== TileType.CLOUD) continue;

      this.tiles[row][col] = TileType.EMPTY;
      this.crumbleRespawn.set(`${key}|${tile}`, 3.2);
      if (this.screen === 'playing') sound.brickBreak();
      this.triggerShake(0.08, 2.2);

      const cx = (col + 0.5) * TILE_SIZE;
      const cy = (row + 0.5) * TILE_SIZE;
      const colour = tile === TileType.CLOUD ? '#e8f0ff' : '#c89a5a';
      for (let i = 0; i < 6; i++) {
        this.spawnParticle({
          kind: 'brick',
          x: cx,
          y: cy,
          vx: (Math.random() - 0.5) * 180,
          vy: -90 - Math.random() * 150,
          size: 8,
          color: colour,
          life: 0.6,
          gravity: 1250,
          rotSpeed: (Math.random() - 0.5) * 16,
        });
      }
    }

    for (const [key, left] of [...this.crumbleRespawn.entries()]) {
      const next = left - dt;
      if (next > 0) {
        this.crumbleRespawn.set(key, next);
        continue;
      }
      this.crumbleRespawn.delete(key);
      const [coords, tileStr] = key.split('|');
      const [cs, rs] = coords.split(',');
      const col = parseInt(cs, 10);
      const row = parseInt(rs, 10);
      if (this.getTile(col, row) !== TileType.EMPTY) continue;
      // Don't rebuild a block inside Mario.
      const px = this.player.x;
      const py = this.player.y;
      const overlaps =
        px + this.player.width > col * TILE_SIZE &&
        px < (col + 1) * TILE_SIZE &&
        py + this.player.height > row * TILE_SIZE &&
        py < (row + 1) * TILE_SIZE;
      if (overlaps) {
        this.crumbleRespawn.set(key, 0.4);
        continue;
      }
      this.tiles[row][col] = parseInt(tileStr, 10);
      this.spawnSparkleBurst(
        (col + 0.5) * TILE_SIZE,
        (row + 0.5) * TILE_SIZE,
        '#ffffff',
        6
      );
    }
  }

  /** Spike contact from the side/below, and checkpoint flag activation. */
  private updateHazardContacts(): void {
    const p = this.player;
    if (p.dead) return;

    const c1 = Math.floor((p.x + 4) / TILE_SIZE);
    const c2 = Math.floor((p.x + p.width - 4) / TILE_SIZE);
    const r1 = Math.floor((p.y + 3) / TILE_SIZE);
    const r2 = Math.floor((p.y + p.height - 3) / TILE_SIZE);

    for (let r = r1; r <= r2; r++) {
      for (let c = c1; c <= c2; c++) {
        const t = this.getTile(c, r);
        if (t === TileType.SPIKE) {
          this.damagePlayer();
          return;
        }
        if (t === TileType.CHECKPOINT) {
          this.activateCheckpoint(c);
        }
      }
    }
  }

  /** Light up a checkpoint flag the first time Mario reaches it. */
  private activateCheckpoint(col: number): void {
    const list = this.levelDef.checkpoints ?? [];
    const idx = list.indexOf(col);
    if (idx < 0 || idx <= this.checkpointIndex) return;

    this.checkpointIndex = idx;
    this.addScore(500);
    this.timeRemaining = Math.min(
      this.levelDef.timeLimit,
      this.timeRemaining + 40
    );
    this.addFloatingText(
      (col + 0.5) * TILE_SIZE,
      11 * TILE_SIZE,
      'CHECKPOINT!',
      '#4ade80',
      1.2
    );
    this.spawnSparkleBurst(
      (col + 0.5) * TILE_SIZE,
      11.5 * TILE_SIZE,
      '#4ade80',
      18
    );
    this.triggerShake(0.12, 3);
    if (this.screen === 'playing') sound.checkpoint();
    this.emitHud(true);
  }

  private updateBumps(dt: number): void {
    for (let i = this.bumps.length - 1; i >= 0; i--) {
      this.bumps[i].timer += dt;
      if (this.bumps[i].timer >= this.bumps[i].duration) {
        this.bumps.splice(i, 1);
      }
    }
  }

  private updateSpringTimers(dt: number): void {
    for (const [k, v] of this.springTimers.entries()) {
      const next = v - dt;
      if (next <= 0) this.springTimers.delete(k);
      else this.springTimers.set(k, next);
    }
  }

  private addBump(col: number, row: number, tile: TileType): void {
    this.bumps = this.bumps.filter((b) => !(b.col === col && b.row === row));
    this.bumps.push({ col, row, timer: 0, duration: 0.16, tile });
  }

  public getBumpOffset(col: number, row: number): number {
    for (const b of this.bumps) {
      if (b.col === col && b.row === row) {
        const progress = b.timer / b.duration;
        return -Math.sin(progress * Math.PI) * 10;
      }
    }
    return 0;
  }

  private updateCamera(dt: number): void {
    const scale = Math.min(
      this.viewportHeight / (15 * TILE_SIZE),
      this.viewportWidth / 448
    );
    const logicalViewWidth = this.viewportWidth / Math.max(0.25, scale);
    const maxCam = Math.max(
      0,
      this.levelDef.widthCols * TILE_SIZE - logicalViewWidth
    );

    const lead = this.player.facing === 1 ? 75 : -20;
    const desired = this.player.x - logicalViewWidth * 0.36 + lead;
    // Mario camera mostly scrolls forward (with slight cushion) for classic arcade focus
    const clampedTarget = Math.max(
      this.cameraX - 64,
      Math.min(maxCam, Math.max(0, desired))
    );
    this.cameraX += (clampedTarget - this.cameraX) * Math.min(1, dt * 8.5);
  }

  private spawnDust(x: number, y: number): void {
    for (let i = 0; i < 4; i++) {
      this.spawnParticle({
        kind: 'dust',
        x: x + (Math.random() - 0.5) * 10,
        y: y - 2,
        vx: (Math.random() - 0.5) * 65,
        vy: -18 - Math.random() * 35,
        size: 5 + Math.random() * 4,
        color: '#f5f3eb',
        life: 0.26 + Math.random() * 0.12,
        gravity: -20,
      });
    }
  }

  private spawnSparkleBurst(
    x: number,
    y: number,
    color: string,
    count: number
  ): void {
    for (let i = 0; i < count; i++) {
      const a = (Math.PI * 2 * i) / count + Math.random() * 0.4;
      const spd = 55 + Math.random() * 115;
      this.spawnParticle({
        kind: 'sparkle',
        x,
        y,
        vx: Math.cos(a) * spd,
        vy: Math.sin(a) * spd,
        size: 4 + Math.random() * 3,
        color,
        life: 0.28 + Math.random() * 0.16,
        gravity: 160,
      });
    }
  }

  private spawnParticle(opts: {
    kind: Particle['kind'];
    x: number;
    y: number;
    vx: number;
    vy: number;
    size: number;
    color: string;
    life: number;
    gravity: number;
    rotSpeed?: number;
  }): void {
    this.particles.push({
      kind: opts.kind,
      x: opts.x,
      y: opts.y,
      vx: opts.vx,
      vy: opts.vy,
      size: opts.size,
      color: opts.color,
      alpha: 1,
      life: opts.life,
      maxLife: opts.life,
      gravity: opts.gravity,
      rotation: 0,
      rotSpeed: opts.rotSpeed ?? 0,
    });
  }

  private updateParticles(dt: number): void {
    for (let i = this.particles.length - 1; i >= 0; i--) {
      const pt = this.particles[i];
      pt.life -= dt;
      if (pt.life <= 0) {
        this.particles.splice(i, 1);
        continue;
      }
      pt.vy += pt.gravity * dt;
      pt.x += pt.vx * dt;
      pt.y += pt.vy * dt;
      pt.rotation += pt.rotSpeed * dt;
      pt.alpha = Math.max(0, pt.life / pt.maxLife);
      if (pt.kind === 'ring') {
        pt.size += 820 * dt;
      }
    }
  }

  private addFloatingText(
    x: number,
    y: number,
    text: string,
    color: string,
    scale = 1
  ): void {
    this.floatingTexts.push({
      x,
      y,
      vy: -56,
      text,
      color,
      life: 0.78,
      maxLife: 0.78,
      scale,
    });
  }

  private updateFloatingTexts(dt: number): void {
    for (let i = this.floatingTexts.length - 1; i >= 0; i--) {
      const ft = this.floatingTexts[i];
      ft.life -= dt;
      if (ft.life <= 0) {
        this.floatingTexts.splice(i, 1);
        continue;
      }
      ft.y += ft.vy * dt;
      ft.vy *= 0.96;
    }
  }

  private triggerShake(duration: number, magnitude: number): void {
    this.shakeTime = Math.max(this.shakeTime, duration);
    this.shakeMagnitude = Math.max(this.shakeMagnitude, magnitude);
    if (this.shakeTime <= 0.01) this.shakeMagnitude = magnitude;
  }

  private addScore(pts: number): void {
    if (this.screen !== 'playing' && this.screen !== 'stage_clear') return;
    this.score += pts;
    if (this.score > this.highScore) {
      this.highScore = this.score;
    }
  }

  public getTile(col: number, row: number): TileType {
    if (row < 0) return TileType.EMPTY;
    if (row >= this.tiles.length) return TileType.EMPTY;
    if (col < 0 || col >= this.tiles[0].length) return TileType.SOLID_BLOCK;
    return this.tiles[row][col] as TileType;
  }

  public isSolidTile(t: TileType): boolean {
    return (
      t === TileType.GROUND ||
      t === TileType.BRICK ||
      t === TileType.Q_COIN ||
      t === TileType.Q_POWER ||
      t === TileType.Q_STAR ||
      t === TileType.Q_1UP ||
      t === TileType.MULTI_COIN_BRICK ||
      t === TileType.SOLID_BLOCK ||
      t === TileType.USED_BLOCK ||
      t === TileType.PIPE_TL ||
      t === TileType.PIPE_TR ||
      t === TileType.PIPE_BL ||
      t === TileType.PIPE_BR ||
      t === TileType.POW_BLOCK ||
      t === TileType.SPIKE ||
      t === TileType.ICE ||
      t === TileType.CONVEYOR_LEFT ||
      t === TileType.CONVEYOR_RIGHT ||
      t === TileType.JELLY ||
      t === TileType.CRUMBLE
    );
  }

  /** Tiles that behave like ground for enemies / items (incl. one-ways). */
  public isStandable(t: TileType): boolean {
    return (
      this.isSolidTile(t) ||
      t === TileType.BRIDGE ||
      t === TileType.SPRING ||
      t === TileType.CLOUD ||
      t === TileType.CHECKPOINT
    );
  }

  private isSolidOrBridge(t: TileType): boolean {
    return this.isStandable(t);
  }

  private rectHitsSolid(x: number, y: number, w: number, h: number): boolean {
    const c1 = Math.floor(x / TILE_SIZE);
    const c2 = Math.floor((x + w) / TILE_SIZE);
    const r1 = Math.floor(y / TILE_SIZE);
    const r2 = Math.floor((y + h) / TILE_SIZE);
    for (let r = r1; r <= r2; r++) {
      for (let c = c1; c <= c2; c++) {
        if (this.isSolidTile(this.getTile(c, r))) return true;
      }
    }
    return false;
  }

  private rectsOverlap(
    a: { x: number; y: number; width: number; height: number },
    b: { x: number; y: number; width: number; height: number }
  ): boolean {
    return (
      a.x < b.x + b.width &&
      a.x + a.width > b.x &&
      a.y < b.y + b.height &&
      a.y + a.height > b.y
    );
  }

  public getHudSnapshot(): HudSnapshot {
    return {
      screen: this.screen,
      score: this.score,
      highScore: this.highScore,
      coins: this.coins,
      lives: this.lives,
      worldLabel:
        this.loopCount > 1
          ? `${this.levelDef.worldLabel}+`
          : this.levelDef.worldLabel,
      worldSubtitle: this.levelDef.subtitle,
      levelIndex: this.levelIndex,
      loopCount: this.loopCount,
      timeRemaining: Math.max(0, Math.ceil(this.timeRemaining)),
      power: this.player.power,
      starActive: this.player.starTimer > 0,
      maxCombo: this.maxCombo,
      stageBonus: this.stageBonus,
      timeBonus: this.timeBonus,
      difficulty: this.difficulty,
      levelNumber: this.levelIndex + 1,
      themeName: getLevelBiome(this.levelIndex + 1).name,
      themeIcon: getLevelBiome(this.levelIndex + 1).icon,
      themeAccent: getLevelBiome(this.levelIndex + 1).accent,
      character: this.character,
      bankedCoins: this.bankedCoins,
      demoMode: this.demoMode,
      freshDiscovery: this.freshDiscovery,
      weatherLabel: WEATHER_DEFS[getLevelBiome(this.levelIndex + 1).weather].label,
      stompChain: this.player.stompCombo,
      rewinds: this.rewindCharges,
      rewinding: this.rewinding,
      bossHp: this.boss ? this.boss.hp / this.boss.maxHp : -1,
      bossPhase: this.boss ? this.boss.phase : 0,
      dailyLevel: dailyLevelFor(new Date()),
      isDaily: this.isDaily,
      timeSlow: this.player.timeSlowTimer,
      magnet: this.player.magnetTimer,
      shadow: this.player.shadowTimer,
      dashCharges: Math.max(
        0,
        (this.character === 'rosalina' ? 2 : 1) - this.player.airDashesUsed
      ),
      relicFound: !!this.relic?.collected,
      pet: this.pet,
      isNight: this.isNight,
      slippery: this.slippery,
      weatherSchedule:
        SCHEDULE_LABEL[getLevelBiome(this.levelIndex + 1).schedule],
      tierName: getLevelTier(this.levelIndex + 1).name,
      tierColor: getLevelTier(this.levelIndex + 1).color,
      hazardLabel: this.levelDef.hazardLabel,
      weapon: this.currentWeapon,
      weaponAmmo: this.currentWeapon ? this.ammoFor(this.currentWeapon) : 0,
      ownedWeapons: [...this.ownedWeapons],
      weaponAmmoMap: { ...this.weaponAmmo },
      checkpointIndex: this.checkpointIndex,
      checkpointTotal: this.levelDef.checkpoints?.length ?? 0,
      soundEnabled: sound.isSoundEnabled(),
      musicEnabled: sound.isMusicEnabled(),
    };
  }

  private emitHud(force: boolean): void {
    if (!this.onHudChange) return;
    const snap = this.getHudSnapshot();
    const hash = `${snap.screen}|${snap.score}|${snap.highScore}|${snap.coins}|${snap.lives}|${snap.levelNumber}|${snap.timeRemaining}|${snap.power}|${snap.starActive}|${snap.difficulty}|${snap.checkpointIndex}|${snap.weapon}|${snap.weaponAmmo}|${snap.bankedCoins}|${snap.demoMode}|${snap.freshDiscovery}|${snap.ownedWeapons.length}|${snap.soundEnabled}|${snap.musicEnabled}`;
    if (force || hash !== this.lastHudHash) {
      this.lastHudHash = hash;
      this.onHudChange(snap);
    }
  }
}
