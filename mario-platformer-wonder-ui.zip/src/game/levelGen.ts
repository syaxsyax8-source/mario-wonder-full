import { getLevelBiome } from './biomes';
import {
  Difficulty,
  EnemyKind,
  PipeWarp,
  WeaponKind,
  weaponsAvailableAt,
  getLevelTier,
  LevelDefinition,
  THEME_HAZARDS,
  TileType,
  TOTAL_LEVELS,
  WorldTheme,
} from './types';

const ROWS = 15;
const GROUND_ROW = 13;
const STAND_ROW = 12;

/** Deterministic PRNG so every level number always rebuilds identically. */
function mulberry32(seed: number) {
  let a = seed >>> 0;
  return function rng(): number {
    a |= 0;
    a = (a + 0x6d2b79f5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

interface Rng {
  next(): number;
  range(min: number, max: number): number;
  int(min: number, max: number): number;
  chance(p: number): boolean;
  pick<T>(items: T[]): T;
}

function makeRng(seed: number): Rng {
  const r = mulberry32(seed);
  return {
    next: r,
    range: (min, max) => min + r() * (max - min),
    int: (min, max) => Math.floor(min + r() * (max - min + 1)),
    chance: (p) => r() < p,
    pick: (items) => items[Math.floor(r() * items.length)],
  };
}

interface Builder {
  tiles: number[][];
  coins: Array<{ col: number; row: number }>;
  enemies: Array<{ kind: EnemyKind; col: number; row: number }>;
  platforms: LevelDefinition['platforms'];
  width: number;
  /** Themes that use lava instead of bottomless pits. */
  lavaPits: boolean;
  /** Ceiling of bricks (cave-like themes). */
  closedRoof: boolean;
  /** Theme signature obstacle tile. */
  primary: TileType | null;
  /** Theme flavour obstacle tile. */
  secondary: TileType | null;
  /** Enterable pipe mouths (linked up after layout). */
  warps: PipeWarp[];
  /** Weapon crates placed in the map. */
  crates: Array<{ col: number; row: number; weapon: WeaponKind }>;
  /** Hidden relic location. */
  relic: { col: number; row: number } | null;
  /** Button/gate puzzle. */
  puzzle: {
    buttons: Array<{ col: number; row: number }>;
    gates: Array<{ col: number; row: number }>;
  } | null;
}

function setTile(b: Builder, col: number, row: number, tile: TileType) {
  if (row >= 0 && row < ROWS && col >= 0 && col < b.width) {
    b.tiles[row][col] = tile;
  }
}

function isSolidGround(b: Builder, col: number): boolean {
  return b.tiles[GROUND_ROW]?.[col] === TileType.GROUND;
}

function addCoin(b: Builder, col: number, row: number) {
  if (col > 1 && col < b.width - 3 && row > 0 && row < GROUND_ROW) {
    b.coins.push({ col, row });
  }
}

function addEnemy(b: Builder, kind: EnemyKind, col: number, row: number) {
  if (col < 6 || col > b.width - 10) return;
  b.enemies.push({ kind, col, row });
}

/** Place a ground enemy only where there is real footing. */
function addGroundEnemy(b: Builder, kind: EnemyKind, col: number) {
  if (!isSolidGround(b, col)) return;
  // Keep the tile above clear so the NPC is not stuck inside a block.
  if (b.tiles[STAND_ROW][col] !== TileType.EMPTY) return;
  addEnemy(b, kind, col, STAND_ROW);
}

// ---------------------------------------------------------------------------
// Difficulty curve
// ---------------------------------------------------------------------------

export interface LevelPlan {
  level: number;
  theme: WorldTheme;
  progress: number; // 0..1 across the whole campaign
  tierIndex: number;
  enemyKinds: EnemyKind[];
  enemyDensity: number;
  hazardRate: number;
  speedScale: number;
  widthCols: number;
  timeLimit: number;
}

const DIFFICULTY_MODIFIER: Record<
  Difficulty,
  { density: number; hazard: number; speed: number; kindBoost: number }
> = {
  easy: { density: 0.62, hazard: 0.65, speed: 0.88, kindBoost: -500 },
  medium: { density: 1.0, hazard: 1.0, speed: 1.0, kindBoost: 0 },
  hard: { density: 1.32, hazard: 1.22, speed: 1.1, kindBoost: 450 },
  nightmare: { density: 1.7, hazard: 1.45, speed: 1.22, kindBoost: 1400 },
};

/** Enemy roster unlocks progressively as the campaign goes on. */
function rosterForLevel(effectiveLevel: number): EnemyKind[] {
  const roster: EnemyKind[] = ['goomba'];
  if (effectiveLevel >= 12) roster.push('koopa_green');
  if (effectiveLevel >= 40) roster.push('piranha');
  if (effectiveLevel >= 80) roster.push('koopa_red');
  if (effectiveLevel >= 160) roster.push('buzzy');
  if (effectiveLevel >= 320) roster.push('hammer_bro');
  if (effectiveLevel >= 560) roster.push('fire_bro');
  if (effectiveLevel >= 700) roster.push('spiny');
  if (effectiveLevel >= 1000) roster.push('armored_goomba');
  if (effectiveLevel >= 1200) roster.push('dry_bones');
  if (effectiveLevel >= 1600) roster.push('sniper_bro');
  if (effectiveLevel >= 2000) roster.push('lakitu');
  return roster;
}

export function planLevel(level: number, difficulty: Difficulty): LevelPlan {
  const clamped = Math.max(1, Math.min(TOTAL_LEVELS, Math.floor(level)));
  const mod = DIFFICULTY_MODIFIER[difficulty];
  // Logarithmic curve: fast early ramp, long tail so level 8000 is brutal.
  const progress = Math.log10(1 + (clamped - 1) * 9 / TOTAL_LEVELS * 10) / 2;
  const p = Math.max(0, Math.min(1, progress));
  const effective = clamped + mod.kindBoost;

  /**
   * Gentle on-ramp.
   *
   * The log curve alone still threw full-density levels at brand new
   * players, so the first ~40 stages get an extra easing multiplier that
   * fades out. Level 1 lands at ~25% of the normal enemy count and almost
   * no pits, which makes the opening genuinely easy to walk through.
   */
  const onRamp = Math.min(1, Math.pow((clamped - 1) / 40, 0.75));
  const easeIn = 0.25 + 0.75 * onRamp;

  return {
    level: clamped,
    theme: getLevelBiome(clamped).family,
    progress: p,
    tierIndex: getLevelTier(clamped).index,
    enemyKinds: rosterForLevel(effective),
    enemyDensity: (0.78 + p * 1.85) * mod.density * easeIn,
    // Hazard chunks (pits, moving platforms) stay rare at the start.
    hazardRate: Math.min(0.75, (0.12 + p * 0.5) * mod.hazard * easeIn),
    speedScale: (0.95 + p * 0.5) * mod.speed * (0.78 + 0.22 * onRamp),
    // Short, readable maps first; they grow as the player improves.
    widthCols: Math.round(104 + p * 108) - Math.round((1 - onRamp) * 22),
    // Extra time while learning.
    timeLimit: Math.round(420 - p * 150) + Math.round((1 - onRamp) * 60),
  };
}

// ---------------------------------------------------------------------------
// Chunk builders — each returns how many columns it consumed
// ---------------------------------------------------------------------------

type Chunk = (b: Builder, col: number, rng: Rng, plan: LevelPlan) => number;

const chunkFlatCoins: Chunk = (b, col, rng) => {
  const len = rng.int(5, 9);
  const row = rng.int(8, 10);
  const count = rng.int(3, 5);
  for (let i = 0; i < count; i++) addCoin(b, col + 1 + i, row);
  return len;
};

const chunkQuestionRow: Chunk = (b, col, rng, plan) => {
  const len = rng.int(6, 9);
  const row = rng.chance(0.3) ? 8 : 9;
  const span = rng.int(3, 5);
  for (let i = 0; i < span; i++) {
    const c = col + 1 + i;
    if (i === Math.floor(span / 2)) {
      setTile(b, c, row, TileType.Q_POWER);
    } else if (rng.chance(0.45)) {
      setTile(b, c, row, TileType.Q_COIN);
    } else {
      setTile(b, c, row, TileType.BRICK);
    }
  }
  if (plan.progress > 0.25 && rng.chance(0.3)) {
    setTile(b, col + 1, row - 4, TileType.MULTI_COIN_BRICK);
  }
  return len;
};

const chunkPit: Chunk = (b, col, rng, plan) => {
  // Narrow pits for the first stretch of the campaign.
  const early = plan.level < 40;
  const maxGap = early ? 2 : plan.progress > 0.6 ? 5 : plan.progress > 0.3 ? 4 : 3;
  const gap = rng.int(early ? 1 : 2, maxGap);
  for (let i = 0; i < gap; i++) {
    setTile(b, col + 1 + i, GROUND_ROW, TileType.EMPTY);
    setTile(
      b,
      col + 1 + i,
      GROUND_ROW + 1,
      b.lavaPits ? TileType.LAVA : TileType.EMPTY
    );
  }
  // Reward line of coins arcing over the gap.
  for (let i = 0; i < gap; i++) addCoin(b, col + 1 + i, 9);
  // Long gaps get a proper landing ledge (3 tiles) rather than a pixel-perfect
  // single block, so the jump is a challenge and not a coin flip.
  if (gap >= 4) {
    const mid = col + 1 + Math.floor(gap / 2);
    for (let i = -1; i <= 1; i++) setTile(b, mid + i, 11, TileType.BRIDGE);
  }
  return gap + 3;
};

const chunkPipe: Chunk = (b, col, rng, plan) => {
  // Max 3 tiles: a standing jump clears 3.89 tiles, so this is always fair.
  const h = rng.int(2, plan.progress > 0.4 ? 3 : 2);
  const topRow = GROUND_ROW - h;
  setTile(b, col + 1, topRow, TileType.PIPE_TL);
  setTile(b, col + 2, topRow, TileType.PIPE_TR);
  for (let r = topRow + 1; r < GROUND_ROW; r++) {
    setTile(b, col + 1, r, TileType.PIPE_BL);
    setTile(b, col + 2, r, TileType.PIPE_BR);
  }
  const hasPlant = plan.enemyKinds.includes('piranha') && rng.chance(0.45);
  if (hasPlant) {
    addEnemy(b, 'piranha', col + 1, topRow);
  } else if (rng.chance(0.55)) {
    // A clear pipe is a candidate warp entrance (linked later).
    b.warps.push({ col: col + 1, row: topRow, destIndex: -1, orientation: 'top' });
  }
  return h + 5;
};

const chunkStairs: Chunk = (b, col, rng) => {
  const steps = rng.int(3, 5);
  const descend = rng.chance(0.45);
  for (let i = 0; i < steps; i++) {
    const h = descend ? steps - i : i + 1;
    for (let r = GROUND_ROW - h; r < GROUND_ROW; r++) {
      setTile(b, col + 1 + i, r, TileType.SOLID_BLOCK);
    }
  }
  return steps + 3;
};

const chunkFloatPlatform: Chunk = (b, col, rng, plan) => {
  const len = rng.int(5, 8);
  const row = rng.int(5, 8);
  for (let i = 0; i < len - 2; i++) {
    setTile(b, col + 1 + i, row, TileType.BRICK);
    if (rng.chance(0.4)) addCoin(b, col + 1 + i, row - 1);
  }
  if (plan.progress > 0.2 && rng.chance(0.35)) {
    setTile(b, col + 2, row, TileType.Q_COIN);
  }
  return len + 1;
};

const chunkMovingPlatform: Chunk = (b, col, rng, plan) => {
  const gap = rng.int(4, 7);
  for (let i = 0; i < gap; i++) {
    setTile(b, col + 1 + i, GROUND_ROW, TileType.EMPTY);
    setTile(
      b,
      col + 1 + i,
      GROUND_ROW + 1,
      b.lavaPits ? TileType.LAVA : TileType.EMPTY
    );
  }
  const vertical = rng.chance(0.4);
  b.platforms.push({
    col: col + 1.5,
    row: vertical ? 10 : rng.int(9, 11),
    widthTiles: 3,
    rangeCols: vertical ? 0 : Math.min(3.5, gap * 0.5),
    rangeRows: vertical ? 3 : 0,
    speed: 1.5 + plan.progress * 1.4,
    phase: rng.range(0, Math.PI * 2),
  });
  for (let i = 0; i < 3; i++) addCoin(b, col + 2 + i, 7);
  return gap + 3;
};

const chunkSpring: Chunk = (b, col, rng) => {
  setTile(b, col + 1, STAND_ROW, TileType.SPRING);
  const row = rng.int(4, 6);
  for (let i = 0; i < 4; i++) {
    setTile(b, col + 3 + i, row, TileType.BRIDGE);
    addCoin(b, col + 3 + i, row - 1);
  }
  return 9;
};

const chunkPowArena: Chunk = (b, col, rng) => {
  setTile(b, col + 3, 9, TileType.POW_BLOCK);
  for (let i = 0; i < 3; i++) {
    setTile(b, col + 1 + i, 5, TileType.BRICK);
    setTile(b, col + 5 + i, 5, TileType.BRICK);
  }
  addCoin(b, col + 4, 4);
  return rng.int(9, 11);
};

const chunkBridgeRun: Chunk = (b, col, rng, plan) => {
  const gap = rng.int(4, 8);
  for (let i = 0; i < gap; i++) {
    setTile(b, col + 1 + i, GROUND_ROW, TileType.EMPTY);
    setTile(
      b,
      col + 1 + i,
      GROUND_ROW + 1,
      b.lavaPits ? TileType.LAVA : TileType.EMPTY
    );
    setTile(b, col + 1 + i, 11, TileType.BRIDGE);
  }
  if (plan.progress > 0.3) {
    for (let i = 1; i < gap - 1; i += 2) addCoin(b, col + 1 + i, 10);
  }
  return gap + 3;
};

const chunkTowerGate: Chunk = (b, col, rng) => {
  // A short wall with a stepping stone in front: climbable, still a hurdle.
  const h = rng.int(2, 3);
  for (let r = GROUND_ROW - h; r < GROUND_ROW; r++) {
    setTile(b, col + 3, r, TileType.SOLID_BLOCK);
  }
  if (h === 3) {
    // Half-height step so the climb is never a max-height jump.
    setTile(b, col + 2, GROUND_ROW - 1, TileType.SOLID_BLOCK);
  }
  setTile(b, col + 3, GROUND_ROW - h - 2, TileType.Q_COIN);
  return rng.int(7, 9);
};


// --- Theme signature parkour chunks ------------------------------------

/** Spike gauntlet: hop the spike beds (underground / volcano / castle). */
const chunkSpikeRun: Chunk = (b, col, rng, plan) => {
  const beds = plan.level < 30 ? 1 : rng.int(2, plan.progress > 0.5 ? 4 : 3);
  let c = col + 1;
  for (let i = 0; i < beds; i++) {
    const w = rng.int(1, 2);
    for (let k = 0; k < w; k++) setTile(b, c + k, STAND_ROW, TileType.SPIKE);
    addCoin(b, c, 10);
    c += w + rng.int(2, 3);
  }
  return c - col + 2;
};

/** Slippery ice shelf with a gap you must carry momentum across (snow). */
const chunkIceRun: Chunk = (b, col, rng, plan) => {
  const len = rng.int(6, 10);
  for (let i = 0; i < len; i++) setTile(b, col + 1 + i, STAND_ROW, TileType.ICE);
  // Ice already removes most of the player's control, so keep the gap short.
  const gap = rng.int(2, plan.progress > 0.45 ? 3 : 2);
  for (let i = 0; i < gap; i++) {
    const c = col + 1 + len + i;
    setTile(b, c, GROUND_ROW, TileType.EMPTY);
    setTile(b, c, GROUND_ROW + 1, b.lavaPits ? TileType.LAVA : TileType.EMPTY);
    setTile(b, c, STAND_ROW, TileType.EMPTY);
    addCoin(b, c, 9);
  }
  // Generous landing strip so a slide does not carry you into the next pit.
  for (let i = 0; i < 5; i++) {
    setTile(b, col + 1 + len + gap + i, STAND_ROW, TileType.ICE);
  }
  return len + gap + 7;
};

/** Opposing conveyor belts — run against the belt to progress (factory). */
const chunkConveyorRun: Chunk = (b, col, rng, plan) => {
  const len = rng.int(5, 9);
  const against = plan.progress > 0.3 && rng.chance(0.6);
  const belt = against ? TileType.CONVEYOR_LEFT : TileType.CONVEYOR_RIGHT;
  for (let i = 0; i < len; i++) setTile(b, col + 1 + i, STAND_ROW, belt);
  // Spikes under the belt run raise the stakes.
  if (plan.progress > 0.4 && rng.chance(0.5)) {
    setTile(b, col + 2 + Math.floor(len / 2), 9, TileType.SPIKE);
  }
  for (let i = 1; i < len; i += 2) addCoin(b, col + 1 + i, 10);
  return len + 3;
};

/** Jelly trampoline chain — chain bounces to grab high coins (candy/beach). */
const chunkJellyChain: Chunk = (b, col, rng) => {
  const pads = rng.int(2, 4);
  let c = col + 1;
  for (let i = 0; i < pads; i++) {
    setTile(b, c, STAND_ROW, TileType.JELLY);
    addCoin(b, c, 7 - (i % 2));
    addCoin(b, c, 5);
    c += rng.int(3, 4);
  }
  return c - col + 1;
};

/** Crumbling bridge — blocks fall away as you cross (desert / haunted). */
const chunkCrumbleBridge: Chunk = (b, col, rng, plan) => {
  const len = rng.int(4, plan.progress > 0.4 ? 8 : 6);
  for (let i = 0; i < len; i++) {
    const c = col + 1 + i;
    setTile(b, c, GROUND_ROW, TileType.EMPTY);
    setTile(b, c, GROUND_ROW + 1, b.lavaPits ? TileType.LAVA : TileType.EMPTY);
    setTile(b, c, 11, TileType.CRUMBLE);
    if (i % 2 === 0) addCoin(b, c, 10);
  }
  return len + 3;
};

/** Vine climb over a wide chasm (jungle). */
const chunkVineClimb: Chunk = (b, col, rng, plan) => {
  const gap = rng.int(4, plan.progress > 0.4 ? 7 : 5);
  for (let i = 0; i < gap; i++) {
    const c = col + 1 + i;
    setTile(b, c, GROUND_ROW, TileType.EMPTY);
    setTile(b, c, GROUND_ROW + 1, TileType.EMPTY);
  }
  // Vines flush against both edges of the chasm so they are easy to grab.
  for (let r = 6; r < GROUND_ROW; r++) {
    setTile(b, col + 1, r, TileType.VINE);
    setTile(b, col + gap, r, TileType.VINE);
  }
  // A real ledge across the top instead of a single floating block.
  const ledgeStart = col + 2;
  const ledgeEnd = col + gap - 1;
  for (let c2 = ledgeStart; c2 <= ledgeEnd; c2++) {
    setTile(b, c2, 6, TileType.BRIDGE);
    addCoin(b, c2, 5);
  }
  return gap + 4;
};

/** Vanishing cloud stepping stones (sky). */
const chunkCloudHop: Chunk = (b, col, rng, plan) => {
  const steps = rng.int(2, plan.progress > 0.4 ? 4 : 3);
  const gap = steps * 3 + 1;
  for (let i = 0; i < gap; i++) {
    const c = col + 1 + i;
    setTile(b, c, GROUND_ROW, TileType.EMPTY);
    setTile(b, c, GROUND_ROW + 1, TileType.EMPTY);
  }
  for (let i = 0; i < steps; i++) {
    const c = col + 2 + i * 3;
    const r = 10 - (i % 2);
    // 3-wide pads give a real landing target instead of a pixel-perfect hop.
    setTile(b, c, r, TileType.CLOUD);
    setTile(b, c + 1, r, TileType.CLOUD);
    setTile(b, c + 2, r, TileType.CLOUD);
    addCoin(b, c + 1, r - 1);
  }
  return gap + 3;
};

/** Pick the signature parkour chunk for this biome. */
function themeChunk(theme: WorldTheme): Chunk {
  switch (theme) {
    case 'snow':
      return chunkIceRun;
    case 'factory':
      return chunkConveyorRun;
    case 'candy':
    case 'beach':
    case 'overworld':
      return chunkJellyChain;
    case 'desert':
    case 'haunted':
      return chunkCrumbleBridge;
    case 'jungle':
      return chunkVineClimb;
    case 'sky':
      return chunkCloudHop;
    case 'underground':
    case 'volcano':
    case 'castle':
    default:
      return chunkSpikeRun;
  }
}

const ALL_CHUNKS: Chunk[] = [
  chunkFlatCoins,
  chunkQuestionRow,
  chunkPit,
  chunkPipe,
  chunkStairs,
  chunkFloatPlatform,
  chunkMovingPlatform,
  chunkSpring,
  chunkPowArena,
  chunkBridgeRun,
  chunkTowerGate,
];

const HAZARD_CHUNKS = new Set<Chunk>([
  chunkPit,
  chunkMovingPlatform,
  chunkBridgeRun,
]);

// ---------------------------------------------------------------------------
// Main generator
// ---------------------------------------------------------------------------


// ---------------------------------------------------------------------------
// Fairness pass — guarantees every wall can actually be climbed
// ---------------------------------------------------------------------------

/** Tiles that physically block movement (must be climbed, not walked through). */
const BLOCKING = new Set<number>([
  TileType.GROUND, TileType.BRICK, TileType.Q_COIN, TileType.Q_POWER,
  TileType.Q_STAR, TileType.Q_1UP, TileType.MULTI_COIN_BRICK,
  TileType.SOLID_BLOCK, TileType.USED_BLOCK, TileType.PIPE_TL,
  TileType.PIPE_TR, TileType.PIPE_BL, TileType.PIPE_BR, TileType.POW_BLOCK,
  TileType.SPIKE, TileType.ICE, TileType.CONVEYOR_LEFT,
  TileType.CONVEYOR_RIGHT, TileType.JELLY, TileType.CRUMBLE,
  TileType.WALL_RUN,
]);

const PIPE_TILES = new Set<number>([
  TileType.PIPE_TL, TileType.PIPE_TR, TileType.PIPE_BL, TileType.PIPE_BR,
]);

/** Height of the blocking stack resting on the ground at a column. */
function wallHeight(b: Builder, col: number): number {
  if (col < 0 || col >= b.width) return 0;
  let h = 0;
  for (let r = STAND_ROW; r >= 0; r--) {
    if (BLOCKING.has(b.tiles[r][col])) h++;
    else break;
  }
  return h;
}

/**
 * Mario clears 3.89 tiles from a standstill and 4.68 at a full sprint, so we
 * cap every forward step-up at 3 tiles. Walls that are too tall get a real
 * staircase built in front of them (so they stay a fun obstacle) and are only
 * shaved down as a last resort when there is no room for steps.
 */
const MAX_RISE = 3;

/**
 * Apply the fairness pass to an already-built level definition
 * (used for the handcrafted stages, which skip the generator).
 */
export function makeLevelFair<T extends { tiles: number[][]; widthCols: number }>(
  def: T
): T {
  const shim = {
    tiles: def.tiles,
    width: def.widthCols,
  } as unknown as Builder;
  ensureClimbable(shim);
  return def;
}

function ensureClimbable(b: Builder): void {
  for (let c = 1; c < b.width; c++) {
    const cur = wallHeight(b, c);
    if (cur === 0) continue;

    // Only the immediately preceding column matters: that is where the
    // player stands when facing the wall.
    const approach = wallHeight(b, c - 1);
    if (cur - approach <= MAX_RISE) continue;

    // Build a staircase that touches the wall, working backwards.
    for (let k = 1; k <= 4; k++) {
      const sc = c - k;
      if (sc <= 1) break;
      const needed = cur - MAX_RISE * k;
      if (needed <= 0) break;

      const atStand = b.tiles[STAND_ROW][sc];
      const existing = wallHeight(b, sc);
      if (existing >= needed) continue;
      // Never carve into a pipe or bury a checkpoint flag / spring.
      if (PIPE_TILES.has(atStand)) break;
      if (atStand === TileType.CHECKPOINT || atStand === TileType.SPRING) break;
      // Never bury interactive props under a staircase.
      if (atStand === TileType.BUTTON || atStand === TileType.GATE ||
          atStand === TileType.PHASE_WALL) break;
      // A step needs solid ground beneath it.
      if (b.tiles[GROUND_ROW][sc] !== TileType.GROUND) break;

      for (let h = existing + 1; h <= needed; h++) {
        setTile(b, sc, STAND_ROW - (h - 1), TileType.SOLID_BLOCK);
      }
    }

    // Still unfair (no room for steps, e.g. the wall rises out of a pit)?
    // Shave the top so the climb is always possible.
    const after = wallHeight(b, c - 1);
    let height = wallHeight(b, c);
    if (height - after > MAX_RISE) {
      const keep = Math.max(1, after + MAX_RISE);
      const isPipe = PIPE_TILES.has(b.tiles[STAND_ROW][c]);
      for (let h = height; h > keep; h--) {
        setTile(b, c, STAND_ROW - (h - 1), TileType.EMPTY);
      }
      height = keep;
      if (isPipe) {
        // Re-cap the shortened pipe so it still reads as a pipe.
        const topRow = STAND_ROW - (keep - 1);
        const leftIsPipe =
          c - 1 >= 0 && PIPE_TILES.has(b.tiles[STAND_ROW][c - 1]);
        setTile(b, c, topRow, leftIsPipe ? TileType.PIPE_TR : TileType.PIPE_TL);
      }
    }
  }
}

export function generateLevel(
  level: number,
  difficulty: Difficulty
): LevelDefinition {
  const plan = planLevel(level, difficulty);
  // Mixing constants keep neighbouring levels visually unrelated.
  const rng = makeRng(plan.level * 2654435761 + 0x9e3779b9);

  const theme = plan.theme;
  const width = plan.widthCols;
  const hazards = THEME_HAZARDS[theme];
  const lavaPits = hazards.lavaPits;
  const closedRoof =
    theme === 'underground' || theme === 'haunted' || theme === 'factory';

  const tiles: number[][] = Array.from({ length: ROWS }, () =>
    Array(width).fill(TileType.EMPTY)
  );
  for (let c = 0; c < width; c++) {
    tiles[GROUND_ROW][c] = TileType.GROUND;
    tiles[GROUND_ROW + 1][c] = TileType.GROUND;
  }

  const b: Builder = {
    tiles,
    coins: [],
    enemies: [],
    platforms: [],
    width,
    lavaPits,
    closedRoof,
    primary: hazards.primary,
    secondary: hazards.secondary,
    warps: [],
    crates: [],
    relic: null,
    puzzle: null,
  };

  if (closedRoof) {
    for (let c = 2; c < width - 16; c++) setTile(b, c, 1, TileType.BRICK);
  }

  // --- Layout pass -------------------------------------------------------
  const flagCol = width - 8;
  const castleCol = width - 5;
  let col = 7; // safe spawn runway

  const signature = themeChunk(theme);
  // Signature parkour appears regularly so each biome plays differently.
  const signatureEvery = plan.progress > 0.45 ? 3 : 4;
  let placedChunks = 0;

  while (col < flagCol - 12) {
    let chunk: Chunk;
    if (placedChunks % signatureEvery === signatureEvery - 1) {
      chunk = signature;
    } else {
      const isHazard = rng.chance(plan.hazardRate);
      const pool = isHazard
        ? ALL_CHUNKS.filter((c) => HAZARD_CHUNKS.has(c))
        : ALL_CHUNKS.filter((c) => !HAZARD_CHUNKS.has(c));
      chunk = rng.pick(pool);
    }
    const consumed = chunk(b, col, rng, plan);
    col += Math.max(4, consumed);
    placedChunks++;
  }

  // --- Finale -----------------------------------------------------------
  // The approach to the flagpole is never a staircase. 14 distinct obstacle
  // runs are available; the one used is derived from the level seed (not a
  // simple modulo) so consecutive levels feel unrelated. Every variant stays
  // inside the 3-tile climb rule enforced later by ensureClimbable().
  const finaleStart = Math.max(12, flagCol - 18);
  const finaleEnd = flagCol - 3;
  const FINALE_COUNT = 14;
  // A fixed permutation guarantees all 14 variants appear in every block of
  // 14 levels and that neighbours never match, while the per-block rotation
  // stops the sequence from looking cyclic.
  const FINALE_PERM = [5, 11, 2, 8, 0, 13, 6, 1, 9, 4, 12, 7, 3, 10];
  const fIdx = (plan.level - 1) % FINALE_COUNT;
  const fBlock = Math.floor((plan.level - 1) / FINALE_COUNT);
  const finaleKind = (FINALE_PERM[fIdx] + fBlock * 3) % FINALE_COUNT;

  // Wipe the run-up so no leftover chunk (especially a stair chunk) survives
  // into the finale — the approach to the flagpole is purely the obstacle
  // design chosen below.
  for (let c = finaleStart - 2; c <= finaleEnd + 1; c++) {
    for (let r = 1; r < GROUND_ROW; r++) setTile(b, c, r, TileType.EMPTY);
    setTile(b, c, GROUND_ROW, TileType.GROUND);
    setTile(b, c, GROUND_ROW + 1, TileType.GROUND);
  }
  b.platforms = b.platforms.filter(
    (pl) => pl.col + pl.widthTiles < finaleStart - 2 || pl.col > finaleEnd + 1
  );
  b.coins = b.coins.filter(
    (cn) => cn.col < finaleStart - 2 || cn.col > finaleEnd + 1
  );

  /** Carve a pit (lava-filled in hot biomes) across a column range. */
  // (helper defined below)
  const pit = (from: number, to: number) => {
    for (let c = from; c <= to; c++) {
      setTile(b, c, GROUND_ROW, TileType.EMPTY);
      setTile(b, c, GROUND_ROW + 1,
        b.lavaPits ? TileType.LAVA : TileType.EMPTY);
    }
  };

  switch (finaleKind) {
    case 0: {
      // Spike corridor under a low brick ceiling.
      for (let c = finaleStart; c <= finaleEnd; c += 3) {
        setTile(b, c, STAND_ROW, TileType.SPIKE);
        addCoin(b, c + 1, 10);
      }
      for (let c = finaleStart; c <= finaleEnd; c += 2) {
        setTile(b, c, 7, TileType.BRICK);
      }
      break;
    }
    case 1: {
      // Crumbling causeway over a pit.
      pit(finaleStart, finaleEnd);
      for (let c = finaleStart; c <= finaleEnd; c++) {
        setTile(b, c, 11, TileType.CRUMBLE);
        if (c % 2 === 0) addCoin(b, c, 10);
      }
      break;
    }
    case 2: {
      // Moving-platform ferry across a wide chasm.
      pit(finaleStart, finaleEnd);
      const span = finaleEnd - finaleStart;
      b.platforms.push({
        col: finaleStart + 1, row: 11, widthTiles: 3,
        rangeCols: Math.min(4, span * 0.3), rangeRows: 0,
        speed: 1.6 + plan.progress, phase: 0,
      });
      b.platforms.push({
        col: finaleStart + Math.round(span * 0.6), row: 9, widthTiles: 3,
        rangeCols: 0, rangeRows: 2.5,
        speed: 1.8 + plan.progress, phase: Math.PI,
      });
      for (let i = 0; i < 4; i++) addCoin(b, finaleStart + 3 + i * 3, 8);
      break;
    }
    case 3: {
      // Spring launch into a floating brick gauntlet.
      setTile(b, finaleStart, STAND_ROW, TileType.SPRING);
      for (let i = 0; i < 5; i++) {
        const c = finaleStart + 3 + i * 2;
        if (c > finaleEnd) break;
        setTile(b, c, 6 + (i % 2), TileType.BRICK);
        addCoin(b, c, 5 + (i % 2));
      }
      for (let c = finaleStart + 4; c <= finaleEnd; c += 5) {
        setTile(b, c, STAND_ROW, TileType.SPIKE);
      }
      break;
    }
    case 4: {
      // Jelly bounce run with alternating gaps.
      for (let c = finaleStart; c <= finaleEnd; c += 4) {
        setTile(b, c, STAND_ROW, TileType.JELLY);
        addCoin(b, c, 7);
        if (c + 2 <= finaleEnd) pit(c + 2, c + 2);
      }
      break;
    }
    case 5: {
      // Guarded gate: deliberately non-ascending pillars plus spikes.
      for (let i = 0; i < 3; i++) {
        const c = finaleStart + i * 5;
        if (c > finaleEnd) break;
        const h = i === 1 ? 1 : 3;
        for (let r = GROUND_ROW - h; r < GROUND_ROW; r++) {
          setTile(b, c, r, TileType.SOLID_BLOCK);
        }
        addCoin(b, c, GROUND_ROW - h - 2);
      }
      for (let c = finaleStart + 2; c <= finaleEnd; c += 5) {
        setTile(b, c, STAND_ROW, TileType.SPIKE);
      }
      break;
    }
    case 6: {
      // Conveyor belt treadmill running against you, over spikes.
      for (let c = finaleStart; c <= finaleEnd; c++) {
        setTile(b, c, STAND_ROW, TileType.CONVEYOR_LEFT);
      }
      for (let c = finaleStart + 3; c <= finaleEnd; c += 4) {
        setTile(b, c, 9, TileType.SPIKE);
        addCoin(b, c, 10);
      }
      break;
    }
    case 7: {
      // Vanishing cloud stepping stones over a chasm.
      pit(finaleStart, finaleEnd);
      for (let i = 0; ; i++) {
        const c = finaleStart + 1 + i * 3;
        if (c + 2 > finaleEnd) break;
        const r = 10 - (i % 2);
        setTile(b, c, r, TileType.CLOUD);
        setTile(b, c + 1, r, TileType.CLOUD);
        setTile(b, c + 2, r, TileType.CLOUD);
        addCoin(b, c + 1, r - 1);
      }
      break;
    }
    case 8: {
      // Slippery ice shelf ending in a short hop.
      for (let c = finaleStart; c <= finaleEnd - 4; c++) {
        setTile(b, c, STAND_ROW, TileType.ICE);
        if (c % 3 === 0) addCoin(b, c, 10);
      }
      pit(finaleEnd - 3, finaleEnd - 2);
      setTile(b, finaleEnd - 1, STAND_ROW, TileType.ICE);
      setTile(b, finaleEnd, STAND_ROW, TileType.ICE);
      break;
    }
    case 9: {
      // Twin vine climb with a bridge across the top.
      pit(finaleStart + 1, finaleEnd - 1);
      for (let r = 6; r < GROUND_ROW; r++) {
        setTile(b, finaleStart, r, TileType.VINE);
        setTile(b, finaleEnd, r, TileType.VINE);
      }
      for (let c = finaleStart + 1; c <= finaleEnd - 1; c++) {
        setTile(b, c, 6, TileType.BRIDGE);
        addCoin(b, c, 5);
      }
      break;
    }
    case 10: {
      // Piranha pipe row: duck between three short pipes.
      for (let i = 0; i < 3; i++) {
        const c = finaleStart + 1 + i * 5;
        if (c + 1 > finaleEnd) break;
        const topRow = GROUND_ROW - 2;
        setTile(b, c, topRow, TileType.PIPE_TL);
        setTile(b, c + 1, topRow, TileType.PIPE_TR);
        setTile(b, c, topRow + 1, TileType.PIPE_BL);
        setTile(b, c + 1, topRow + 1, TileType.PIPE_BR);
        if (plan.enemyKinds.includes('piranha')) {
          addEnemy(b, 'piranha', c, topRow);
        }
        addCoin(b, c, topRow - 2);
      }
      break;
    }
    case 11: {
      // POW arena: a block to clear the guards, with brick cover.
      setTile(b, finaleStart + 3, 9, TileType.POW_BLOCK);
      for (let i = 0; i < 4; i++) {
        const c = finaleStart + 1 + i * 2;
        if (c > finaleEnd) break;
        setTile(b, c, 5, TileType.BRICK);
      }
      for (let c = finaleStart + 6; c <= finaleEnd; c += 3) {
        setTile(b, c, STAND_ROW, TileType.SPIKE);
        addCoin(b, c, 10);
      }
      break;
    }
    case 12: {
      // Spike-and-crumble zigzag: alternate floor hazards and fragile ledges.
      for (let i = 0; ; i++) {
        const c = finaleStart + i * 3;
        if (c > finaleEnd) break;
        if (i % 2 === 0) {
          setTile(b, c, STAND_ROW, TileType.SPIKE);
          setTile(b, c, 9, TileType.CRUMBLE);
          addCoin(b, c, 8);
        } else {
          setTile(b, c, 10, TileType.CRUMBLE);
        }
      }
      break;
    }
    default: {
      // Double spring tower hop over a lava moat.
      setTile(b, finaleStart, STAND_ROW, TileType.SPRING);
      pit(finaleStart + 2, finaleStart + 5);
      for (let i = 0; i < 3; i++) {
        const c = finaleStart + 7 + i * 3;
        if (c > finaleEnd) break;
        setTile(b, c, 8, TileType.BRIDGE);
        setTile(b, c + 1, 8, TileType.BRIDGE);
        addCoin(b, c, 7);
      }
      if (finaleEnd - 1 > finaleStart + 7) {
        setTile(b, finaleEnd - 1, STAND_ROW, TileType.SPRING);
      }
      break;
    }
  }

  // Clear the flag approach so the pole is always reachable.
  for (let c = flagCol - 2; c <= castleCol + 4 && c < width; c++) {
    for (let r = 2; r < GROUND_ROW; r++) setTile(b, c, r, TileType.EMPTY);
    setTile(b, c, GROUND_ROW, TileType.GROUND);
    setTile(b, c, GROUND_ROW + 1, TileType.GROUND);
  }

  // --- Fairness pass -----------------------------------------------------
  // Must run before enemies/coins so steps never bury a spawn.
  ensureClimbable(b);

  // --- Enemy pass --------------------------------------------------------
  const roster = plan.enemyKinds.filter((k) => k !== 'piranha');
  const baseCount = Math.round((width / 10.5) * plan.enemyDensity);
  const enemyCount = Math.max(5, Math.min(48, baseCount));

  for (let i = 0; i < enemyCount; i++) {
    const t = (i + 1) / (enemyCount + 1);
    // Bias spawn columns across the level, with jitter.
    const target = Math.round(10 + t * (flagCol - 24) + rng.range(-5, 5));
    const kind = rng.pick(roster);

    if (kind === 'lakitu') {
      addEnemy(b, 'lakitu', target, 3);
      continue;
    }
    // Walk outward to find valid footing.
    let placed = false;
    for (let d = 0; d < 7 && !placed; d++) {
      for (const c of [target + d, target - d]) {
        if (isSolidGround(b, c) && b.tiles[STAND_ROW][c] === TileType.EMPTY) {
          addGroundEnemy(b, kind, c);
          placed = true;
          break;
        }
      }
    }
  }

  // Elite guards stationed on the final staircase from mid-campaign onward.
  if (plan.enemyKinds.includes('hammer_bro') && plan.progress > 0.22) {
    const guards = plan.progress > 0.65 ? 2 : 1;
    for (let i = 0; i < guards; i++) {
      addGroundEnemy(b, 'hammer_bro', finaleStart - 4 - i * 6);
    }
  }

  // De-duplicate spawn tiles so NPCs never stack.
  const seen = new Set<string>();
  b.enemies = b.enemies.filter((e) => {
    const key = `${e.col},${e.row}`;
    if (seen.has(key)) return false;
    seen.add(key);
    return true;
  });

  // De-duplicate coins and drop any that ended up inside solid tiles.
  const coinSeen = new Set<string>();
  b.coins = b.coins.filter((c) => {
    const key = `${c.col},${c.row}`;
    if (coinSeen.has(key)) return false;
    coinSeen.add(key);
    return b.tiles[c.row]?.[c.col] === TileType.EMPTY;
  });

  // --- Warp pipe pass ----------------------------------------------------
  // Every third level gets a guaranteed pair of enterable green pipes that
  // shortcut a chunk of the map. Pipes are built from scratch on clear ground
  // so the pair is always reachable and never clashes with other scenery.
  const warps: PipeWarp[] = [];
  const wantWarp = plan.level % 3 === 0 || b.warps.length >= 2;

  /** Carve a 2-wide, `h`-tall pipe at `col` if the ground there is clear. */
  const buildPipe = (col: number, h: number): PipeWarp | null => {
    if (col < 10 || col + 1 > flagCol - 10) return null;
    for (let c = col - 1; c <= col + 2; c++) {
      if (!isSolidGround(b, c)) return null;
      for (let r = GROUND_ROW - h - 1; r < GROUND_ROW; r++) {
        if (b.tiles[r]?.[c] !== TileType.EMPTY) return null;
      }
    }
    const topRow = GROUND_ROW - h;
    setTile(b, col, topRow, TileType.PIPE_TL);
    setTile(b, col + 1, topRow, TileType.PIPE_TR);
    for (let r = topRow + 1; r < GROUND_ROW; r++) {
      setTile(b, col, r, TileType.PIPE_BL);
      setTile(b, col + 1, r, TileType.PIPE_BR);
    }
    return { col, row: topRow, destIndex: -1, orientation: 'top' };
  };

  if (wantWarp) {
    // Prefer pipes the layout already produced, then fill in the gaps.
    const existing = b.warps
      .filter((w) => w.col > 9 && w.col < flagCol - 10)
      .sort((p1, p2) => p1.col - p2.col);

    let entry: PipeWarp | null = existing[0] ?? null;
    let exit: PipeWarp | null =
      existing.length > 1 ? existing[existing.length - 1] : null;

    if (!entry) {
      for (let c = Math.round(flagCol * 0.22); c < flagCol * 0.45 && !entry; c += 2) {
        entry = buildPipe(c, 2);
      }
    }
    if (!exit) {
      for (let c = Math.round(flagCol * 0.78); c > flagCol * 0.5 && !exit; c -= 2) {
        const made = buildPipe(c, 2);
        // Keep the two ends far enough apart for the skip to feel worthwhile.
        if (made && (!entry || made.col - entry.col > 18)) exit = made;
      }
    }

    if (entry && exit && exit.col > entry.col + 12) {
      warps.push({ ...entry, destIndex: 1 });
      warps.push({ ...exit, destIndex: 0 });
    }
  }

  // --- Weapon crate pass -------------------------------------------------
  // Weapons unlocked by earlier maps show up as crates to restock ammo.
  const pool = weaponsAvailableAt(plan.level).filter((w) => w !== 'fireball');
  const crates: Array<{ col: number; row: number; weapon: WeaponKind }> = [];
  if (pool.length > 0) {
    const crateCount = plan.level < 10 ? 1 : plan.level < 60 ? 2 : 3;
    for (let i = 1; i <= crateCount; i++) {
      const ideal = Math.round((flagCol * i) / (crateCount + 1)) + rng.int(-6, 6);
      for (let d = 0; d < 12; d++) {
        let placed = false;
        for (const c of [ideal + d, ideal - d]) {
          if (c < 9 || c > flagCol - 8) continue;
          if (!isSolidGround(b, c)) continue;
          if (b.tiles[STAND_ROW][c] !== TileType.EMPTY) continue;
          if (crates.some((e) => Math.abs(e.col - c) < 10)) continue;
          // Newer weapons weight toward later crates for a sense of progress.
          const weapon = pool[Math.min(pool.length - 1,
            Math.floor(rng.next() * pool.length))];
          crates.push({ col: c, row: STAND_ROW, weapon });
          placed = true;
          break;
        }
        if (placed) break;
      }
    }
  }

  // --- Traversal props ---------------------------------------------------
  // Grapple anchors hang above the widest pits so a skilled player can swing
  // straight across instead of using the platforms.
  {
    let gapStart = -1;
    for (let c = 8; c <= flagCol; c++) {
      const solid = b.tiles[GROUND_ROW][c] === TileType.GROUND;
      if (!solid && gapStart < 0) gapStart = c;
      if (solid && gapStart >= 0) {
        const width = c - gapStart;
        if (width >= 4) {
          const mid = Math.floor(gapStart + width / 2);
          for (let d = -1; d <= 1; d++) {
            const gc = mid + d * 2;
            if (gc > 8 && gc < flagCol - 4 && b.tiles[4][gc] === TileType.EMPTY) {
              setTile(b, gc, 4, TileType.GRAPPLE_POINT);
            }
          }
        }
        gapStart = -1;
      }
    }
  }

  // Wall-run strips on tall solid columns, and the odd phase wall that only
  // the Shadow costume can slip through.
  for (let c = 12; c < flagCol - 10; c++) {
    const h = wallHeight(b, c);
    if (h >= 3 && rng.chance(0.3)) {
      for (let r = GROUND_ROW - h; r < GROUND_ROW - 1; r++) {
        setTile(b, c, r, TileType.WALL_RUN);
      }
    }
  }
  if (plan.level >= 6 && rng.chance(0.4)) {
    for (let tries = 0; tries < 10; tries++) {
      const c = rng.int(16, Math.max(17, flagCol - 14));
      if (b.tiles[GROUND_ROW][c] !== TileType.GROUND) continue;
      if (b.tiles[STAND_ROW][c] !== TileType.EMPTY) continue;
      setTile(b, c, STAND_ROW, TileType.PHASE_WALL);
      setTile(b, c, STAND_ROW - 1, TileType.PHASE_WALL);
      // Reward behind the thin wall.
      addCoin(b, c + 1, STAND_ROW);
      addCoin(b, c + 1, STAND_ROW - 1);
      break;
    }
  }

  // --- Physics puzzle ----------------------------------------------------
  // A gate blocks a coin stash; stepping on every button opens it. A pushable
  // crate lets the player weigh a button down permanently.
  let puzzle: LevelDefinition['puzzle'] = null;
  if (plan.level >= 4) {
    const base = Math.round(flagCol * rng.range(0.3, 0.62));
    const buttons: Array<{ col: number; row: number }> = [];
    const gates: Array<{ col: number; row: number }> = [];
    const count = plan.level >= 40 ? 2 : 1;

    for (let i = 0; i < count; i++) {
      for (let d = 0; d < 10; d++) {
        const c = base + i * 7 + d;
        if (c < 10 || c > flagCol - 12) break;
        if (b.tiles[GROUND_ROW][c] !== TileType.GROUND) continue;
        if (b.tiles[STAND_ROW][c] !== TileType.EMPTY) continue;
        setTile(b, c, STAND_ROW, TileType.BUTTON);
        buttons.push({ col: c, row: STAND_ROW });
        break;
      }
    }

    if (buttons.length === count) {
      // Pushable crate next to the first button.
      const pc = buttons[0].col + 3;
      if (pc < flagCol - 10 && b.tiles[GROUND_ROW][pc] === TileType.GROUND &&
          b.tiles[STAND_ROW][pc] === TileType.EMPTY) {
        setTile(b, pc, STAND_ROW, TileType.PUSH_BLOCK);
      }

      const gc = buttons[buttons.length - 1].col + 8;
      if (gc < flagCol - 8) {
        for (let r = STAND_ROW; r > STAND_ROW - 3; r--) {
          setTile(b, gc, r, TileType.GATE);
          gates.push({ col: gc, row: r });
        }
        // Treasure sealed behind the gate.
        for (let i = 1; i <= 4; i++) addCoin(b, gc + i, STAND_ROW);
      }
      if (gates.length > 0) puzzle = { buttons, gates };
      else for (const bt of buttons) setTile(b, bt.col, bt.row, TileType.EMPTY);
    }
  }

  // Traversal props and the gate rewrote terrain (a gate can overwrite the
  // steps the first fairness pass built), so re-assert the climb rule now
  // that every structural edit is done. The pass is idempotent.
  ensureClimbable(b);

  // --- Hidden relic ------------------------------------------------------
  // Tucked high up and off the critical path so it rewards exploring.
  let relic: { col: number; row: number } | null = null;
  for (let tries = 0; tries < 24 && !relic; tries++) {
    const c = rng.int(14, Math.max(15, flagCol - 10));
    const r = rng.int(3, 7);
    if (b.tiles[r][c] !== TileType.EMPTY) continue;
    if (b.tiles[r + 1][c] !== TileType.EMPTY) continue;
    relic = { col: c, row: r };
  }

  // --- Checkpoint pass ---------------------------------------------------
  // Longer maps get more respawn flags; always on firm, clear ground.
  const checkpointCount = width > 170 ? 3 : width > 130 ? 2 : 1;
  const checkpoints: number[] = [];
  for (let i = 1; i <= checkpointCount; i++) {
    const ideal = Math.round((flagCol * i) / (checkpointCount + 1));
    for (let d = 0; d < 14; d++) {
      let done = false;
      for (const c of [ideal + d, ideal - d]) {
        if (c < 10 || c > flagCol - 6) continue;
        if (!isSolidGround(b, c)) continue;
        if (b.tiles[STAND_ROW][c] !== TileType.EMPTY) continue;
        if (b.tiles[11][c] !== TileType.EMPTY) continue;
        if (checkpoints.some((e) => Math.abs(e - c) < 12)) continue;
        setTile(b, c, STAND_ROW, TileType.CHECKPOINT);
        checkpoints.push(c);
        done = true;
        break;
      }
      if (done) break;
    }
  }
  checkpoints.sort((a, z) => a - z);

  // Keep a safe landing zone around every flag so a respawn can never drop
  // Mario straight into an enemy (which would cause a spawn-kill loop).
  if (checkpoints.length > 0) {
    b.enemies = b.enemies.filter((e) => {
      if (e.kind === 'lakitu') return true;
      return !checkpoints.some((cp) => Math.abs(cp - e.col) < 5);
    });
  }

  const meta = { name: getLevelBiome(plan.level).name };
  const worldIndex = Math.floor((plan.level - 1) / 12) + 1;
  const stageIndex = ((plan.level - 1) % 12) + 1;

  return {
    index: plan.level - 1,
    worldLabel: `${worldIndex}-${stageIndex}`,
    subtitle: meta.name,
    theme,
    timeLimit: plan.timeLimit,
    widthCols: width,
    heightRows: ROWS,
    tiles: b.tiles,
    coins: b.coins,
    enemies: b.enemies,
    platforms: b.platforms,
    flagCol,
    castleCol,
    checkpoints,
    relic,
    puzzle,
    warps,
    weaponCrates: crates,
    hazardLabel: hazards.label,
  };
}
