import {
  Difficulty,
  EnemyKind,
  LevelDefinition,
  THEME_HAZARDS,
  TileType,
  TOTAL_LEVELS,
} from './types';
import { generateLevel, makeLevelFair } from './levelGen';

const ROWS = 15;

interface LevelBuilder {
  tiles: number[][];
  coins: Array<{ col: number; row: number }>;
  enemies: Array<{ kind: EnemyKind; col: number; row: number }>;
  platforms: LevelDefinition['platforms'];
  widthCols: number;
}

function createBuilder(widthCols: number): LevelBuilder {
  const tiles: number[][] = Array.from({ length: ROWS }, () =>
    Array(widthCols).fill(TileType.EMPTY)
  );
  // Default full ground across rows 13 & 14
  for (let c = 0; c < widthCols; c++) {
    tiles[13][c] = TileType.GROUND;
    tiles[14][c] = TileType.GROUND;
  }
  return {
    tiles,
    coins: [],
    enemies: [],
    platforms: [],
    widthCols,
  };
}

function setTile(b: LevelBuilder, col: number, row: number, tile: TileType) {
  if (row >= 0 && row < ROWS && col >= 0 && col < b.widthCols) {
    b.tiles[row][col] = tile;
  }
}

function fillRect(
  b: LevelBuilder,
  colStart: number,
  rowStart: number,
  w: number,
  h: number,
  tile: TileType
) {
  for (let r = rowStart; r < rowStart + h; r++) {
    for (let c = colStart; c < colStart + w; c++) {
      setTile(b, c, r, tile);
    }
  }
}

function addPit(b: LevelBuilder, colStart: number, width: number, withLava = false) {
  for (let c = colStart; c < colStart + width; c++) {
    setTile(b, c, 13, TileType.EMPTY);
    setTile(b, c, 14, withLava ? TileType.LAVA : TileType.EMPTY);
  }
}

function addPipe(
  b: LevelBuilder,
  col: number,
  heightTiles: number,
  withPiranha = false
) {
  const topRow = 13 - heightTiles;
  setTile(b, col, topRow, TileType.PIPE_TL);
  setTile(b, col + 1, topRow, TileType.PIPE_TR);
  for (let r = topRow + 1; r < 13; r++) {
    setTile(b, col, r, TileType.PIPE_BL);
    setTile(b, col + 1, r, TileType.PIPE_BR);
  }
  if (withPiranha) {
    b.enemies.push({ kind: 'piranha', col, row: topRow });
  }
}

function addCoinRow(b: LevelBuilder, startCol: number, row: number, count: number) {
  for (let i = 0; i < count; i++) {
    b.coins.push({ col: startCol + i, row });
  }
}

function addCoinArc(b: LevelBuilder, centerCol: number, peakRow: number) {
  b.coins.push({ col: centerCol - 2, row: peakRow + 1 });
  b.coins.push({ col: centerCol - 1, row: peakRow });
  b.coins.push({ col: centerCol, row: peakRow });
  b.coins.push({ col: centerCol + 1, row: peakRow + 1 });
}

function buildWorld1_1(): LevelDefinition {
  const widthCols = 118;
  const b = createBuilder(widthCols);

  // First 10 seconds hook: instant coins, ? power-up, bricks, first Goomba!
  addCoinRow(b, 6, 10, 3);
  setTile(b, 11, 9, TileType.Q_COIN);

  setTile(b, 15, 9, TileType.BRICK);
  setTile(b, 16, 9, TileType.Q_POWER); // Super Mushroom / Fire Flower right away!
  setTile(b, 17, 9, TileType.BRICK);
  setTile(b, 18, 9, TileType.Q_COIN);
  setTile(b, 19, 9, TileType.BRICK);
  setTile(b, 17, 5, TileType.Q_COIN);
  addCoinRow(b, 16, 4, 3);

  b.enemies.push({ kind: 'goomba', col: 17, row: 12 });

  // Signature overworld parkour: bouncy mushroom pads.
  setTile(b, 21, 12, TileType.JELLY);
  addCoinRow(b, 21, 7, 1);

  // Puzzle: button opens the gate guarding a coin stash.
  setTile(b, 46, 12, TileType.BUTTON);
  setTile(b, 49, 12, TileType.PUSH_BLOCK);
  for (let r = 10; r <= 12; r++) setTile(b, 54, r, TileType.GATE);
  for (let i = 1; i <= 4; i++) b.coins.push({ col: 54 + i, row: 12 });
  // Grapple anchors over the wide gaps.
  setTile(b, 51, 4, TileType.GRAPPLE_POINT);
  setTile(b, 70, 4, TileType.GRAPPLE_POINT);

  // Mid-level respawn flags.
  setTile(b, 34, 12, TileType.CHECKPOINT);
  setTile(b, 72, 12, TileType.CHECKPOINT);

  // Classic Warp Pipe Trio + Shell Bowling Alley!
  addPipe(b, 23, 2, false);
  b.enemies.push({ kind: 'goomba', col: 27, row: 12 });

  addPipe(b, 30, 3, true);
  addCoinArc(b, 35, 7);
  b.enemies.push({ kind: 'koopa_green', col: 35, row: 12 });
  b.enemies.push({ kind: 'goomba', col: 38, row: 12 });
  b.enemies.push({ kind: 'goomba', col: 40, row: 12 });

  addPipe(b, 43, 4, true);
  addCoinRow(b, 43, 6, 2);

  // Hidden/Bonus 1-UP + Gap #1
  setTile(b, 47, 8, TileType.Q_1UP);
  addPit(b, 50, 3);
  addCoinArc(b, 51, 8);

  // POW Block & Multi-Layer Brick Arena
  fillRect(b, 56, 9, 3, 1, TileType.BRICK);
  setTile(b, 57, 9, TileType.Q_POWER);
  setTile(b, 60, 9, TileType.POW_BLOCK); // Hit POW to flip the whole squad!
  fillRect(b, 62, 5, 6, 1, TileType.BRICK);
  addCoinRow(b, 63, 4, 4);

  b.enemies.push({ kind: 'goomba', col: 58, row: 12 });
  b.enemies.push({ kind: 'koopa_red', col: 64, row: 4 });
  b.enemies.push({ kind: 'goomba', col: 63, row: 12 });
  b.enemies.push({ kind: 'goomba', col: 65, row: 12 });

  // Starman Rush Section!
  addPit(b, 69, 3);
  setTile(b, 74, 9, TileType.BRICK);
  setTile(b, 75, 9, TileType.Q_STAR); // Super Star!
  setTile(b, 76, 9, TileType.MULTI_COIN_BRICK);
  addCoinRow(b, 79, 11, 4);

  b.enemies.push({ kind: 'goomba', col: 80, row: 12 });
  b.enemies.push({ kind: 'goomba', col: 82, row: 12 });
  b.enemies.push({ kind: 'koopa_green', col: 84, row: 12 });
  b.enemies.push({ kind: 'goomba', col: 86, row: 12 });

  // Spring High-Road + Stair Pyramid Finale
  setTile(b, 89, 12, TileType.SPRING);
  fillRect(b, 91, 6, 5, 1, TileType.BRIDGE);
  addCoinRow(b, 91, 5, 5);

  // Finale: spike hops into a crumbling causeway (no staircase).
  setTile(b, 97, 12, TileType.SPIKE);
  setTile(b, 100, 12, TileType.SPIKE);
  addPit(b, 102, 4);
  for (let i = 0; i < 4; i++) setTile(b, 102 + i, 11, TileType.CRUMBLE);
  addCoinRow(b, 102, 10, 4);
  setTile(b, 108, 12, TileType.JELLY);
  addCoinRow(b, 108, 7, 1);

  return {
    index: 0,
    worldLabel: '1-1',
    subtitle: 'MUSHROOM PLAINS',
    theme: 'overworld',
    timeLimit: 360,
    widthCols,
    heightRows: ROWS,
    tiles: b.tiles,
    coins: b.coins,
    enemies: b.enemies,
    platforms: b.platforms,
    flagCol: 112,
    castleCol: 115,
    checkpoints: [34, 72],
    relic: { col: 62, row: 4 },
    puzzle: {
      buttons: [{ col: 46, row: 12 }],
      gates: [
        { col: 54, row: 12 }, { col: 54, row: 11 }, { col: 54, row: 10 },
      ],
    },
    // Pipe at col 23 warps forward to the tall pipe at col 43.
    warps: [
      { col: 23, row: 11, destIndex: 1, orientation: 'top' as const },
      { col: 43, row: 9, destIndex: 0, orientation: 'top' as const },
    ],
    weaponCrates: [{ col: 27, row: 12, weapon: 'hammer' as const }],
    hazardLabel: THEME_HAZARDS.overworld.label,
  };
}

function buildWorld1_2(): LevelDefinition {
  const widthCols = 122;
  const b = createBuilder(widthCols);

  // Underground brick ceiling (with opening near flagpole at end)
  for (let c = 2; c < 104; c++) {
    setTile(b, c, 1, TileType.BRICK);
  }

  // Opening coin run & power-up
  addCoinRow(b, 6, 11, 4);
  setTile(b, 11, 9, TileType.Q_POWER);
  setTile(b, 12, 9, TileType.Q_COIN);
  setTile(b, 13, 9, TileType.BRICK);
  b.enemies.push({ kind: 'buzzy', col: 16, row: 12 });

  // Signature cavern parkour: spike beds and crumbling rock.
  setTile(b, 17, 12, TileType.SPIKE);
  setTile(b, 46, 12, TileType.SPIKE);
  setTile(b, 47, 12, TileType.SPIKE);
  for (let i = 0; i < 4; i++) setTile(b, 53 + i, 11, TileType.CRUMBLE);

  setTile(b, 28, 12, TileType.BUTTON);
  setTile(b, 31, 12, TileType.PUSH_BLOCK);
  for (let r = 10; r <= 12; r++) setTile(b, 36, r, TileType.GATE);
  for (let i = 1; i <= 4; i++) b.coins.push({ col: 36 + i, row: 12 });
  setTile(b, 52, 4, TileType.GRAPPLE_POINT);
  setTile(b, 86, 4, TileType.GRAPPLE_POINT);

  // Mid-level respawn flags.
  setTile(b, 32, 12, TileType.CHECKPOINT);
  setTile(b, 74, 12, TileType.CHECKPOINT);

  // Stone Pillars + Red Koopa Patrol
  fillRect(b, 19, 10, 2, 3, TileType.SOLID_BLOCK);
  addCoinArc(b, 22, 7);
  fillRect(b, 24, 8, 2, 5, TileType.SOLID_BLOCK);
  b.enemies.push({ kind: 'koopa_red', col: 28, row: 12 });
  b.enemies.push({ kind: 'goomba', col: 30, row: 12 });

  // Classic Mario Bros Underground POW Chamber!
  fillRect(b, 33, 9, 5, 1, TileType.BRICK);
  setTile(b, 39, 9, TileType.POW_BLOCK);
  fillRect(b, 41, 9, 5, 1, TileType.BRICK);
  fillRect(b, 36, 5, 7, 1, TileType.BRICK);
  setTile(b, 39, 5, TileType.Q_POWER);
  addCoinRow(b, 37, 4, 5);

  b.enemies.push({ kind: 'buzzy', col: 37, row: 8 });
  b.enemies.push({ kind: 'buzzy', col: 42, row: 8 });
  b.enemies.push({ kind: 'koopa_green', col: 39, row: 12 });

  // Underground Moving Elevator Chasm
  addPit(b, 49, 7);
  b.platforms.push({
    col: 50,
    row: 10,
    widthTiles: 3,
    rangeCols: 3,
    rangeRows: 0,
    speed: 1.8,
  });
  addCoinRow(b, 51, 7, 3);

  // Warp Pipes & Multi-Coin Stash
  addPipe(b, 59, 3, true);
  setTile(b, 63, 9, TileType.MULTI_COIN_BRICK);
  setTile(b, 64, 9, TileType.Q_STAR);
  addPipe(b, 67, 4, true);

  // Crystal Cavern Gauntlet
  b.enemies.push({ kind: 'buzzy', col: 72, row: 12 });
  b.enemies.push({ kind: 'goomba', col: 74, row: 12 });
  b.enemies.push({ kind: 'koopa_green', col: 76, row: 12 });
  b.enemies.push({ kind: 'goomba', col: 78, row: 12 });
  addCoinRow(b, 72, 9, 6);

  // Vertical Moving Lift + Upper Secret Route
  addPit(b, 83, 6);
  b.platforms.push({
    col: 84.5,
    row: 11,
    widthTiles: 3,
    rangeCols: 0,
    rangeRows: 4,
    speed: 2.1,
  });
  fillRect(b, 90, 6, 7, 1, TileType.BRICK);
  addCoinRow(b, 91, 5, 5);
  setTile(b, 96, 6, TileType.Q_1UP);

  // Exit Stairs to Cavern Citadel
  // Finale: spring launch into floating brick hops (no staircase).
  setTile(b, 100, 12, TileType.SPRING);
  for (let i = 0; i < 4; i++) {
    setTile(b, 104 + i * 2, 7 + (i % 2), TileType.BRICK);
    b.coins.push({ col: 104 + i * 2, row: 6 + (i % 2) });
  }
  setTile(b, 106, 12, TileType.SPIKE);
  setTile(b, 110, 12, TileType.SPIKE);

  return {
    index: 1,
    worldLabel: '1-2',
    subtitle: 'CRYSTAL CAVERN',
    theme: 'underground',
    timeLimit: 360,
    widthCols,
    heightRows: ROWS,
    tiles: b.tiles,
    coins: b.coins,
    enemies: b.enemies,
    platforms: b.platforms,
    flagCol: 115,
    castleCol: 118,
    checkpoints: [32, 74],
    relic: { col: 44, row: 3 },
    puzzle: {
      buttons: [{ col: 28, row: 12 }],
      gates: [
        { col: 36, row: 12 }, { col: 36, row: 11 }, { col: 36, row: 10 },
      ],
    },
    warps: [
      { col: 59, row: 10, destIndex: 1, orientation: 'top' as const },
      { col: 67, row: 9, destIndex: 0, orientation: 'top' as const },
    ],
    weaponCrates: [
      { col: 21, row: 12, weapon: 'hammer' as const },
      { col: 72, row: 12, weapon: 'boomerang' as const },
    ],
    hazardLabel: THEME_HAZARDS.underground.label,
  };
}

function buildWorld1_3(): LevelDefinition {
  const widthCols = 126;
  const b = createBuilder(widthCols);

  // Immediate Castle Bridge + Power-Up
  addCoinRow(b, 6, 10, 3);
  setTile(b, 10, 9, TileType.Q_POWER);
  setTile(b, 11, 9, TileType.BRICK);
  setTile(b, 12, 9, TileType.Q_COIN);

  // First Lava Moat with Bridge
  addPit(b, 15, 5, true);
  fillRect(b, 15, 11, 5, 1, TileType.BRIDGE);
  addCoinArc(b, 17, 8);
  b.enemies.push({ kind: 'koopa_red', col: 22, row: 12 });

  // Signature fortress parkour: spike traps lining the lava moats.
  setTile(b, 24, 12, TileType.SPIKE);
  setTile(b, 40, 12, TileType.SPIKE);
  setTile(b, 64, 12, TileType.SPIKE);
  setTile(b, 65, 12, TileType.SPIKE);

  setTile(b, 50, 12, TileType.BUTTON);
  setTile(b, 53, 12, TileType.PUSH_BLOCK);
  for (let r = 10; r <= 12; r++) setTile(b, 58, r, TileType.GATE);
  for (let i = 1; i <= 4; i++) b.coins.push({ col: 58 + i, row: 12 });
  setTile(b, 30, 4, TileType.GRAPPLE_POINT);
  setTile(b, 55, 4, TileType.GRAPPLE_POINT);

  // Mid-level respawn flags.
  setTile(b, 38, 12, TileType.CHECKPOINT);
  setTile(b, 74, 12, TileType.CHECKPOINT);

  // Dual Sky Bridges & Spring Jump
  addPit(b, 26, 12, true);
  fillRect(b, 27, 10, 4, 1, TileType.BRIDGE);
  fillRect(b, 32, 7, 5, 1, TileType.BRIDGE);
  addCoinRow(b, 33, 6, 3);
  b.enemies.push({ kind: 'koopa_red', col: 34, row: 6 });

  // Stone Bastion + POW Defense
  setTile(b, 41, 9, TileType.POW_BLOCK);
  setTile(b, 44, 9, TileType.Q_POWER);
  b.enemies.push({ kind: 'buzzy', col: 42, row: 12 });
  b.enemies.push({ kind: 'koopa_green', col: 45, row: 12 });
  b.enemies.push({ kind: 'buzzy', col: 47, row: 12 });

  // Moving Lava Platforms
  addPit(b, 51, 13, true);
  b.platforms.push({
    col: 52,
    row: 10,
    widthTiles: 3,
    rangeCols: 3.5,
    rangeRows: 0,
    speed: 1.9,
    phase: 0,
  });
  b.platforms.push({
    col: 59,
    row: 8,
    widthTiles: 3,
    rangeCols: 3,
    rangeRows: 1.5,
    speed: 2.0,
    phase: Math.PI,
  });
  addCoinRow(b, 54, 7, 2);
  addCoinRow(b, 60, 5, 3);

  // Fortress Battlements + Starman Blitz!
  addPipe(b, 67, 3, true);
  setTile(b, 71, 9, TileType.Q_STAR);
  setTile(b, 72, 9, TileType.MULTI_COIN_BRICK);
  fillRect(b, 75, 9, 6, 1, TileType.BRICK);
  addCoinRow(b, 76, 8, 4);

  b.enemies.push({ kind: 'buzzy', col: 76, row: 12 });
  b.enemies.push({ kind: 'koopa_red', col: 79, row: 12 });
  b.enemies.push({ kind: 'goomba', col: 82, row: 12 });
  b.enemies.push({ kind: 'koopa_green', col: 85, row: 12 });

  // Final Lava Leap + Spring Launch to Fortress Summit
  addPit(b, 89, 5, true);
  fillRect(b, 90, 9, 3, 1, TileType.BRIDGE);
  addCoinRow(b, 90, 8, 3);

  setTile(b, 97, 12, TileType.SPRING);
  fillRect(b, 99, 6, 4, 1, TileType.BRIDGE);
  setTile(b, 101, 3, TileType.Q_1UP);

  // Finale: lava ferry on moving platforms (no staircase).
  addPit(b, 106, 8, true);
  b.platforms.push({
    col: 107, row: 11, widthTiles: 3,
    rangeCols: 3, rangeRows: 0, speed: 2.1, phase: 0,
  });
  b.platforms.push({
    col: 111, row: 9, widthTiles: 3,
    rangeCols: 0, rangeRows: 2.5, speed: 2.3, phase: Math.PI,
  });
  addCoinRow(b, 108, 8, 4);

  return {
    index: 2,
    worldLabel: '1-3',
    subtitle: 'STARLIGHT FORTRESS',
    theme: 'castle',
    timeLimit: 360,
    widthCols,
    heightRows: ROWS,
    tiles: b.tiles,
    coins: b.coins,
    enemies: b.enemies,
    platforms: b.platforms,
    flagCol: 118,
    castleCol: 121,
    checkpoints: [38, 74],
    relic: { col: 56, row: 4 },
    puzzle: {
      buttons: [{ col: 50, row: 12 }],
      gates: [
        { col: 58, row: 12 }, { col: 58, row: 11 }, { col: 58, row: 10 },
      ],
    },
    warps: [
      { col: 67, row: 10, destIndex: 1, orientation: 'top' as const },
      { col: 90, row: 12, destIndex: 0, orientation: 'top' as const },
    ],
    weaponCrates: [
      { col: 22, row: 12, weapon: 'hammer' as const },
      { col: 57, row: 12, weapon: 'boomerang' as const },
    ],
    hazardLabel: THEME_HAZARDS.castle.label,
  };
}

// ---------------------------------------------------------------------------
// Campaign API — 8000 levels, every level a different theme than its neighbour
// ---------------------------------------------------------------------------

/**
 * Three handcrafted showcase stages are pinned to the level numbers whose
 * rotating theme matches them, so the campaign opens with authored content
 * and everything else is generated procedurally.
 */
const HANDCRAFTED: Record<number, () => LevelDefinition> = {
  1: buildWorld1_1, // overworld slot
  2: buildWorld1_2, // underground slot
  12: buildWorld1_3, // castle slot
};

export interface EnemySpawn {
  kind: EnemyKind;
  col: number;
  row: number;
}

/** Bonus NPC packs layered onto the handcrafted stages per difficulty. */
const HAND_EXTRAS: Record<number, Record<string, EnemySpawn[]>> = {
  1: {
    medium: [
      { kind: 'goomba', col: 21, row: 12 },
      { kind: 'goomba', col: 37, row: 12 },
      { kind: 'buzzy', col: 54, row: 12 },
      { kind: 'goomba', col: 61, row: 12 },
      { kind: 'goomba', col: 79, row: 12 },
      { kind: 'koopa_red', col: 87, row: 12 },
      { kind: 'hammer_bro', col: 92, row: 5 },
    ],
    hard: [
      { kind: 'koopa_green', col: 26, row: 12 },
      { kind: 'hammer_bro', col: 33, row: 12 },
      { kind: 'spiny', col: 58, row: 12 },
      { kind: 'dry_bones', col: 68, row: 12 },
      { kind: 'spiny', col: 83, row: 12 },
    ],
    nightmare: [
      { kind: 'lakitu', col: 30, row: 3 },
      { kind: 'spiny', col: 45, row: 12 },
      { kind: 'dry_bones', col: 57, row: 12 },
      { kind: 'dry_bones', col: 77, row: 12 },
    ],
  },
  2: {
    medium: [
      { kind: 'goomba', col: 14, row: 12 },
      { kind: 'buzzy', col: 27, row: 12 },
      { kind: 'hammer_bro', col: 40, row: 4 },
      { kind: 'goomba', col: 44, row: 12 },
      { kind: 'koopa_red', col: 65, row: 12 },
      { kind: 'buzzy', col: 80, row: 12 },
    ],
    hard: [
      { kind: 'koopa_red', col: 18, row: 12 },
      { kind: 'spiny', col: 30, row: 12 },
      { kind: 'dry_bones', col: 46, row: 12 },
      { kind: 'spiny', col: 66, row: 12 },
      { kind: 'hammer_bro', col: 70, row: 12 },
    ],
    nightmare: [
      { kind: 'lakitu', col: 24, row: 3 },
      { kind: 'dry_bones', col: 31, row: 12 },
      { kind: 'spiny', col: 58, row: 12 },
      { kind: 'dry_bones', col: 97, row: 12 },
    ],
  },
  12: {
    medium: [
      { kind: 'goomba', col: 20, row: 12 },
      { kind: 'buzzy', col: 44, row: 12 },
      { kind: 'goomba', col: 48, row: 12 },
      { kind: 'hammer_bro', col: 77, row: 8 },
      { kind: 'koopa_red', col: 86, row: 12 },
    ],
    hard: [
      { kind: 'buzzy', col: 25, row: 12 },
      { kind: 'hammer_bro', col: 49, row: 12 },
      { kind: 'spiny', col: 66, row: 12 },
      { kind: 'dry_bones', col: 84, row: 12 },
    ],
    nightmare: [
      { kind: 'lakitu', col: 20, row: 3 },
      { kind: 'spiny', col: 45, row: 12 },
      { kind: 'dry_bones', col: 83, row: 12 },
      { kind: 'spiny', col: 95, row: 12 },
    ],
  },
};

function withHandcraftedExtras(
  def: LevelDefinition,
  levelNumber: number,
  difficulty: Difficulty
): LevelDefinition {
  const packs = HAND_EXTRAS[levelNumber];
  // These are early-campaign stages, so they stay close to their authored
  // design unless the player deliberately picks a harder NPC setting.
  if (!packs || difficulty === 'easy' || difficulty === 'medium') return def;

  const extra: EnemySpawn[] = [...(packs.medium ?? [])];
  extra.push(...(packs.hard ?? []));
  if (difficulty === 'nightmare') {
    extra.push(...(packs.nightmare ?? []));
  }

  const seen = new Set(def.enemies.map((e) => `${e.col},${e.row}`));
  const merged = [...def.enemies];
  for (const spawn of extra) {
    const key = `${spawn.col},${spawn.row}`;
    if (seen.has(key)) continue;
    seen.add(key);
    merged.push(spawn);
  }
  return { ...def, enemies: merged };
}

/** Small LRU so revisiting nearby levels never re-generates terrain. */
const levelCache = new Map<string, LevelDefinition>();
const CACHE_LIMIT = 24;

export function getLevel(
  levelNumber: number,
  difficulty: Difficulty = 'medium'
): LevelDefinition {
  const level = Math.max(1, Math.min(TOTAL_LEVELS, Math.floor(levelNumber)));
  const key = `${level}|${difficulty}`;

  const cached = levelCache.get(key);
  if (cached) return cached;

  let def: LevelDefinition;
  const handcrafted = HANDCRAFTED[level];
  if (handcrafted) {
    // The authored stages were built dense; thin them out for newcomers so
    // the opening of the campaign matches the gentle generated ramp.
    const thin = (d: LevelDefinition): LevelDefinition => {
      const keep = level <= 2 ? 0.45 : level <= 12 ? 0.7 : 1;
      if (keep >= 1) return d;
      return {
        ...d,
        enemies: d.enemies.filter(
          (e, i) => e.kind === 'piranha' || i % Math.round(1 / keep) === 0
        ),
      };
    };
    // Handcrafted stages skip the generator, so run the fairness pass here
    // to guarantee no wall is taller than a standing jump.
    def = thin(makeLevelFair(withHandcraftedExtras(handcrafted(), level, difficulty)));
  } else {
    def = generateLevel(level, difficulty);
  }

  if (levelCache.size >= CACHE_LIMIT) {
    const oldest = levelCache.keys().next().value;
    if (oldest !== undefined) levelCache.delete(oldest);
  }
  levelCache.set(key, def);
  return def;
}

export { TOTAL_LEVELS };
