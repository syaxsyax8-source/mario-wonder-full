import { MarioGameEngine } from './engine';
import { getSprites, SpriteBank } from './sprites';
import {
  BackdropLayer,
  getLevelBiome,
  LayerKind,
  LevelBiome,
} from './biomes';
import { getBiomeTiles } from './sprites';
import { WEATHER_DEFS, weatherIntensity } from './types';
import {
  PETS,
  Enemy,
  EnemyProjectile,
  ENEMY_STATS,
  Fireball,
  WeaponPickup,
  WEAPONS,
  PowerItem,
  TILE_SIZE,
  TileType,
  WorldTheme,
} from './types';

/** Default horizontal repeat distance per layer kind (world px). */
const DEFAULT_SPAN: Partial<Record<LayerKind, number>> = {
  clouds: 300, cloudislands: 250, mountains: 330, snowpeaks: 330, hills: 320,
  dunes: 260, mesa: 300, pyramids: 340, pines: 230, broadleaf: 280,
  mushroomtrees: 280, candytrees: 280, palms: 230, bamboo: 190, cacti: 240,
  deadtrees: 250, vines: 95, kelp: 180, coral: 220, buildings: 250,
  neon: 250, towers: 290, ruins: 230, obelisk: 240, pillars: 240,
  crystals: 230, stalactites: 230, tombstones: 240, lanterns: 240,
  shipwreck: 340, windmill: 300, balloons: 240, lollipops: 260,
  icebergs: 240, geyser: 250, planets: 420, gridfloor: 46,
};

/** How fast each weather settles onto the terrain (per second). */
/** Surfaces that weather can settle on. */
const DEPOSIT_TILES = new Set<number>([
  TileType.GROUND, TileType.BRICK, TileType.SOLID_BLOCK, TileType.USED_BLOCK,
  TileType.Q_COIN, TileType.Q_POWER, TileType.Q_STAR, TileType.Q_1UP,
  TileType.MULTI_COIN_BRICK, TileType.PIPE_TL, TileType.PIPE_TR,
  TileType.BRIDGE, TileType.ICE, TileType.CRUMBLE,
]);

const ACCUM_RATE: Record<string, number> = {
  snow: 0.16, blizzard: 0.3, hail: 0.2, sandstorm: 0.26,
  rain: 0.3, storm: 0.4, typhoon: 0.5, embers: 0.14, petals: 0.13,
  fog: 0.1,
};

const ATMOSPHERE: Partial<Record<WorldTheme, { c: string; a: number }>> = {
  underground: { c: '#1d4ed8', a: 0.16 },
  castle: { c: '#7f1d1d', a: 0.16 },
  haunted: { c: '#6d28d9', a: 0.2 },
  volcano: { c: '#ea580c', a: 0.18 },
  factory: { c: '#334155', a: 0.14 },
  snow: { c: '#bae6fd', a: 0.14 },
  desert: { c: '#f59e0b', a: 0.12 },
  candy: { c: '#f472b6', a: 0.12 },
  jungle: { c: '#15803d', a: 0.13 },
  sky: { c: '#93c5fd', a: 0.1 },
  beach: { c: '#22d3ee', a: 0.1 },
};

export class MarioRenderer {
  private sprites: SpriteBank;
  /** Current weather strength 0..1, driven by the level's schedule. */
  private weatherStrength = 1;
  /**
   * How much weather has settled on the map, 0..1. Builds while the weather
   * falls and melts/dries away after it stops, so storms leave a visible
   * mark on the terrain instead of vanishing the instant they end.
   */
  private accumulation = 0;
  private accumLevel = -1;
  private lastFrameTime = 0;

  constructor() {
    this.sprites = getSprites();
  }

  public render(
    ctx: CanvasRenderingContext2D,
    engine: MarioGameEngine,
    canvasWidth: number,
    canvasHeight: number
  ): void {
    const worldPixelHeight = 15 * TILE_SIZE; // 480px logical height
    const scale = Math.min(
      canvasHeight / worldPixelHeight,
      canvasWidth / 448
    );
    const viewW = canvasWidth / scale;
    const fullLogicalH = canvasHeight / scale;
    const extraBottom = Math.max(0, fullLogicalH - worldPixelHeight);
    // Slight top offset on tall portrait screens while keeping bottom pad clear
    const offsetY = Math.min(36, extraBottom * 0.16);

    ctx.save();
    ctx.imageSmoothingEnabled = false;
    ctx.scale(scale, scale);

    // Fill full screen base so tall portrait viewports have cohesive dark bedrock
    ctx.fillStyle =
      engine.levelDef.theme === 'underground'
        ? '#08142b'
        : engine.levelDef.theme === 'castle'
          ? '#140c1f'
          : '#231006';
    ctx.fillRect(0, 0, viewW + 2, fullLogicalH + 2);

    ctx.translate(0, offsetY);

    // Apply decaying screen shake
    let shakeX = 0;
    let shakeY = 0;
    if (engine.shakeTime > 0) {
      const mag = engine.shakeMagnitude * Math.min(1, engine.shakeTime * 5);
      shakeX = (Math.random() * 2 - 1) * mag;
      shakeY = (Math.random() * 2 - 1) * mag;
    }

    const camX = Math.floor(engine.cameraX);
    const lb = getLevelBiome(engine.levelIndex + 1);

    // How far through the map we are — drives position-based schedules.
    const levelPx = Math.max(1, engine.levelDef.widthCols * TILE_SIZE - viewW);
    const progress = Math.max(0, Math.min(1, engine.cameraX / levelPx));
    const elapsed = Math.max(
      0, engine.levelDef.timeLimit - engine.timeRemaining
    );
    this.weatherStrength = weatherIntensity(lb.schedule, progress, elapsed);

    // Settle / melt the deposit layer.
    const dt = Math.max(
      0, Math.min(0.1, engine.worldTime - this.lastFrameTime)
    );
    this.lastFrameTime = engine.worldTime;
    if (this.accumLevel !== engine.levelIndex) {
      this.accumLevel = engine.levelIndex;
      this.accumulation = 0;
    }
    const settleRate = ACCUM_RATE[lb.weather] ?? 0;
    if (settleRate > 0) {
      const target = this.weatherStrength;
      if (target > 0.05) {
        this.accumulation = Math.min(
          1, this.accumulation + dt * settleRate * target
        );
      } else {
        // Fades roughly 3x slower than it builds — the mark lingers.
        this.accumulation = Math.max(
          0, this.accumulation - dt * settleRate * 0.34
        );
      }
    }

    // Violent weather buffets the camera on top of any impact shake
    // (scaled so a dying storm stops shaking the view).
    const wsh = WEATHER_DEFS[lb.weather].shake * this.weatherStrength;
    if (wsh > 0) {
      const t = engine.worldTime;
      shakeX += Math.sin(t * 7.3) * wsh + Math.sin(t * 2.1) * wsh * 0.6;
      shakeY += Math.sin(t * 5.7 + 1.1) * wsh * 0.5;
    }

    // 1. Sky & Multi-Layer Parallax Background
    this.drawBackground(
      ctx,
      lb,
      camX,
      viewW,
      worldPixelHeight,
      engine.worldTime,
      offsetY
    );

    const variant = lb;

    ctx.save();
    ctx.translate(-camX + shakeX, shakeY);
    // Palette grading is baked into the biome colours (see getGradedBiome),
    // so no per-frame canvas filter is needed here — that was a ~50x cost
    // on devices without GPU-accelerated canvas.

    // 2. End-of-stage Flagpole & Castle (behind player/foreground pipes)
    this.drawCastleAndFlagpole(ctx, engine);

    // 3. Emerging Power-Up Items (behind blocks while emerging!)
    for (const item of engine.items) {
      if (item.active && item.emerging) {
        this.drawItem(ctx, item, engine.worldTime);
      }
    }

    // 4. Piranha Plants (drawn BEFORE Warp Pipes so pipes mask them cleanly!)
    for (const enemy of engine.enemies) {
      if (enemy.active && enemy.kind === 'piranha') {
        this.drawEnemy(ctx, enemy, engine.worldTime);
      }
    }

    // 5. World Tilemap (visible columns only for blazing 60fps performance)
    this.drawTiles(ctx, engine, camX, viewW);

    // 6. Moving Platforms
    this.drawPlatforms(ctx, engine);

    // 7. Collectible Coins
    this.drawCoins(ctx, engine);

    // 8. Active Non-Emerging Power-Ups
    for (const item of engine.items) {
      if (item.active && !item.emerging) {
        this.drawItem(ctx, item, engine.worldTime);
      }
    }

    // 9. Walking / Shell / Flying Enemies
    for (const enemy of engine.enemies) {
      if (enemy.active && enemy.kind !== 'piranha') {
        if (
          enemy.x + enemy.width < camX - 80 ||
          enemy.x > camX + viewW + 80
        ) {
          continue;
        }
        this.drawEnemy(ctx, enemy, engine.worldTime);
      }
    }

    // 10. Hammer Bro projectiles
    for (const hammer of engine.hammers) {
      if (!hammer.active) continue;
      ctx.save();
      ctx.globalAlpha = 0.22;
      ctx.fillStyle = '#ffd166';
      ctx.fillRect(hammer.x - 12, hammer.y - 12, 24, 24);
      ctx.globalAlpha = 1;
      ctx.translate(hammer.x, hammer.y);
      ctx.rotate(hammer.rotation);
      // Wooden handle
      ctx.fillStyle = '#14121d';
      ctx.fillRect(-3, -4, 7, 20);
      ctx.fillStyle = '#b5651d';
      ctx.fillRect(-2, -3, 5, 18);
      ctx.fillStyle = '#f0b56a';
      ctx.fillRect(-2, -3, 2, 16);
      // Steel head
      ctx.fillStyle = '#14121d';
      ctx.fillRect(-11, -14, 22, 12);
      ctx.fillRect(-8, -4, 17, 4);
      ctx.fillStyle = '#9ca9c7';
      ctx.fillRect(-9, -12, 18, 8);
      ctx.fillStyle = '#eef3ff';
      ctx.fillRect(-7, -11, 10, 3);
      ctx.fillStyle = '#5d6882';
      ctx.fillRect(-9, -6, 18, 2);
      ctx.restore();
    }

    // 10e. Pushable crates
    for (const pb of engine.pushBlocks) {
      ctx.fillStyle = '#3b2513';
      ctx.fillRect(pb.x, pb.y, 32, 32);
      const g = ctx.createLinearGradient(pb.x, pb.y, pb.x, pb.y + 32);
      g.addColorStop(0, '#b98a4e');
      g.addColorStop(1, '#6b4a24');
      ctx.fillStyle = g;
      ctx.fillRect(pb.x + 2, pb.y + 2, 28, 28);
      ctx.strokeStyle = '#3b2513';
      ctx.lineWidth = 2.5;
      ctx.beginPath();
      ctx.moveTo(pb.x + 3, pb.y + 3); ctx.lineTo(pb.x + 29, pb.y + 29);
      ctx.moveTo(pb.x + 29, pb.y + 3); ctx.lineTo(pb.x + 3, pb.y + 29);
      ctx.stroke();
      ctx.fillStyle = 'rgba(255,255,255,0.3)';
      ctx.fillRect(pb.x + 3, pb.y + 3, 26, 2);
    }

    // 10f. Hidden relic
    if (engine.relic && !engine.relic.collected) {
      const rl = engine.relic;
      const bob = Math.sin(engine.worldTime * 2.6) * 4;
      const ry = rl.y + bob;
      ctx.save();
      ctx.globalCompositeOperation = 'lighter';
      ctx.globalAlpha = 0.35 + 0.25 * Math.sin(engine.worldTime * 4);
      const rg = ctx.createRadialGradient(rl.x, ry, 2, rl.x, ry, 30);
      rg.addColorStop(0, '#fcd34d');
      rg.addColorStop(1, 'rgba(252,211,77,0)');
      ctx.fillStyle = rg;
      ctx.beginPath();
      ctx.arc(rl.x, ry, 30, 0, Math.PI * 2);
      ctx.fill();
      ctx.restore();
      // Little amphora.
      ctx.save();
      ctx.translate(rl.x, ry);
      ctx.rotate(Math.sin(engine.worldTime * 1.6) * 0.12);
      ctx.fillStyle = '#b45309';
      ctx.beginPath();
      ctx.ellipse(0, 2, 9, 11, 0, 0, Math.PI * 2);
      ctx.fill();
      ctx.fillStyle = '#fcd34d';
      ctx.fillRect(-4, -11, 8, 5);
      ctx.fillStyle = '#fde68a';
      ctx.beginPath();
      ctx.ellipse(-3, -1, 2.6, 4, -0.3, 0, Math.PI * 2);
      ctx.fill();
      ctx.restore();
    }

    // 10g. Shockwaves from ground slams
    for (const sw of engine.shockwaves) {
      const f = 1 - sw.r / sw.max;
      ctx.save();
      ctx.globalAlpha = f * 0.85;
      ctx.strokeStyle = '#fef3c7';
      ctx.lineWidth = 5 * f + 1;
      ctx.beginPath();
      ctx.ellipse(sw.x, sw.y, sw.r, sw.r * 0.45, 0, Math.PI, Math.PI * 2);
      ctx.stroke();
      ctx.strokeStyle = '#f59e0b';
      ctx.lineWidth = 2 * f + 0.5;
      ctx.beginPath();
      ctx.ellipse(sw.x, sw.y, sw.r * 0.78, sw.r * 0.33, 0, Math.PI, Math.PI * 2);
      ctx.stroke();
      ctx.restore();
    }

    // 10h. Grapple rope
    if (engine.player.grappleActive) {
      const p = engine.player;
      const px = p.x + p.width * 0.5;
      const py = p.y + p.height * 0.4;
      ctx.save();
      ctx.strokeStyle = '#d6b370';
      ctx.lineWidth = 2.6;
      ctx.beginPath();
      ctx.moveTo(p.grappleX, p.grappleY);
      ctx.lineTo(px, py);
      ctx.stroke();
      ctx.strokeStyle = 'rgba(255,255,255,0.35)';
      ctx.lineWidth = 1;
      ctx.stroke();
      // Hook head.
      ctx.fillStyle = '#9ca3af';
      ctx.beginPath();
      ctx.arc(p.grappleX, p.grappleY, 5, 0, Math.PI * 2);
      ctx.fill();
      ctx.restore();
    }

    // 11. Player weapon projectiles
    for (const fb of engine.fireballs) {
      if (!fb.active) continue;
      this.drawProjectile(ctx, fb, engine.worldTime);
    }

    // 11b. Enemy projectiles
    for (const shot of engine.enemyShots) {
      if (!shot.active) continue;
      this.drawEnemyShot(ctx, shot);
    }

    // 11c. Weapon crates
    for (const w of engine.weaponPickups) {
      if (!w.active) continue;
      this.drawWeaponCrate(ctx, w, engine.worldTime);
    }

    // 11. Mario!
    this.drawPlayer(ctx, engine);

    // 11d. Companion pet
    if (engine.pet !== 'none') {
      const def = PETS[engine.pet];
      const bx = engine.petX;
      const by = engine.petY;
      ctx.save();
      ctx.globalCompositeOperation = 'lighter';
      ctx.globalAlpha = 0.3 + 0.2 * Math.sin(engine.worldTime * 5);
      const pg = ctx.createRadialGradient(bx, by, 1, bx, by, 20);
      pg.addColorStop(0, def.color);
      pg.addColorStop(1, 'rgba(0,0,0,0)');
      ctx.fillStyle = pg;
      ctx.beginPath();
      ctx.arc(bx, by, 20, 0, Math.PI * 2);
      ctx.fill();
      ctx.restore();

      ctx.save();
      ctx.translate(bx, by);
      // Body
      ctx.fillStyle = def.color;
      ctx.beginPath();
      ctx.arc(0, 0, 8, 0, Math.PI * 2);
      ctx.fill();
      // Flapping wings / fins
      const flap = Math.sin(engine.worldTime * 14) * 5;
      ctx.fillStyle = 'rgba(255,255,255,0.8)';
      ctx.beginPath();
      ctx.ellipse(-10, -2 + flap * 0.4, 6, 3.4, -0.5, 0, Math.PI * 2);
      ctx.ellipse(10, -2 - flap * 0.4, 6, 3.4, 0.5, 0, Math.PI * 2);
      ctx.fill();
      // Eyes
      ctx.fillStyle = '#0f172a';
      ctx.fillRect(-3.5, -3, 2.2, 2.6);
      ctx.fillRect(1.5, -3, 2.2, 2.6);
      ctx.restore();
    }

    // 12. Juicy Particles & POW Shockwaves
    this.drawParticles(ctx, engine);

    // 13. Floating Score & Combo Popups
    this.drawFloatingTexts(ctx, engine);

    ctx.restore();

    // 14. Atmosphere pass — subtle grade + vignette for depth.
    this.drawAtmosphere(ctx, engine, viewW, worldPixelHeight, offsetY);

    // 14b. Per-level sky tint + weather so every map reads differently.
    this.drawSkyAndWeather(
      ctx, variant, viewW, worldPixelHeight, offsetY, engine.worldTime, camX
    );

    ctx.restore();
  }

  /** Cheap full-screen grade: keeps 60fps but adds a lot of mood. */
  /** Time-of-day wash plus the level's weather effect. */
  /**
   * Per-level weather. Wind pushes every particle, gusts make it surge, and
   * violent systems add lightning plus a screen-wide colour wash.
   */
  private drawSkyAndWeather(
    ctx: CanvasRenderingContext2D,
    variant: LevelBiome,
    viewW: number,
    viewH: number,
    offsetY: number,
    time: number,
    camX: number
  ): void {
    // --- time-of-day wash ---
    if (variant.skyAlpha > 0) {
      ctx.save();
      ctx.globalCompositeOperation = 'multiply';
      ctx.globalAlpha = variant.skyAlpha;
      ctx.fillStyle = variant.skyTint;
      ctx.fillRect(0, -offsetY, viewW + 2, viewH + offsetY * 2);
      ctx.restore();
    }

    const w = WEATHER_DEFS[variant.weather];
    const top = -offsetY;
    const H = viewH + offsetY * 2;

    // Schedule decides whether the weather is rolling in, raging or gone.
    const intensity = this.weatherStrength;
    if (intensity <= 0.01) return;

    // --- weather colour wash (scales with strength) ---
    if (w.tintAlpha > 0) {
      ctx.save();
      ctx.globalCompositeOperation = 'multiply';
      ctx.globalAlpha = w.tintAlpha * intensity;
      ctx.fillStyle = w.tint;
      ctx.fillRect(0, top, viewW + 2, H);
      ctx.restore();
    }

    // Gusting wind: a slow swell plus a faster ripple keeps it organic.
    const gust =
      w.wind +
      Math.sin(time * 0.55) * w.gust +
      Math.sin(time * 1.9 + 1.3) * w.gust * 0.45;

    ctx.save();
    // Fade the whole system in and out with the schedule.
    ctx.globalAlpha = intensity;
    const dens = (base: number) => Math.max(1, Math.round(base * intensity));

    switch (w.kind) {
      case 'rain':
      case 'storm':
      case 'typhoon': {
        const n = dens(w.density);
        const speed = w.kind === 'typhoon' ? 1250 : w.kind === 'storm' ? 1000 : 820;
        const len = w.kind === 'typhoon' ? 24 : 18;
        // Drops fall straight down; wind only tilts them slightly.
        const lean = w.kind === 'typhoon' ? 0.34 : w.kind === 'storm' ? 0.2 : 0.12;
        const dx = len * lean * Math.sign(gust || -1);
        ctx.strokeStyle =
          w.kind === 'typhoon' ? 'rgba(205,225,255,0.72)'
            : w.kind === 'storm' ? 'rgba(190,215,255,0.66)'
              : 'rgba(170,200,255,0.52)';
        ctx.lineWidth = w.kind === 'rain' ? 1.5 : 1.9;
        ctx.beginPath();
        for (let i = 0; i < n; i++) {
          // X is anchored to WORLD space, so scrolling the camera no longer
          // drags the rain sideways — it just falls past you.
          const wx = (i * 137.5) % (viewW + 160) - 80;
          const x = wx - (camX % (viewW + 160));
          const sx = x < -80 ? x + viewW + 160 : x;
          const y = (i * 53.7 + time * speed) % H + top;
          ctx.moveTo(sx, y);
          ctx.lineTo(sx + dx, y + len);
        }
        ctx.stroke();
        break;
      }

      case 'snow':
      case 'blizzard': {
        const n = dens(w.density);
        const fall = w.kind === 'blizzard' ? 260 : 105;
        ctx.fillStyle = 'rgba(255,255,255,0.92)';
        for (let i = 0; i < n; i++) {
          // Gentle side-to-side drift, but the dominant motion is downward.
          const drift = Math.sin(time * 1.25 + i * 0.7) *
            (w.kind === 'blizzard' ? 16 : 20);
          const wx = (i * 149.3) % (viewW + 140) - 70;
          const x0 = wx - (camX % (viewW + 140));
          const x = (x0 < -70 ? x0 + viewW + 140 : x0) + drift;
          const y = (i * 61.3 + time * fall) % H + top;
          const s = 2 + (i % 3);
          ctx.fillRect(x, y, s, s);
        }
        break;
      }

      case 'fog': {
        for (let b = 0; b < 4; b++) {
          const o = (camX * (0.1 + b * 0.05) + time * (10 + b * 7)) % 520;
          ctx.globalAlpha = 0.09 + b * 0.045;
          ctx.fillStyle = '#e2e8f0';
          ctx.beginPath();
          ctx.ellipse(
            viewW * 0.5 - o + b * 200, viewH * (0.38 + b * 0.15),
            viewW * 0.8, 44 + b * 18, 0, 0, Math.PI * 2
          );
          ctx.fill();
        }
        break;
      }

      case 'embers': {
        for (let i = 0; i < dens(w.density); i++) {
          const sway = Math.sin(time * 2.1 + i * 0.9) * 14;
          const wx = (i * 151.7) % (viewW + 80) - 40;
          const x0 = wx - (camX % (viewW + 80));
          const x = (x0 < -40 ? x0 + viewW + 80 : x0) + sway;
          const y = H + top - ((i * 67 + time * 165) % H);
          const life = ((i * 67 + time * 165) % H) / H;
          ctx.globalAlpha = 0.35 + 0.6 * Math.sin(life * Math.PI);
          ctx.fillStyle = i % 3 === 0 ? '#fff3c4' : i % 3 === 1 ? '#ffd166' : '#ff6a1f';
          const s = 2 + (i % 3);
          ctx.fillRect(x, y, s, s);
        }
        ctx.globalAlpha = 1;
        break;
      }

      case 'petals': {
        for (let i = 0; i < dens(w.density); i++) {
          const sway = Math.sin(time * 1.6 + i * 1.1) * 26;
          const wx = (i * 139.1) % (viewW + 120) - 60;
          const x0 = wx - (camX % (viewW + 120));
          const x = (x0 < -60 ? x0 + viewW + 120 : x0) + sway;
          const y = (i * 71.3 + time * 86) % H + top;
          ctx.globalAlpha = 0.9;
          ctx.fillStyle = ['#ff8a3d', '#e8562f', '#ffc24d', '#c4452f'][i % 4];
          ctx.save();
          ctx.translate(x, y);
          // Tumbling leaf: rotation plus a squash cycle reads as 3D flutter.
          ctx.rotate(time * 2.4 + i);
          ctx.scale(1, Math.abs(Math.cos(time * 3 + i)) * 0.8 + 0.2);
          ctx.beginPath();
          ctx.ellipse(0, 0, 5.5, 3.2, 0, 0, Math.PI * 2);
          ctx.fill();
          ctx.restore();
        }
        ctx.globalAlpha = 1;
        break;
      }

      case 'hail': {
        // Fast icy pellets plus a few bouncing off the ground line.
        ctx.fillStyle = 'rgba(226,242,255,0.95)';
        for (let i = 0; i < dens(w.density); i++) {
          const wx = (i * 163.7) % (viewW + 160) - 80;
          const x0 = wx - (camX % (viewW + 160));
          const x = x0 < -80 ? x0 + viewW + 160 : x0;
          const y = (i * 67.7 + time * 760) % H + top;
          const s2 = 3 + (i % 2) * 2;
          ctx.fillRect(x, y, s2, s2);
          ctx.fillStyle = 'rgba(255,255,255,0.7)';
          ctx.fillRect(x, y, 1.5, 1.5);
          ctx.fillStyle = 'rgba(226,242,255,0.95)';
        }
        // Bounce sparks at ground level.
        ctx.fillStyle = 'rgba(240,250,255,0.8)';
        for (let i = 0; i < 14; i++) {
          const ph = (time * 2.6 + i * 0.41) % 1;
          const bx = (i * 149 + Math.floor(time * 2.6) * 83) % (viewW + 40) - 20;
          const by = viewH - 28 - Math.sin(ph * Math.PI) * 16;
          ctx.globalAlpha = intensity * (1 - ph);
          ctx.fillRect(bx, by, 3, 3);
        }
        ctx.globalAlpha = intensity;
        break;
      }

      case 'sandstorm': {
        // Layered translucent sheets give the sense of depth in the dust.
        for (let b = 0; b < 3; b++) {
          ctx.globalAlpha = 0.1 + b * 0.05;
          ctx.fillStyle = b % 2 ? '#e8c478' : '#c99a4f';
          const o = (time * (260 + b * 160) + camX * 0.5) % (viewW + 400);
          ctx.beginPath();
          ctx.ellipse(viewW + 200 - o, viewH * (0.3 + b * 0.22),
            viewW * 0.7, 70 + b * 26, 0, 0, Math.PI * 2);
          ctx.fill();
        }
        ctx.globalAlpha = 0.6;
        ctx.strokeStyle = '#f0d6a0';
        ctx.lineWidth = 1.7;
        ctx.beginPath();
        for (let i = 0; i < dens(w.density); i++) {
          const wx = (i * 157.3) % (viewW + 160) - 80;
          const x0 = wx - (camX % (viewW + 160));
          const x = x0 < -80 ? x0 + viewW + 160 : x0;
          const y = (i * 59 + time * 900) % H + top;
          // Grains stream downward with a strong slant.
          ctx.moveTo(x, y);
          ctx.lineTo(x + 11, y + 20);
        }
        ctx.stroke();
        break;
      }
    }

    ctx.restore();

    // --- lightning ---
    if (w.lightning > 0 && intensity > 0.35) {
      // Deterministic strike schedule keyed off wall-clock time.
      const period = 1 / w.lightning;
      const phase = (time % period) / period;
      if (phase < 0.12) {
        const f = 1 - phase / 0.12;
        ctx.save();
        ctx.globalCompositeOperation = 'lighter';
        ctx.fillStyle = `rgba(226,240,255,${0.5 * f * f})`;
        ctx.fillRect(0, top, viewW + 2, H);

        // Forked bolt, seeded so it holds still during the flash.
        const seed = Math.floor(time / period);
        let bx = ((seed * 9301 + 49297) % 233280) / 233280 * viewW;
        ctx.strokeStyle = `rgba(255,255,255,${0.85 * f})`;
        ctx.lineWidth = 2.6;
        ctx.beginPath();
        ctx.moveTo(bx, top);
        let by = top;
        for (let i = 0; i < 7; i++) {
          const r = ((seed * (i + 7) * 7919) % 1000) / 1000;
          bx += (r - 0.5) * 72;
          by += H / 8;
          ctx.lineTo(bx, by);
        }
        ctx.stroke();
        ctx.restore();
      }
    }
  }

  private drawAtmosphere(
    ctx: CanvasRenderingContext2D,
    engine: MarioGameEngine,
    viewW: number,
    viewH: number,
    offsetY: number
  ): void {
    const tint = ATMOSPHERE[getLevelBiome(engine.levelIndex + 1).family];

    if (tint) {
      ctx.save();
      ctx.globalCompositeOperation = 'overlay';
      ctx.globalAlpha = tint.a;
      ctx.fillStyle = tint.c;
      ctx.fillRect(0, -offsetY, viewW + 2, viewH + offsetY * 2);
      ctx.restore();
    }

    // Vignette draws the eye to the centre of the action.
    const vg = ctx.createRadialGradient(
      viewW * 0.5, viewH * 0.46, viewH * 0.26,
      viewW * 0.5, viewH * 0.5, viewH * 0.95
    );
    vg.addColorStop(0, 'rgba(0,0,0,0)');
    vg.addColorStop(1, 'rgba(0,0,0,0.34)');
    ctx.save();
    ctx.fillStyle = vg;
    ctx.fillRect(0, -offsetY, viewW + 2, viewH + offsetY * 2);
    ctx.restore();

    // Slow-motion costume: a cool wash plus soft edge vignette.
    if (engine.player.timeSlowTimer > 0) {
      ctx.save();
      ctx.globalCompositeOperation = 'multiply';
      ctx.globalAlpha = 0.18;
      ctx.fillStyle = '#818cf8';
      ctx.fillRect(0, -offsetY, viewW + 2, viewH + offsetY * 2);
      ctx.restore();
      ctx.save();
      ctx.globalAlpha = 0.1 + 0.05 * Math.sin(engine.worldTime * 10);
      ctx.strokeStyle = '#c7d2fe';
      ctx.lineWidth = 10;
      ctx.strokeRect(5, -offsetY + 5, viewW - 8, viewH + offsetY * 2 - 10);
      ctx.restore();
    }

    // Starman / low-time flash.
    if (engine.player.starTimer > 0) {
      ctx.save();
      ctx.globalCompositeOperation = 'lighter';
      ctx.globalAlpha = 0.07 + 0.05 * Math.sin(engine.worldTime * 14);
      ctx.fillStyle = '#ffe94d';
      ctx.fillRect(0, -offsetY, viewW + 2, viewH + offsetY * 2);
      ctx.restore();
    }
  }

  /** Sky gradient + every parallax layer the biome asks for. */
  /**
   * Draws a biome's sky + parallax layers onto any context.
   *
   * Exposed so non-gameplay screens (the sign-in backdrop) can show the
   * real game art instead of a hand-rolled approximation.
   */
  public drawShowcaseBackdrop(
    ctx: CanvasRenderingContext2D,
    lb: LevelBiome,
    camX: number,
    viewW: number,
    viewH: number,
    time: number
  ): void {
    this.drawBackground(ctx, lb, camX, viewW, viewH, time, 0);
  }

  private drawBackground(
    ctx: CanvasRenderingContext2D,
    lb: LevelBiome,
    camX: number,
    viewW: number,
    viewH: number,
    time: number,
    topExtend = 0
  ): void {
    const sky = lb.biome.sky;
    const grad = ctx.createLinearGradient(0, -topExtend, 0, viewH);
    grad.addColorStop(0, sky[0]);
    grad.addColorStop(0.6, sky[1]);
    grad.addColorStop(1, sky[2]);
    ctx.fillStyle = grad;
    ctx.fillRect(0, -topExtend - 2, viewW + 2, viewH + topExtend + 2);

    for (const layer of lb.biome.layers) {
      this.drawLayer(ctx, layer, camX, viewW, viewH, time);
    }
  }

  /**
   * Draws one parallax layer. Everything is procedural and tiled across the
   * viewport, so a biome is defined purely by data.
   */
  private drawLayer(
    ctx: CanvasRenderingContext2D,
    layer: BackdropLayer,
    camX: number,
    viewW: number,
    viewH: number,
    time: number
  ): void {
    const c = layer.colors;
    const span = layer.span ?? DEFAULT_SPAN[layer.kind] ?? 260;
    const baseY = layer.baseY ?? 420;
    const off = ((camX * layer.parallax) % span + span) % span;
    const from = -off - span;
    const to = viewW + span;

    ctx.save();

    switch (layer.kind) {
      case 'fog': {
        for (let b = 0; b < 3; b++) {
          const o = (camX * (layer.parallax + b * 0.04) + time * (8 + b * 5)) % 460;
          ctx.fillStyle = c[0];
          ctx.globalAlpha = 0.1 + b * 0.05;
          ctx.beginPath();
          ctx.ellipse(viewW * 0.5 - o + b * 190, viewH * (0.42 + b * 0.17),
            viewW * 0.8, 46 + b * 18, 0, 0, Math.PI * 2);
          ctx.fill();
        }
        break;
      }
      case 'stars': {
        for (let i = 0; i < 80; i++) {
          const x = (i * 137.5 + camX * layer.parallax) % (viewW + 40) - 20;
          const y = (i * 71.3) % (viewH * 0.7);
          const tw = 0.45 + 0.55 * Math.abs(Math.sin(time * 1.6 + i));
          ctx.globalAlpha = tw;
          ctx.fillStyle = c[i % c.length];
          const s = i % 9 === 0 ? 3 : 2;
          ctx.fillRect(x, y, s, s);
        }
        break;
      }
      case 'nebula': {
        for (let i = 0; i < 3; i++) {
          const x = ((i * 340 - camX * layer.parallax) % (viewW + 620)) - 160;
          ctx.globalAlpha = 0.3;
          const g = ctx.createRadialGradient(x, 120 + i * 60, 10, x, 120 + i * 60, 220);
          g.addColorStop(0, c[i % c.length]);
          g.addColorStop(1, 'rgba(0,0,0,0)');
          ctx.fillStyle = g;
          ctx.fillRect(x - 220, 0, 440, viewH);
        }
        break;
      }
      case 'aurora': {
        ctx.globalCompositeOperation = 'lighter';
        for (let i = 0; i < 3; i++) {
          ctx.globalAlpha = 0.16;
          ctx.strokeStyle = c[i % c.length];
          ctx.lineWidth = 26 + i * 10;
          ctx.beginPath();
          for (let x = -40; x < viewW + 40; x += 20) {
            const y = 70 + i * 34 + Math.sin(x * 0.012 + time * 0.8 + i) * 26;
            if (x === -40) ctx.moveTo(x, y); else ctx.lineTo(x, y);
          }
          ctx.stroke();
        }
        break;
      }
      case 'moonbig': {
        ctx.fillStyle = c[0];
        ctx.beginPath();
        ctx.arc(viewW - 110, 86, 46, 0, Math.PI * 2);
        ctx.fill();
        ctx.globalAlpha = 0.16;
        ctx.beginPath();
        ctx.arc(viewW - 110, 86, 70, 0, Math.PI * 2);
        ctx.fill();
        break;
      }
      case 'planets': {
        for (let x = from; x < to; x += span) {
          const r = 34 + (Math.abs(Math.sin(x)) * 22);
          const g = ctx.createRadialGradient(x + 40, 110, 4, x + 56, 120, r);
          g.addColorStop(0, c[0]);
          g.addColorStop(1, c[c.length - 1]);
          ctx.fillStyle = g;
          ctx.beginPath();
          ctx.arc(x + 56, 118, r, 0, Math.PI * 2);
          ctx.fill();
        }
        break;
      }
      case 'meteors': {
        for (let i = 0; i < 7; i++) {
          const p = ((time * 90 + i * 180) % (viewW + 300)) - 150;
          ctx.globalAlpha = 0.75;
          ctx.strokeStyle = c[i % c.length];
          ctx.lineWidth = 2.5;
          ctx.beginPath();
          ctx.moveTo(viewW - p, 40 + i * 26);
          ctx.lineTo(viewW - p + 44, 40 + i * 26 + 20);
          ctx.stroke();
        }
        break;
      }
      case 'clouds': {
        for (let x = from; x < to; x += span) {
          this.drawPixelCloud(ctx, x + 40 - time * 6, 62, 1.1, c);
          this.drawPixelCloud(ctx, x + 175 - time * 4, 110, 0.85, c);
        }
        break;
      }
      case 'cloudislands': {
        for (let x = from; x < to; x += span) {
          const bob = Math.sin(time * 0.9 + x * 0.01) * 5;
          ctx.fillStyle = c[0];
          ctx.beginPath();
          ctx.ellipse(x + 90, 350 + bob, 92, 26, 0, 0, Math.PI * 2);
          ctx.fill();
          ctx.fillStyle = c[1] ?? c[0];
          ctx.beginPath();
          ctx.ellipse(x + 90, 366 + bob, 70, 18, 0, 0, Math.PI * 2);
          ctx.fill();
        }
        break;
      }
      case 'mountains':
      case 'snowpeaks': {
        const snow = layer.kind === 'snowpeaks';
        for (let x = from; x < to; x += span) {
          this.drawMountain(ctx, x + 20, baseY, 190, 160, c[0], c[1] ?? '#fff');
          this.drawMountain(ctx, x + 170, baseY, 140, 115, c[0], c[1] ?? '#fff');
          if (snow) {
            ctx.fillStyle = c[1] ?? '#fff';
            ctx.globalAlpha = 0.5;
            ctx.fillRect(x, baseY - 6, span, 8);
            ctx.globalAlpha = 1;
          }
        }
        break;
      }
      case 'hills': {
        for (let x = from; x < to; x += span) {
          this.drawRoundHill(ctx, x + 20, baseY, 140, 80, c);
          this.drawRoundHill(ctx, x + 180, baseY, 92, 52, c);
        }
        break;
      }
      case 'dunes': {
        for (let x = from; x < to; x += span) {
          ctx.fillStyle = c[0];
          ctx.beginPath();
          ctx.moveTo(x, baseY + 4);
          ctx.quadraticCurveTo(x + 80, baseY - 72, x + 168, baseY + 4);
          ctx.closePath();
          ctx.fill();
          ctx.fillStyle = c[1] ?? c[0];
          ctx.beginPath();
          ctx.moveTo(x + 100, baseY + 4);
          ctx.quadraticCurveTo(x + 170, baseY - 48, x + 250, baseY + 4);
          ctx.closePath();
          ctx.fill();
        }
        break;
      }
      case 'mesa': {
        for (let x = from; x < to; x += span) {
          ctx.fillStyle = c[0];
          ctx.fillRect(x + 20, baseY - 150, 120, 150);
          ctx.fillStyle = c[1] ?? c[0];
          ctx.fillRect(x + 20, baseY - 150, 120, 12);
          ctx.fillStyle = c[0];
          ctx.fillRect(x + 165, baseY - 96, 80, 96);
          ctx.fillStyle = c[1] ?? c[0];
          ctx.fillRect(x + 165, baseY - 96, 80, 10);
        }
        break;
      }
      case 'pyramids': {
        for (let x = from; x < to; x += span) {
          ctx.fillStyle = c[0];
          ctx.beginPath();
          ctx.moveTo(x + 20, baseY);
          ctx.lineTo(x + 110, baseY - 166);
          ctx.lineTo(x + 200, baseY);
          ctx.closePath();
          ctx.fill();
          ctx.fillStyle = c[1] ?? c[0];
          ctx.beginPath();
          ctx.moveTo(x + 110, baseY - 166);
          ctx.lineTo(x + 200, baseY);
          ctx.lineTo(x + 150, baseY);
          ctx.closePath();
          ctx.fill();
        }
        break;
      }
      case 'pines': {
        for (let x = from; x < to; x += span) {
          for (const [dx, h] of [[30, 96], [96, 72], [158, 108]] as const) {
            ctx.fillStyle = c[0];
            ctx.beginPath();
            ctx.moveTo(x + dx, baseY);
            ctx.lineTo(x + dx + 26, baseY - h);
            ctx.lineTo(x + dx + 52, baseY);
            ctx.closePath();
            ctx.fill();
            if (c[1]) {
              ctx.fillStyle = c[1];
              ctx.fillRect(x + dx + 18, baseY - h + 10, 16, 8);
            }
          }
        }
        break;
      }
      case 'broadleaf':
      case 'mushroomtrees':
      case 'candytrees': {
        const round = layer.kind !== 'broadleaf';
        for (let x = from; x < to; x += span) {
          for (const [dx, h, r] of [[30, 90, 44], [120, 68, 34], [200, 100, 48]] as const) {
            ctx.fillStyle = c[0];
            ctx.fillRect(x + dx + r - 6, baseY - h, 12, h);
            ctx.fillStyle = c[1] ?? c[0];
            ctx.beginPath();
            if (round) {
              ctx.arc(x + dx + r, baseY - h, r, Math.PI, 0);
            } else {
              ctx.arc(x + dx + r, baseY - h - 6, r, 0, Math.PI * 2);
            }
            ctx.fill();
            if (c[2]) {
              ctx.fillStyle = c[2];
              ctx.beginPath();
              ctx.arc(x + dx + r - 12, baseY - h - 10, 7, 0, Math.PI * 2);
              ctx.fill();
            }
          }
        }
        break;
      }
      case 'palms': {
        for (let x = from; x < to; x += span) {
          ctx.fillStyle = c[0];
          ctx.fillRect(x + 60, baseY - 124, 12, 124);
          ctx.fillStyle = c[1] ?? c[0];
          for (let f = 0; f < 5; f++) {
            ctx.save();
            ctx.translate(x + 66, baseY - 122);
            ctx.rotate(-1.1 + f * 0.55 + Math.sin(time * 1.2 + f) * 0.05);
            ctx.fillRect(0, -6, 58, 11);
            ctx.restore();
          }
        }
        break;
      }
      case 'bamboo': {
        for (let x = from; x < to; x += span) {
          for (let i = 0; i < 6; i++) {
            const bx = x + i * 26 + (i % 2) * 8;
            const h = 150 + (i % 3) * 40;
            ctx.fillStyle = c[0];
            ctx.fillRect(bx, baseY - h, 12, h);
            ctx.fillStyle = c[1] ?? c[0];
            for (let k = 0; k < h; k += 26) ctx.fillRect(bx, baseY - h + k, 12, 3);
          }
        }
        break;
      }
      case 'cacti': {
        for (let x = from; x < to; x += span) {
          ctx.fillStyle = c[0];
          ctx.fillRect(x + 60, baseY - 62, 14, 62);
          ctx.fillRect(x + 46, baseY - 44, 14, 12);
          ctx.fillRect(x + 74, baseY - 52, 14, 12);
        }
        break;
      }
      case 'deadtrees': {
        for (let x = from; x < to; x += span) {
          ctx.strokeStyle = c[0];
          ctx.lineWidth = 9;
          ctx.beginPath();
          ctx.moveTo(x + 60, baseY);
          ctx.lineTo(x + 60, baseY - 124);
          ctx.moveTo(x + 60, baseY - 84);
          ctx.lineTo(x + 24, baseY - 124);
          ctx.moveTo(x + 60, baseY - 102);
          ctx.lineTo(x + 98, baseY - 138);
          ctx.stroke();
        }
        break;
      }
      case 'vines': {
        for (let x = from; x < to; x += span) {
          const sway = Math.sin(time * 1.3 + x * 0.04) * 8;
          ctx.strokeStyle = c[0];
          ctx.globalAlpha = 0.6;
          ctx.lineWidth = 6;
          ctx.beginPath();
          ctx.moveTo(x + 20, 0);
          ctx.quadraticCurveTo(x + 20 + sway, 74, x + 20, 150);
          ctx.stroke();
        }
        break;
      }
      case 'kelp': {
        for (let x = from; x < to; x += span) {
          for (let i = 0; i < 4; i++) {
            const kx = x + i * 34;
            const sway = Math.sin(time * 1.1 + i) * 11;
            ctx.strokeStyle = c[i % c.length];
            ctx.lineWidth = 9;
            ctx.beginPath();
            ctx.moveTo(kx, baseY);
            ctx.quadraticCurveTo(kx + sway, baseY - 80, kx + sway * 1.6, baseY - 160);
            ctx.stroke();
          }
        }
        break;
      }
      case 'coral': {
        for (let x = from; x < to; x += span) {
          for (let i = 0; i < 3; i++) {
            ctx.fillStyle = c[i % c.length];
            const cx2 = x + 40 + i * 54;
            ctx.beginPath();
            ctx.arc(cx2, baseY - 18, 20, Math.PI, 0);
            ctx.fill();
            ctx.fillRect(cx2 - 5, baseY - 24, 10, 24);
          }
        }
        break;
      }
      case 'bubbles': {
        for (let i = 0; i < 34; i++) {
          const bx = (i * 113 + camX * layer.parallax) % (viewW + 60) - 30;
          const by = viewH - ((i * 67 + time * 46) % (viewH + 40));
          ctx.globalAlpha = 0.45;
          ctx.strokeStyle = c[0];
          ctx.lineWidth = 2;
          ctx.beginPath();
          ctx.arc(bx, by, 3 + (i % 4) * 2.5, 0, Math.PI * 2);
          ctx.stroke();
        }
        break;
      }
      case 'waves': {
        ctx.fillStyle = c[0];
        ctx.fillRect(0, baseY - 92, viewW + 2, 96);
        for (let i = 0; i < 5; i++) {
          const y = baseY - 80 + i * 18;
          const shift = Math.sin(time * 1.5 + i) * 22;
          ctx.fillStyle = i % 2 === 0 ? (c[1] ?? c[0]) : c[0];
          ctx.fillRect(-40 + shift, y, viewW + 90, 6);
        }
        break;
      }
      case 'icebergs': {
        for (let x = from; x < to; x += span) {
          ctx.fillStyle = c[0];
          ctx.beginPath();
          ctx.moveTo(x + 10, baseY);
          ctx.lineTo(x + 70, baseY - 104);
          ctx.lineTo(x + 130, baseY);
          ctx.closePath();
          ctx.fill();
          ctx.fillStyle = c[1] ?? c[0];
          ctx.beginPath();
          ctx.moveTo(x + 70, baseY - 104);
          ctx.lineTo(x + 130, baseY);
          ctx.lineTo(x + 96, baseY);
          ctx.closePath();
          ctx.fill();
        }
        break;
      }
      case 'geyser': {
        for (let x = from; x < to; x += span) {
          const h = 70 + Math.abs(Math.sin(time * 1.1 + x * 0.01)) * 110;
          ctx.globalAlpha = 0.5;
          ctx.fillStyle = c[0];
          ctx.fillRect(x + 64, baseY - h, 22, h);
          ctx.globalAlpha = 0.3;
          ctx.fillStyle = c[1] ?? c[0];
          ctx.beginPath();
          ctx.arc(x + 75, baseY - h, 28, 0, Math.PI * 2);
          ctx.fill();
        }
        break;
      }
      case 'lavaflow': {
        ctx.fillStyle = c[0];
        ctx.fillRect(0, baseY - 16, viewW + 2, 22);
        for (let i = 0; i < 6; i++) {
          const y = baseY - 14 + Math.sin(time * 2 + i) * 3;
          ctx.fillStyle = c[1] ?? c[0];
          ctx.fillRect((i * 140 - (time * 40 % 140)), y, 90, 4);
        }
        break;
      }
      case 'buildings':
      case 'neon': {
        const lit = layer.kind === 'neon';
        for (let x = from; x < to; x += span) {
          for (let i = 0; i < 3; i++) {
            const bw = 60 + i * 14;
            const bh = 130 + ((i * 53) % 110);
            const bx = x + i * 78;
            ctx.fillStyle = c[0];
            ctx.fillRect(bx, baseY - bh, bw, bh);
            for (let wy = 0; wy < bh - 20; wy += 26) {
              for (let wx = 0; wx < bw - 16; wx += 20) {
                if ((wx + wy + i + Math.floor(time * 1.2)) % 3 === 0) continue;
                ctx.fillStyle = lit
                  ? c[1 + ((wx + wy + i) % Math.max(1, c.length - 1))]
                  : (c[1] ?? '#ffb23d');
                ctx.fillRect(bx + 9 + wx, baseY - bh + 14 + wy, 10, 14);
              }
            }
          }
        }
        break;
      }
      case 'towers': {
        for (let x = from; x < to; x += span) {
          ctx.fillStyle = c[0];
          ctx.fillRect(x + 30, baseY - 215, 78, 215);
          for (let b = 0; b < 4; b++) ctx.fillRect(x + 30 + b * 21, baseY - 229, 13, 15);
          ctx.fillStyle = c[1] ?? '#ff8c3b';
          ctx.fillRect(x + 60, baseY - 180, 15, 26);
          ctx.fillRect(x + 60, baseY - 128, 15, 26);
        }
        break;
      }
      case 'ruins': {
        for (let x = from; x < to; x += span) {
          for (let i = 0; i < 4; i++) {
            const h = 60 + ((i * 37) % 80);
            ctx.fillStyle = c[0];
            ctx.fillRect(x + 26 + i * 48, baseY - h, 26, h);
            ctx.fillStyle = c[1] ?? c[0];
            ctx.fillRect(x + 26 + i * 48, baseY - h, 26, 6);
          }
        }
        break;
      }
      case 'obelisk': {
        for (let x = from; x < to; x += span) {
          ctx.fillStyle = c[0];
          ctx.beginPath();
          ctx.moveTo(x + 54, baseY);
          ctx.lineTo(x + 62, baseY - 186);
          ctx.lineTo(x + 78, baseY - 186);
          ctx.lineTo(x + 86, baseY);
          ctx.closePath();
          ctx.fill();
          ctx.fillStyle = c[1] ?? c[0];
          ctx.fillRect(x + 62, baseY - 186, 16, 10);
        }
        break;
      }
      case 'pillars': {
        for (let x = from; x < to; x += span) {
          for (let i = 0; i < 3; i++) {
            const px = x + 34 + i * 72;
            ctx.fillStyle = c[0];
            ctx.fillRect(px, 60, 30, viewH - 120);
            ctx.fillStyle = c[1] ?? c[0];
            ctx.fillRect(px - 5, 56, 40, 12);
            ctx.fillRect(px - 5, viewH - 72, 40, 12);
          }
        }
        break;
      }
      case 'crystals': {
        for (let x = from; x < to; x += span) {
          for (let i = 0; i < 3; i++) {
            const cx2 = x + 40 + i * 70;
            const h = 70 + ((i * 41) % 70);
            const pulse = 0.5 + 0.5 * Math.sin(time * 2.2 + i + x * 0.01);
            ctx.globalAlpha = 0.55 + pulse * 0.4;
            ctx.fillStyle = c[i % c.length];
            ctx.beginPath();
            ctx.moveTo(cx2, baseY);
            ctx.lineTo(cx2 + 14, baseY - h);
            ctx.lineTo(cx2 + 28, baseY);
            ctx.closePath();
            ctx.fill();
          }
        }
        break;
      }
      case 'stalactites': {
        for (let x = from; x < to; x += span) {
          ctx.fillStyle = c[0];
          ctx.fillRect(x + 40, 26, 28, viewH - 60);
          ctx.fillStyle = c[1] ?? c[0];
          ctx.fillRect(x + 44, 26, 9, viewH - 60);
          for (let i = 0; i < 3; i++) {
            ctx.fillStyle = c[0];
            ctx.beginPath();
            ctx.moveTo(x + 120 + i * 40, 20);
            ctx.lineTo(x + 134 + i * 40, 92);
            ctx.lineTo(x + 148 + i * 40, 20);
            ctx.closePath();
            ctx.fill();
          }
        }
        break;
      }
      case 'gears': {
        for (let x = from; x < to; x += span) {
          ctx.save();
          ctx.translate(x + 80, 130);
          ctx.rotate(time * 0.7);
          ctx.globalAlpha = 0.25;
          ctx.fillStyle = c[0];
          for (let t = 0; t < 8; t++) {
            ctx.rotate(Math.PI / 4);
            ctx.fillRect(-9, -66, 18, 26);
          }
          ctx.beginPath();
          ctx.arc(0, 0, 46, 0, Math.PI * 2);
          ctx.fill();
          ctx.restore();
        }
        break;
      }
      case 'pipes': {
        for (let x = from; x < to; x += span) {
          ctx.fillStyle = c[0];
          ctx.fillRect(x + 20, baseY - 150, 180, 20);
          ctx.fillRect(x + 20, baseY - 150, 20, 150);
          ctx.fillStyle = c[1] ?? c[0];
          ctx.fillRect(x + 20, baseY - 150, 180, 5);
          for (let i = 0; i < 3; i++) ctx.fillRect(x + 60 + i * 52, baseY - 152, 12, 24);
        }
        break;
      }
      case 'tombstones': {
        for (let x = from; x < to; x += span) {
          for (let i = 0; i < 3; i++) {
            const tx = x + 40 + i * 66;
            ctx.fillStyle = c[0];
            ctx.fillRect(tx, baseY - 42, 36, 42);
            ctx.beginPath();
            ctx.arc(tx + 18, baseY - 42, 18, Math.PI, 0);
            ctx.fill();
          }
        }
        break;
      }
      case 'lanterns': {
        for (let x = from; x < to; x += span) {
          for (let i = 0; i < 3; i++) {
            const lx = x + 50 + i * 72;
            const ly = 96 + Math.sin(time * 1.4 + i) * 10;
            ctx.globalAlpha = 0.3;
            ctx.fillStyle = c[0];
            ctx.beginPath();
            ctx.arc(lx, ly, 20, 0, Math.PI * 2);
            ctx.fill();
            ctx.globalAlpha = 1;
            ctx.fillStyle = c[c.length - 1];
            ctx.fillRect(lx - 7, ly - 9, 14, 18);
          }
        }
        break;
      }
      case 'shipwreck': {
        for (let x = from; x < to; x += span) {
          ctx.fillStyle = c[0];
          ctx.beginPath();
          ctx.moveTo(x + 20, baseY);
          ctx.lineTo(x + 40, baseY - 56);
          ctx.lineTo(x + 180, baseY - 56);
          ctx.lineTo(x + 200, baseY);
          ctx.closePath();
          ctx.fill();
          ctx.fillStyle = c[1] ?? c[0];
          ctx.fillRect(x + 100, baseY - 170, 10, 116);
          ctx.fillStyle = c[2] ?? '#d6c4a0';
          ctx.beginPath();
          ctx.moveTo(x + 110, baseY - 164);
          ctx.lineTo(x + 166, baseY - 110);
          ctx.lineTo(x + 110, baseY - 86);
          ctx.closePath();
          ctx.fill();
        }
        break;
      }
      case 'windmill': {
        for (let x = from; x < to; x += span) {
          ctx.fillStyle = c[0];
          ctx.fillRect(x + 60, baseY - 130, 34, 130);
          ctx.save();
          ctx.translate(x + 77, baseY - 130);
          ctx.rotate(time * 0.9);
          ctx.fillStyle = c[1] ?? c[0];
          for (let b = 0; b < 4; b++) {
            ctx.rotate(Math.PI / 2);
            ctx.fillRect(-5, -56, 10, 50);
          }
          ctx.restore();
        }
        break;
      }
      case 'balloons': {
        for (let x = from; x < to; x += span) {
          for (let i = 0; i < 3; i++) {
            const bx = x + 40 + i * 70;
            const by = 90 + Math.sin(time * 0.9 + i * 1.7) * 26;
            ctx.fillStyle = c[i % c.length];
            ctx.beginPath();
            ctx.ellipse(bx, by, 20, 25, 0, 0, Math.PI * 2);
            ctx.fill();
            ctx.strokeStyle = 'rgba(255,255,255,0.4)';
            ctx.lineWidth = 1.5;
            ctx.beginPath();
            ctx.moveTo(bx, by + 24);
            ctx.lineTo(bx, by + 50);
            ctx.stroke();
          }
        }
        break;
      }
      case 'lollipops': {
        for (let x = from; x < to; x += span) {
          for (let i = 0; i < 2; i++) {
            const lx = x + 50 + i * 110;
            ctx.fillStyle = '#ffffff';
            ctx.fillRect(lx - 5, baseY - 118, 10, 118);
            ctx.fillStyle = c[i % c.length];
            ctx.beginPath();
            ctx.arc(lx, baseY - 128, 38, 0, Math.PI * 2);
            ctx.fill();
            ctx.fillStyle = c[(i + 1) % c.length];
            ctx.beginPath();
            ctx.arc(lx - 11, baseY - 139, 12, 0, Math.PI * 2);
            ctx.fill();
          }
        }
        break;
      }
      case 'rainbowarc': {
        ctx.globalAlpha = 0.5;
        for (let i = 0; i < c.length; i++) {
          ctx.strokeStyle = c[i];
          ctx.lineWidth = 16;
          ctx.beginPath();
          ctx.arc(viewW * 0.5 - camX * layer.parallax % viewW, baseY + 120,
            230 - i * 17, Math.PI, Math.PI * 2);
          ctx.stroke();
        }
        break;
      }
      case 'gridfloor': {
        ctx.strokeStyle = c[0];
        ctx.globalAlpha = 0.28;
        ctx.lineWidth = 1.5;
        const gs = 46;
        const gx = ((camX * layer.parallax) % gs + gs) % gs;
        for (let x = -gx; x < viewW + gs; x += gs) {
          ctx.beginPath();
          ctx.moveTo(x, baseY - 150);
          ctx.lineTo(x, baseY);
          ctx.stroke();
        }
        for (let y = baseY - 150; y < baseY; y += 26) {
          ctx.beginPath();
          ctx.moveTo(0, y);
          ctx.lineTo(viewW + 2, y);
          ctx.stroke();
        }
        break;
      }
    }

    ctx.restore();
  }

  private drawPixelCloud(
    ctx: CanvasRenderingContext2D,
    x: number,
    y: number,
    s: number,
    colors: string[] = ['#ffffff', '#cdeaff']
  ): void {
    ctx.save();
    ctx.translate(x, y);
    ctx.scale(s, s);
    ctx.fillStyle = colors[1] ?? colors[0];
    ctx.fillRect(4, 14, 68, 16);
    ctx.fillStyle = colors[0];
    ctx.fillRect(8, 8, 60, 18);
    ctx.fillRect(20, 0, 34, 14);
    ctx.restore();
  }

  private drawMountain(
    ctx: CanvasRenderingContext2D,
    x: number,
    baseY: number,
    w: number,
    h: number,
    color: string,
    capColor: string
  ): void {
    ctx.fillStyle = color;
    ctx.beginPath();
    ctx.moveTo(x, baseY);
    ctx.lineTo(x + w * 0.5, baseY - h);
    ctx.lineTo(x + w, baseY);
    ctx.closePath();
    ctx.fill();

    ctx.fillStyle = capColor;
    ctx.beginPath();
    ctx.moveTo(x + w * 0.36, baseY - h * 0.72);
    ctx.lineTo(x + w * 0.5, baseY - h);
    ctx.lineTo(x + w * 0.64, baseY - h * 0.72);
    ctx.closePath();
    ctx.fill();
  }

  private drawRoundHill(
    ctx: CanvasRenderingContext2D,
    x: number,
    baseY: number,
    w: number,
    h: number,
    colors: string[]
  ): void {
    ctx.fillStyle = colors[0];
    ctx.beginPath();
    ctx.moveTo(x, baseY);
    ctx.quadraticCurveTo(x + w * 0.5, baseY - h * 1.7, x + w, baseY);
    ctx.closePath();
    ctx.fill();
    if (colors[1]) {
      ctx.fillStyle = colors[1];
      ctx.fillRect(x + w * 0.44, baseY - h * 0.58, 8, 12);
      ctx.fillRect(x + w * 0.32, baseY - h * 0.32, 8, 10);
      ctx.fillRect(x + w * 0.58, baseY - h * 0.32, 8, 10);
    }
  }

  /**
   * Draws whatever the weather has left behind on exposed tile surfaces.
   * This runs in world space, so the deposits scroll with the map — snow
   * really does sit on the ledges rather than sliding across the screen.
   */
  private drawDeposit(
    ctx: CanvasRenderingContext2D,
    weather: string,
    x: number,
    y: number,
    col: number,
    amount: number,
    time: number
  ): void {
    if (amount <= 0.02) return;
    // Deterministic per-column jitter keeps the surface from looking flat.
    const j = ((col * 2654435761) >>> 0) % 1000 / 1000;

    switch (weather) {
      case 'snow':
      case 'blizzard': {
        const h = (2 + j * 2.5) * amount + 1;
        ctx.fillStyle = '#ffffff';
        // Rounded cap with a slight lip so it reads as settled snow.
        ctx.beginPath();
        ctx.moveTo(x, y + h);
        ctx.quadraticCurveTo(x + 8, y - h * 0.5, x + 16, y + h * 0.15);
        ctx.quadraticCurveTo(x + 24, y - h * 0.4, x + 32, y + h);
        ctx.lineTo(x + 32, y + h + 1.5);
        ctx.lineTo(x, y + h + 1.5);
        ctx.closePath();
        ctx.fill();
        ctx.fillStyle = 'rgba(190,215,240,0.6)';
        ctx.fillRect(x, y + h + 0.5, 32, 1.2);
        break;
      }
      case 'hail': {
        ctx.fillStyle = 'rgba(226,242,255,0.95)';
        for (let i = 0; i < 4; i++) {
          const px = x + 2 + i * 8 + ((j * 7 + i) % 3);
          const sz = (2 + ((i + col) % 2)) * Math.min(1, amount + 0.3);
          ctx.fillRect(px, y - sz + 1, sz, sz);
        }
        break;
      }
      case 'rain':
      case 'storm':
      case 'typhoon': {
        // Wet sheen plus the odd puddle that catches the light.
        ctx.fillStyle = `rgba(90,130,185,${0.3 * amount})`;
        ctx.fillRect(x, y, 32, 3);
        if (j > 0.55) {
          const shimmer = 0.25 + 0.2 * Math.sin(time * 2.2 + col);
          ctx.fillStyle = `rgba(185,222,255,${shimmer * amount})`;
          ctx.fillRect(x + 4 + j * 6, y + 0.5, 14, 1.6);
        }
        break;
      }
      case 'sandstorm': {
        const h = (2 + j * 3) * amount;
        ctx.fillStyle = '#e8c478';
        // Drifts bank up against one side of each tile.
        ctx.beginPath();
        ctx.moveTo(x, y + 2);
        ctx.quadraticCurveTo(x + 12, y - h, x + 32, y + 1);
        ctx.lineTo(x + 32, y + 3);
        ctx.lineTo(x, y + 3);
        ctx.closePath();
        ctx.fill();
        break;
      }
      case 'embers': {
        ctx.fillStyle = `rgba(118,110,105,${0.65 * amount})`;
        ctx.fillRect(x, y, 32, 2 + j);
        // A few embers still glowing in the ash.
        if (j > 0.7) {
          const glow = 0.4 + 0.5 * Math.sin(time * 3 + col * 1.7);
          ctx.fillStyle = `rgba(255,140,60,${glow * amount})`;
          ctx.fillRect(x + 6 + j * 12, y, 3, 2);
        }
        break;
      }
      case 'petals': {
        const cols = ['#ff8a3d', '#e8562f', '#ffc24d', '#c4452f'];
        for (let i = 0; i < 3; i++) {
          const px = x + 3 + i * 10 + ((j * 9 + i * 3) % 5);
          ctx.globalAlpha = amount;
          ctx.fillStyle = cols[(col + i) % 4];
          ctx.beginPath();
          ctx.ellipse(px, y - 1, 4, 2.2, (j + i) * 1.4, 0, Math.PI * 2);
          ctx.fill();
        }
        ctx.globalAlpha = 1;
        break;
      }
      case 'fog': {
        ctx.fillStyle = `rgba(210,230,240,${0.22 * amount})`;
        ctx.fillRect(x, y, 32, 2);
        break;
      }
    }
  }

  private drawTiles(
    ctx: CanvasRenderingContext2D,
    engine: MarioGameEngine,
    camX: number,
    viewW: number
  ): void {
    const startCol = Math.max(0, Math.floor(camX / TILE_SIZE) - 1);
    const endCol = Math.min(
      engine.levelDef.widthCols - 1,
      Math.ceil((camX + viewW) / TILE_SIZE) + 1
    );
    const themeTiles = getBiomeTiles(getLevelBiome(engine.levelIndex + 1).biome);
    const qFrame = Math.floor(engine.worldTime * 5.5) % 3;
    const weather = getLevelBiome(engine.levelIndex + 1).weather;
    const accum = this.accumulation;

    for (let r = 0; r < engine.levelDef.heightRows; r++) {
      for (let c = startCol; c <= endCol; c++) {
        const t = engine.tiles[r][c] as TileType;
        if (t === TileType.EMPTY) continue;

        const x = c * TILE_SIZE;
        const bumpY = engine.getBumpOffset(c, r);
        const y = r * TILE_SIZE + bumpY;

        switch (t) {
          case TileType.GROUND:
            ctx.drawImage(themeTiles.ground, x, y, TILE_SIZE, TILE_SIZE);
            break;
          case TileType.BRICK:
          case TileType.MULTI_COIN_BRICK:
            ctx.drawImage(themeTiles.brick, x, y, TILE_SIZE, TILE_SIZE);
            break;
          case TileType.SOLID_BLOCK:
            ctx.drawImage(themeTiles.solid, x, y, TILE_SIZE, TILE_SIZE);
            break;
          case TileType.USED_BLOCK:
            ctx.drawImage(themeTiles.used, x, y, TILE_SIZE, TILE_SIZE);
            break;
          case TileType.Q_COIN:
          case TileType.Q_POWER:
          case TileType.Q_STAR:
          case TileType.Q_1UP:
            ctx.drawImage(this.sprites.tiles.qBlocks[qFrame], x, y, TILE_SIZE, TILE_SIZE);
            break;
          case TileType.POW_BLOCK: {
            const charge = engine.powCharges.get(`${c},${r}`) ?? 3;
            const sprite =
              this.sprites.tiles.pow[Math.max(0, Math.min(2, charge - 1))];
            ctx.drawImage(sprite, x, y, TILE_SIZE, TILE_SIZE);
            break;
          }
          case TileType.SPRING: {
            const active = engine.springTimers.has(`${c},${r}`);
            ctx.drawImage(
              active
                ? this.sprites.tiles.springDown
                : this.sprites.tiles.springUp,
              x, y, TILE_SIZE, TILE_SIZE
            );
            break;
          }
          case TileType.BRIDGE:
            this.drawBridgeTile(ctx, x, y, engine.levelDef.theme);
            break;
          case TileType.LAVA:
            this.drawLavaTile(ctx, x, y, c, engine.worldTime);
            break;
          case TileType.GRAPPLE_POINT: {
            const sw = Math.sin(engine.worldTime * 2.5) * 2;
            ctx.fillStyle = '#4b3a28';
            ctx.fillRect(x + 8, y, 16, 7);
            ctx.fillStyle = '#8a6b4a';
            ctx.fillRect(x + 10, y + 1, 12, 4);
            // Hanging ring that the hook latches onto.
            ctx.strokeStyle = '#fcd34d';
            ctx.lineWidth = 3;
            ctx.beginPath();
            ctx.arc(x + 16 + sw, y + 15, 7, 0, Math.PI * 2);
            ctx.stroke();
            ctx.strokeStyle = 'rgba(252,211,77,0.35)';
            ctx.lineWidth = 6;
            ctx.stroke();
            break;
          }
          case TileType.BUTTON: {
            const down = engine.pressedButtons.has(`${c},${r}`);
            ctx.fillStyle = '#1f2937';
            ctx.fillRect(x + 3, y + 24, 26, 8);
            const g = ctx.createLinearGradient(0, y, 0, y + 32);
            g.addColorStop(0, down ? '#16a34a' : '#ef4444');
            g.addColorStop(1, down ? '#064e3b' : '#7f1d1d');
            ctx.fillStyle = g;
            ctx.fillRect(x + 6, y + (down ? 22 : 16), 20, down ? 4 : 10);
            ctx.fillStyle = 'rgba(255,255,255,0.45)';
            ctx.fillRect(x + 8, y + (down ? 22 : 16), 16, 2);
            break;
          }
          case TileType.GATE: {
            if (engine.puzzleSolved) break;   // open gates vanish
            ctx.fillStyle = '#1e293b';
            ctx.fillRect(x + 2, y, 28, 32);
            ctx.fillStyle = '#64748b';
            for (let i = 0; i < 3; i++) ctx.fillRect(x + 5 + i * 9, y, 5, 32);
            ctx.fillStyle = '#94a3b8';
            ctx.fillRect(x + 2, y + 14, 28, 4);
            break;
          }
          case TileType.WALL_RUN: {
            ctx.drawImage(themeTiles.solid, x, y, TILE_SIZE, TILE_SIZE);
            // Chevrons hint that this surface can be run along.
            ctx.save();
            ctx.globalAlpha = 0.5 + 0.2 * Math.sin(engine.worldTime * 4 + r);
            ctx.strokeStyle = '#67e8f9';
            ctx.lineWidth = 2;
            for (let i = 0; i < 2; i++) {
              const yy = y + 9 + i * 13;
              ctx.beginPath();
              ctx.moveTo(x + 9, yy + 5);
              ctx.lineTo(x + 16, yy);
              ctx.lineTo(x + 23, yy + 5);
              ctx.stroke();
            }
            ctx.restore();
            break;
          }
          case TileType.PHASE_WALL: {
            const ghost = engine.player.shadowTimer > 0;
            ctx.save();
            ctx.globalAlpha = ghost ? 0.22 : 0.72;
            ctx.fillStyle = '#6d28d9';
            ctx.fillRect(x + 2, y, 28, 32);
            ctx.fillStyle = '#a78bfa';
            ctx.fillRect(x + 2, y, 28, 3);
            ctx.globalAlpha = ghost ? 0.4 : 0.9;
            ctx.fillStyle = '#ddd6fe';
            for (let i = 0; i < 3; i++) {
              const yy = y + 6 + i * 10 + Math.sin(engine.worldTime * 3 + i) * 2;
              ctx.fillRect(x + 7, yy, 18, 2);
            }
            ctx.restore();
            break;
          }
          case TileType.CHECKPOINT:
            this.drawCheckpoint(
              ctx,
              x,
              y,
              engine.worldTime,
              (engine.levelDef.checkpoints ?? []).indexOf(c) <=
                engine.checkpointIndex
            );
            break;
          case TileType.SPIKE:
            this.drawSpike(ctx, x, y, engine.levelDef.theme);
            break;
          case TileType.ICE:
            this.drawIce(ctx, x, y);
            break;
          case TileType.CONVEYOR_LEFT:
          case TileType.CONVEYOR_RIGHT:
            this.drawConveyor(
              ctx,
              x,
              y,
              t === TileType.CONVEYOR_RIGHT ? 1 : -1,
              engine.worldTime
            );
            break;
          case TileType.JELLY:
            this.drawJelly(
              ctx,
              x,
              y,
              engine.springTimers.has(`${c},${r}`),
              engine.levelDef.theme
            );
            break;
          case TileType.CRUMBLE:
            this.drawCrumble(
              ctx,
              x,
              y,
              engine.crumbleTimers.get(`${c},${r}`),
              engine.levelDef.theme
            );
            break;
          case TileType.VINE:
            this.drawVine(ctx, x, y, r, engine.worldTime);
            break;
          case TileType.CLOUD:
            this.drawCloudTile(
              ctx,
              x,
              y,
              engine.crumbleTimers.get(`${c},${r}`)
            );
            break;
          case TileType.PIPE_TL:
          case TileType.PIPE_TR:
          case TileType.PIPE_BL:
          case TileType.PIPE_BR: {
            const isWarp = (engine.levelDef.warps ?? []).some(
              (wp) => wp.row === r && (wp.col === c || wp.col + 1 === c)
            );
            this.drawPipeTile(ctx, t, x, y, isWarp, engine.worldTime);
            break;
          }
        }

        // Weather settles on any surface that has open sky directly above it.
        if (accum > 0.02 && DEPOSIT_TILES.has(t)) {
          const above = engine.getTile(c, r - 1);
          if (above === TileType.EMPTY) {
            this.drawDeposit(
              ctx, weather, x, y, c, accum, engine.worldTime
            );
          }
        }
      }
    }
  }

  private drawPipeTile(
    ctx: CanvasRenderingContext2D,
    t: TileType,
    x: number,
    y: number,
    isWarp = false,
    time = 0
  ): void {
    const isTop = t === TileType.PIPE_TL || t === TileType.PIPE_TR;
    const isLeft = t === TileType.PIPE_TL || t === TileType.PIPE_BL;

    // Enterable pipes get an animated glow + downward arrow prompt.
    if (isWarp && isTop) {
      const pulse = 0.45 + 0.35 * Math.sin(time * 5);
      ctx.save();
      ctx.globalAlpha = pulse;
      ctx.fillStyle = '#7bf78f';
      ctx.fillRect(x - 2, y - 10, 36, 14);
      ctx.restore();
      if (isLeft) {
        const bob = Math.sin(time * 4) * 3;
        ctx.save();
        ctx.globalAlpha = 0.9;
        ctx.fillStyle = '#eafff0';
        ctx.beginPath();
        ctx.moveTo(x + 26, y - 26 + bob);
        ctx.lineTo(x + 38, y - 26 + bob);
        ctx.lineTo(x + 32, y - 16 + bob);
        ctx.closePath();
        ctx.fill();
        ctx.restore();
      }
    }

    if (isTop) {
      const rx = isLeft ? x : x - 2;
      const rw = isLeft ? 34 : 34;
      ctx.fillStyle = '#0d2614';
      ctx.fillRect(rx, y, rw, 32);
      const gTop = ctx.createLinearGradient(rx, 0, rx + rw, 0);
      gTop.addColorStop(0, '#2fe06a');
      gTop.addColorStop(0.35, '#1ec94c');
      gTop.addColorStop(1, '#0f8a33');
      ctx.fillStyle = gTop;
      ctx.fillRect(rx + 2, y + 2, rw - 4, 28);
      if (isLeft) {
        ctx.fillStyle = '#7bf78f';
        ctx.fillRect(x + 6, y + 2, 8, 28);
        ctx.fillRect(x + 18, y + 2, 3, 28);
      } else {
        ctx.fillStyle = '#118731';
        ctx.fillRect(x + 14, y + 2, 14, 28);
      }
      ctx.fillStyle = '#0d2614';
      ctx.fillRect(rx, y + 29, rw, 3);
    } else {
      const bx = isLeft ? x + 4 : x;
      const bw = 28;
      ctx.fillStyle = '#0d2614';
      ctx.fillRect(bx, y, bw, 32);
      ctx.fillStyle = '#1ec94c';
      ctx.fillRect(isLeft ? bx + 2 : bx, y, isLeft ? bw - 2 : bw - 2, 32);
      if (isLeft) {
        ctx.fillStyle = '#7bf78f';
        ctx.fillRect(bx + 5, y, 7, 32);
        ctx.fillRect(bx + 15, y, 3, 32);
      } else {
        ctx.fillStyle = '#118731';
        ctx.fillRect(bx + 12, y, 12, 32);
      }
    }
  }

  private drawBridgeTile(
    ctx: CanvasRenderingContext2D,
    x: number,
    y: number,
    theme: WorldTheme
  ): void {
    ctx.fillStyle = '#171321';
    ctx.fillRect(x, y, 32, 12);
    ctx.fillStyle = theme === 'castle' ? '#d97724' : '#f5b942';
    ctx.fillRect(x + 1, y + 2, 30, 8);
    ctx.fillStyle = theme === 'castle' ? '#ffbe6b' : '#fff0a6';
    ctx.fillRect(x + 1, y + 2, 30, 3);
    // Plank dividers
    ctx.fillStyle = '#171321';
    ctx.fillRect(x + 10, y + 2, 2, 8);
    ctx.fillRect(x + 21, y + 2, 2, 8);
  }

  private drawLavaTile(
    ctx: CanvasRenderingContext2D,
    x: number,
    y: number,
    col: number,
    time: number
  ): void {
    const wave = Math.sin(time * 6 + col * 0.9) * 3;
    ctx.fillStyle = '#d9230f';
    ctx.fillRect(x, y + 4 + wave, 32, 32);
    ctx.fillStyle = '#ff7b1c';
    ctx.fillRect(x, y + 4 + wave, 32, 8);
    ctx.fillStyle = '#ffe94d';
    ctx.fillRect(x + 4, y + 4 + wave, 14, 4);
  }

  /** Mid-level respawn flag — grey when dormant, green once activated. */
  private drawCheckpoint(
    ctx: CanvasRenderingContext2D,
    x: number,
    y: number,
    time: number,
    active: boolean
  ): void {
    // Base plate
    ctx.fillStyle = '#14121d';
    ctx.fillRect(x + 6, y + 26, 20, 6);
    ctx.fillStyle = active ? '#22c55e' : '#64748b';
    ctx.fillRect(x + 8, y + 27, 16, 4);

    // Pole
    ctx.fillStyle = '#1f2937';
    ctx.fillRect(x + 14, y - 30, 5, 58);
    ctx.fillStyle = active ? '#86efac' : '#94a3b8';
    ctx.fillRect(x + 15, y - 30, 2, 58);

    // Pennant
    const flutter = active ? Math.sin(time * 9) * 3 : 0;
    ctx.fillStyle = active ? '#22c55e' : '#475569';
    ctx.beginPath();
    ctx.moveTo(x + 19, y - 28);
    ctx.lineTo(x + 40 + flutter, y - 20);
    ctx.lineTo(x + 19, y - 12);
    ctx.closePath();
    ctx.fill();
    ctx.fillStyle = active ? '#dcfce7' : '#94a3b8';
    ctx.fillRect(x + 24, y - 23, 5, 5);

    if (active) {
      // Soft glow pulse so players can see it is banked.
      const pulse = 0.4 + 0.3 * Math.sin(time * 4);
      ctx.fillStyle = `rgba(74, 222, 128, ${pulse * 0.35})`;
      ctx.beginPath();
      ctx.arc(x + 16, y - 4, 20, 0, Math.PI * 2);
      ctx.fill();
    }
  }

  private drawSpike(
    ctx: CanvasRenderingContext2D,
    x: number,
    y: number,
    theme: WorldTheme
  ): void {
    const base = theme === 'volcano' ? '#2b1410' : theme === 'castle' ? '#2f3344' : '#1e2433';
    const tip = theme === 'volcano' ? '#ff8a4c' : '#cbd5f5';
    ctx.fillStyle = base;
    ctx.fillRect(x, y + 22, 32, 10);
    ctx.fillStyle = tip;
    for (let i = 0; i < 4; i++) {
      const sx = x + i * 8;
      ctx.beginPath();
      ctx.moveTo(sx, y + 24);
      ctx.lineTo(sx + 4, y + 4);
      ctx.lineTo(sx + 8, y + 24);
      ctx.closePath();
      ctx.fill();
    }
    ctx.fillStyle = 'rgba(255,255,255,0.65)';
    for (let i = 0; i < 4; i++) ctx.fillRect(x + i * 8 + 3, y + 8, 2, 10);
  }

  private drawIce(
    ctx: CanvasRenderingContext2D,
    x: number,
    y: number
  ): void {
    ctx.fillStyle = '#9fd8f5';
    ctx.fillRect(x, y, 32, 32);
    ctx.fillStyle = '#d8f2ff';
    ctx.fillRect(x, y, 32, 7);
    ctx.fillStyle = '#ffffff';
    ctx.fillRect(x + 3, y + 2, 12, 3);
    ctx.fillStyle = '#6fb6dd';
    ctx.fillRect(x, y + 27, 32, 5);
    // Glassy streaks
    ctx.strokeStyle = 'rgba(255,255,255,0.75)';
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.moveTo(x + 6, y + 26);
    ctx.lineTo(x + 18, y + 9);
    ctx.moveTo(x + 18, y + 27);
    ctx.lineTo(x + 28, y + 13);
    ctx.stroke();
  }

  private drawConveyor(
    ctx: CanvasRenderingContext2D,
    x: number,
    y: number,
    dir: number,
    time: number
  ): void {
    ctx.fillStyle = '#1b2029';
    ctx.fillRect(x, y, 32, 32);
    ctx.fillStyle = '#39414f';
    ctx.fillRect(x, y + 4, 32, 20);
    // Scrolling tread arrows
    const shift = ((time * 90 * dir) % 16 + 16) % 16;
    ctx.fillStyle = '#ffb23d';
    for (let i = -1; i < 3; i++) {
      const ax = x + i * 16 + shift;
      ctx.beginPath();
      if (dir > 0) {
        ctx.moveTo(ax + 2, y + 9);
        ctx.lineTo(ax + 11, y + 14);
        ctx.lineTo(ax + 2, y + 19);
      } else {
        ctx.moveTo(ax + 11, y + 9);
        ctx.lineTo(ax + 2, y + 14);
        ctx.lineTo(ax + 11, y + 19);
      }
      ctx.closePath();
      ctx.fill();
    }
    // Rollers
    ctx.fillStyle = '#9aa4b5';
    ctx.fillRect(x, y + 24, 32, 5);
    ctx.fillStyle = '#5b6474';
    const rollShift = ((time * 60 * dir) % 10 + 10) % 10;
    for (let i = -1; i < 4; i++) {
      ctx.fillRect(x + i * 10 + rollShift, y + 25, 4, 3);
    }
  }

  private drawJelly(
    ctx: CanvasRenderingContext2D,
    x: number,
    y: number,
    squashed: boolean,
    theme: WorldTheme
  ): void {
    const top = squashed ? y + 12 : y + 4;
    const h = squashed ? 20 : 28;
    const body = theme === 'beach' ? '#5ad7f5' : theme === 'overworld' ? '#ff5fa2' : '#ff7ad1';
    const light = theme === 'beach' ? '#c6f4ff' : '#ffd0e8';
    ctx.fillStyle = '#14121d';
    ctx.fillRect(x + 1, top - 2, 30, h + 2);
    ctx.fillStyle = body;
    ctx.fillRect(x + 2, top, 28, h - 2);
    ctx.fillStyle = light;
    ctx.fillRect(x + 5, top + 3, 12, 5);
    ctx.fillRect(x + 5, top + 10, 6, 4);
    // Wobbling highlight rim
    ctx.fillStyle = 'rgba(255,255,255,0.4)';
    ctx.fillRect(x + 2, top + h - 7, 28, 3);
  }

  private drawCrumble(
    ctx: CanvasRenderingContext2D,
    x: number,
    y: number,
    timer: number | undefined,
    theme: WorldTheme
  ): void {
    const shaking = timer !== undefined;
    const sx = shaking ? Math.sin(timer * 70) * 2 : 0;
    const base = theme === 'haunted' ? '#5a4580' : '#c89a5a';
    const light = theme === 'haunted' ? '#8f74bd' : '#ecc48c';
    const dark = theme === 'haunted' ? '#33244d' : '#7b5a2c';

    ctx.save();
    if (shaking) ctx.globalAlpha = 0.55 + 0.45 * Math.sin(timer * 40);
    ctx.fillStyle = dark;
    ctx.fillRect(x + sx, y, 32, 32);
    ctx.fillStyle = base;
    ctx.fillRect(x + 2 + sx, y + 2, 28, 28);
    ctx.fillStyle = light;
    ctx.fillRect(x + 2 + sx, y + 2, 28, 4);
    // Cracks
    ctx.strokeStyle = dark;
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.moveTo(x + 8 + sx, y + 6);
    ctx.lineTo(x + 13 + sx, y + 17);
    ctx.lineTo(x + 9 + sx, y + 28);
    ctx.moveTo(x + 22 + sx, y + 5);
    ctx.lineTo(x + 18 + sx, y + 16);
    ctx.lineTo(x + 24 + sx, y + 29);
    ctx.stroke();
    ctx.restore();
  }

  private drawVine(
    ctx: CanvasRenderingContext2D,
    x: number,
    y: number,
    row: number,
    time: number
  ): void {
    const sway = Math.sin(time * 2 + row * 0.6) * 2;
    ctx.strokeStyle = '#1f7a34';
    ctx.lineWidth = 7;
    ctx.beginPath();
    ctx.moveTo(x + 16 - sway, y);
    ctx.lineTo(x + 16 + sway, y + 32);
    ctx.stroke();
    ctx.strokeStyle = '#4ade80';
    ctx.lineWidth = 3;
    ctx.beginPath();
    ctx.moveTo(x + 16 - sway, y);
    ctx.lineTo(x + 16 + sway, y + 32);
    ctx.stroke();
    // Leaves
    ctx.fillStyle = '#2fae5c';
    const lx = x + 16 + sway;
    if (row % 2 === 0) {
      ctx.beginPath();
      ctx.ellipse(lx + 9, y + 12, 8, 4, 0.4, 0, Math.PI * 2);
      ctx.fill();
    } else {
      ctx.beginPath();
      ctx.ellipse(lx - 9, y + 20, 8, 4, -0.4, 0, Math.PI * 2);
      ctx.fill();
    }
  }

  private drawCloudTile(
    ctx: CanvasRenderingContext2D,
    x: number,
    y: number,
    timer: number | undefined
  ): void {
    ctx.save();
    if (timer !== undefined) {
      ctx.globalAlpha = 0.35 + 0.45 * Math.abs(Math.sin(timer * 26));
    }
    ctx.fillStyle = '#dbe6ff';
    ctx.fillRect(x, y + 8, 32, 14);
    ctx.fillStyle = '#ffffff';
    ctx.fillRect(x + 2, y + 4, 12, 12);
    ctx.fillRect(x + 16, y + 2, 14, 14);
    ctx.fillRect(x, y + 10, 32, 8);
    ctx.fillStyle = '#aebde8';
    ctx.fillRect(x, y + 19, 32, 4);
    ctx.restore();
  }

  /** Distinct art per weapon so each one reads instantly. */
  private drawProjectile(
    ctx: CanvasRenderingContext2D,
    fb: Fireball,
    time: number
  ): void {
    const def = WEAPONS[fb.weapon];
    ctx.save();
    ctx.translate(fb.x, fb.y);

    // Soft glow halo for every shot.
    ctx.save();
    ctx.globalAlpha = 0.33;
    ctx.fillStyle = def.glow;
    ctx.beginPath();
    ctx.arc(0, 0, 13, 0, Math.PI * 2);
    ctx.fill();
    ctx.restore();

    ctx.rotate(fb.rotation);

    switch (fb.weapon) {
      case 'hammer': {
        ctx.fillStyle = '#14121d';
        ctx.fillRect(-3, -4, 7, 19);
        ctx.fillStyle = '#b5651d';
        ctx.fillRect(-2, -3, 5, 17);
        ctx.fillStyle = '#14121d';
        ctx.fillRect(-11, -14, 22, 12);
        ctx.fillStyle = '#c0c7d8';
        ctx.fillRect(-9, -12, 18, 8);
        ctx.fillStyle = '#f2f6ff';
        ctx.fillRect(-7, -11, 9, 3);
        break;
      }
      case 'boomerang': {
        ctx.strokeStyle = '#0e7490';
        ctx.lineWidth = 7;
        ctx.lineCap = 'round';
        ctx.beginPath();
        ctx.moveTo(-9, 7);
        ctx.lineTo(0, -8);
        ctx.lineTo(9, 7);
        ctx.stroke();
        ctx.strokeStyle = def.color;
        ctx.lineWidth = 4;
        ctx.beginPath();
        ctx.moveTo(-9, 7);
        ctx.lineTo(0, -8);
        ctx.lineTo(9, 7);
        ctx.stroke();
        break;
      }
      case 'iceball': {
        ctx.fillStyle = '#0ea5e9';
        for (let i = 0; i < 6; i++) {
          ctx.rotate(Math.PI / 3);
          ctx.fillRect(-1.5, -9, 3, 9);
        }
        ctx.fillStyle = '#e0f7ff';
        ctx.beginPath();
        ctx.arc(0, 0, 5, 0, Math.PI * 2);
        ctx.fill();
        break;
      }
      case 'bomb': {
        ctx.fillStyle = '#0b0f1a';
        ctx.beginPath();
        ctx.arc(0, 0, 9, 0, Math.PI * 2);
        ctx.fill();
        ctx.fillStyle = '#3b4252';
        ctx.beginPath();
        ctx.arc(-3, -3, 3.5, 0, Math.PI * 2);
        ctx.fill();
        // Sparking fuse
        ctx.strokeStyle = '#b45309';
        ctx.lineWidth = 2;
        ctx.beginPath();
        ctx.moveTo(4, -7);
        ctx.lineTo(8, -13);
        ctx.stroke();
        const spark = 2 + Math.abs(Math.sin(time * 22)) * 3;
        ctx.fillStyle = Math.floor(time * 20) % 2 ? '#fff3c4' : '#ff9f43';
        ctx.beginPath();
        ctx.arc(8, -13, spark, 0, Math.PI * 2);
        ctx.fill();
        break;
      }
      case 'laser': {
        ctx.fillStyle = def.glow;
        ctx.fillRect(-16, -3, 32, 6);
        ctx.fillStyle = '#ffffff';
        ctx.fillRect(-12, -1.5, 24, 3);
        ctx.fillStyle = def.color;
        ctx.beginPath();
        ctx.arc(14, 0, 4, 0, Math.PI * 2);
        ctx.fill();
        break;
      }
      default: {
        // Fireball
        ctx.fillStyle = '#ff3b1f';
        ctx.fillRect(-6, -6, 12, 12);
        ctx.fillStyle = '#ffe94d';
        ctx.fillRect(-4, -4, 8, 8);
        ctx.fillStyle = '#ffffff';
        ctx.fillRect(-2, -2, 4, 4);
      }
    }
    ctx.restore();
  }

  private drawEnemyShot(
    ctx: CanvasRenderingContext2D,
    s: EnemyProjectile
  ): void {
    ctx.save();
    ctx.translate(s.x, s.y);

    if (s.kind === 'laser') {
      ctx.save();
      ctx.globalAlpha = 0.4;
      ctx.fillStyle = '#c084fc';
      ctx.beginPath();
      ctx.arc(0, 0, 12, 0, Math.PI * 2);
      ctx.fill();
      ctx.restore();
      ctx.rotate(Math.atan2(s.vy, s.vx));
      ctx.fillStyle = '#7c3aed';
      ctx.fillRect(-14, -3.5, 28, 7);
      ctx.fillStyle = '#f5f3ff';
      ctx.fillRect(-10, -1.5, 20, 3);
      ctx.restore();
      return;
    }

    ctx.rotate(s.rotation);
    if (s.kind === 'fire') {
      ctx.fillStyle = '#ff6b1a';
      ctx.beginPath();
      ctx.arc(0, 0, 7, 0, Math.PI * 2);
      ctx.fill();
      ctx.fillStyle = '#ffd166';
      ctx.beginPath();
      ctx.arc(0, 0, 4, 0, Math.PI * 2);
      ctx.fill();
    } else if (s.kind === 'bone') {
      ctx.fillStyle = '#f3f6ff';
      ctx.fillRect(-9, -2.5, 18, 5);
      ctx.beginPath();
      ctx.arc(-9, -3, 3.2, 0, Math.PI * 2);
      ctx.arc(-9, 3, 3.2, 0, Math.PI * 2);
      ctx.arc(9, -3, 3.2, 0, Math.PI * 2);
      ctx.arc(9, 3, 3.2, 0, Math.PI * 2);
      ctx.fill();
    } else if (s.kind === 'spit') {
      ctx.fillStyle = '#22c55e';
      ctx.beginPath();
      ctx.ellipse(0, 0, 7, 5, 0, 0, Math.PI * 2);
      ctx.fill();
      ctx.fillStyle = '#bbf7d0';
      ctx.beginPath();
      ctx.arc(-2, -1.5, 2, 0, Math.PI * 2);
      ctx.fill();
    } else {
      // hammer
      ctx.fillStyle = '#14121d';
      ctx.fillRect(-2.5, -3, 6, 16);
      ctx.fillStyle = '#b5651d';
      ctx.fillRect(-1.5, -2, 4, 14);
      ctx.fillStyle = '#14121d';
      ctx.fillRect(-9, -12, 18, 10);
      ctx.fillStyle = '#9ca9c7';
      ctx.fillRect(-7, -10, 14, 6);
    }
    ctx.restore();
  }

  private drawWeaponCrate(
    ctx: CanvasRenderingContext2D,
    w: WeaponPickup,
    time: number
  ): void {
    const def = WEAPONS[w.weapon];
    const bob = Math.sin(w.bob) * 3;
    const x = w.x;
    const y = w.y + bob;

    ctx.save();
    // Glow pulse
    ctx.globalAlpha = 0.3 + 0.15 * Math.sin(time * 5);
    ctx.fillStyle = def.glow;
    ctx.beginPath();
    ctx.arc(x + 13, y + 13, 22, 0, Math.PI * 2);
    ctx.fill();
    ctx.globalAlpha = 1;

    // Crate body with bevel
    ctx.fillStyle = '#14121d';
    ctx.fillRect(x, y, 26, 26);
    const g = ctx.createLinearGradient(x, y, x, y + 26);
    g.addColorStop(0, '#4b5563');
    g.addColorStop(1, '#1f2937');
    ctx.fillStyle = g;
    ctx.fillRect(x + 2, y + 2, 22, 22);
    ctx.fillStyle = def.color;
    ctx.fillRect(x + 2, y + 2, 22, 4);
    // Corner rivets
    ctx.fillStyle = '#9ca3af';
    ctx.fillRect(x + 3, y + 8, 3, 3);
    ctx.fillRect(x + 20, y + 8, 3, 3);
    ctx.fillRect(x + 3, y + 20, 3, 3);
    ctx.fillRect(x + 20, y + 20, 3, 3);

    // Weapon icon
    ctx.font = '13px serif';
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.fillText(def.icon, x + 13, y + 15);
    ctx.restore();
  }

  private drawPlatforms(
    ctx: CanvasRenderingContext2D,
    engine: MarioGameEngine
  ): void {
    for (const p of engine.platforms) {
      ctx.fillStyle = '#14121d';
      ctx.fillRect(p.x, p.y, p.width, p.height);
      ctx.fillStyle = '#f8fafc';
      ctx.fillRect(p.x + 2, p.y + 2, p.width - 4, p.height - 4);
      ctx.fillStyle = '#ef4444';
      for (let rx = p.x + 8; rx < p.x + p.width - 8; rx += 16) {
        ctx.fillRect(rx, p.y + 4, 8, 6);
      }
    }
  }

  private drawCastleAndFlagpole(
    ctx: CanvasRenderingContext2D,
    engine: MarioGameEngine
  ): void {
    const flagCol = engine.levelDef.flagCol;
    const poleX = flagCol * TILE_SIZE + TILE_SIZE * 0.5;
    const baseBlockY = 12 * TILE_SIZE;
    const topY = 3 * TILE_SIZE;

    // Base pedestal block
    const themeTiles = getBiomeTiles(getLevelBiome(engine.levelIndex + 1).biome);
    ctx.drawImage(themeTiles.solid, flagCol * TILE_SIZE, baseBlockY, TILE_SIZE, TILE_SIZE);

    // Pole shaft
    ctx.fillStyle = '#1b3b22';
    ctx.fillRect(poleX - 4, topY, 8, baseBlockY - topY);
    ctx.fillStyle = '#7bf78f';
    ctx.fillRect(poleX - 2, topY, 4, baseBlockY - topY);

    // Golden finial ball
    ctx.fillStyle = '#14121d';
    ctx.fillRect(poleX - 8, topY - 12, 16, 16);
    ctx.fillStyle = '#ffd93d';
    ctx.fillRect(poleX - 6, topY - 10, 12, 12);
    ctx.fillStyle = '#ffffff';
    ctx.fillRect(poleX - 4, topY - 8, 4, 4);

    // Fluttering Pennant Flag
    const fy = engine.flagY;
    const flutter = Math.sin(engine.worldTime * 9) * 2;
    ctx.fillStyle = '#1ec95b';
    ctx.beginPath();
    ctx.moveTo(poleX - 2, fy);
    ctx.lineTo(poleX - 36, fy + 12 + flutter);
    ctx.lineTo(poleX - 2, fy + 24);
    ctx.closePath();
    ctx.fill();
    ctx.fillStyle = '#ffffff';
    ctx.fillRect(poleX - 18, fy + 9 + flutter * 0.4, 8, 6);

    // Brick Fortress Castle!
    const cx = engine.levelDef.castleCol * TILE_SIZE;
    const cy = 8 * TILE_SIZE;
    const cw = 4 * TILE_SIZE;
    const ch = 5 * TILE_SIZE;

    // Lower body
    for (let r = 10; r < 13; r++) {
      for (let c = 0; c < 4; c++) {
        ctx.drawImage(themeTiles.brick, cx + c * TILE_SIZE, r * TILE_SIZE, TILE_SIZE, TILE_SIZE);
      }
    }
    // Upper keep
    for (let r = 8; r < 10; r++) {
      for (let c = 1; c < 3; c++) {
        ctx.drawImage(themeTiles.brick, cx + c * TILE_SIZE, r * TILE_SIZE, TILE_SIZE, TILE_SIZE);
      }
    }
    // Battlements
    ctx.fillStyle = '#e2e8f0';
    for (let i = 0; i < 4; i++) {
      ctx.fillRect(cx + i * 34, 10 * TILE_SIZE - 10, 22, 10);
    }
    ctx.fillRect(cx + 32, cy - 10, 20, 10);
    ctx.fillRect(cx + 76, cy - 10, 20, 10);

    // Arched Dark Doorway
    ctx.fillStyle = '#090b14';
    ctx.fillRect(cx + cw * 0.5 - 18, 11 * TILE_SIZE + 8, 36, 56);
    ctx.beginPath();
    ctx.arc(cx + cw * 0.5, 11 * TILE_SIZE + 8, 18, Math.PI, 0);
    ctx.fill();
    void ch;
  }

  private drawCoins(ctx: CanvasRenderingContext2D, engine: MarioGameEngine): void {
    const frame = Math.floor(engine.worldTime * 8) % 4;
    const sprite = this.sprites.items.coins[frame];
    for (const coin of engine.coinsList) {
      if (coin.collected) continue;
      const bob = Math.sin(engine.worldTime * 4.5 + coin.bobOffset) * 3;
      const y = coin.y - 16 + bob;

      // Soft halo so coins pop against busy backdrops.
      const pulse = 0.4 + 0.3 * Math.sin(engine.worldTime * 5 + coin.bobOffset);
      ctx.save();
      ctx.globalCompositeOperation = 'lighter';
      ctx.globalAlpha = pulse * 0.5;
      const g = ctx.createRadialGradient(
        coin.x, y + 16, 2, coin.x, y + 16, 22
      );
      g.addColorStop(0, '#ffe94d');
      g.addColorStop(1, 'rgba(255,233,77,0)');
      ctx.fillStyle = g;
      ctx.beginPath();
      ctx.arc(coin.x, y + 16, 22, 0, Math.PI * 2);
      ctx.fill();
      ctx.restore();

      ctx.drawImage(sprite, coin.x - 16, y, 32, 32);

      // Occasional twinkle.
      const tw = Math.sin(engine.worldTime * 3 + coin.bobOffset * 2.7);
      if (tw > 0.93) {
        ctx.save();
        ctx.strokeStyle = '#fffbe6';
        ctx.lineWidth = 1.6;
        ctx.globalAlpha = (tw - 0.93) / 0.07;
        const r = 10;
        ctx.beginPath();
        ctx.moveTo(coin.x - r, y + 16); ctx.lineTo(coin.x + r, y + 16);
        ctx.moveTo(coin.x, y + 16 - r); ctx.lineTo(coin.x, y + 16 + r);
        ctx.stroke();
        ctx.restore();
      }
    }
  }

  private drawItem(
    ctx: CanvasRenderingContext2D,
    item: PowerItem,
    time: number
  ): void {
    let sprite = this.sprites.items.mushroom;
    if (item.kind === 'one_up') {
      sprite = this.sprites.items.oneUp;
    } else if (item.kind === 'fire_flower') {
      sprite =
        Math.floor(time * 10) % 2 === 0
          ? this.sprites.items.flower1
          : this.sprites.items.flower2;
    } else if (item.kind === 'star') {
      sprite =
        Math.floor(time * 12) % 2 === 0
          ? this.sprites.items.star1
          : this.sprites.items.star2;
    }
    // Rotating aura marks power-ups as important pickups.
    ctx.save();
    ctx.globalCompositeOperation = 'lighter';
    const pulse = 0.45 + 0.35 * Math.sin(time * 6);
    const g = ctx.createRadialGradient(
      item.x + 13, item.y + 12, 3, item.x + 13, item.y + 12, 26
    );
    const hue = item.kind === 'one_up' ? '#4ade80'
      : item.kind === 'star' ? '#ffe94d'
        : item.kind === 'fire_flower' ? '#ff9f2e' : '#ff5959';
    g.addColorStop(0, hue);
    g.addColorStop(1, 'rgba(0,0,0,0)');
    ctx.globalAlpha = pulse * 0.6;
    ctx.fillStyle = g;
    ctx.beginPath();
    ctx.arc(item.x + 13, item.y + 12, 26, 0, Math.PI * 2);
    ctx.fill();
    ctx.restore();

    ctx.drawImage(sprite, item.x - 3, item.y - 4, 32, 32);
  }

  private drawEnemy(
    ctx: CanvasRenderingContext2D,
    e: Enemy,
    time: number
  ): void {
    // Frozen foes render inside a cracked ice block.
    if (e.frozenTimer > 0) {
      this.drawEnemyBody(ctx, e, time);
      const flicker = e.frozenTimer < 1 && Math.floor(time * 14) % 2 === 0;
      ctx.save();
      ctx.globalAlpha = flicker ? 0.45 : 0.78;
      const g = ctx.createLinearGradient(e.x, e.y - 4, e.x, e.y + e.height + 4);
      g.addColorStop(0, '#e0f7ff');
      g.addColorStop(0.5, '#7dd3fc');
      g.addColorStop(1, '#38bdf8');
      ctx.fillStyle = g;
      ctx.fillRect(e.x - 4, e.y - 5, e.width + 8, e.height + 9);
      ctx.strokeStyle = '#f0fbff';
      ctx.lineWidth = 2;
      ctx.strokeRect(e.x - 4, e.y - 5, e.width + 8, e.height + 9);
      ctx.fillStyle = 'rgba(255,255,255,0.85)';
      ctx.fillRect(e.x - 1, e.y - 2, 4, e.height + 2);
      ctx.restore();
      this.drawHpBar(ctx, e);
      return;
    }

    this.drawEnemyBody(ctx, e, time);

    // White flash when a weapon connects.
    if (e.hitFlash > 0) {
      ctx.save();
      ctx.globalAlpha = Math.min(0.85, e.hitFlash * 4.5);
      ctx.globalCompositeOperation = 'lighter';
      ctx.fillStyle = '#ffffff';
      ctx.fillRect(e.x - 3, e.y - 3, e.width + 6, e.height + 6);
      ctx.restore();
    }

    this.drawHpBar(ctx, e);
  }

  /** Small pip bar so tougher enemies are obvious at a glance. */
  private drawHpBar(ctx: CanvasRenderingContext2D, e: Enemy): void {
    if (e.maxHp <= 1) return;
    if (e.state === 'squished' || e.state === 'flipped') return;
    const stats = ENEMY_STATS[e.kind];
    const pipW = 5;
    const gap = 1.5;
    const total = e.maxHp * pipW + (e.maxHp - 1) * gap;
    const bx = e.x + e.width * 0.5 - total / 2;
    const by = e.y - 9;

    ctx.save();
    ctx.fillStyle = 'rgba(8,10,20,0.72)';
    ctx.fillRect(bx - 2, by - 2, total + 4, 7);
    for (let i = 0; i < e.maxHp; i++) {
      ctx.fillStyle = i < e.hp ? stats.tint : 'rgba(255,255,255,0.18)';
      ctx.fillRect(bx + i * (pipW + gap), by, pipW, 3);
    }
    // Elite variants get a gold crown bar.
    if (e.variant > 0) {
      ctx.fillStyle = '#fde047';
      ctx.fillRect(bx - 2, by - 4, total + 4, 1.5);
    }
    ctx.restore();
  }

  private drawEnemyBody(
    ctx: CanvasRenderingContext2D,
    e: Enemy,
    time: number
  ): void {
    ctx.save();
    // Elite recolour: a subtle hue shift marks the stronger variant.
    // Elite marker: a cheap additive rim instead of an expensive filter.
    if (e.variant > 0) {
      ctx.save();
      ctx.globalCompositeOperation = 'lighter';
      ctx.globalAlpha = 0.18;
      ctx.fillStyle = '#ffd166';
      ctx.fillRect(e.x - 2, e.y - 2, e.width + 4, e.height + 4);
      ctx.restore();
    }
    const cx = e.x + e.width * 0.5;
    const cy = e.y + e.height * 0.5;

    if (e.state === 'flipped') {
      ctx.translate(cx, cy);
      ctx.scale(1, -1);
      ctx.translate(-cx, -cy);
    }

    if (e.kind === 'goomba') {
      const sprite =
        e.state === 'squished'
          ? this.sprites.goomba.squish
          : Math.floor(e.animTimer * 6) % 2 === 0
            ? this.sprites.goomba.walk1
            : this.sprites.goomba.walk2;
      ctx.drawImage(sprite, e.x - 3, e.y - 2, 32, 32);
      ctx.restore();
      return;
    }

    if (e.kind === 'piranha') {
      const sprite =
        Math.floor(time * 6) % 2 === 0
          ? this.sprites.piranha.open
          : this.sprites.piranha.closed;
      ctx.drawImage(sprite, e.x - 3, e.y, 32, 32);
      ctx.restore();
      return;
    }

    if (e.kind === 'armored_goomba') {
      const sprite = Math.floor(e.animTimer * 5) % 2 === 0
        ? this.sprites.armoredGoomba.walk1
        : this.sprites.armoredGoomba.walk2;
      ctx.drawImage(sprite, e.x - 3, e.y - 3, 36, 36);
      ctx.restore();
      return;
    }

    if (e.kind === 'fire_bro' || e.kind === 'sniper_bro') {
      const set = e.kind === 'fire_bro'
        ? this.sprites.fireBro
        : this.sprites.sniperBro;
      const f = Math.floor(e.animTimer * 7) % 2;
      const sprite = e.facing === 1
        ? (f === 0 ? set.walk1R : set.walk2R)
        : (f === 0 ? set.walk1L : set.walk2L);

      if (e.throwWindup > 0 && e.state !== 'flipped') {
        const pulse = 1 + Math.sin(time * 24) * 0.12;
        const tint = e.kind === 'fire_bro' ? '#ff8a3d' : '#c084fc';
        ctx.save();
        ctx.translate(cx, e.y - 11);
        ctx.scale(pulse, pulse);
        ctx.fillStyle = '#090b14';
        ctx.fillRect(-10, -11, 20, 19);
        ctx.fillStyle = tint;
        ctx.fillRect(-8, -9, 16, 15);
        ctx.fillStyle = '#1b1020';
        ctx.font = 'bold 12px "Press Start 2P", monospace';
        ctx.textAlign = 'center';
        ctx.textBaseline = 'middle';
        ctx.fillText('!', 0, 0);
        ctx.restore();
      }
      ctx.drawImage(sprite, e.x - 3, e.y + 2, 32, 32);
      ctx.restore();
      return;
    }

    if (e.kind === 'spiny') {
      const sprite =
        Math.floor(e.animTimer * 8) % 2 === 0
          ? this.sprites.spiny.walk1
          : this.sprites.spiny.walk2;
      ctx.drawImage(sprite, e.x - 3, e.y - 4, 32, 32);
      ctx.restore();
      return;
    }

    if (e.kind === 'dry_bones') {
      if (e.state === 'collapsed') {
        // Rattle just before it rebuilds itself.
        const shake =
          e.stateTimer < 1.1 ? Math.sin(time * 42) * 1.8 : 0;
        ctx.drawImage(
          this.sprites.dryBones.down,
          e.x - 3 + shake,
          e.y - 2,
          32,
          32
        );
        ctx.restore();
        return;
      }
      const f = Math.floor(e.animTimer * 7) % 2;
      const sprite =
        e.facing === 1
          ? f === 0
            ? this.sprites.dryBones.walk1R
            : this.sprites.dryBones.walk2R
          : f === 0
            ? this.sprites.dryBones.walk1L
            : this.sprites.dryBones.walk2L;
      ctx.drawImage(sprite, e.x - 3, e.y - 2, 32, 32);
      ctx.restore();
      return;
    }

    if (e.kind === 'lakitu') {
      const f = Math.floor(time * 5) % 2;
      const sprite =
        e.facing === 1
          ? f === 0
            ? this.sprites.lakitu.frame1R
            : this.sprites.lakitu.frame2R
          : f === 0
            ? this.sprites.lakitu.frame1L
            : this.sprites.lakitu.frame2L;
      const bob = Math.sin(time * 3.4) * 3;
      ctx.drawImage(sprite, e.x - 3, e.y + bob, 32, 36);
      ctx.restore();
      return;
    }

    if (e.kind === 'bullet_bill') {
      const sprite =
        e.vx >= 0
          ? this.sprites.bulletBill.right
          : this.sprites.bulletBill.left;
      ctx.save();
      ctx.globalAlpha = 0.28;
      ctx.drawImage(sprite, e.x - 3 - e.vx * 0.022, e.y - 3, 32, 32);
      ctx.restore();
      ctx.drawImage(sprite, e.x - 3, e.y - 3, 32, 32);
      ctx.restore();
      return;
    }

    if (e.kind === 'hammer_bro') {
      const f = Math.floor(e.animTimer * 7) % 2;
      const sprite =
        e.facing === 1
          ? f === 0
            ? this.sprites.hammerBro.walk1R
            : this.sprites.hammerBro.walk2R
          : f === 0
            ? this.sprites.hammerBro.walk1L
            : this.sprites.hammerBro.walk2L;

      // Telegraphed throw: a bobbing warning marker + raised hammer.
      if (e.throwWindup > 0 && e.state !== 'flipped') {
        const pulse = 1 + Math.sin(time * 24) * 0.12;
        ctx.save();
        ctx.translate(cx, e.y - 11);
        ctx.scale(pulse, pulse);
        ctx.fillStyle = '#090b14';
        ctx.fillRect(-10, -11, 20, 19);
        ctx.fillStyle = '#ffd166';
        ctx.fillRect(-8, -9, 16, 15);
        ctx.fillStyle = '#3a2400';
        ctx.font = 'bold 12px "Press Start 2P", monospace';
        ctx.textAlign = 'center';
        ctx.textBaseline = 'middle';
        ctx.fillText('!', 0, 0);
        ctx.restore();
      }

      ctx.drawImage(sprite, e.x - 3, e.y + 2, 32, 32);
      ctx.restore();
      return;
    }

    const set =
      e.kind === 'koopa_red'
        ? this.sprites.koopaRed
        : e.kind === 'buzzy'
          ? this.sprites.buzzy
          : this.sprites.koopaGreen;

    let sprite: HTMLCanvasElement;
    if (e.state === 'shell_idle') {
      // Blink slightly right before recovering!
      sprite =
        e.stateTimer > 5.0 && Math.floor(time * 12) % 2 === 0
          ? set.shell2
          : set.shell1;
    } else if (e.state === 'shell_spin') {
      sprite = Math.floor(time * 22) % 2 === 0 ? set.shell1 : set.shell2;
    } else {
      const f = Math.floor(e.animTimer * 6) % 2;
      if (e.facing === 1) {
        sprite = f === 0 ? set.walk1R : set.walk2R;
      } else {
        sprite = f === 0 ? set.walk1L : set.walk2L;
      }
    }

    ctx.drawImage(sprite, e.x - 3, e.y - 2, 32, 32);
    ctx.restore();
  }

  private drawPlayer(
    ctx: CanvasRenderingContext2D,
    engine: MarioGameEngine
  ): void {
    const p = engine.player;

    // Invulnerability flicker
    if (
      p.invulnTimer > 0 &&
      !p.dead &&
      Math.floor(engine.worldTime * 20) % 2 === 0
    ) {
      return;
    }

    let pose = 'idle';
    if (p.dead) {
      pose = 'dead';
    } else if (p.flagSlide) {
      pose = 'jump';
    } else if (p.crouching) {
      pose = 'crouch';
    } else if (!p.onGround) {
      pose = 'jump';
    } else if (p.skidding) {
      pose = 'skid';
    } else if (Math.abs(p.vx) > 12) {
      pose = p.animFrame === 0 ? 'run1' : p.animFrame === 1 ? 'run2' : 'run3';
    }

    // Power-up transformation flash between small and big
    let renderPower = p.power;
    if (p.transformTimer > 0 && Math.floor(engine.worldTime * 24) % 2 === 0) {
      renderPower = p.power === 'small' ? 'big' : 'small';
    }

    const starTick = p.starTimer > 0 ? engine.worldTime : 0;
    const sprite = this.sprites.getMario(
      renderPower, pose, p.facing, starTick, engine.character
    );

    const footX = p.x + p.width * 0.5;
    const footY = p.y + p.height;

    // Contact shadow: grounds the sprite and hints at fall height.
    {
      let shadowY = -1;
      for (let r = Math.floor(footY / 32); r < 15; r++) {
        if (engine.isSolidTile(engine.getTile(Math.floor(footX / 32), r))) {
          shadowY = r * 32;
          break;
        }
      }
      if (shadowY >= 0) {
        const drop = Math.max(0, shadowY - footY);
        const t = Math.max(0, 1 - drop / 180);
        ctx.save();
        ctx.globalAlpha = 0.3 * t;
        ctx.fillStyle = '#000000';
        ctx.beginPath();
        ctx.ellipse(footX, shadowY + 2, 13 * (0.55 + t * 0.45), 4.5, 0, 0, Math.PI * 2);
        ctx.fill();
        ctx.restore();
      }
    }

    // Sprint / Starman subtle speed-ghost trail!
    if (!p.dead && (Math.abs(p.vx) > 305 || p.starTimer > 0)) {
      ctx.save();
      ctx.globalAlpha = p.starTimer > 0 ? 0.34 : 0.2;
      ctx.translate(footX - p.vx * 0.035, footY - p.vy * 0.02);
      ctx.scale(p.scaleX, p.scaleY);
      ctx.drawImage(sprite, -sprite.width * 0.5, -sprite.height + 2);
      ctx.restore();
    }

    ctx.save();

    // Magnet costume: a pulsing pull-ring around the player.
    if (p.magnetTimer > 0) {
      const rr = 150 + Math.sin(engine.worldTime * 6) * 14;
      ctx.save();
      ctx.globalAlpha = 0.16 + 0.08 * Math.sin(engine.worldTime * 6);
      ctx.strokeStyle = '#fbbf24';
      ctx.lineWidth = 3;
      ctx.beginPath();
      ctx.arc(footX, footY - p.height * 0.5, rr * 0.55, 0, Math.PI * 2);
      ctx.stroke();
      ctx.restore();
    }

    ctx.translate(footX, footY);
    ctx.scale(p.scaleX, p.scaleY);

    // Shadow costume: see-through violet silhouette.
    if (p.shadowTimer > 0) {
      ctx.globalAlpha = 0.45 + 0.1 * Math.sin(engine.worldTime * 9);
      ctx.shadowColor = '#c084fc';
      ctx.shadowBlur = 16;
    }

    // Starman aura glow
    if (p.starTimer > 0) {
      ctx.shadowColor =
        Math.floor(engine.worldTime * 15) % 2 === 0 ? '#ffe94d' : '#4df3ff';
      ctx.shadowBlur = 14;
    }

    ctx.drawImage(sprite, -sprite.width * 0.5, -sprite.height + 2);
    ctx.restore();
  }

  private drawParticles(
    ctx: CanvasRenderingContext2D,
    engine: MarioGameEngine
  ): void {
    const coinFrame = Math.floor(engine.worldTime * 18) % 4;
    for (const pt of engine.particles) {
      ctx.save();
      ctx.globalAlpha = pt.alpha;

      if (pt.kind === 'ring') {
        ctx.strokeStyle = pt.color;
        ctx.lineWidth = 5;
        ctx.beginPath();
        ctx.arc(pt.x, pt.y, pt.size, 0, Math.PI * 2);
        ctx.stroke();
        ctx.restore();
        continue;
      }

      if (pt.kind === 'coin_pop') {
        ctx.drawImage(
          this.sprites.items.coins[coinFrame],
          pt.x - 14,
          pt.y - 14,
          28,
          28
        );
        ctx.restore();
        continue;
      }

      ctx.translate(pt.x, pt.y);
      if (pt.rotation !== 0) ctx.rotate(pt.rotation);
      ctx.fillStyle = pt.color;
      ctx.fillRect(-pt.size * 0.5, -pt.size * 0.5, pt.size, pt.size);
      if (pt.kind === 'brick') {
        ctx.strokeStyle = '#1a0c05';
        ctx.lineWidth = 1.5;
        ctx.strokeRect(-pt.size * 0.5, -pt.size * 0.5, pt.size, pt.size);
      }
      ctx.restore();
    }
  }

  private drawFloatingTexts(
    ctx: CanvasRenderingContext2D,
    engine: MarioGameEngine
  ): void {
    ctx.save();
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';

    for (const ft of engine.floatingTexts) {
      const alpha = Math.min(1, (ft.life / ft.maxLife) * 1.4);
      ctx.globalAlpha = alpha;
      const fontSize = Math.round(11 * ft.scale);
      ctx.font = `bold ${fontSize}px "Press Start 2P", monospace`;
      ctx.fillStyle = '#090b14';
      ctx.fillText(ft.text, ft.x + 2, ft.y + 2);
      ctx.fillStyle = ft.color;
      ctx.fillText(ft.text, ft.x, ft.y);
    }
    ctx.restore();
  }
}
