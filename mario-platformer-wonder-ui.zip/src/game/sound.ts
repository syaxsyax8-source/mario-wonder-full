import { WorldTheme } from './types';

class ChiptuneSoundEngine {
  private ctx: AudioContext | null = null;
  private noiseBuffer: AudioBuffer | null = null;
  private soundEnabled = true;
  private musicEnabled = true;
  private bgmTimer: number | null = null;
  private bgmStep = 0;
  private currentTheme: WorldTheme = 'overworld';
  private starMode = false;
  /** Adaptive layer chosen from live gameplay state. */
  private mood: 'normal' | 'tense' | 'boss' | 'hurry' | 'calm' = 'normal';
  private moodIntensity = 0;
  private isPlayingBgm = false;

  constructor() {
    try {
      const savedSfx = localStorage.getItem('smb_sfx_enabled');
      const savedBgm = localStorage.getItem('smb_bgm_enabled');
      if (savedSfx !== null) this.soundEnabled = savedSfx === 'true';
      if (savedBgm !== null) this.musicEnabled = savedBgm === 'true';
    } catch {
      // Ignore storage access issues
    }
  }

  public unlock(): void {
    if (!this.ctx) {
      const AudioCtx =
        window.AudioContext ||
        (window as unknown as { webkitAudioContext: typeof AudioContext })
          .webkitAudioContext;
      if (AudioCtx) {
        this.ctx = new AudioCtx();
        this.createNoiseBuffer();
      }
    }
    if (this.ctx && this.ctx.state === 'suspended') {
      this.ctx.resume().catch(() => {});
    }
  }

  private createNoiseBuffer(): void {
    if (!this.ctx) return;
    const bufferSize = this.ctx.sampleRate * 0.5;
    const buffer = this.ctx.createBuffer(1, bufferSize, this.ctx.sampleRate);
    const data = buffer.getChannelData(0);
    for (let i = 0; i < bufferSize; i++) {
      data[i] = Math.random() * 2 - 1;
    }
    this.noiseBuffer = buffer;
  }

  public isSoundEnabled(): boolean {
    return this.soundEnabled;
  }

  public isMusicEnabled(): boolean {
    return this.musicEnabled;
  }

  public toggleSound(): boolean {
    this.soundEnabled = !this.soundEnabled;
    if (!this.soundEnabled) {
      this.stopMusic();
    } else if (this.musicEnabled && this.isPlayingBgm) {
      this.startMusic(this.currentTheme, this.starMode);
    }
    try {
      localStorage.setItem('smb_sfx_enabled', String(this.soundEnabled));
    } catch {
      // Ignore
    }
    return this.soundEnabled;
  }

  public toggleMusic(): boolean {
    this.musicEnabled = !this.musicEnabled;
    if (!this.musicEnabled) {
      this.clearBgmLoop();
    } else if (this.soundEnabled && this.isPlayingBgm) {
      this.startMusic(this.currentTheme, this.starMode);
    }
    try {
      localStorage.setItem('smb_bgm_enabled', String(this.musicEnabled));
    } catch {
      // Ignore
    }
    return this.musicEnabled;
  }

  private playTone(
    freqStart: number,
    freqEnd: number,
    duration: number,
    type: OscillatorType = 'square',
    gainPeak = 0.14,
    delay = 0
  ): void {
    if (!this.soundEnabled) return;
    this.unlock();
    if (!this.ctx) return;

    const now = this.ctx.currentTime + delay;
    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();

    osc.type = type;
    osc.frequency.setValueAtTime(Math.max(20, freqStart), now);
    if (freqEnd !== freqStart) {
      osc.frequency.exponentialRampToValueAtTime(
        Math.max(20, freqEnd),
        now + duration
      );
    }

    gain.gain.setValueAtTime(0.001, now);
    gain.gain.linearRampToValueAtTime(gainPeak, now + 0.008);
    gain.gain.exponentialRampToValueAtTime(0.001, now + duration);

    osc.connect(gain);
    gain.connect(this.ctx.destination);

    osc.start(now);
    osc.stop(now + duration + 0.01);
  }

  private playNoise(
    duration: number,
    filterFreq = 1200,
    gainPeak = 0.18,
    delay = 0
  ): void {
    if (!this.soundEnabled) return;
    this.unlock();
    if (!this.ctx || !this.noiseBuffer) return;

    const now = this.ctx.currentTime + delay;
    const src = this.ctx.createBufferSource();
    src.buffer = this.noiseBuffer;

    const filter = this.ctx.createBiquadFilter();
    filter.type = 'bandpass';
    filter.frequency.setValueAtTime(filterFreq, now);
    filter.Q.setValueAtTime(1.2, now);

    const gain = this.ctx.createGain();
    gain.gain.setValueAtTime(gainPeak, now);
    gain.gain.exponentialRampToValueAtTime(0.001, now + duration);

    src.connect(filter);
    filter.connect(gain);
    gain.connect(this.ctx.destination);

    src.start(now);
    src.stop(now + duration + 0.01);
  }

  public jump(isBig: boolean): void {
    if (isBig) {
      this.playTone(150, 440, 0.16, 'square', 0.11);
    } else {
      this.playTone(210, 580, 0.14, 'square', 0.11);
    }
  }

  public spring(): void {
    this.playTone(180, 880, 0.24, 'triangle', 0.18);
    this.playTone(260, 1040, 0.22, 'square', 0.09, 0.03);
  }

  public coin(): void {
    this.playTone(987.77, 987.77, 0.075, 'square', 0.11, 0);
    this.playTone(1318.51, 1318.51, 0.24, 'square', 0.11, 0.07);
  }

  public bump(): void {
    this.playTone(165, 72, 0.09, 'triangle', 0.22);
    this.playNoise(0.05, 400, 0.09);
  }

  public brickBreak(): void {
    this.playNoise(0.18, 950, 0.24, 0);
    this.playNoise(0.14, 620, 0.18, 0.05);
    this.playTone(240, 68, 0.15, 'sawtooth', 0.12);
  }

  public stomp(combo = 1): void {
    const mult = Math.min(2.2, 1 + (combo - 1) * 0.14);
    this.playTone(240 * mult, 540 * mult, 0.09, 'square', 0.13);
    this.playNoise(0.04, 1500, 0.1);
  }

  public kick(): void {
    this.playTone(160, 490, 0.08, 'sawtooth', 0.14);
    this.playNoise(0.05, 1800, 0.13);
  }

  public hammerWindup(): void {
    this.playTone(220, 330, 0.11, 'triangle', 0.1);
    this.playTone(330, 392, 0.08, 'square', 0.06, 0.08);
  }

  public hammerThrow(): void {
    this.playTone(480, 150, 0.16, 'square', 0.11);
    this.playNoise(0.08, 2200, 0.1);
  }

  public bulletBill(): void {
    this.playNoise(0.38, 620, 0.12);
    this.playTone(150, 58, 0.34, 'sawtooth', 0.1);
  }

  public weaponSwitch(): void {
    this.playTone(520, 780, 0.07, 'square', 0.09);
    this.playTone(780, 1040, 0.06, 'square', 0.07, 0.05);
  }

  public weaponFire(kind: string): void {
    switch (kind) {
      case 'hammer':
        this.playTone(300, 170, 0.1, 'square', 0.1);
        this.playNoise(0.06, 1500, 0.08);
        break;
      case 'boomerang':
        this.playTone(880, 540, 0.14, 'triangle', 0.1);
        break;
      case 'iceball':
        this.playTone(1180, 760, 0.11, 'sine', 0.11);
        this.playNoise(0.05, 4200, 0.05);
        break;
      case 'bomb':
        this.playTone(220, 120, 0.14, 'triangle', 0.12);
        break;
      case 'laser':
        this.playTone(1500, 420, 0.1, 'sawtooth', 0.09);
        break;
      default:
        this.playTone(760, 240, 0.07, 'square', 0.1);
        this.playTone(420, 880, 0.06, 'triangle', 0.09, 0.04);
    }
  }

  public explosion(): void {
    this.playNoise(0.42, 420, 0.3);
    this.playTone(160, 36, 0.4, 'sawtooth', 0.24);
    this.playTone(320, 70, 0.26, 'square', 0.14, 0.02);
  }

  public enemyHurt(): void {
    this.playTone(420, 250, 0.07, 'square', 0.09);
  }

  public enemyShoot(kind: string): void {
    if (kind === 'laser') {
      this.playTone(1250, 600, 0.1, 'sawtooth', 0.08);
    } else if (kind === 'fire') {
      this.playTone(560, 260, 0.09, 'square', 0.08);
    } else {
      this.playTone(330, 210, 0.08, 'triangle', 0.08);
      this.playNoise(0.05, 1700, 0.05);
    }
  }

  public warp(): void {
    const notes = [660, 560, 470, 390, 320, 260];
    notes.forEach((n, i) => {
      this.playTone(n, n * 0.85, 0.07, 'square', 0.1, i * 0.045);
    });
  }

  public dash(): void {
    this.playTone(880, 1760, 0.09, 'square', 0.1);
    this.playNoise(0.07, 3200, 0.07);
  }

  public grapple(): void {
    this.playTone(420, 980, 0.1, 'triangle', 0.11);
    this.playNoise(0.05, 2400, 0.06);
  }

  public costume(): void {
    const notes = [523, 659, 784, 1046, 1318];
    notes.forEach((n, i) => {
      this.playTone(n, n * 1.02, 0.08, 'square', 0.1, i * 0.05);
    });
  }

  /** Fanfare when a boss phase changes. */
  public bossPhase(phase: number): void {
    const root = phase === 3 ? 196 : phase === 2 ? 220 : 247;
    [0, 0.09, 0.18].forEach((t, i) => {
      this.playTone(root * (1 + i * 0.25), root, 0.16, 'sawtooth', 0.16, t);
    });
    this.playNoise(0.3, 300, 0.2);
  }

  /** Rising chime as a stomp chain builds. */
  public comboStep(n: number): void {
    const f = 440 * Math.pow(1.12, Math.min(8, n));
    this.playTone(f, f * 1.5, 0.09, 'square', 0.1);
  }

  /** Warning sting when the clock runs low. */
  public timeWarning(): void {
    this.playTone(880, 660, 0.12, 'square', 0.13);
    this.playTone(660, 880, 0.12, 'square', 0.1, 0.14);
  }

  /** Soft confirm used by menus. */
  public uiSelect(): void {
    this.playTone(660, 990, 0.06, 'square', 0.07);
  }

  public rewind(): void {
    const notes = [1046, 880, 740, 622, 523, 440];
    notes.forEach((n, i) => {
      this.playTone(n, n * 0.9, 0.07, 'triangle', 0.1, i * 0.04);
    });
  }

  public checkpoint(): void {
    const notes = [523.25, 659.25, 783.99, 1046.5];
    notes.forEach((n, i) => {
      this.playTone(n, n, 0.12, 'square', 0.12, i * 0.07);
      this.playTone(n * 0.5, n * 0.5, 0.1, 'triangle', 0.08, i * 0.07);
    });
  }

  public spinyDrop(): void {
    this.playTone(640, 320, 0.13, 'triangle', 0.09);
    this.playNoise(0.06, 2600, 0.07);
  }

  public skid(): void {
    this.playNoise(0.045, 2400, 0.06);
  }

  public fireball(): void {
    this.playTone(760, 240, 0.07, 'square', 0.1);
    this.playTone(420, 880, 0.06, 'triangle', 0.09, 0.04);
  }

  public powerUpSpawn(): void {
    const notes = [330, 392, 440, 494, 523, 587, 659];
    notes.forEach((n, i) => {
      this.playTone(n, n * 1.03, 0.05, 'square', 0.08, i * 0.035);
    });
  }

  public powerUpCollect(): void {
    const notes = [330, 392, 659, 523, 587, 784, 659, 1046];
    notes.forEach((n, i) => {
      this.playTone(n, n, 0.07, 'square', 0.11, i * 0.045);
    });
  }

  public oneUp(): void {
    const notes = [659.25, 783.99, 1318.5, 1046.5, 1174.66, 1567.98];
    notes.forEach((n, i) => {
      this.playTone(n, n, 0.095, 'square', 0.12, i * 0.075);
    });
  }

  public powerDown(): void {
    const notes = [587, 440, 330, 440, 293, 220];
    notes.forEach((n, i) => {
      this.playTone(n, n * 0.9, 0.07, 'sawtooth', 0.11, i * 0.055);
    });
  }

  public pow(): void {
    this.playNoise(0.32, 340, 0.28);
    this.playTone(150, 38, 0.34, 'sawtooth', 0.22);
    this.playTone(300, 75, 0.25, 'square', 0.14, 0.03);
  }

  public flagpole(): void {
    const notes = [261, 329, 392, 523, 659, 784, 1046];
    notes.forEach((n, i) => {
      this.playTone(n, n * 1.06, 0.09, 'square', 0.1, i * 0.055);
    });
  }

  public stageClear(): void {
    const melody = [
      { f: 392, d: 0.11, t: 0 },
      { f: 523.25, d: 0.11, t: 0.11 },
      { f: 659.25, d: 0.11, t: 0.22 },
      { f: 783.99, d: 0.22, t: 0.33 },
      { f: 659.25, d: 0.14, t: 0.56 },
      { f: 783.99, d: 0.42, t: 0.72 },
    ];
    melody.forEach((m) => {
      this.playTone(m.f, m.f, m.d, 'square', 0.12, m.t);
      this.playTone(m.f * 0.5, m.f * 0.5, m.d, 'triangle', 0.14, m.t);
    });
  }

  public firework(): void {
    this.playNoise(0.22, 1100, 0.2);
    this.playTone(620, 180, 0.18, 'triangle', 0.12);
  }

  public die(): void {
    this.stopMusic();
    const notes = [
      { f: 493.88, d: 0.1, t: 0.05 },
      { f: 698.46, d: 0.14, t: 0.2 },
      { f: 698.46, d: 0.12, t: 0.38 },
      { f: 698.46, d: 0.12, t: 0.52 },
      { f: 659.25, d: 0.14, t: 0.66 },
      { f: 587.33, d: 0.14, t: 0.82 },
      { f: 523.25, d: 0.32, t: 0.98 },
    ];
    notes.forEach((m) => {
      this.playTone(m.f, m.f, m.d, 'square', 0.13, m.t);
    });
  }

  public gameOver(): void {
    this.stopMusic();
    const notes = [
      { f: 523.25, d: 0.18, t: 0.05 },
      { f: 392.0, d: 0.18, t: 0.28 },
      { f: 329.63, d: 0.24, t: 0.52 },
      { f: 440.0, d: 0.18, t: 0.8 },
      { f: 493.88, d: 0.18, t: 0.98 },
      { f: 440.0, d: 0.18, t: 1.16 },
      { f: 415.3, d: 0.22, t: 1.34 },
      { f: 466.16, d: 0.22, t: 1.56 },
      { f: 392.0, d: 0.45, t: 1.78 },
    ];
    notes.forEach((m) => {
      this.playTone(m.f, m.f, m.d, 'triangle', 0.16, m.t);
      this.playTone(m.f * 0.5, m.f * 0.5, m.d, 'square', 0.07, m.t);
    });
  }

  public startMusic(theme: WorldTheme, starMode = false): void {
    this.currentTheme = theme;
    this.starMode = starMode;
    this.isPlayingBgm = true;
    this.clearBgmLoop();

    if (!this.soundEnabled || !this.musicEnabled) return;
    this.unlock();

    // Tempo follows the mood: calm drifts, danger drives, boss is relentless.
    let stepMs = starMode ? 115 : theme === 'castle' ? 130 : 155;
    if (!starMode) {
      if (this.mood === 'boss') stepMs = 108;
      else if (this.mood === 'hurry') stepMs = 96;
      else if (this.mood === 'tense') stepMs = Math.round(stepMs * 0.82);
      else if (this.mood === 'calm') stepMs = Math.round(stepMs * 1.18);
    }
    this.bgmTimer = window.setInterval(() => {
      this.tickBgm();
    }, stepMs);
  }

  /**
   * Re-scores the soundtrack from what is happening in the level.
   *
   * Rather than swapping tracks (which would stutter), the sequencer keeps
   * the same clock and switches which pattern + instrument it plays, so the
   * music shifts smoothly as danger rises.
   */
  public setMood(
    mood: 'normal' | 'tense' | 'boss' | 'hurry' | 'calm',
    intensity = 1
  ): void {
    this.moodIntensity = Math.max(0, Math.min(1, intensity));
    if (this.mood === mood) return;
    this.mood = mood;
    if (this.isPlayingBgm) this.startMusic(this.currentTheme, this.starMode);
  }

  public setStarMusic(starActive: boolean): void {
    if (this.starMode === starActive) return;
    this.starMode = starActive;
    if (this.isPlayingBgm) {
      this.startMusic(this.currentTheme, this.starMode);
    }
  }

  public stopMusic(): void {
    this.isPlayingBgm = false;
    this.clearBgmLoop();
  }

  private clearBgmLoop(): void {
    if (this.bgmTimer !== null) {
      clearInterval(this.bgmTimer);
      this.bgmTimer = null;
    }
  }

  private tickBgm(): void {
    if (!this.soundEnabled || !this.musicEnabled || !this.ctx) return;
    if (this.ctx.state !== 'running') return;

    const overworldLead = [
      659, 659, 0, 659, 0, 523, 659, 0,
      784, 0, 0, 0, 392, 0, 0, 0,
      523, 0, 0, 392, 0, 0, 330, 0,
      0, 440, 0, 494, 0, 466, 440, 0,
    ];
    const overworldBass = [
      196, 0, 196, 0, 131, 0, 196, 0,
      247, 0, 0, 0, 196, 0, 0, 0,
      131, 0, 0, 98, 0, 0, 82, 0,
      0, 110, 0, 123, 0, 116, 110, 0,
    ];

    const undergroundLead = [
      261, 523, 220, 440, 233, 466, 0, 0,
      261, 523, 220, 440, 233, 466, 0, 0,
      174, 349, 146, 293, 155, 311, 0, 0,
      196, 0, 220, 0, 246, 0, 261, 0,
    ];

    const castleLead = [
      440, 415, 440, 392, 440, 466, 440, 392,
      494, 466, 494, 440, 494, 523, 494, 440,
      523, 494, 523, 466, 523, 587, 523, 466,
      659, 0, 587, 0, 523, 0, 494, 0,
    ];

    const starLead = [
      523, 523, 523, 0, 523, 0, 523, 587,
      659, 0, 523, 0, 440, 0, 392, 0,
      494, 494, 494, 0, 494, 0, 494, 523,
      587, 0, 494, 0, 392, 0, 349, 0,
    ];

    const idx = this.bgmStep % 32;
    this.bgmStep++;

    // --- adaptive layers -------------------------------------------------
    if (!this.starMode && this.mood !== 'normal') {
      const bossLead = [
        220, 0, 233, 0, 220, 0, 185, 0,
        196, 0, 208, 0, 196, 0, 165, 0,
        147, 147, 0, 147, 0, 165, 185, 0,
        220, 0, 233, 247, 262, 0, 233, 0,
      ];
      const tenseLead = [
        330, 0, 0, 392, 0, 0, 330, 0,
        294, 0, 0, 349, 0, 0, 294, 0,
        262, 0, 0, 311, 0, 0, 262, 0,
        247, 0, 262, 0, 294, 0, 311, 0,
      ];
      const hurryLead = [
        523, 523, 659, 659, 784, 784, 659, 523,
        587, 587, 698, 698, 880, 880, 698, 587,
        523, 659, 784, 1046, 784, 659, 523, 440,
        494, 587, 740, 988, 740, 587, 494, 392,
      ];
      const calmLead = [
        392, 0, 0, 0, 440, 0, 0, 0,
        494, 0, 0, 0, 440, 0, 0, 0,
        392, 0, 0, 0, 349, 0, 0, 0,
        330, 0, 0, 0, 294, 0, 0, 0,
      ];

      const idx2 = this.bgmStep % 32;
      const vol = 0.03 + this.moodIntensity * 0.045;

      if (this.mood === 'boss') {
        const f = bossLead[idx2];
        if (f > 0) {
          this.playTone(f, f, 0.1, 'sawtooth', vol);
          this.playTone(f * 0.5, f * 0.5, 0.14, 'triangle', vol * 1.3);
        }
        // Driving kick keeps the pressure on.
        if (idx2 % 4 === 0) this.playNoise(0.07, 180, 0.12);
        if (idx2 % 8 === 4) this.playNoise(0.05, 2600, 0.05);
        return;
      }
      if (this.mood === 'hurry') {
        const f = hurryLead[idx2];
        if (f > 0) this.playTone(f, f, 0.07, 'square', vol);
        if (idx2 % 2 === 0) this.playTone(131, 131, 0.06, 'triangle', vol);
        return;
      }
      if (this.mood === 'tense') {
        const f = tenseLead[idx2];
        if (f > 0) this.playTone(f, f, 0.12, 'triangle', vol);
        if (idx2 % 8 === 0) this.playTone(98, 98, 0.2, 'sawtooth', vol * 0.9);
        return;
      }
      if (this.mood === 'calm') {
        const f = calmLead[idx2];
        if (f > 0) {
          this.playTone(f, f, 0.26, 'sine', vol * 1.2);
          this.playTone(f * 2, f * 2, 0.18, 'sine', vol * 0.4);
        }
        return;
      }
    }

    if (this.starMode) {
      const f = starLead[idx];
      if (f > 0) this.playTone(f, f, 0.085, 'square', 0.045);
      if (idx % 2 === 0) {
        this.playTone(f > 0 ? f * 0.5 : 196, 196, 0.07, 'triangle', 0.05);
      }
      return;
    }

    if (this.currentTheme === 'underground') {
      const f = undergroundLead[idx];
      if (f > 0) {
        this.playTone(f, f, 0.11, 'triangle', 0.07);
        this.playTone(f * 0.5, f * 0.5, 0.09, 'square', 0.03);
      }
      return;
    }

    if (this.currentTheme === 'castle') {
      const f = castleLead[idx];
      if (f > 0) {
        this.playTone(f, f, 0.09, 'sawtooth', 0.038);
      }
      if (idx % 4 === 0) {
        this.playTone(110, 110, 0.18, 'triangle', 0.075);
      }
      return;
    }

    const lead = overworldLead[idx];
    const bass = overworldBass[idx];
    if (lead > 0) {
      this.playTone(lead, lead, 0.1, 'square', 0.042);
    }
    if (bass > 0) {
      this.playTone(bass, bass, 0.12, 'triangle', 0.065);
    }
  }
}

export const sound = new ChiptuneSoundEngine();
