import { CharacterId, CHARACTERS, PowerState, WorldTheme } from './types';
import type { BiomeDef } from './biomes';

type Palette = Record<string, string>;

function makePixelCanvas(
  rows: string[],
  palette: Palette,
  scale = 2,
  flipX = false
): HTMLCanvasElement {
  const h = rows.length;
  const w = rows[0]?.length || 16;
  const canvas = document.createElement('canvas');
  canvas.width = w * scale;
  canvas.height = h * scale;
  const ctx = canvas.getContext('2d')!;
  ctx.imageSmoothingEnabled = false;

  for (let y = 0; y < h; y++) {
    const row = rows[y];
    for (let x = 0; x < w; x++) {
      const ch = row[x];
      if (!ch || ch === '.') continue;
      const color = palette[ch];
      if (!color) continue;
      ctx.fillStyle = color;
      const drawX = flipX ? (w - 1 - x) * scale : x * scale;
      ctx.fillRect(drawX, y * scale, scale, scale);
    }
  }
  return canvas;
}

const MARIO_PALETTES: Record<string, Palette> = {
  normal: {
    R: '#ef2b2d', // Cap / shirt red
    D: '#a61419', // Dark red shade
    B: '#2357e6', // Royal blue overalls
    N: '#14318a', // Dark blue shade
    S: '#ffcc99', // Skin peach
    T: '#e09b63', // Skin shadow
    H: '#5c2c16', // Hair / mustache / boots
    K: '#14121d', // Outline / eye
    Y: '#ffd93d', // Gold button
    W: '#ffffff', // Glove white
  },
  fire: {
    R: '#fff7eb', // White cap / tunic
    D: '#d7cce0', // Cool shadow
    B: '#e82929', // Fiery red overalls
    N: '#991117', // Deep crimson shade
    S: '#ffcc99',
    T: '#e09b63',
    H: '#6b3218',
    K: '#14121d',
    Y: '#ffd93d',
    W: '#ffffff',
  },
  star0: {
    R: '#ffe94d',
    D: '#ff9d1c',
    B: '#26f7b2',
    N: '#0aa37f',
    S: '#fffbe0',
    T: '#ffd275',
    H: '#ff3b7f',
    K: '#14121d',
    Y: '#ffffff',
    W: '#ffffff',
  },
  star1: {
    R: '#4df3ff',
    D: '#1d9bf0',
    B: '#ff4dd8',
    N: '#ad1896',
    S: '#fff6ff',
    T: '#f5b8ff',
    H: '#ffe63b',
    K: '#14121d',
    Y: '#ffffff',
    W: '#ffffff',
  },
};

// 16x16 Small Mario grids
const SMALL_IDLE = [
  '....RRRRRR......',
  '...RRRRRRRRRR...',
  '...HHHSSKSH.....',
  '..HSHSSSKSKSS...',
  '..HSHHSSSSKSSS..',
  '..HHSSSSHHHHH...',
  '....SSSSSSS.....',
  '...RRBRRRR......',
  '..RRRBRRBRRR....',
  '.RRRRBBBBBRRRR..',
  '.WW.BYBBBYB.WW..',
  '.WW.BBBBBBB.WW..',
  '....BBB.BBB.....',
  '...HHHH.HHHH....',
  '..HHHHH.HHHHH...',
  '................',
];

const SMALL_RUN1 = [
  '....RRRRRR......',
  '...RRRRRRRRRR...',
  '...HHHSSKSH.....',
  '..HSHSSSKSKSS...',
  '..HSHHSSSSKSSS..',
  '..HHSSSSHHHHH...',
  '....SSSSSSS.....',
  '...RRRRBBRR.....',
  '..WW.BBBBBRWW...',
  '.WW..BYBBBB.WW..',
  '....BBBBBBB.....',
  '...BBBB.BBBB....',
  '..HHHH...HHHH...',
  '.HHHHH....HHH...',
  '................',
  '................',
];

const SMALL_RUN2 = [
  '................',
  '....RRRRRR......',
  '...RRRRRRRRRR...',
  '...HHHSSKSH.....',
  '..HSHSSSKSKSS...',
  '..HSHHSSSSKSSS..',
  '..HHSSSSHHHHH...',
  '....SSSSSSS.....',
  '...RRRRBRRR.....',
  '...WWBBBBBBWW...',
  '...WWBYBBYBWW...',
  '....BBBBBBB.....',
  '....BBBBBBB.....',
  '....HHHHHHH.....',
  '...HHHHH........',
  '................',
];

const SMALL_JUMP = [
  '...........WWW..',
  '....RRRRRR.WWW..',
  '...RRRRRRRRRR...',
  '...HHHSSKSHRR...',
  '..HSHSSSKSKSSR..',
  '..HSHHSSSSKSSS..',
  '..HHSSSSHHHHH...',
  '....SSSSSSSR....',
  '..RRRRBRRRR.....',
  '.WW.RRBBBBBR....',
  'WW..BYBBBBBB....',
  '....BBBBBBBHHH..',
  '...BBBBBBBBHHH..',
  '..HHHH..........',
  '.HHHH...........',
  '................',
];

const SMALL_SKID = [
  '....RRRRRR......',
  '...RRRRRRRRRR...',
  '...HSHKSSHHH....',
  '..SSKSKSSSHSH...',
  '..SSSKSSSSHHSH..',
  '...HHHHHSSSSHH..',
  '.....SSSSSSS....',
  '....RRRRBBRR....',
  '...WWBBBBBRR....',
  '...WWBYBBBBB....',
  '....BBBBBBB.....',
  '...BBBB.BBB.....',
  '..HHHH..HHHH....',
  '........HHHHH...',
  '................',
  '................',
];

const SMALL_DEAD = [
  '....RRRRRR......',
  '...RRRRRRRRRR...',
  '..HHHHSSSSHHHH..',
  '..HSSKSSSSKSSH..',
  '..HSSKSSSSKSSH..',
  '...SSSSSSSSSS...',
  '....SHHHHHHS....',
  '..WW.BBBBBB.WW..',
  '.WW.RBYBBYBR.WW.',
  '....RBBBBBBBR...',
  '....BBBBBBBB....',
  '...BBBB..BBBB...',
  '..HHHH....HHHH..',
  '.HHHHH....HHHHH.',
  '................',
  '................',
];

// 16x26 Super / Fire Mario grids
const BIG_IDLE = [
  '....RRRRRRR.....',
  '...RRRRRRRRRR...',
  '...RRRRRRRRRRR..',
  '...HHHSSSKSH....',
  '..HSHSSSSKSKSS..',
  '..HSHHSSSSSKSSS.',
  '..HSHHSSSSSKSSS.',
  '..HHHSSSSHHHHH..',
  '....SSSSSSSS....',
  '....SSTTTTSS....',
  '...RRRRBRRRRR...',
  '..RRRRRBRRBRRR..',
  '.RRRRRRBBBBBRRR.',
  '.WW.RRBYBBBYBRWW',
  '.WWW.RBBBBBBBRWW',
  '.WWW.BBBBBBBBBWW',
  '.....BBBBBBBBB..',
  '....BBBBBBBBBB..',
  '....BBBB..BBBB..',
  '...NNNN....NNNN.',
  '...BBBB....BBBB.',
  '...HHHH....HHHH.',
  '..HHHHH....HHHHH',
  '..HHHHHH..HHHHHH',
  '................',
  '................',
];

const BIG_RUN1 = [
  '....RRRRRRR.....',
  '...RRRRRRRRRR...',
  '...RRRRRRRRRRR..',
  '...HHHSSSKSH....',
  '..HSHSSSSKSKSS..',
  '..HSHHSSSSSKSSS.',
  '..HHHSSSSHHHHH..',
  '....SSSSSSSS....',
  '...RRRRBBRRRR...',
  '..WWWRRBBBRRWW..',
  '.WWW.RBYBBBBRWW.',
  '.....BBBBBBBBB..',
  '....BBBBBBBBBB..',
  '....BBBBBBBBBB..',
  '...BBBB....BBBB.',
  '..NNNN......BBBB',
  '.HHHHH......HHHH',
  '.HHHHHH.....HHHH',
  '............HHH.',
  '................',
  '................',
  '................',
  '................',
  '................',
  '................',
  '................',
];

const BIG_RUN2 = [
  '................',
  '....RRRRRRR.....',
  '...RRRRRRRRRR...',
  '...RRRRRRRRRRR..',
  '...HHHSSSKSH....',
  '..HSHSSSSKSKSS..',
  '..HSHHSSSSSKSSS.',
  '..HHHSSSSHHHHH..',
  '....SSSSSSSS....',
  '...RRRRRBRRRR...',
  '...WWWRBBBBWW...',
  '...WWWBYBBYBWW..',
  '....BBBBBBBBBB..',
  '....BBBBBBBBBB..',
  '....BBBBBBBBBB..',
  '.....BBBBBBBB...',
  '.....NNNNBBBB...',
  '....HHHHHH.HHH..',
  '...HHHHHHH..HHH.',
  '................',
  '................',
  '................',
  '................',
  '................',
  '................',
  '................',
];

const BIG_JUMP = [
  '...........WWW..',
  '....RRRRRRRWWWW.',
  '...RRRRRRRRRRWW.',
  '...RRRRRRRRRRR..',
  '...HHHSSSKSHRR..',
  '..HSHSSSSKSKSSR.',
  '..HSHHSSSSSKSSSR',
  '..HHHSSSSHHHHHR.',
  '....SSSSSSSSRR..',
  '..RRRRRBRRRRR...',
  '.WWWRRRBBBBBR...',
  'WWW.RRBYBBBBBB..',
  '....RBBBBBBBBB..',
  '....BBBBBBBBBB..',
  '...BBBBBBBBBBB..',
  '...BBBB...BBBBHH',
  '..NNNN.....BBBHH',
  '.HHHHH......HHH.',
  '.HHHH...........',
  '................',
  '................',
  '................',
  '................',
  '................',
  '................',
  '................',
];

const BIG_CROUCH = [
  '................',
  '................',
  '................',
  '................',
  '................',
  '....RRRRRRR.....',
  '...RRRRRRRRRR...',
  '...RRRRRRRRRRR..',
  '...HHHSSSKSH....',
  '..HSHSSSSKSKSS..',
  '..HSHHSSSSSKSSS.',
  '..HHHSSSSHHHHH..',
  '....SSSSSSSS....',
  '..WWWRBBBBBRWW..',
  '.WWW.BYBBBBYBWW.',
  '.....BBBBBBBB...',
  '....BBBBBBBBBB..',
  '...BBBBBBBBBBBB.',
  '...HHHH....HHHH.',
  '..HHHHHH..HHHHHH',
  '................',
  '................',
  '................',
  '................',
  '................',
  '................',
];

// Correct BIG_RUN1 & BIG_RUN2 & BIG_JUMP boot height to align cleanly with bottom of 26-row sprite!
function alignBottomRows(grid: string[], totalRows = 26): string[] {
  const empty = '................';
  const nonEmpty = grid.filter((r) => r !== empty);
  const padTop = Math.max(0, totalRows - nonEmpty.length);
  const result: string[] = [];
  for (let i = 0; i < padTop; i++) result.push(empty);
  for (const r of nonEmpty) result.push(r);
  while (result.length < totalRows) result.push(empty);
  return result.slice(0, totalRows);
}

// Enemies (16x16)
const GOOMBA_PAL: Palette = {
  M: '#c84c0c',
  D: '#7c2905',
  S: '#fbd6a2',
  W: '#ffffff',
  K: '#14121d',
};

const GOOMBA_1 = [
  '......MMMM......',
  '....MMMMMMMM....',
  '...MMMMMMMMMM...',
  '..MMMMMMMMMMMM..',
  '.MMMWKMMMMKWMMM.',
  '.MMWWKMMMMKWWMM.',
  'MMMWWKMMMMKWWMMM',
  'MMMMWWKKKKWWMMMM',
  'MMMMMMMMMMMMMMMM',
  '.DDDDSSSSSSSSDD.',
  '...SSSSSSSSSS...',
  '...SSSSSSSSSS...',
  '..KKKKK...KKKK..',
  '.KKKKKK...KKKKK.',
  '.KKKKKK....KKKK.',
  '................',
];

const GOOMBA_2 = [
  '......MMMM......',
  '....MMMMMMMM....',
  '...MMMMMMMMMM...',
  '..MMMMMMMMMMMM..',
  '.MMMWKMMMMKWMMM.',
  '.MMWWKMMMMKWWMM.',
  'MMMWWKMMMMKWWMMM',
  'MMMMWWKKKKWWMMMM',
  'MMMMMMMMMMMMMMMM',
  '.DDDDSSSSSSSSDD.',
  '...SSSSSSSSSS...',
  '...SSSSSSSSSS...',
  '....KKKK...KKKKK',
  '...KKKKK...KKKKK',
  '...KKKK....KKKK.',
  '................',
];

const GOOMBA_SQUISH = [
  '................',
  '................',
  '................',
  '................',
  '................',
  '................',
  '................',
  '....MMMMMMMM....',
  '..MMMMMMMMMMMM..',
  '.MMWWKKKKKKWWMM.',
  'MMMMMMMMMMMMMMMM',
  '.DDDDSSSSSSSSDD.',
  '..KKKKK..KKKKK..',
  '................',
  '................',
  '................',
];

// Koopa (16x22)
const KOOPA_WALK_1 = [
  '.........GGGG...',
  '........GGWWKG..',
  '........GGWWKG..',
  '........YYYYYY..',
  '.......YYYYYYYY.',
  '....GGGGGGGGYY..',
  '...GGGGLLLGGG...',
  '..GGGLLLLLLGGG..',
  '.GGGLLLLLLLLGGG.',
  '.GGGLLLLLLLLGGG.',
  '.WWWWGGGGGGGWWW.',
  '..YYYYWWWWYYYY..',
  '...YYYY..YYYY...',
  '..YYYY....YYYY..',
  '.KKKK......KKKK.',
  '................',
];

const KOOPA_WALK_2 = [
  '................',
  '.........GGGG...',
  '........GGWWKG..',
  '........GGWWKG..',
  '........YYYYYY..',
  '.......YYYYYYYY.',
  '....GGGGGGGGYY..',
  '...GGGGLLLGGG...',
  '..GGGLLLLLLGGG..',
  '.GGGLLLLLLLLGGG.',
  '.WWWWGGGGGGGWWW.',
  '..YYYYWWWWYYYY..',
  '....YYYY.YYYY...',
  '...KKKK...KKKK..',
  '................',
  '................',
];

const KOOPA_SHELL_1 = [
  '................',
  '................',
  '....GGGGGGGG....',
  '..GGGGLLLLGGGG..',
  '.GGGLLLLLLLLGGG.',
  '.GGLLLLGGLLLLGG.',
  'GGGLLLGGGGLLLGGG',
  'GGGLLLGGGGLLLGGG',
  'GGGGGGGGGGGGGGGG',
  '.WWWWWWWWWWWWWW.',
  '..YYYYWWWWYYYY..',
  '...KKKKKKKKKK...',
  '................',
  '................',
  '................',
  '................',
];

const KOOPA_SHELL_2 = [
  '................',
  '................',
  '....GGGGGGGG....',
  '..GGLLLLLLLLGG..',
  '.GGLLGGGGGGLLGG.',
  '.GGLGGGGGGGGLGG.',
  'GGGLLLGGGGLLLGGG',
  'GGGGLLLLLLLLGGGG',
  'GGGGGGGGGGGGGGGG',
  '.WWWWWWWWWWWWWW.',
  '..YYYYYYYYYYYY..',
  '...KKKKKKKKKK...',
  '................',
  '................',
  '................',
  '................',
];

const PIRANHA_OPEN = [
  '..RRRR....RRRR..',
  '.RRWWRR..RRWWRR.',
  'RRWWWWR..RWWWWRR',
  'RRRRRRWWWWWRRRRR',
  'RRRRRWW....WRRRR',
  '.RRRRW......WRR.',
  '..RRRRWWWWWWWR..',
  '....GGGGGGGG....',
  '.....GGGGGG.....',
  '..GG..GGGG..GG..',
  '.GGGG.GGGG.GGGG.',
  '..GGG.GGGG.GGG..',
  '......GGGG......',
  '......GGGG......',
  '......GGGG......',
  '......GGGG......',
];

const PIRANHA_CLOSED = [
  '....RRRRRRRR....',
  '..RRWWRRRRRRRR..',
  '.RRWWWWRRRRWWRR.',
  '.RRRRRRRRRWWWWR.',
  'RRRRWWWWWWWRRRRR',
  '.RRRRRRRRRRRRRR.',
  '..RRRRRRRRRRRR..',
  '....GGGGGGGG....',
  '.....GGGGGG.....',
  '..GG..GGGG..GG..',
  '.GGGG.GGGG.GGGG.',
  '..GGG.GGGG.GGG..',
  '......GGGG......',
  '......GGGG......',
  '......GGGG......',
  '......GGGG......',
];

// Items (16x16)
const MUSHROOM_GRID = [
  '.....KKKKKK.....',
  '...KKRRRRRRKK...',
  '..KRRWWWRRRRWWK.',
  '.KRWWWWWRRRWWWRK',
  '.KRWWWWWRRRWWWRK',
  'KRRRWWWRRRRRRRRK',
  'KRRRRRRRRWWWRRRK',
  'KWWWRRRRRWWWRRRK',
  'KWWWRRRRRRRRRRRK',
  '.KKKKKKKKKKKKKK.',
  '..KSSSSSSSSSSK..',
  '..KSSKSSSSKSSK..',
  '..KSSKSSSSKSSK..',
  '...KSSSSSSSSK...',
  '....KKKKKKKK....',
  '................',
];

const FLOWER_GRID = [
  '....KKKKKKKK....',
  '..KKOOOOOOOOOO..',
  '.KOOYYYYYYYYOOK.',
  'KOOYYWWWWWWYYOOK',
  'KOOYWWKKKKWWYOOK',
  'KOOYWWKWWKWWYOOK',
  'KOOYYWWWWWWYYOOK',
  '.KOOYYYYYYYYOOK.',
  '..KKOOOOOOOOOO..',
  '....KKGGGGKK....',
  '..KK..GGGG..KK..',
  '.KGGK.GGGG.KGGK.',
  '.KGGG.GGGG.GGGK.',
  '..KK..GGGG..KK..',
  '......KKKK......',
  '................',
];

const STAR_GRID = [
  '.......KK.......',
  '......KYYK......',
  '......KYYK......',
  '.....KYYYYK.....',
  'KKKKKKYYYYKKKKKK',
  'KYYYYYYYYYYYYYYK',
  '.KYYYYKYYKYYYYK.',
  '..KYYYKYYKYYYK..',
  '...KYYYYYYYYK...',
  '...KYYYYYYYYK...',
  '..KYYYYYYYYYYK..',
  '..KYYYYKKYYYYK..',
  '.KYYYYK..KYYYYK.',
  '.KYYKK....KKYYK.',
  'KKKK........KKKK',
  '................',
];

const COIN_1 = [
  '.....KKKKKK.....',
  '...KKYYYYYYKK...',
  '..KYYWWWWYYYYK..',
  '.KYYWWKKYYOYYYK.',
  '.KYYWKYYYYOYYYK.',
  'KYYYWKYYYYOYYYYK',
  'KYYYWKYYYYOYYYYK',
  'KYYYWKYYYYOYYYYK',
  'KYYYWKYYYYOYYYYK',
  'KYYYWKYYYYOYYYYK',
  '.KYYWKYYYYOYYYK.',
  '.KYYWWOOOOOYYYK.',
  '..KYYYYYYYYYYK..',
  '...KKOOOOOOKK...',
  '.....KKKKKK.....',
  '................',
];

const COIN_2 = [
  '......KKKK......',
  '....KKYYYYKK....',
  '...KYWWYYYYOK...',
  '...KYWKYYYYOK...',
  '..KYYWKYYYYOYK..',
  '..KYYWKYYYYOYK..',
  '..KYYWKYYYYOYK..',
  '..KYYWKYYYYOYK..',
  '..KYYWKYYYYOYK..',
  '..KYYWKYYYYOYK..',
  '...KYWKYYYYOK...',
  '...KYWOOOOYOK...',
  '....KKOOOOOK....',
  '......KKKK......',
  '................',
  '................',
];

const COIN_3 = [
  '.......KK.......',
  '......KYYK......',
  '......KWWK......',
  '......KYYK......',
  '......KYYK......',
  '......KYYK......',
  '......KYYK......',
  '......KYYK......',
  '......KYYK......',
  '......KYYK......',
  '......KOOK......',
  '......KOOK......',
  '......KYYK......',
  '.......KK.......',
  '................',
  '................',
];

// Hammer Bro medium-difficulty NPC (16x16)
const HAMMER_BRO_1 = [
  '.....HHHHHH.....',
  '....HHHHHHHH....',
  '...HHHHHHHHHH...',
  '...HHKKHHKKHH...',
  '...HHHHHHHHHH...',
  '....SSSSSSSS....',
  '....SSKSSKSS....',
  '....SSSSSSSS....',
  '...GGGGGGGGGG...',
  '..GGGGYYYYGGGG..',
  '.GGGGYWWWWYGGGG.',
  '.GGGGYYYYYYGGGG.',
  '..GGGGGGGGGGGG..',
  '...GGG.SS.GGG...',
  '..SSSS.SS.SSSS..',
  '...HHH....HHH...',
];

const HAMMER_BRO_2 = [
  '.....HHHHHH.....',
  '....HHHHHHHH....',
  '...HHHHHHHHHH...',
  '...HHKKHHKKHH...',
  '...HHHHHHHHHH...',
  '....SSSSSSSS....',
  '....SSKSSKSS....',
  '....SSSSSSSS....',
  '...GGGGGGGGGG...',
  '..GGGGYYYYGGGG..',
  '.GGGGYWWWWYGGGG.',
  '.GGGGYYYYYYGGGG.',
  '..GGGGGGGGGGGG..',
  '...GGG.SS.GGG...',
  '...SSS.SS.SSS...',
  '..HHHH....HHHH..',
];

// Spiny — spiked shell, stomping it hurts Mario (16x16)
const SPINY_1 = [
  '..K..K....K..K..',
  '.KWK.KWK.KWK.KW.',
  '.KOK.KOK.KOK.KO.',
  '..KOOKOOKOOKOK..',
  '.KOOOOOOOOOOOOK.',
  'KOORRRRRRRRRROOK',
  'KORRRRRRRRRRRROK',
  'KORRRRRRRRRRRROK',
  'KKOORRRRRRRROOKK',
  '.KKOOOOOOOOOOKK.',
  '..KYYKKWWKKYYK..',
  '.KYYKKKKKKKKYYK.',
  '.KYKKWWKKWWKKYK.',
  '..KK.KK..KK.KK..',
  '.KKK.......KKK..',
  '................',
];

const SPINY_2 = [
  '..K..K....K..K..',
  '.KWK.KWK.KWK.KW.',
  '.KOK.KOK.KOK.KO.',
  '..KOOKOOKOOKOK..',
  '.KOOOOOOOOOOOOK.',
  'KOORRRRRRRRRROOK',
  'KORRRRRRRRRRRROK',
  'KORRRRRRRRRRRROK',
  'KKOORRRRRRRROOKK',
  '.KKOOOOOOOOOOKK.',
  '..KYYKKWWKKYYK..',
  '.KYYKKKKKKKKYYK.',
  '..KYKKWWKKWWKYK.',
  '...KK.KK.KK.KK..',
  '..KKK.......KKK.',
  '................',
];

// Dry Bones — collapses when stomped, then rebuilds itself (16x16)
const DRY_BONES_1 = [
  '.....WWWWWW.....',
  '....WWWWWWWW....',
  '...WWKKWWKKWW...',
  '...WWKKWWKKWW...',
  '....WWWWWWWW....',
  '.....WKKKKW.....',
  '......WWWW......',
  '...WWWWWWWWWW...',
  '..WW.WWWWWW.WW..',
  '.WW..WKWWKW..WW.',
  '.W...WWWWWW...W.',
  '.....WWWWWW.....',
  '....WWW..WWW....',
  '...WWW....WWW...',
  '..WWW......WWW..',
  '................',
];

const DRY_BONES_2 = [
  '.....WWWWWW.....',
  '....WWWWWWWW....',
  '...WWKKWWKKWW...',
  '...WWKKWWKKWW...',
  '....WWWWWWWW....',
  '.....WKKKKW.....',
  '......WWWW......',
  '...WWWWWWWWWW...',
  '..WW.WWWWWW.WW..',
  '.WW..WKWWKW..WW.',
  '.W...WWWWWW...W.',
  '.....WWWWWW.....',
  '.....WWW.WWW....',
  '....WWW...WWW...',
  '...WWW.....WWW..',
  '................',
];

const DRY_BONES_DOWN = [
  '................',
  '................',
  '................',
  '................',
  '................',
  '................',
  '................',
  '................',
  '..WW..WWWW..WW..',
  '.WWKW.WKKW.WKWW.',
  '.WWWW.WWWW.WWWW.',
  '..WW...WW...WW..',
  '.WWWWWWWWWWWWWW.',
  '..WWW.WWWW.WWW..',
  '................',
  '................',
];

// Lakitu — flies on a cloud and rains Spinies (16x18)
const LAKITU_1 = [
  '......GGGG......',
  '....GGGGGGGG....',
  '...GGKKGGKKGG...',
  '...GGKWGGKWGG...',
  '...GGGGGGGGGG...',
  '....GGGWWGGG....',
  '.....GGGGGG.....',
  '...YYYYYYYYYY...',
  '..YYYYYYYYYYYY..',
  '...GG......GG...',
  '..WWWWWWWWWWWW..',
  '.WWWWWWWWWWWWWW.',
  'WWWWWWWWWWWWWWWW',
  'WWWKKWWWWWWKKWWW',
  'WWWWWWWWWWWWWWWW',
  '.WW.WWW..WWW.WW.',
  '..W..WW...WW..W.',
  '................',
];

const LAKITU_2 = [
  '......GGGG......',
  '....GGGGGGGG....',
  '...GGKKGGKKGG...',
  '...GGWKGGWKGG...',
  '...GGGGGGGGGG...',
  '....GGGWWGGG....',
  '.....GGGGGG.....',
  '...YYYYYYYYYY...',
  '..YYYYYYYYYYYY..',
  '...GG......GG...',
  '..WWWWWWWWWWWW..',
  '.WWWWWWWWWWWWWW.',
  'WWWWWWWWWWWWWWWW',
  'WWWKKWWWWWWKKWWW',
  'WWWWWWWWWWWWWWWW',
  '..WW.WWW..WWW.W.',
  '...W..WW...WW...',
  '................',
];

// Bullet Bill — screams across the map, stomp it or dodge (16x16)
const BULLET_BILL = [
  '....KKKKKKKK....',
  '..KKKKKKKKKKKK..',
  '.KKKKKKKKKKKKKK.',
  'KKKKKKKKKKKKKKKK',
  'KKWWKKKKKKKKKKKK',
  'KWWWWKKKKKKKKKKK',
  'KWWWWKKKKKKKKKKK',
  'KWWKKWWWKKKKKKKK',
  'KWWKKWWWKKKKKKKK',
  'KWWWWKKKKKKKKKKK',
  'KWWWWKKKKKKKKKKK',
  'KKWWKKKKKKKKKKKK',
  'KKKKKKKKKKKKKKKK',
  '.KKKKKKKKKKKKKK.',
  '..KKKKKKKKKKKK..',
  '....KKKKKKKK....',
];

// Armoured Goomba — bulky, riveted helmet (16x16)
const ARMORED_GOOMBA = [
  '.....KKKKKK.....',
  '...KKMMMMMMKK...',
  '..KMMLLLLLLMMK..',
  '.KMMLLMMMMLLMMK.',
  '.KMLLMMMMMMLLMK.',
  'KMMLMMWWWWMMLMMK',
  'KMMMMWWKKWWMMMMK',
  'KMMMMWKKKKWMMMMK',
  'KMMMMMMMMMMMMMMK',
  '.KMMMMMMMMMMMMK.',
  '..KKSSSSSSSSKK..',
  '...SSSSSSSSSS...',
  '..KKKKK..KKKKK..',
  '.KKKKKK..KKKKKK.',
  '.KKKK......KKKK.',
  '................',
];

const ARMORED_GOOMBA_2 = [
  '.....KKKKKK.....',
  '...KKMMMMMMKK...',
  '..KMMLLLLLLMMK..',
  '.KMMLLMMMMLLMMK.',
  '.KMLLMMMMMMLLMK.',
  'KMMLMMWWWWMMLMMK',
  'KMMMMWWKKWWMMMMK',
  'KMMMMWKKKKWMMMMK',
  'KMMMMMMMMMMMMMMK',
  '.KMMMMMMMMMMMMK.',
  '..KKSSSSSSSSKK..',
  '...SSSSSSSSSS...',
  '....KKKK..KKKKK.',
  '...KKKKK..KKKKK.',
  '...KKKK....KKKK.',
  '................',
];

export interface SpriteBank {
  getMario: (
    power: PowerState,
    pose: string,
    facing: 1 | -1,
    starTick: number,
    character?: CharacterId
  ) => HTMLCanvasElement;
  goomba: {
    walk1: HTMLCanvasElement;
    walk2: HTMLCanvasElement;
    squish: HTMLCanvasElement;
  };
  koopaGreen: {
    walk1L: HTMLCanvasElement;
    walk2L: HTMLCanvasElement;
    walk1R: HTMLCanvasElement;
    walk2R: HTMLCanvasElement;
    shell1: HTMLCanvasElement;
    shell2: HTMLCanvasElement;
  };
  koopaRed: {
    walk1L: HTMLCanvasElement;
    walk2L: HTMLCanvasElement;
    walk1R: HTMLCanvasElement;
    walk2R: HTMLCanvasElement;
    shell1: HTMLCanvasElement;
    shell2: HTMLCanvasElement;
  };
  buzzy: {
    walk1L: HTMLCanvasElement;
    walk2L: HTMLCanvasElement;
    walk1R: HTMLCanvasElement;
    walk2R: HTMLCanvasElement;
    shell1: HTMLCanvasElement;
    shell2: HTMLCanvasElement;
  };
  piranha: {
    open: HTMLCanvasElement;
    closed: HTMLCanvasElement;
  };
  hammerBro: {
    walk1L: HTMLCanvasElement;
    walk2L: HTMLCanvasElement;
    walk1R: HTMLCanvasElement;
    walk2R: HTMLCanvasElement;
  };
  spiny: {
    walk1: HTMLCanvasElement;
    walk2: HTMLCanvasElement;
  };
  fireBro: {
    walk1L: HTMLCanvasElement;
    walk2L: HTMLCanvasElement;
    walk1R: HTMLCanvasElement;
    walk2R: HTMLCanvasElement;
  };
  sniperBro: {
    walk1L: HTMLCanvasElement;
    walk2L: HTMLCanvasElement;
    walk1R: HTMLCanvasElement;
    walk2R: HTMLCanvasElement;
  };
  armoredGoomba: {
    walk1: HTMLCanvasElement;
    walk2: HTMLCanvasElement;
  };
  dryBones: {
    walk1L: HTMLCanvasElement;
    walk2L: HTMLCanvasElement;
    walk1R: HTMLCanvasElement;
    walk2R: HTMLCanvasElement;
    down: HTMLCanvasElement;
  };
  lakitu: {
    frame1L: HTMLCanvasElement;
    frame2L: HTMLCanvasElement;
    frame1R: HTMLCanvasElement;
    frame2R: HTMLCanvasElement;
  };
  bulletBill: {
    left: HTMLCanvasElement;
    right: HTMLCanvasElement;
  };
  items: {
    mushroom: HTMLCanvasElement;
    oneUp: HTMLCanvasElement;
    flower1: HTMLCanvasElement;
    flower2: HTMLCanvasElement;
    star1: HTMLCanvasElement;
    star2: HTMLCanvasElement;
    coins: HTMLCanvasElement[];
  };
  tiles: Record<WorldTheme, {
    ground: HTMLCanvasElement;
    brick: HTMLCanvasElement;
    solid: HTMLCanvasElement;
    used: HTMLCanvasElement;
  }> & {
    qBlocks: HTMLCanvasElement[];
    pow: HTMLCanvasElement[];
    springUp: HTMLCanvasElement;
    springDown: HTMLCanvasElement;
  };
}

let cachedBank: SpriteBank | null = null;

function createGroundTile(
  topColor: string,
  mainColor: string,
  shadeColor: string,
  crackColor: string
): HTMLCanvasElement {
  const c = document.createElement('canvas');
  c.width = 32;
  c.height = 32;
  const ctx = c.getContext('2d')!;
  ctx.fillStyle = mainColor;
  ctx.fillRect(0, 0, 32, 32);

  // Top highlight band
  ctx.fillStyle = topColor;
  ctx.fillRect(0, 0, 32, 6);
  ctx.fillRect(4, 6, 8, 2);
  ctx.fillRect(20, 6, 8, 2);

  // Cobble shading
  ctx.fillStyle = shadeColor;
  ctx.fillRect(0, 28, 32, 4);
  ctx.fillRect(14, 8, 4, 12);
  ctx.fillRect(0, 18, 32, 3);
  ctx.fillRect(6, 20, 4, 10);
  ctx.fillRect(24, 20, 4, 10);

  // Crisp pixel outline cracks
  ctx.fillStyle = crackColor;
  ctx.fillRect(0, 0, 32, 2);
  ctx.fillRect(15, 6, 2, 12);
  ctx.fillRect(0, 18, 32, 2);
  ctx.fillRect(7, 20, 2, 12);
  ctx.fillRect(25, 20, 2, 12);
  return c;
}

function createBrickTile(
  base: string,
  highlight: string,
  mortar: string
): HTMLCanvasElement {
  const c = document.createElement('canvas');
  c.width = 32;
  c.height = 32;
  const ctx = c.getContext('2d')!;
  ctx.fillStyle = mortar;
  ctx.fillRect(0, 0, 32, 32);

  const drawBrick = (x: number, y: number, w: number, h: number) => {
    ctx.fillStyle = base;
    ctx.fillRect(x, y, w, h);
    ctx.fillStyle = highlight;
    ctx.fillRect(x, y, w, 2);
    ctx.fillRect(x, y, 2, h);
  };

  drawBrick(1, 1, 14, 6);
  drawBrick(17, 1, 14, 6);
  drawBrick(1, 9, 7, 6);
  drawBrick(10, 9, 14, 6);
  drawBrick(26, 9, 5, 6);
  drawBrick(1, 17, 14, 6);
  drawBrick(17, 17, 14, 6);
  drawBrick(1, 25, 7, 6);
  drawBrick(10, 25, 14, 6);
  drawBrick(26, 25, 5, 6);
  return c;
}

function createSolidTile(base: string, light: string, dark: string): HTMLCanvasElement {
  const c = document.createElement('canvas');
  c.width = 32;
  c.height = 32;
  const ctx = c.getContext('2d')!;
  ctx.fillStyle = base;
  ctx.fillRect(0, 0, 32, 32);
  ctx.fillStyle = light;
  ctx.fillRect(0, 0, 32, 4);
  ctx.fillRect(0, 0, 4, 32);
  ctx.fillStyle = dark;
  ctx.fillRect(0, 28, 32, 4);
  ctx.fillRect(28, 0, 4, 32);
  ctx.fillStyle = '#14121d';
  ctx.strokeRect(1, 1, 30, 30);
  ctx.fillRect(5, 5, 3, 3);
  ctx.fillRect(24, 5, 3, 3);
  ctx.fillRect(5, 24, 3, 3);
  ctx.fillRect(24, 24, 3, 3);
  return c;
}

function createQBlock(bg: string, shine: string): HTMLCanvasElement {
  const c = document.createElement('canvas');
  c.width = 32;
  c.height = 32;
  const ctx = c.getContext('2d')!;

  ctx.fillStyle = '#181425';
  ctx.fillRect(0, 0, 32, 32);
  ctx.fillStyle = bg;
  ctx.fillRect(2, 2, 28, 28);
  ctx.fillStyle = shine;
  ctx.fillRect(2, 2, 28, 3);
  ctx.fillRect(2, 2, 3, 28);
  ctx.fillStyle = '#b85b00';
  ctx.fillRect(2, 27, 28, 3);
  ctx.fillRect(27, 2, 3, 28);

  // Corner rivets
  ctx.fillStyle = '#472409';
  ctx.fillRect(4, 4, 3, 3);
  ctx.fillRect(25, 4, 3, 3);
  ctx.fillRect(4, 25, 3, 3);
  ctx.fillRect(25, 25, 3, 3);

  // Question mark shadow + bright white glyph
  const drawMark = (ox: number, oy: number, col: string) => {
    ctx.fillStyle = col;
    ctx.fillRect(10 + ox, 7 + oy, 12, 3);
    ctx.fillRect(8 + ox, 10 + oy, 4, 4);
    ctx.fillRect(19 + ox, 10 + oy, 4, 5);
    ctx.fillRect(14 + ox, 14 + oy, 6, 3);
    ctx.fillRect(14 + ox, 17 + oy, 4, 3);
    ctx.fillRect(14 + ox, 22 + oy, 4, 4);
  };
  drawMark(2, 2, '#5e2b04');
  drawMark(0, 0, '#fffdf0');
  return c;
}

function createPowBlock(level: number): HTMLCanvasElement {
  const c = document.createElement('canvas');
  c.width = 32;
  c.height = 32;
  const ctx = c.getContext('2d')!;
  const h = level === 3 ? 32 : level === 2 ? 26 : 20;
  const yOff = 32 - h;

  ctx.fillStyle = '#14121d';
  ctx.fillRect(0, yOff, 32, h);
  ctx.fillStyle = '#1f5eff';
  ctx.fillRect(2, yOff + 2, 28, h - 4);
  ctx.fillStyle = '#6ea8ff';
  ctx.fillRect(2, yOff + 2, 28, 3);

  ctx.fillStyle = '#fff8d6';
  ctx.font = 'bold 9px "Press Start 2P", monospace';
  ctx.textAlign = 'center';
  ctx.textBaseline = 'middle';
  ctx.fillText('POW', 16, yOff + h / 2 + 1);
  return c;
}

function createSpring(compressed: boolean): HTMLCanvasElement {
  const c = document.createElement('canvas');
  c.width = 32;
  c.height = 32;
  const ctx = c.getContext('2d')!;
  const topY = compressed ? 14 : 2;

  // Top red pad
  ctx.fillStyle = '#14121d';
  ctx.fillRect(2, topY, 28, 7);
  ctx.fillStyle = '#ff3b30';
  ctx.fillRect(4, topY + 2, 24, 4);
  ctx.fillStyle = '#ffd1cf';
  ctx.fillRect(6, topY + 2, 10, 2);

  // Coils
  ctx.fillStyle = '#ffd93d';
  const coilSpace = (26 - (topY + 7)) / 3;
  for (let i = 0; i < 3; i++) {
    const cy = Math.round(topY + 7 + i * coilSpace);
    ctx.fillRect(7, cy, 18, 3);
  }

  // Bottom pad
  ctx.fillStyle = '#14121d';
  ctx.fillRect(2, 26, 28, 6);
  ctx.fillStyle = '#ff3b30';
  ctx.fillRect(4, 27, 24, 3);
  return c;
}

export interface BiomeTileSet {
  ground: HTMLCanvasElement;
  brick: HTMLCanvasElement;
  solid: HTMLCanvasElement;
  used: HTMLCanvasElement;
}

/**
 * Tiles are generated per biome on demand and cached. Only a handful of
 * biomes are ever on screen in a session, so a small LRU keeps memory flat
 * while avoiding any work during gameplay.
 */
const biomeTileCache = new Map<string, BiomeTileSet>();
const BIOME_TILE_LIMIT = 12;

export function getBiomeTiles(biome: BiomeDef): BiomeTileSet {
  const hit = biomeTileCache.get(biome.id);
  if (hit) return hit;

  const t = biome.tiles;
  const set: BiomeTileSet = {
    ground: createGroundTile(t.top, t.main, t.shade, t.crack),
    brick: createBrickTile(t.brick[0], t.brick[1], t.brick[2]),
    solid: createSolidTile(t.solid[0], t.solid[1], t.solid[2]),
    used: createSolidTile(t.used[0], t.used[1], t.used[2]),
  };

  if (biomeTileCache.size >= BIOME_TILE_LIMIT) {
    const oldest = biomeTileCache.keys().next().value;
    if (oldest !== undefined) biomeTileCache.delete(oldest);
  }
  biomeTileCache.set(biome.id, set);
  return set;
}

export function getSprites(): SpriteBank {
  if (cachedBank) return cachedBank;

  const marioCache = new Map<string, HTMLCanvasElement>();
  const bigRun1Aligned = alignBottomRows(BIG_RUN1, 26);
  const bigRun2Aligned = alignBottomRows(BIG_RUN2, 26);
  const bigJumpAligned = alignBottomRows(BIG_JUMP, 26);

  const buildMarioForPalette = (palName: string, pal: Palette) => {
    const smallPoses: Record<string, string[]> = {
      idle: SMALL_IDLE,
      run1: SMALL_RUN1,
      run2: SMALL_RUN2,
      run3: SMALL_IDLE,
      jump: SMALL_JUMP,
      skid: SMALL_SKID,
      crouch: SMALL_IDLE,
      dead: SMALL_DEAD,
    };
    const bigPoses: Record<string, string[]> = {
      idle: BIG_IDLE,
      run1: bigRun1Aligned,
      run2: bigRun2Aligned,
      run3: BIG_IDLE,
      jump: bigJumpAligned,
      skid: bigRun2Aligned,
      crouch: BIG_CROUCH,
      dead: SMALL_DEAD,
    };

    for (const [pose, grid] of Object.entries(smallPoses)) {
      marioCache.set(`small_${palName}_${pose}_1`, makePixelCanvas(grid, pal, 2, false));
      marioCache.set(`small_${palName}_${pose}_-1`, makePixelCanvas(grid, pal, 2, true));
    }
    for (const [pose, grid] of Object.entries(bigPoses)) {
      marioCache.set(`big_${palName}_${pose}_1`, makePixelCanvas(grid, pal, 2, false));
      marioCache.set(`big_${palName}_${pose}_-1`, makePixelCanvas(grid, pal, 2, true));
    }
  };

  for (const [palName, pal] of Object.entries(MARIO_PALETTES)) {
    buildMarioForPalette(palName, pal);
  }

  // Each purchasable character reuses the Mario sheets with its own colours,
  // so swapping characters costs nothing at runtime.
  for (const id of Object.keys(CHARACTERS) as CharacterId[]) {
    if (id === 'mario') continue;
    const c = CHARACTERS[id].palette;
    buildMarioForPalette(`c_${id}`, {
      R: c.R, D: c.D, B: c.B, N: c.N,
      S: c.S, T: c.T, H: c.H, K: '#14121d',
      Y: '#ffd93d', W: c.W,
    });
    // Fire form: brighten the shirt, keep the character's overalls.
    buildMarioForPalette(`cf_${id}`, {
      R: '#fff7eb', D: '#d7cce0', B: c.R, N: c.D,
      S: c.S, T: c.T, H: c.H, K: '#14121d',
      Y: '#ffd93d', W: c.W,
    });
  }

  const greenKoopaPal: Palette = {
    G: '#1ec95b',
    L: '#7df799',
    Y: '#ffd24c',
    W: '#ffffff',
    K: '#14121d',
  };
  const redKoopaPal: Palette = {
    G: '#ef333f',
    L: '#ff8a8a',
    Y: '#ffd24c',
    W: '#ffffff',
    K: '#14121d',
  };
  const buzzyPal: Palette = {
    G: '#2d3d73',
    L: '#5974bd',
    Y: '#f2b866',
    W: '#d6e3ff',
    K: '#14121d',
  };

  const piranhaPal: Palette = {
    R: '#e82936',
    W: '#ffffff',
    G: '#21c453',
  };
  const hammerBroPal: Palette = {
    H: '#fff5df',
    K: '#14121d',
    S: '#ffd06a',
    G: '#1fb85b',
    Y: '#ffcc33',
    W: '#fff4c0',
  };
  const fireBroPal: Palette = {
    H: '#ffd9b0', K: '#2a0f06', S: '#ff8a3d',
    G: '#e8491d', Y: '#ffb347', W: '#fff0c4',
  };
  const sniperBroPal: Palette = {
    H: '#e9d5ff', K: '#1e0a33', S: '#c084fc',
    G: '#7c3aed', Y: '#d8b4fe', W: '#faf5ff',
  };
  const armoredPal: Palette = {
    K: '#14121d', M: '#78716c', L: '#a8a29e',
    W: '#f5f5f4', S: '#fbbf24',
  };
  const spinyPal: Palette = {
    K: '#14121d',
    W: '#ffffff',
    O: '#ff8a1f',
    R: '#e02424',
    Y: '#ffd24c',
  };
  const bonePal: Palette = {
    W: '#f3f6ff',
    K: '#14121d',
  };
  const lakituPal: Palette = {
    G: '#28c85a',
    K: '#14121d',
    W: '#ffffff',
    Y: '#ffd93d',
  };
  const bulletPal: Palette = {
    K: '#1b1b24',
    W: '#ffffff',
  };

  const mushroomPal: Palette = {
    R: '#ff3030',
    W: '#fff7e6',
    S: '#ffd59e',
    K: '#14121d',
  };
  const oneUpPal: Palette = {
    R: '#1fd655',
    W: '#fff7e6',
    S: '#ffd59e',
    K: '#14121d',
  };
  const flowerPal1: Palette = {
    O: '#ff4824',
    Y: '#ffd93d',
    W: '#ffffff',
    G: '#25d35a',
    K: '#14121d',
  };
  const flowerPal2: Palette = {
    O: '#ffd93d',
    Y: '#ff4824',
    W: '#fff4b8',
    G: '#25d35a',
    K: '#14121d',
  };
  const starPal1: Palette = {
    Y: '#ffe43b',
    K: '#14121d',
  };
  const starPal2: Palette = {
    Y: '#fff8a6',
    K: '#14121d',
  };
  const coinPal: Palette = {
    Y: '#ffd93d',
    W: '#fffbe6',
    O: '#d98600',
    K: '#261705',
  };

  cachedBank = {
    getMario(power, pose, facing, starTick, character = 'mario') {
      const sizeKey = power === 'small' ? 'small' : 'big';
      let palKey = power === 'fire' ? 'fire' : 'normal';
      if (character !== 'mario') {
        palKey = power === 'fire' ? `cf_${character}` : `c_${character}`;
      }
      // The star rainbow overrides every character palette.
      if (starTick > 0) {
        const idx = Math.floor(starTick * 18) % 3;
        palKey = idx === 0 ? 'star0' : idx === 1 ? 'star1' : 'fire';
      }
      const key = `${sizeKey}_${palKey}_${pose}_${facing}`;
      return (
        marioCache.get(key) ||
        marioCache.get(`${sizeKey}_normal_${pose}_${facing}`) ||
        marioCache.get(`${sizeKey}_normal_idle_1`)!
      );
    },
    goomba: {
      walk1: makePixelCanvas(GOOMBA_1, GOOMBA_PAL, 2, false),
      walk2: makePixelCanvas(GOOMBA_2, GOOMBA_PAL, 2, false),
      squish: makePixelCanvas(GOOMBA_SQUISH, GOOMBA_PAL, 2, false),
    },
    koopaGreen: {
      walk1R: makePixelCanvas(KOOPA_WALK_1, greenKoopaPal, 2, false),
      walk2R: makePixelCanvas(KOOPA_WALK_2, greenKoopaPal, 2, false),
      walk1L: makePixelCanvas(KOOPA_WALK_1, greenKoopaPal, 2, true),
      walk2L: makePixelCanvas(KOOPA_WALK_2, greenKoopaPal, 2, true),
      shell1: makePixelCanvas(KOOPA_SHELL_1, greenKoopaPal, 2, false),
      shell2: makePixelCanvas(KOOPA_SHELL_2, greenKoopaPal, 2, false),
    },
    koopaRed: {
      walk1R: makePixelCanvas(KOOPA_WALK_1, redKoopaPal, 2, false),
      walk2R: makePixelCanvas(KOOPA_WALK_2, redKoopaPal, 2, false),
      walk1L: makePixelCanvas(KOOPA_WALK_1, redKoopaPal, 2, true),
      walk2L: makePixelCanvas(KOOPA_WALK_2, redKoopaPal, 2, true),
      shell1: makePixelCanvas(KOOPA_SHELL_1, redKoopaPal, 2, false),
      shell2: makePixelCanvas(KOOPA_SHELL_2, redKoopaPal, 2, false),
    },
    buzzy: {
      walk1R: makePixelCanvas(KOOPA_WALK_1, buzzyPal, 2, false),
      walk2R: makePixelCanvas(KOOPA_WALK_2, buzzyPal, 2, false),
      walk1L: makePixelCanvas(KOOPA_WALK_1, buzzyPal, 2, true),
      walk2L: makePixelCanvas(KOOPA_WALK_2, buzzyPal, 2, true),
      shell1: makePixelCanvas(KOOPA_SHELL_1, buzzyPal, 2, false),
      shell2: makePixelCanvas(KOOPA_SHELL_2, buzzyPal, 2, false),
    },
    piranha: {
      open: makePixelCanvas(PIRANHA_OPEN, piranhaPal, 2, false),
      closed: makePixelCanvas(PIRANHA_CLOSED, piranhaPal, 2, false),
    },
    hammerBro: {
      walk1L: makePixelCanvas(HAMMER_BRO_1, hammerBroPal, 2, true),
      walk2L: makePixelCanvas(HAMMER_BRO_2, hammerBroPal, 2, true),
      walk1R: makePixelCanvas(HAMMER_BRO_1, hammerBroPal, 2, false),
      walk2R: makePixelCanvas(HAMMER_BRO_2, hammerBroPal, 2, false),
    },
    spiny: {
      walk1: makePixelCanvas(SPINY_1, spinyPal, 2, false),
      walk2: makePixelCanvas(SPINY_2, spinyPal, 2, false),
    },
    fireBro: {
      walk1L: makePixelCanvas(HAMMER_BRO_1, fireBroPal, 2, true),
      walk2L: makePixelCanvas(HAMMER_BRO_2, fireBroPal, 2, true),
      walk1R: makePixelCanvas(HAMMER_BRO_1, fireBroPal, 2, false),
      walk2R: makePixelCanvas(HAMMER_BRO_2, fireBroPal, 2, false),
    },
    sniperBro: {
      walk1L: makePixelCanvas(HAMMER_BRO_1, sniperBroPal, 2, true),
      walk2L: makePixelCanvas(HAMMER_BRO_2, sniperBroPal, 2, true),
      walk1R: makePixelCanvas(HAMMER_BRO_1, sniperBroPal, 2, false),
      walk2R: makePixelCanvas(HAMMER_BRO_2, sniperBroPal, 2, false),
    },
    armoredGoomba: {
      walk1: makePixelCanvas(ARMORED_GOOMBA, armoredPal, 2, false),
      walk2: makePixelCanvas(ARMORED_GOOMBA_2, armoredPal, 2, false),
    },
    dryBones: {
      walk1L: makePixelCanvas(DRY_BONES_1, bonePal, 2, true),
      walk2L: makePixelCanvas(DRY_BONES_2, bonePal, 2, true),
      walk1R: makePixelCanvas(DRY_BONES_1, bonePal, 2, false),
      walk2R: makePixelCanvas(DRY_BONES_2, bonePal, 2, false),
      down: makePixelCanvas(DRY_BONES_DOWN, bonePal, 2, false),
    },
    lakitu: {
      frame1L: makePixelCanvas(LAKITU_1, lakituPal, 2, true),
      frame2L: makePixelCanvas(LAKITU_2, lakituPal, 2, true),
      frame1R: makePixelCanvas(LAKITU_1, lakituPal, 2, false),
      frame2R: makePixelCanvas(LAKITU_2, lakituPal, 2, false),
    },
    bulletBill: {
      left: makePixelCanvas(BULLET_BILL, bulletPal, 2, true),
      right: makePixelCanvas(BULLET_BILL, bulletPal, 2, false),
    },
    items: {
      mushroom: makePixelCanvas(MUSHROOM_GRID, mushroomPal, 2, false),
      oneUp: makePixelCanvas(MUSHROOM_GRID, oneUpPal, 2, false),
      flower1: makePixelCanvas(FLOWER_GRID, flowerPal1, 2, false),
      flower2: makePixelCanvas(FLOWER_GRID, flowerPal2, 2, false),
      star1: makePixelCanvas(STAR_GRID, starPal1, 2, false),
      star2: makePixelCanvas(STAR_GRID, starPal2, 2, false),
      coins: [
        makePixelCanvas(COIN_1, coinPal, 2, false),
        makePixelCanvas(COIN_2, coinPal, 2, false),
        makePixelCanvas(COIN_3, coinPal, 2, false),
        makePixelCanvas(COIN_2, coinPal, 2, true),
      ],
    },
    tiles: {
      overworld: {
        ground: createGroundTile('#4be35e', '#c85a17', '#8f3808', '#2b1204'),
        brick: createBrickTile('#cf571b', '#ff9b61', '#261107'),
        solid: createSolidTile('#c7662a', '#ffb178', '#752f09'),
        used: createSolidTile('#8f7965', '#bfb0a1', '#4d3e31'),
      },
      underground: {
        ground: createGroundTile('#5cd1ff', '#1e5b94', '#10365e', '#08172b'),
        brick: createBrickTile('#2569ad', '#6bb8ff', '#0b1e36'),
        solid: createSolidTile('#2f78b8', '#7ac9ff', '#143c66'),
        used: createSolidTile('#526478', '#8397ad', '#2c3745'),
      },
      castle: {
        ground: createGroundTile('#a8b2c7', '#586075', '#363c4d', '#151821'),
        brick: createBrickTile('#686f82', '#9ea7bd', '#1c1f29'),
        solid: createSolidTile('#7d859c', '#b8c1d9', '#424759'),
        used: createSolidTile('#4b4e5c', '#74788a', '#292b36'),
      },
      desert: {
        ground: createGroundTile('#ffd98a', '#d9a441', '#a9752a', '#4a2f0d'),
        brick: createBrickTile('#d4a04a', '#ffe0a0', '#4a3113'),
        solid: createSolidTile('#cf9a44', '#ffdc9c', '#8a6020'),
        used: createSolidTile('#9c8763', '#c9b792', '#584a32'),
      },
      snow: {
        ground: createGroundTile('#ffffff', '#9fc7e8', '#6b96bd', '#2b4258'),
        brick: createBrickTile('#8fb6d8', '#e4f3ff', '#28415a'),
        solid: createSolidTile('#a9cce8', '#eaf7ff', '#5c82a4'),
        used: createSolidTile('#8d9aa8', '#c0cbd6', '#4a545f'),
      },
      beach: {
        ground: createGroundTile('#ffe9ab', '#e9c173', '#b58a42', '#4f3a16'),
        brick: createBrickTile('#3fa7c7', '#9fe2f5', '#13394b'),
        solid: createSolidTile('#46b3d4', '#a9ecff', '#1f6e88'),
        used: createSolidTile('#93a3a8', '#c3d1d6', '#4d585c'),
      },
      jungle: {
        ground: createGroundTile('#7cf06a', '#3f7a2c', '#275219', '#0f2409'),
        brick: createBrickTile('#4b8b33', '#8fd96f', '#16290d'),
        solid: createSolidTile('#55953a', '#a3e283', '#2d5a1f'),
        used: createSolidTile('#6f7d63', '#9cab8e', '#39422f'),
      },
      sky: {
        ground: createGroundTile('#ffffff', '#b9c9ff', '#8a9ce0', '#3e4a80'),
        brick: createBrickTile('#8d9df0', '#d6e0ff', '#2f3766'),
        solid: createSolidTile('#9aa9f5', '#dbe4ff', '#5b67ad'),
        used: createSolidTile('#9aa0b5', '#c5cadb', '#4e5467'),
      },
      haunted: {
        ground: createGroundTile('#7b5bb5', '#3d2a5e', '#271a3d', '#120b1e'),
        brick: createBrickTile('#4a356e', '#8b6cc4', '#1a1029'),
        solid: createSolidTile('#55407a', '#937ac4', '#2e2147'),
        used: createSolidTile('#4a4458', '#726a85', '#282430'),
      },
      factory: {
        ground: createGroundTile('#ffb23d', '#5a6372', '#39404c', '#171a20'),
        brick: createBrickTile('#5d6675', '#99a4b5', '#1d2128'),
        solid: createSolidTile('#6b7484', '#a8b3c4', '#3b424e'),
        used: createSolidTile('#4a4f58', '#767c88', '#272a30'),
      },
      candy: {
        ground: createGroundTile('#ffd1ea', '#f06bb0', '#bd3d80', '#5c1639'),
        brick: createBrickTile('#f277b4', '#ffc4e2', '#60203f'),
        solid: createSolidTile('#f58ac2', '#ffd3eb', '#b24a86'),
        used: createSolidTile('#bfa3b4', '#e0ccd7', '#6b5260'),
      },
      volcano: {
        ground: createGroundTile('#ff8d3b', '#6d2a1d', '#451710', '#1d0906'),
        brick: createBrickTile('#8a3722', '#d4673f', '#2a0e07'),
        solid: createSolidTile('#93402a', '#e07a4c', '#55200f'),
        used: createSolidTile('#5b4440', '#8a6d66', '#2e2220'),
      },
      qBlocks: [
        createQBlock('#f59e0b', '#ffe57f'),
        createQBlock('#fbbf24', '#fff6b3'),
        createQBlock('#d97706', '#fcd34d'),
      ],
      pow: [
        createPowBlock(1),
        createPowBlock(2),
        createPowBlock(3),
      ],
      springUp: createSpring(false),
      springDown: createSpring(true),
    },
  };

  return cachedBank;
}
