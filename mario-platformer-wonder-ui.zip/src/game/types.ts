export type GameScreen =
  | 'title'
  | 'playing'
  | 'paused'
  | 'stage_clear'
  | 'gameover'
  | 'victory';

export type PowerState = 'small' | 'big' | 'fire';

// ---------------------------------------------------------------------------
// Playable characters — unlocked with coins banked across runs
// ---------------------------------------------------------------------------

export type CharacterId =
  | 'mario' | 'luigi' | 'toad' | 'peach' | 'wario' | 'yoshi' | 'rosalina';

export interface CharacterDef {
  id: CharacterId;
  name: string;
  /** Coin cost; 0 = owned from the start. */
  cost: number;
  /** Horizontal speed multiplier. */
  speed: number;
  /** Jump strength multiplier. */
  jump: number;
  /** Ground acceleration / traction multiplier (low = slippery). */
  grip: number;
  /** Weapon cooldown multiplier (lower is faster). */
  fireRate: number;
  /** Extra lives granted at the start of a run. */
  bonusLives: number;
  /** Seconds of flutter-hover available after the jump apex (0 = none). */
  hoverTime: number;
  /** Palette override keys for the shared Mario sprite sheets. */
  palette: {
    R: string; D: string; B: string; N: string;
    S: string; T: string; H: string; W: string;
  };
  blurb: string;
  perk: string;
}

export const CHARACTERS: Record<CharacterId, CharacterDef> = {
  mario: {
    id: 'mario', name: 'MARIO', cost: 0,
    speed: 1, jump: 1, grip: 1, fireRate: 1, bonusLives: 0, hoverTime: 0,
    palette: { R: '#ef2b2d', D: '#a61419', B: '#2357e6', N: '#14318a',
      S: '#ffcc99', T: '#e09b63', H: '#5c2c16', W: '#ffffff' },
    blurb: 'The all-rounder. Balanced in every way.',
    perk: 'Balanced',
  },
  luigi: {
    id: 'luigi', name: 'LUIGI', cost: 300,
    speed: 0.97, jump: 1.16, grip: 0.82, fireRate: 1, bonusLives: 0, hoverTime: 0,
    palette: { R: '#17b84a', D: '#0b6b29', B: '#2357e6', N: '#14318a',
      S: '#ffcc99', T: '#e09b63', H: '#4a2a12', W: '#ffffff' },
    blurb: 'Jumps far higher, but slides on landing.',
    perk: '+16% jump',
  },
  toad: {
    id: 'toad', name: 'TOAD', cost: 650,
    speed: 1.18, jump: 0.94, grip: 1.3, fireRate: 0.8, bonusLives: 0, hoverTime: 0,
    palette: { R: '#f4f4f5', D: '#c026d3', B: '#1e40af', N: '#132c6b',
      S: '#ffd9b0', T: '#e8a877', H: '#e11d48', W: '#ffffff' },
    blurb: 'Quick feet and rapid fire, weaker jump.',
    perk: '+18% speed',
  },
  peach: {
    id: 'peach', name: 'PEACH', cost: 1200,
    speed: 0.95, jump: 1.05, grip: 1.05, fireRate: 1, bonusLives: 0, hoverTime: 0.52,
    palette: { R: '#ff8ac4', D: '#c2185b', B: '#ffd1e8', N: '#d68cb0',
      S: '#ffd9b8', T: '#e8ab84', H: '#f5d76e', W: '#ffffff' },
    blurb: 'Can hover briefly at the top of a jump.',
    perk: 'Float hover',
  },
  wario: {
    id: 'wario', name: 'WARIO', cost: 1800,
    speed: 0.9, jump: 0.92, grip: 1.25, fireRate: 0.75, bonusLives: 2, hoverTime: 0,
    palette: { R: '#ffd93d', D: '#b8860b', B: '#8b2fc9', N: '#5b1a85',
      S: '#ffcc99', T: '#e09b63', H: '#3d2a10', W: '#ffffff' },
    blurb: 'Tanky bruiser: 2 extra lives and fast attacks.',
    perk: '+2 lives',
  },
  yoshi: {
    id: 'yoshi', name: 'YOSHI', cost: 2600,
    speed: 1.1, jump: 1.1, grip: 1.15, fireRate: 0.9, bonusLives: 1, hoverTime: 0.34,
    palette: { R: '#22c55e', D: '#15803d', B: '#ffffff', N: '#cbd5e1',
      S: '#fde68a', T: '#f0c04a', H: '#b91c1c', W: '#ffffff' },
    blurb: 'Fast, springy, and flutter-jumps a little.',
    perk: 'All-round+',
  },
  rosalina: {
    id: 'rosalina', name: 'ROSALINA', cost: 4000,
    speed: 1.05, jump: 1.2, grip: 1.1, fireRate: 0.65, bonusLives: 1, hoverTime: 0.7,
    palette: { R: '#67e8f9', D: '#0e7490', B: '#c4b5fd', N: '#7c5cd6',
      S: '#ffe4c4', T: '#e8bb90', H: '#fef08a', W: '#ffffff' },
    blurb: 'Cosmic royalty: best jump, hover and fire rate.',
    perk: 'Elite all-stats',
  },
};

export const CHARACTER_ORDER: CharacterId[] = [
  'mario', 'luigi', 'toad', 'peach', 'wario', 'yoshi', 'rosalina',
];

// ---------------------------------------------------------------------------
// Weapons — collected in earlier maps, kept for the rest of the run
// ---------------------------------------------------------------------------

export type WeaponKind =
  | 'fireball'
  | 'hammer'
  | 'boomerang'
  | 'iceball'
  | 'bomb'
  | 'laser';

export interface WeaponDef {
  kind: WeaponKind;
  name: string;
  icon: string;
  color: string;
  glow: string;
  /** Damage dealt to an enemy's hit points. */
  damage: number;
  /** Seconds between shots. */
  cooldown: number;
  /** Max simultaneous live projectiles. */
  maxLive: number;
  speed: number;
  /** Downward acceleration (0 = flies straight). */
  gravity: number;
  /** Bounces off the floor instead of expiring. */
  bouncy: boolean;
  /** Passes through enemies instead of being consumed. */
  piercing: boolean;
  /** Flies out then curves back to the player. */
  returns: boolean;
  /** Area-of-effect blast on impact. */
  explodes: boolean;
  /** Freezes the target solid for a few seconds. */
  freezes: boolean;
  /** Level at which this weapon starts appearing in crates. */
  unlockLevel: number;
  /** Ammo granted per pickup (Infinity = unlimited). */
  ammoPerPickup: number;
  blurb: string;
}

export const WEAPONS: Record<WeaponKind, WeaponDef> = {
  fireball: {
    kind: 'fireball', name: 'FIRE FLOWER', icon: '🔥',
    color: '#ff5924', glow: '#ffe13b',
    damage: 1, cooldown: 0.2, maxLive: 3, speed: 430, gravity: 1550,
    bouncy: true, piercing: false, returns: false, explodes: false, freezes: false,
    unlockLevel: 1, ammoPerPickup: Infinity,
    blurb: 'Bouncing flames. Unlimited while you hold the flower.',
  },
  hammer: {
    kind: 'hammer', name: 'HAMMER', icon: '🔨',
    color: '#c0c7d8', glow: '#ffd166',
    damage: 2, cooldown: 0.34, maxLive: 3, speed: 330, gravity: 1180,
    bouncy: false, piercing: false, returns: false, explodes: false, freezes: false,
    unlockLevel: 4, ammoPerPickup: 20,
    blurb: 'Heavy arcing throw. Smashes armoured foes.',
  },
  boomerang: {
    kind: 'boomerang', name: 'BOOMERANG', icon: '🪃',
    color: '#67e8f9', glow: '#a5f3fc',
    damage: 1, cooldown: 0.45, maxLive: 2, speed: 380, gravity: 0,
    bouncy: false, piercing: true, returns: true, explodes: false, freezes: false,
    unlockLevel: 12, ammoPerPickup: 15,
    blurb: 'Flies out, hits everything, and comes back.',
  },
  iceball: {
    kind: 'iceball', name: 'ICE FLOWER', icon: '❄️',
    color: '#7dd3fc', glow: '#e0f2fe',
    damage: 1, cooldown: 0.24, maxLive: 3, speed: 400, gravity: 900,
    bouncy: true, piercing: false, returns: false, explodes: false, freezes: true,
    unlockLevel: 25, ammoPerPickup: 25,
    blurb: 'Freezes enemies solid so you can use them as platforms.',
  },
  bomb: {
    kind: 'bomb', name: 'BOB-OMB', icon: '💣',
    color: '#1f2937', glow: '#f97316',
    damage: 3, cooldown: 0.6, maxLive: 2, speed: 300, gravity: 1250,
    bouncy: true, piercing: false, returns: false, explodes: true, freezes: false,
    unlockLevel: 45, ammoPerPickup: 10,
    blurb: 'Lobbed explosive with a wide blast radius.',
  },
  laser: {
    kind: 'laser', name: 'STAR ROD', icon: '⚡',
    color: '#fde047', glow: '#fef9c3',
    damage: 2, cooldown: 0.16, maxLive: 5, speed: 760, gravity: 0,
    bouncy: false, piercing: true, returns: false, explodes: false, freezes: false,
    unlockLevel: 90, ammoPerPickup: 30,
    blurb: 'Instant piercing starlight beam.',
  },
};

export const WEAPON_ORDER: WeaponKind[] = [
  'fireball', 'hammer', 'boomerang', 'iceball', 'bomb', 'laser',
];

/** Weapons that can appear in crates by the time the player reaches a level. */
export function weaponsAvailableAt(level: number): WeaponKind[] {
  return WEAPON_ORDER.filter((w) => WEAPONS[w].unlockLevel <= level);
}

export type WorldTheme =
  | 'overworld'
  | 'underground'
  | 'castle'
  | 'desert'
  | 'snow'
  | 'beach'
  | 'jungle'
  | 'sky'
  | 'volcano'
  | 'haunted'
  | 'factory'
  | 'candy';

/**
 * 12 distinct biomes. Levels step through this list in order, so two
 * consecutive levels can never share the same map theme.
 */
export const THEME_ORDER: WorldTheme[] = [
  'overworld',
  'underground',
  'desert',
  'beach',
  'jungle',
  'snow',
  'sky',
  'haunted',
  'factory',
  'candy',
  'volcano',
  'castle',
];

export const THEME_META: Record<
  WorldTheme,
  { name: string; icon: string; accent: string; music: 'overworld' | 'underground' | 'castle' }
> = {
  overworld: { name: 'MUSHROOM PLAINS', icon: '🍄', accent: '#4ade80', music: 'overworld' },
  underground: { name: 'CRYSTAL CAVERN', icon: '💎', accent: '#60a5fa', music: 'underground' },
  desert: { name: 'DRY DUNES', icon: '🏜️', accent: '#fbbf24', music: 'overworld' },
  beach: { name: 'CORAL COAST', icon: '🐚', accent: '#22d3ee', music: 'overworld' },
  jungle: { name: 'VINE JUNGLE', icon: '🌴', accent: '#34d399', music: 'overworld' },
  snow: { name: 'FROZEN PEAKS', icon: '❄️', accent: '#bae6fd', music: 'overworld' },
  sky: { name: 'CLOUD KINGDOM', icon: '☁️', accent: '#a5b4fc', music: 'overworld' },
  haunted: { name: 'HAUNTED HOLLOW', icon: '👻', accent: '#c084fc', music: 'underground' },
  factory: { name: 'IRON FACTORY', icon: '⚙️', accent: '#94a3b8', music: 'castle' },
  candy: { name: 'SUGAR RUSH', icon: '🍬', accent: '#f9a8d4', music: 'overworld' },
  volcano: { name: 'MAGMA CORE', icon: '🌋', accent: '#fb7185', music: 'castle' },
  castle: { name: 'BOWSER FORTRESS', icon: '🏰', accent: '#f87171', music: 'castle' },
};

/** Total procedurally generated levels available in the campaign. */
export const TOTAL_LEVELS = 8000;

export interface LevelTier {
  index: number;
  name: string;
  color: string;
  minLevel: number;
}

/** Progressive NPC difficulty bands across the 8000-level campaign. */
export const LEVEL_TIERS: LevelTier[] = [
  { index: 0, name: 'ROOKIE', color: '#4ade80', minLevel: 1 },
  { index: 1, name: 'SCOUT', color: '#a3e635', minLevel: 60 },
  { index: 2, name: 'FIGHTER', color: '#facc15', minLevel: 200 },
  { index: 3, name: 'VETERAN', color: '#fb923c', minLevel: 500 },
  { index: 4, name: 'ELITE', color: '#f87171', minLevel: 1000 },
  { index: 5, name: 'MASTER', color: '#f472b6', minLevel: 1800 },
  { index: 6, name: 'NIGHTMARE', color: '#c084fc', minLevel: 3000 },
  { index: 7, name: 'INFERNO', color: '#a78bfa', minLevel: 4500 },
  { index: 8, name: 'COSMIC', color: '#38bdf8', minLevel: 6000 },
  { index: 9, name: 'LEGEND', color: '#fde047', minLevel: 7200 },
];

/**
 * Today's shared daily-challenge level.
 *
 * Derived purely from the UTC date, so every player in the world is sent to
 * the exact same level on the same day without needing a server.
 */
export function dailyLevelFor(d: Date): number {
  const key =
    d.getUTCFullYear() * 10000 + (d.getUTCMonth() + 1) * 100 + d.getUTCDate();
  let h = key >>> 0;
  h = Math.imul(h ^ (h >>> 15), 2246822519);
  h = Math.imul(h ^ (h >>> 13), 3266489917);
  h ^= h >>> 16;
  return ((h >>> 0) % TOTAL_LEVELS) + 1;
}

export function dailyKey(d: Date): string {
  return `${d.getUTCFullYear()}-${String(d.getUTCMonth() + 1).padStart(2, '0')}-${String(d.getUTCDate()).padStart(2, '0')}`;
}

export function getLevelTier(level: number): LevelTier {
  let tier = LEVEL_TIERS[0];
  for (const t of LEVEL_TIERS) {
    if (level >= t.minLevel) tier = t;
  }
  return tier;
}

export function getThemeForLevel(level: number): WorldTheme {
  return THEME_ORDER[(level - 1) % THEME_ORDER.length];
}

// ---------------------------------------------------------------------------
// Core gameplay primitives
// ---------------------------------------------------------------------------

export const TILE_SIZE = 32;

export interface InputState {
  left: boolean;
  right: boolean;
  up: boolean;
  down: boolean;
  jumpHeld: boolean;
  jumpPressed: boolean;
  runHeld: boolean;
  firePressed: boolean;
  /** Cycle to the next owned weapon (edge-triggered). */
  switchPressed: boolean;
  /** Enter a warp pipe (Down held on a pipe mouth). */
  enterPipe: boolean;
  /** Dash / air-dash (edge triggered). */
  dashPressed: boolean;
  /** Fire or release the grappling hook (edge triggered). */
  grapplePressed: boolean;
}

export enum TileType {
  EMPTY = 0,
  GROUND = 1,
  BRICK = 2,
  Q_COIN = 3,
  Q_POWER = 4,
  Q_STAR = 5,
  Q_1UP = 6,
  MULTI_COIN_BRICK = 7,
  SOLID_BLOCK = 8,
  USED_BLOCK = 9,
  PIPE_TL = 10,
  PIPE_TR = 11,
  PIPE_BL = 12,
  PIPE_BR = 13,
  POW_BLOCK = 14,
  SPRING = 15,
  BRIDGE = 16,
  LAVA = 17,
  /** Mid-level respawn flag. */
  CHECKPOINT = 18,
  // --- Theme-specific parkour hazards ---
  /** Solid but damages the player on contact. */
  SPIKE = 19,
  /** Solid with almost no friction. */
  ICE = 20,
  /** Solid, pushes the player left. */
  CONVEYOR_LEFT = 21,
  /** Solid, pushes the player right. */
  CONVEYOR_RIGHT = 22,
  /** Solid, auto-bounces the player. */
  JELLY = 23,
  /** Solid, crumbles away shortly after being stood on. */
  CRUMBLE = 24,
  /** Climbable vine. */
  VINE = 25,
  /** One-way cloud platform that fades when stood on. */
  CLOUD = 26,
  // --- Puzzle & traversal props ---
  /** Ceiling anchor the grappling hook can latch onto. */
  GRAPPLE_POINT = 27,
  /** Stand on it to open linked gates. */
  BUTTON = 28,
  /** Closed gate; opens when its puzzle is solved. */
  GATE = 29,
  /** Heavy crate the player can push along the ground. */
  PUSH_BLOCK = 30,
  /** Rough wall surface that allows wall-running. */
  WALL_RUN = 31,
  /** Thin wall only the Shadow costume can pass through. */
  PHASE_WALL = 32,
}

/** Parkour obstacle kit assigned to each biome family. */
export interface ThemeHazards {
  /** Primary obstacle tile used by the theme's signature parkour chunk. */
  primary: TileType | null;
  /** Secondary flavour tile sprinkled through the level. */
  secondary: TileType | null;
  /** Pits are filled with lava rather than being bottomless. */
  lavaPits: boolean;
  /** Short label shown in the HUD briefing. */
  label: string;
}

// ---------------------------------------------------------------------------
// Weather — one of the three dimensions that make every level unique
// ---------------------------------------------------------------------------

export type WeatherKind =
  | 'hail'
  | 'rain'
  | 'storm'
  | 'typhoon'
  | 'snow'
  | 'blizzard'
  | 'fog'
  | 'embers'
  | 'petals'
  | 'sandstorm';

/** Exactly 10 kinds: 100 biomes x 10 weathers x 8 skies = 8000. */
export const WEATHERS: WeatherKind[] = [
  'rain', 'petals', 'snow', 'storm', 'fog',
  'embers', 'hail', 'typhoon', 'sandstorm', 'blizzard',
];

/**
 * How a level's weather behaves over time. Every level gets one, so the
 * weather can roll in, blow over, or rage from start to finish.
 */
export type WeatherSchedule =
  | 'constant'    // never lets up
  | 'burst'       // heavy at the start, blows over after a few seconds
  | 'midway'      // clear skies, then it rolls in halfway through
  | 'intermittent'// comes and goes in waves
  | 'clearing'    // starts strong and clears before the flag
  | 'building'    // barely there at first, full force by the end
  | 'lateburst';  // sudden squall near the finish

export const WEATHER_SCHEDULES: WeatherSchedule[] = [
  'constant', 'burst', 'midway', 'intermittent',
  'clearing', 'building', 'lateburst',
];

export const SCHEDULE_LABEL: Record<WeatherSchedule, string> = {
  constant: 'ALL MAP',
  burst: 'BRIEF',
  midway: 'FROM MIDWAY',
  intermittent: 'IN WAVES',
  clearing: 'CLEARING',
  building: 'BUILDING',
  lateburst: 'LATE SQUALL',
};

/**
 * Weather strength at a point in the level, 0..1.
 *
 * `progress` is how far through the map the camera has travelled (0..1) and
 * `elapsed` is seconds since the level started. Using both lets a schedule
 * react to either pacing or position.
 */
export function weatherIntensity(
  schedule: WeatherSchedule,
  progress: number,
  elapsed: number
): number {
  const p = Math.max(0, Math.min(1, progress));
  const ramp = (v: number, a: number, b: number) =>
    Math.max(0, Math.min(1, (v - a) / Math.max(0.0001, b - a)));

  switch (schedule) {
    case 'burst':
      // Full strength, then blows over around the 9 second mark.
      return 1 - ramp(elapsed, 7.5, 10.5);
    case 'midway':
      return ramp(p, 0.42, 0.56);
    case 'intermittent': {
      // Waves: ~11s on, ~7s off, with soft edges.
      const cycle = 18;
      const t = elapsed % cycle;
      if (t < 1.6) return ramp(t, 0, 1.6);
      if (t < 11) return 1;
      if (t < 13) return 1 - ramp(t, 11, 13);
      return 0;
    }
    case 'clearing':
      return 1 - ramp(p, 0.48, 0.72);
    case 'building':
      return 0.18 + 0.82 * ramp(p, 0.1, 0.88);
    case 'lateburst':
      return ramp(p, 0.68, 0.8);
    case 'constant':
    default:
      return 1;
  }
}

export interface WeatherDef {
  kind: WeatherKind;
  label: string;
  /** Prefix used in the level name (empty for clear). */
  prefix: string;
  /** Sideways push applied to falling particles, in px/s. */
  wind: number;
  /** How violently the wind gusts (0 = steady). */
  gust: number;
  /** Particle count target. */
  density: number;
  /** Rough lightning strikes per second (0 = none). */
  lightning: number;
  /** Screen-wide colour wash applied over the scene. */
  tint: string;
  tintAlpha: number;
  /** Extra camera sway in px, for violent weather. */
  shake: number;
}

export const WEATHER_DEFS: Record<WeatherKind, WeatherDef> = {
  hail: {
    kind: 'hail', label: 'HAILSTORM', prefix: 'HAIL ', wind: -130, gust: 40,
    density: 80, lightning: 0, tint: '#aec4d9', tintAlpha: 0.16, shake: 0.35,
  },
  rain: {
    kind: 'rain', label: 'RAIN', prefix: 'RAINY ', wind: -90, gust: 24,
    density: 90, lightning: 0, tint: '#6f8fc4', tintAlpha: 0.12, shake: 0,
  },
  storm: {
    kind: 'storm', label: 'THUNDERSTORM', prefix: 'STORM ', wind: -170,
    gust: 70, density: 150, lightning: 0.42, tint: '#4a5f94',
    tintAlpha: 0.2, shake: 0.6,
  },
  typhoon: {
    kind: 'typhoon', label: 'TYPHOON', prefix: 'TYPHOON ', wind: -420,
    gust: 190, density: 190, lightning: 0.18, tint: '#3d5570',
    tintAlpha: 0.26, shake: 1.8,
  },
  snow: {
    kind: 'snow', label: 'SNOWFALL', prefix: 'SNOWY ', wind: -34, gust: 26,
    density: 90, lightning: 0, tint: '#cfe4ff', tintAlpha: 0.12, shake: 0,
  },
  blizzard: {
    kind: 'blizzard', label: 'BLIZZARD', prefix: 'BLIZZARD ', wind: -330,
    gust: 140, density: 210, lightning: 0, tint: '#dbeaff',
    tintAlpha: 0.3, shake: 1.0,
  },
  fog: {
    kind: 'fog', label: 'MIST', prefix: 'MISTY ', wind: -18, gust: 6,
    density: 0, lightning: 0, tint: '#c4d2dd', tintAlpha: 0.2, shake: 0,
  },
  embers: {
    kind: 'embers', label: 'EMBER FALL', prefix: 'EMBER ', wind: 46,
    gust: 40, density: 70, lightning: 0, tint: '#ff7a3d',
    tintAlpha: 0.14, shake: 0,
  },
  petals: {
    kind: 'petals', label: 'FALLING LEAVES', prefix: 'AUTUMN ', wind: -74,
    gust: 56, density: 65, lightning: 0, tint: '#ffb86f',
    tintAlpha: 0.12, shake: 0,
  },
  sandstorm: {
    kind: 'sandstorm', label: 'SANDSTORM', prefix: 'SANDSTORM ', wind: -300,
    gust: 120, density: 180, lightning: 0, tint: '#d9a441',
    tintAlpha: 0.3, shake: 0.9,
  },
};

export const THEME_HAZARDS: Record<WorldTheme, ThemeHazards> = {
  overworld: {
    primary: TileType.JELLY,
    secondary: null,
    lavaPits: false,
    label: 'Bouncy mushroom pads',
  },
  underground: {
    primary: TileType.SPIKE,
    secondary: TileType.CRUMBLE,
    lavaPits: false,
    label: 'Spike pits & crumbling rock',
  },
  desert: {
    primary: TileType.CRUMBLE,
    secondary: TileType.SPIKE,
    lavaPits: false,
    label: 'Collapsing sandstone',
  },
  beach: {
    primary: TileType.JELLY,
    secondary: TileType.CRUMBLE,
    lavaPits: false,
    label: 'Bubble bounce & sandcastles',
  },
  jungle: {
    primary: TileType.VINE,
    secondary: TileType.SPIKE,
    lavaPits: false,
    label: 'Climbing vines',
  },
  snow: {
    primary: TileType.ICE,
    secondary: TileType.SPIKE,
    lavaPits: false,
    label: 'Slippery ice runs',
  },
  sky: {
    primary: TileType.CLOUD,
    secondary: TileType.JELLY,
    lavaPits: false,
    label: 'Vanishing cloud hops',
  },
  haunted: {
    primary: TileType.CRUMBLE,
    secondary: TileType.SPIKE,
    lavaPits: false,
    label: 'Phasing ghost blocks',
  },
  factory: {
    primary: TileType.CONVEYOR_RIGHT,
    secondary: TileType.SPIKE,
    lavaPits: true,
    label: 'Conveyor belts & gears',
  },
  candy: {
    primary: TileType.JELLY,
    secondary: TileType.CLOUD,
    lavaPits: false,
    label: 'Jelly trampolines',
  },
  volcano: {
    primary: TileType.SPIKE,
    secondary: TileType.CRUMBLE,
    lavaPits: true,
    label: 'Lava flows & obsidian spikes',
  },
  castle: {
    primary: TileType.SPIKE,
    secondary: TileType.CONVEYOR_LEFT,
    lavaPits: true,
    label: 'Spike traps over lava',
  },
};

export interface Player {
  x: number;
  y: number;
  vx: number;
  vy: number;
  width: number;
  height: number;
  facing: 1 | -1;
  power: PowerState;
  onGround: boolean;
  crouching: boolean;
  skidding: boolean;
  coyoteTimer: number;
  jumpBufferTimer: number;
  invulnTimer: number;
  starTimer: number;
  transformTimer: number;
  fireCooldown: number;
  stompCombo: number;
  animFrame: number;
  animTimer: number;
  scaleX: number;
  scaleY: number;
  dead: boolean;
  deathTimer: number;
  flagSlide: boolean;
  victoryWalk: boolean;

  // --- Advanced movement ---------------------------------------------
  /** Seconds left in the current dash (0 = not dashing). */
  dashTimer: number;
  /** Cooldown before another dash is allowed. */
  dashCooldown: number;
  /** Air dashes used since last touching the ground. */
  airDashesUsed: number;
  dashDirX: number;
  dashDirY: number;
  /** -1 = clinging to a wall on the left, 1 = right, 0 = not clinging. */
  wallSide: 0 | 1 | -1;
  /** Seconds of horizontal wall-run left. */
  wallRunTimer: number;
  /** Grace period after leaving a wall where a wall-jump still works. */
  wallCoyote: number;
  /** Seconds of continuous airborne wall contact (gates the wall-jump). */
  wallClingTime: number;
  /** True while a ground slam is in progress. */
  slamming: boolean;
  /** Charge built while slamming, drives shockwave size. */
  slamCharge: number;

  // --- Grappling hook --------------------------------------------------
  grappleActive: boolean;
  /** Anchor point in world pixels. */
  grappleX: number;
  grappleY: number;
  /** Current rope length. */
  ropeLen: number;
  /** 0..1 while the hook flies out. */
  grappleShoot: number;

  // --- Costume timers --------------------------------------------------
  /** Slow-motion costume. */
  timeSlowTimer: number;
  /** Coin magnet costume. */
  magnetTimer: number;
  /** Shadow / phase costume. */
  shadowTimer: number;
}

// ---------------------------------------------------------------------------
// Pets, relics and achievements
// ---------------------------------------------------------------------------

export type PetId = 'none' | 'sparky' | 'chirp' | 'bloop';

export interface PetDef {
  id: PetId;
  name: string;
  icon: string;
  cost: number;
  /** Highlights nearby relics and secret blocks. */
  findsSecrets: boolean;
  /** Automatically zaps weak enemies on a timer. */
  attacks: boolean;
  /** Extra coin magnet radius in px. */
  magnetBonus: number;
  color: string;
  blurb: string;
}

export const PETS: Record<PetId, PetDef> = {
  none: {
    id: 'none', name: 'NO PET', icon: '—', cost: 0, findsSecrets: false,
    attacks: false, magnetBonus: 0, color: '#64748b', blurb: 'Travel light.',
  },
  sparky: {
    id: 'sparky', name: 'SPARKY', icon: '⚡', cost: 900, findsSecrets: false,
    attacks: true, magnetBonus: 0, color: '#fbbf24',
    blurb: 'Zaps weak enemies that get too close.',
  },
  chirp: {
    id: 'chirp', name: 'CHIRP', icon: '🐦', cost: 1400, findsSecrets: true,
    attacks: false, magnetBonus: 0, color: '#38bdf8',
    blurb: 'Points out hidden relics and secret blocks.',
  },
  bloop: {
    id: 'bloop', name: 'BLOOP', icon: '🫧', cost: 2000, findsSecrets: true,
    attacks: false, magnetBonus: 90, color: '#c084fc',
    blurb: 'Finds secrets and pulls coins toward you.',
  },
};

export const PET_ORDER: PetId[] = ['none', 'sparky', 'chirp', 'bloop'];

/** A hidden collectible — one per level, tucked away off the main path. */
export interface Relic {
  x: number;
  y: number;
  collected: boolean;
  bob: number;
}

export interface AchievementDef {
  id: string;
  name: string;
  desc: string;
  icon: string;
  /** Progress needed to unlock. */
  goal: number;
}

export const ACHIEVEMENTS: AchievementDef[] = [
  { id: 'first_clear', name: 'FIRST STEPS', desc: 'Clear your first level', icon: '🏁', goal: 1 },
  { id: 'relics_10', name: 'TREASURE HUNTER', desc: 'Collect 10 relics', icon: '🏺', goal: 10 },
  { id: 'relics_50', name: 'CURATOR', desc: 'Collect 50 relics', icon: '🗿', goal: 50 },
  { id: 'coins_1000', name: 'COIN BARON', desc: 'Bank 1,000 coins', icon: '💰', goal: 1000 },
  { id: 'dash_100', name: 'BLUR', desc: 'Air-dash 100 times', icon: '💨', goal: 100 },
  { id: 'grapple_50', name: 'SWINGER', desc: 'Grapple 50 times', icon: '🪝', goal: 50 },
  { id: 'slam_50', name: 'EARTHSHAKER', desc: 'Ground slam 50 enemies', icon: '💥', goal: 50 },
  { id: 'wallrun_30', name: 'WALL CRAWLER', desc: 'Wall-run 30 times', icon: '🧗', goal: 30 },
  { id: 'puzzles_20', name: 'LOCKSMITH', desc: 'Open 20 puzzle gates', icon: '🔑', goal: 20 },
  { id: 'worlds_25', name: 'EXPLORER', desc: 'Discover 25 worlds', icon: '🌍', goal: 25 },
  { id: 'level_100', name: 'CENTURION', desc: 'Reach level 100', icon: '💯', goal: 100 },
  { id: 'level_1000', name: 'LEGEND', desc: 'Reach level 1000', icon: '👑', goal: 1000 },
];

export type Difficulty = 'easy' | 'medium' | 'hard' | 'nightmare';

export const DIFFICULTY_CONFIG: Record<
  Difficulty,
  {
    label: string;
    short: string;
    speed: number;
    aggroRange: number;
    hammerBros: boolean;
    throwInterval: number;
    /** Flying Lakitu that chases Mario and rains down Spinies. */
    lakitu: boolean;
    /** Seconds between Bullet Bill barrages (0 disables them). */
    bulletBillInterval: number;
    blurb: string;
  }
> = {
  easy: {
    label: 'EASY',
    short: 'CLASSIC',
    speed: 0.86,
    aggroRange: 0,
    hammerBros: false,
    throwInterval: 3.2,
    lakitu: false,
    bulletBillInterval: 0,
    blurb: 'Classic patrols. A relaxed tour of the Mushroom Kingdom.',
  },
  medium: {
    label: 'MEDIUM',
    short: '+GUARDS',
    speed: 1.04,
    aggroRange: 165,
    hammerBros: true,
    throwInterval: 2.15,
    lakitu: false,
    bulletBillInterval: 0,
    blurb: 'Extra NPC squads + hammer-throwing Hammer Bro guards. Stomp the guards from above!',
  },
  hard: {
    label: 'HARD',
    short: '+SPINY',
    speed: 1.16,
    aggroRange: 235,
    hammerBros: true,
    throwInterval: 1.5,
    lakitu: false,
    bulletBillInterval: 0,
    blurb: 'Hunting patrols plus spiked Spinies and reviving Dry Bones. Never stomp a Spiny!',
  },
  nightmare: {
    label: 'NIGHTMARE',
    short: '+LAKITU',
    speed: 1.28,
    aggroRange: 320,
    hammerBros: true,
    throwInterval: 1.1,
    lakitu: true,
    bulletBillInterval: 3.1,
    blurb: 'Lakitu hunts you from the sky raining Spinies while Bullet Bills scream across the map.',
  },
};

export const DIFFICULTY_ORDER: Difficulty[] = [
  'easy',
  'medium',
  'hard',
  'nightmare',
];

export type EnemyKind =
  | 'goomba'
  | 'koopa_green'
  | 'koopa_red'
  | 'buzzy'
  | 'piranha'
  | 'hammer_bro'
  | 'spiny'
  | 'dry_bones'
  | 'lakitu'
  | 'bullet_bill'
  // --- elite / ranged variants ---
  | 'fire_bro'
  | 'sniper_bro'
  | 'armored_goomba'
  // Multi-phase arena boss.
  | 'boss';

export type EnemyState =
  | 'walk'
  | 'shell_idle'
  | 'shell_spin'
  | 'squished'
  | 'flipped'
  | 'collapsed' // Dry Bones waiting to rebuild itself
  | 'frozen'; // Encased in ice by the Ice Flower

/** How an enemy fights back. */
export type EnemyAttack =
  | 'none'
  | 'contact'
  | 'hammer' // lobbed arc
  | 'fire' // straight fireball
  | 'spike' // dropped from above
  | 'spit' // fast short-range spit
  | 'bone' // thrown bone that arcs
  | 'laser'; // fast straight beam

export interface EnemyArchetype {
  kind: EnemyKind;
  name: string;
  /** Hit points — higher tier enemies soak more weapon damage. */
  hp: number;
  /** How much damage its attack/contact does to the player. */
  power: number;
  speed: number;
  attack: EnemyAttack;
  /** Seconds between ranged attacks. */
  attackRate: number;
  /** Horizontal range at which it will open fire. */
  attackRange: number;
  /** Stomping is useless (spikes/armour). */
  stompProof: boolean;
  /** Immune to fire-type weapons. */
  fireProof: boolean;
  /** Cannot be frozen. */
  freezeProof: boolean;
  score: number;
  /** Primary colour used for the HP pip bar and damage flashes. */
  tint: string;
  blurb: string;
}

export const ENEMY_STATS: Record<EnemyKind, EnemyArchetype> = {
  goomba: {
    kind: 'goomba', name: 'Goomba', hp: 1, power: 1, speed: 1, attack: 'contact',
    attackRate: 0, attackRange: 0, stompProof: false, fireProof: false,
    freezeProof: false, score: 100, tint: '#c84c0c',
    blurb: 'Basic shuffler. One stomp.',
  },
  koopa_green: {
    kind: 'koopa_green', name: 'Green Koopa', hp: 1, power: 1, speed: 1,
    attack: 'contact', attackRate: 0, attackRange: 0, stompProof: false,
    fireProof: false, freezeProof: false, score: 100, tint: '#1ec95b',
    blurb: 'Walks off ledges. Leaves a kickable shell.',
  },
  koopa_red: {
    kind: 'koopa_red', name: 'Red Koopa', hp: 2, power: 1, speed: 1.05,
    attack: 'contact', attackRate: 0, attackRange: 0, stompProof: false,
    fireProof: false, freezeProof: false, score: 200, tint: '#ef333f',
    blurb: 'Smarter: turns at ledges. Tougher shell.',
  },
  buzzy: {
    kind: 'buzzy', name: 'Buzzy Beetle', hp: 3, power: 1, speed: 0.95,
    attack: 'contact', attackRate: 0, attackRange: 0, stompProof: false,
    fireProof: true, freezeProof: false, score: 200, tint: '#2d3d73',
    blurb: 'Fireproof shell — use hammers, ice or bombs.',
  },
  piranha: {
    kind: 'piranha', name: 'Piranha Plant', hp: 2, power: 1, speed: 1,
    attack: 'spit', attackRate: 2.4, attackRange: 230, stompProof: true,
    fireProof: false, freezeProof: false, score: 200, tint: '#e82936',
    blurb: 'Spits venom from pipes. Never stompable.',
  },
  hammer_bro: {
    kind: 'hammer_bro', name: 'Hammer Bro', hp: 3, power: 1, speed: 1,
    attack: 'hammer', attackRate: 2.0, attackRange: 450, stompProof: false,
    fireProof: false, freezeProof: false, score: 600, tint: '#fff5df',
    blurb: 'Lobs hammers in an arc. Stomp from above.',
  },
  fire_bro: {
    kind: 'fire_bro', name: 'Fire Bro', hp: 4, power: 2, speed: 1.05,
    attack: 'fire', attackRate: 1.7, attackRange: 480, stompProof: false,
    fireProof: true, freezeProof: false, score: 900, tint: '#ff6b35',
    blurb: 'Shoots fireballs and shrugs off flames.',
  },
  spiny: {
    kind: 'spiny', name: 'Spiny', hp: 2, power: 1, speed: 1.15,
    attack: 'contact', attackRate: 0, attackRange: 0, stompProof: true,
    fireProof: false, freezeProof: false, score: 400, tint: '#e02424',
    blurb: 'Spiked shell — stomping hurts YOU.',
  },
  dry_bones: {
    kind: 'dry_bones', name: 'Dry Bones', hp: 3, power: 1, speed: 1,
    attack: 'bone', attackRate: 2.6, attackRange: 300, stompProof: false,
    fireProof: true, freezeProof: true, score: 500, tint: '#f3f6ff',
    blurb: 'Rebuilds itself and throws bones. Bombs end it.',
  },
  lakitu: {
    kind: 'lakitu', name: 'Lakitu', hp: 3, power: 1, speed: 1,
    attack: 'spike', attackRate: 2.5, attackRange: 999, stompProof: false,
    fireProof: false, freezeProof: false, score: 1200, tint: '#28c85a',
    blurb: 'Hovers out of reach raining Spinies.',
  },
  bullet_bill: {
    kind: 'bullet_bill', name: 'Bullet Bill', hp: 2, power: 1, speed: 1,
    attack: 'contact', attackRate: 0, attackRange: 0, stompProof: false,
    fireProof: true, freezeProof: true, score: 800, tint: '#1b1b24',
    blurb: 'Steel shell ignores fire and ice.',
  },
  sniper_bro: {
    kind: 'sniper_bro', name: 'Laser Bro', hp: 5, power: 2, speed: 0.9,
    attack: 'laser', attackRate: 2.2, attackRange: 620, stompProof: false,
    fireProof: false, freezeProof: false, score: 1500, tint: '#a855f7',
    blurb: 'Elite sniper with a long-range beam.',
  },
  boss: {
    kind: 'boss', name: 'Koopa Warlord', hp: 24, power: 2, speed: 1,
    attack: 'fire', attackRate: 1.4, attackRange: 900, stompProof: false,
    fireProof: true, freezeProof: true, score: 10000, tint: '#f97316',
    blurb: 'Arena boss. Changes tactics as its armour cracks.',
  },
  armored_goomba: {
    kind: 'armored_goomba', name: 'Iron Goomba', hp: 6, power: 2, speed: 0.78,
    attack: 'contact', attackRate: 0, attackRange: 0, stompProof: true,
    fireProof: true, freezeProof: false, score: 1000, tint: '#78716c',
    blurb: 'Walking tank. Only heavy weapons dent it.',
  },
};

export interface Enemy {
  id: number;
  kind: EnemyKind;
  state: EnemyState;
  x: number;
  y: number;
  vx: number;
  vy: number;
  width: number;
  height: number;
  facing: 1 | -1;
  onGround: boolean;
  animTimer: number;
  stateTimer: number;
  kickGraceTimer: number;
  shellCombo: number;
  throwCooldown: number;
  throwWindup: number;
  anchorY: number; // Used by Piranha Plants
  active: boolean;
  /** Remaining hit points (from ENEMY_STATS.hp). */
  hp: number;
  maxHp: number;
  /** Counts down after taking weapon damage (drives the white flash). */
  hitFlash: number;
  /** Seconds left frozen by an Ice Flower. */
  frozenTimer: number;
  /** Elite recolour variant index (0 = standard). */
  variant: number;
  /** Boss phase (1..3); 0 for normal enemies. */
  phase: number;
  /** Generic timer used by special AI (block kicks, boss attacks). */
  aiTimer: number;
  /** True while the enemy is winding up a block kick. */
  kicking: boolean;
}

/** A block an enemy has kicked at the player. */
export interface KickedBlock {
  id: number;
  x: number;
  y: number;
  vx: number;
  vy: number;
  rot: number;
  life: number;
  active: boolean;
}

/** One frame of recorded state for the rewind feature. */
export interface RewindFrame {
  px: number;
  py: number;
  vx: number;
  vy: number;
  facing: 1 | -1;
  power: PowerState;
  lives: number;
  score: number;
  camX: number;
  time: number;
}

/** A projectile fired BY an enemy AT the player. */
export interface EnemyProjectile {
  id: number;
  kind: EnemyAttack;
  x: number;
  y: number;
  vx: number;
  vy: number;
  gravity: number;
  rotation: number;
  rotSpeed: number;
  life: number;
  power: number;
  active: boolean;
}

/** A linked pair of enterable green pipes. */
export interface PipeWarp {
  /** Left column of the pipe mouth. */
  col: number;
  /** Row of the pipe lip. */
  row: number;
  /** Index into the level's warp list that this pipe leads to. */
  destIndex: number;
  /** Entered by pressing Down on top (vertical) or walking in (side). */
  orientation: 'top';
}

/** A floating weapon crate the player can collect. */
export interface WeaponPickup {
  id: number;
  weapon: WeaponKind;
  x: number;
  y: number;
  vy: number;
  bob: number;
  active: boolean;
}

export interface HammerProjectile {
  id: number;
  x: number;
  y: number;
  vx: number;
  vy: number;
  rotation: number;
  rotSpeed: number;
  life: number;
  active: boolean;
}

export type ItemKind =
  | 'mushroom' | 'fire_flower' | 'star' | 'one_up'
  | 'clock' | 'magnet' | 'shadow'
  // Rare drops from a 4-enemy stomp chain.
  | 'elixir' | 'secret_key';

export interface PowerItem {
  id: number;
  kind: ItemKind;
  x: number;
  y: number;
  vx: number;
  vy: number;
  width: number;
  height: number;
  emerging: boolean;
  emergeTargetY: number;
  animTimer: number;
  active: boolean;
}

export interface CoinEntity {
  id: number;
  x: number;
  y: number;
  collected: boolean;
  bobOffset: number;
}

export interface Fireball {
  id: number;
  x: number;
  y: number;
  vx: number;
  vy: number;
  bounces: number;
  life: number;
  active: boolean;
  /** Which weapon fired this shot. */
  weapon: WeaponKind;
  damage: number;
  rotation: number;
  /** Boomerang return phase. */
  returning: boolean;
  /** Enemy ids already hit (piercing shots only hit each enemy once). */
  hitIds: number[];
  /** Travel distance, used by returning weapons. */
  travelled: number;
}

export interface MovingPlatform {
  id: number;
  x: number;
  y: number;
  width: number;
  height: number;
  startX: number;
  startY: number;
  rangeX: number;
  rangeY: number;
  speed: number;
  phase: number;
  vx: number;
  vy: number;
}

export interface BlockBump {
  col: number;
  row: number;
  timer: number;
  duration: number;
  tile: TileType;
}

export type ParticleKind =
  | 'dust'
  | 'brick'
  | 'sparkle'
  | 'coin_pop'
  | 'flame'
  | 'ring'
  | 'firework';

export interface Particle {
  kind: ParticleKind;
  x: number;
  y: number;
  vx: number;
  vy: number;
  size: number;
  color: string;
  alpha: number;
  life: number;
  maxLife: number;
  gravity: number;
  rotation: number;
  rotSpeed: number;
}

export interface FloatingText {
  x: number;
  y: number;
  vy: number;
  text: string;
  color: string;
  life: number;
  maxLife: number;
  scale: number;
}

export interface LevelDefinition {
  index: number;
  worldLabel: string;
  subtitle: string;
  theme: WorldTheme;
  timeLimit: number;
  widthCols: number;
  heightRows: number;
  tiles: number[][];
  coins: Array<{ col: number; row: number }>;
  enemies: Array<{ kind: EnemyKind; col: number; row: number }>;
  platforms: Array<{
    col: number;
    row: number;
    widthTiles: number;
    rangeCols: number;
    rangeRows: number;
    speed: number;
    phase?: number;
  }>;
  flagCol: number;
  castleCol: number;
  /** Mid-level respawn columns, ascending. */
  checkpoints: number[];
  /** Hidden collectible position (tile coords). */
  relic: { col: number; row: number } | null;
  /** Buttons wired to gates: pressing every button opens them all. */
  puzzle: {
    buttons: Array<{ col: number; row: number }>;
    gates: Array<{ col: number; row: number }>;
  } | null;
  /** Linked enterable green pipes. */
  warps: PipeWarp[];
  /** Weapon crates scattered through the map. */
  weaponCrates: Array<{ col: number; row: number; weapon: WeaponKind }>;
  /** Short description of the theme's signature parkour obstacle. */
  hazardLabel: string;
}

export interface HudSnapshot {
  screen: GameScreen;
  score: number;
  highScore: number;
  coins: number;
  lives: number;
  worldLabel: string;
  worldSubtitle: string;
  levelIndex: number;
  loopCount: number;
  timeRemaining: number;
  power: PowerState;
  starActive: boolean;
  maxCombo: number;
  stageBonus: number;
  timeBonus: number;
  difficulty: Difficulty;
  levelNumber: number;
  themeName: string;
  themeIcon: string;
  themeAccent: string;
  /** Character being played this run. */
  character: CharacterId;
  /** Coins banked across all runs (the shop currency). */
  bankedCoins: number;
  /** True while test-driving a character that has not been bought. */
  demoMode: boolean;
  /** This map's world is being visited for the first time. */
  freshDiscovery: boolean;
  /** Human readable weather for this level, e.g. "TYPHOON". */
  weatherLabel: string;
  /** Costume timers, in seconds (0 = inactive). */
  timeSlow: number;
  magnet: number;
  shadow: number;
  /** Dash charges left right now. */
  dashCharges: number;
  /** True when the level's relic has been picked up. */
  relicFound: boolean;
  /** Equipped pet. */
  pet: PetId;
  /** Night levels make enemies bolder and open secret routes. */
  isNight: boolean;
  /** Current no-touch-ground stomp chain. */
  stompChain: number;
  /** Rewind charges left this run. */
  rewinds: number;
  /** True while the rewind animation is playing. */
  rewinding: boolean;
  /** Boss HP ratio 0..1, or -1 when there is no boss. */
  bossHp: number;
  bossPhase: number;
  /** Today's daily-challenge level number. */
  dailyLevel: number;
  /** True when the current run is the daily challenge. */
  isDaily: boolean;
  /** Slippery floors (rain / snow / night ice). */
  slippery: boolean;
  /** When that weather is active, e.g. "FROM MIDWAY". */
  weatherSchedule: string;
  tierName: string;
  tierColor: string;
  hazardLabel: string;
  /** Currently equipped weapon (null = none owned yet). */
  weapon: WeaponKind | null;
  /** Ammo for the equipped weapon (-1 = unlimited). */
  weaponAmmo: number;
  /** Every weapon the player has collected this run, in order. */
  ownedWeapons: WeaponKind[];
  /** Ammo per owned weapon. */
  weaponAmmoMap: Partial<Record<WeaponKind, number>>;
  /** Index of the reached checkpoint (-1 = none yet). */
  checkpointIndex: number;
  /** Total checkpoints on the current map. */
  checkpointTotal: number;
  soundEnabled: boolean;
  musicEnabled: boolean;
}

export interface HighScoreEntry {
  id: string;
  initials: string;
  score: number;
  coins: number;
  world: string;
  date: string;
}
