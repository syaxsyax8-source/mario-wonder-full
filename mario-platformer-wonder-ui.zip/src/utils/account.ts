/**
 * Player accounts — username + password, stored on the device.
 *
 * There is no Google sign-in: real OAuth needs a server to hold the client
 * secret and verify tokens, and this game ships as one offline HTML file
 * (and inside an APK) with no backend. A username/password profile gives the
 * same practical benefits without pretending to be something it is not:
 *
 *   - Several people can share one device, each with their own save.
 *   - Logging back in restores that player's progress.
 *   - A sync code carries an account to another device.
 *
 * Passwords are salted and hashed with SHA-256 before being stored, so the
 * raw password is never written to disk.
 */

const ACTIVE_KEY = 'smb_active_account_v1';
const USERS_KEY = 'smb_users_v1';

export type AccountKind = 'guest' | 'local';

export interface Account {
  kind: AccountKind;
  /** Display name (also the login username for 'local' accounts). */
  name: string;
  id: string;
  createdAt: number;
}

interface StoredUser {
  name: string;
  id: string;
  salt: string;
  hash: string;
  createdAt: number;
  /** That player's save, swapped in when they log in. */
  save?: Record<string, string>;
}

/** Save keys that belong to a player's progress. */
const SAVE_KEYS = [
  'smb_banked_coins_v1',
  'smb_owned_chars_v1',
  'smb_selected_char_v1',
  'smb_unlocked_level_v1',
  'smb_cleared_levels_v1',
  'smb_discovered_biomes_v1',
  'smb_achievements_v1',
  'smb_pet_v1',
  'smb_pets_owned_v1',
  'smb_bestiary_v1',
  'smb_daily_v1',
  'smb_arcade_highscores_v1',
];

// ---------------------------------------------------------------------------
// Storage helpers
// ---------------------------------------------------------------------------

function readUsers(): StoredUser[] {
  try {
    const raw = localStorage.getItem(USERS_KEY);
    const list = raw ? (JSON.parse(raw) as StoredUser[]) : [];
    return Array.isArray(list) ? list : [];
  } catch {
    return [];
  }
}

function writeUsers(list: StoredUser[]): void {
  try {
    localStorage.setItem(USERS_KEY, JSON.stringify(list));
  } catch {
    // Ignore quota / private-mode failures.
  }
}

function randomId(): string {
  return (
    Date.now().toString(36) + Math.random().toString(36).slice(2, 8)
  ).toUpperCase();
}

function randomSalt(): string {
  const a = new Uint8Array(12);
  crypto.getRandomValues(a);
  return Array.from(a, (b) => b.toString(16).padStart(2, '0')).join('');
}

/** Salted SHA-256. Falls back to a simple digest if WebCrypto is missing. */
async function hashPassword(pw: string, salt: string): Promise<string> {
  const data = new TextEncoder().encode(`${salt}:${pw}`);
  if (crypto?.subtle?.digest) {
    const buf = await crypto.subtle.digest('SHA-256', data);
    return Array.from(new Uint8Array(buf), (b) =>
      b.toString(16).padStart(2, '0')
    ).join('');
  }
  // Non-secure fallback for exotic WebViews — still never stores the raw text.
  let h = 5381;
  for (let i = 0; i < data.length; i++) h = ((h << 5) + h + data[i]) >>> 0;
  return `fallback${h.toString(16)}`;
}

function normaliseName(name: string): string {
  return name.trim().toUpperCase().slice(0, 14);
}

// ---------------------------------------------------------------------------
// Save slots
// ---------------------------------------------------------------------------

function snapshotSave(): Record<string, string> {
  const out: Record<string, string> = {};
  for (const k of SAVE_KEYS) {
    try {
      const v = localStorage.getItem(k);
      if (v !== null) out[k] = v;
    } catch {
      // Skip unreadable keys.
    }
  }
  return out;
}

function restoreSave(save: Record<string, string> | undefined): void {
  for (const k of SAVE_KEYS) {
    try {
      if (save && typeof save[k] === 'string') localStorage.setItem(k, save[k]);
      else localStorage.removeItem(k);
    } catch {
      // Ignore storage failures.
    }
  }
}

/** Persist the current progress into whichever account is signed in. */
export function syncActiveSave(): void {
  const acc = loadAccount();
  if (!acc || acc.kind !== 'local') return;
  const users = readUsers();
  const u = users.find((x) => x.id === acc.id);
  if (!u) return;
  u.save = snapshotSave();
  writeUsers(users);
}

// ---------------------------------------------------------------------------
// Session
// ---------------------------------------------------------------------------

export function loadAccount(): Account | null {
  try {
    const raw = localStorage.getItem(ACTIVE_KEY);
    if (!raw) return null;
    const a = JSON.parse(raw) as Account;
    return a && a.kind ? a : null;
  } catch {
    return null;
  }
}

function setActive(a: Account | null): void {
  try {
    if (a) localStorage.setItem(ACTIVE_KEY, JSON.stringify(a));
    else localStorage.removeItem(ACTIVE_KEY);
  } catch {
    // Ignore storage failures.
  }
}

/** Every registered username on this device. */
export function listAccounts(): string[] {
  return readUsers().map((u) => u.name);
}

export function hasAccounts(): boolean {
  return readUsers().length > 0;
}

export interface AuthResult {
  ok: boolean;
  account?: Account;
  error?: string;
}

/** Create a new username/password profile and sign into it. */
export async function registerAccount(
  username: string,
  password: string
): Promise<AuthResult> {
  const name = normaliseName(username);
  if (name.length < 3) {
    return { ok: false, error: 'Username needs at least 3 characters.' };
  }
  if (password.length < 4) {
    return { ok: false, error: 'Password needs at least 4 characters.' };
  }

  const users = readUsers();
  if (users.some((u) => u.name === name)) {
    return { ok: false, error: 'That username is already taken on this device.' };
  }

  // Keep the progress made before signing up rather than wiping it.
  const carried = snapshotSave();

  const salt = randomSalt();
  const user: StoredUser = {
    name,
    id: randomId(),
    salt,
    hash: await hashPassword(password, salt),
    createdAt: Date.now(),
    save: carried,
  };
  users.push(user);
  writeUsers(users);

  const acc: Account = {
    kind: 'local',
    name,
    id: user.id,
    createdAt: user.createdAt,
  };
  setActive(acc);
  return { ok: true, account: acc };
}

/** Sign into an existing profile and load its save. */
export async function loginAccount(
  username: string,
  password: string
): Promise<AuthResult> {
  const name = normaliseName(username);
  const users = readUsers();
  const user = users.find((u) => u.name === name);
  if (!user) {
    return { ok: false, error: 'No account with that username on this device.' };
  }
  const hash = await hashPassword(password, user.salt);
  if (hash !== user.hash) {
    return { ok: false, error: 'Wrong password.' };
  }

  // Park the outgoing player's progress before swapping saves.
  syncActiveSave();
  restoreSave(user.save);

  const acc: Account = {
    kind: 'local',
    name: user.name,
    id: user.id,
    createdAt: user.createdAt,
  };
  setActive(acc);
  return { ok: true, account: acc };
}

/** Change the password of the signed-in account. */
export async function changePassword(
  oldPw: string,
  newPw: string
): Promise<AuthResult> {
  const acc = loadAccount();
  if (!acc || acc.kind !== 'local') {
    return { ok: false, error: 'Not signed in.' };
  }
  if (newPw.length < 4) {
    return { ok: false, error: 'Password needs at least 4 characters.' };
  }
  const users = readUsers();
  const u = users.find((x) => x.id === acc.id);
  if (!u) return { ok: false, error: 'Account not found.' };
  if ((await hashPassword(oldPw, u.salt)) !== u.hash) {
    return { ok: false, error: 'Current password is wrong.' };
  }
  u.salt = randomSalt();
  u.hash = await hashPassword(newPw, u.salt);
  writeUsers(users);
  return { ok: true, account: acc };
}

export function signOut(): void {
  syncActiveSave();
  setActive(null);
}

// ---------------------------------------------------------------------------
// Moving an account to another device
// ---------------------------------------------------------------------------

/**
 * Pack the signed-in account (credentials + progress) into a sync code.
 * Paste it on another device to sign in there with the same username and
 * password. Without a server this is how progress travels.
 */
export function exportSave(): string {
  syncActiveSave();
  const acc = loadAccount();
  const users = readUsers();
  const user = acc ? users.find((u) => u.id === acc.id) : undefined;

  const payload = user
    ? { v: 2, user }
    : { v: 2, anon: snapshotSave() };

  return btoa(unescape(encodeURIComponent(JSON.stringify(payload))));
}

/** Restore a sync code produced by exportSave. */
export function importSave(code: string): boolean {
  try {
    const json = decodeURIComponent(escape(atob(code.trim())));
    const data = JSON.parse(json) as {
      v?: number;
      user?: StoredUser;
      anon?: Record<string, string>;
    } & Record<string, string>;

    // v2: a full account record.
    if (data && data.v === 2 && data.user) {
      const users = readUsers().filter((u) => u.name !== data.user!.name);
      users.push(data.user);
      writeUsers(users);
      restoreSave(data.user.save);
      setActive({
        kind: 'local',
        name: data.user.name,
        id: data.user.id,
        createdAt: data.user.createdAt,
      });
      return true;
    }
    if (data && data.v === 2 && data.anon) {
      restoreSave(data.anon);
      return true;
    }

    // v1 codes were a flat key/value map of save keys.
    let wrote = 0;
    for (const k of SAVE_KEYS) {
      if (typeof data[k] === 'string') {
        localStorage.setItem(k, data[k]);
        wrote++;
      }
    }
    return wrote > 0;
  } catch {
    return false;
  }
}
