import { ACHIEVEMENTS } from '../game/types';

const KEY = 'smb_achievements_v1';
const PET_KEY = 'smb_pet_v1';
const PETS_OWNED_KEY = 'smb_pets_owned_v1';

export interface AchProgress {
  [id: string]: number;
}

let cache: AchProgress | null = null;

export function loadProgress(): AchProgress {
  if (cache) return cache;
  try {
    cache = JSON.parse(localStorage.getItem(KEY) || '{}') as AchProgress;
  } catch {
    cache = {};
  }
  return cache;
}

function save(p: AchProgress): void {
  cache = p;
  try {
    localStorage.setItem(KEY, JSON.stringify(p));
  } catch {
    // Ignore storage failures.
  }
}

/**
 * Raise a counter to at least `value` and report any achievements that
 * crossed their goal as a result, so the UI can celebrate them.
 */
export function reportProgress(stats: AchProgress): string[] {
  const p = loadProgress();
  const newly: string[] = [];
  for (const def of ACHIEVEMENTS) {
    const next = stats[def.id];
    if (next === undefined) continue;
    const prev = p[def.id] ?? 0;
    if (next <= prev) continue;
    if (prev < def.goal && next >= def.goal) newly.push(def.id);
    p[def.id] = next;
  }
  if (newly.length || Object.keys(stats).length) save(p);
  return newly;
}

export function isUnlocked(id: string): boolean {
  const def = ACHIEVEMENTS.find((a) => a.id === id);
  if (!def) return false;
  return (loadProgress()[id] ?? 0) >= def.goal;
}

export function unlockedCount(): number {
  return ACHIEVEMENTS.filter((a) => isUnlocked(a.id)).length;
}

// --- pets -------------------------------------------------------------

export function loadOwnedPets(): string[] {
  try {
    const raw = localStorage.getItem(PETS_OWNED_KEY);
    const list = raw ? (JSON.parse(raw) as string[]) : [];
    return list.includes('none') ? list : ['none', ...list];
  } catch {
    return ['none'];
  }
}

export function buyPet(id: string): void {
  const owned = loadOwnedPets();
  if (owned.includes(id)) return;
  try {
    localStorage.setItem(PETS_OWNED_KEY, JSON.stringify([...owned, id]));
  } catch {
    // Ignore storage failures.
  }
}

export function loadPet(): string {
  try {
    return localStorage.getItem(PET_KEY) || 'none';
  } catch {
    return 'none';
  }
}

export function savePet(id: string): void {
  try {
    localStorage.setItem(PET_KEY, id);
  } catch {
    // Ignore storage failures.
  }
}
