import { ENEMY_STATS, EnemyKind, ItemKind } from '../game/types';

const KEY = 'smb_bestiary_v1';

interface BestiaryData {
  enemies: Record<string, number>;
  items: Record<string, number>;
}

let cache: BestiaryData | null = null;

function load(): BestiaryData {
  if (cache) return cache;
  try {
    const raw = localStorage.getItem(KEY);
    cache = raw ? (JSON.parse(raw) as BestiaryData) : { enemies: {}, items: {} };
    if (!cache.enemies) cache.enemies = {};
    if (!cache.items) cache.items = {};
  } catch {
    cache = { enemies: {}, items: {} };
  }
  return cache;
}

function persist(): void {
  try {
    localStorage.setItem(KEY, JSON.stringify(load()));
  } catch {
    // Ignore storage failures.
  }
}

export function recordEnemy(kind: EnemyKind, n = 1): void {
  const d = load();
  d.enemies[kind] = (d.enemies[kind] ?? 0) + n;
  persist();
}

export function recordItem(kind: ItemKind): void {
  const d = load();
  d.items[kind] = (d.items[kind] ?? 0) + 1;
  persist();
}

export function enemyKills(kind: EnemyKind): number {
  return load().enemies[kind] ?? 0;
}

export function itemFinds(kind: ItemKind): number {
  return load().items[kind] ?? 0;
}

export function discoveredEnemies(): number {
  return Object.values(load().enemies).filter((v) => v > 0).length;
}

export function totalEnemyKinds(): number {
  return Object.keys(ENEMY_STATS).length;
}

/** Tongue-in-cheek flavour text, shown once an entry is discovered. */
export const ENEMY_LORE: Record<string, string> = {
  goomba: 'Walks left. Thinks about it. Keeps walking left.',
  koopa_green: 'Marches off cliffs with total confidence.',
  koopa_red: 'The one who actually looks where it is going.',
  buzzy: 'Fireproof helmet. Smug about it.',
  piranha: 'Lives in a pipe. Pays no rent.',
  hammer_bro: 'Brought infinite hammers but no toolbox.',
  fire_bro: 'Hammer Bro who discovered matches.',
  spiny: 'Please stop stepping on it. It is all spikes.',
  dry_bones: 'Refuses to stay defeated. Admirable, really.',
  lakitu: 'Floats above your problems and adds more.',
  bullet_bill: 'Has one idea and commits fully.',
  sniper_bro: 'Bought a laser. Reads the manual mid-fight.',
  armored_goomba: 'A goomba in a tank. Still thinks about walking left.',
  boss: 'Koopa Warlord. Changes tactics when the armour cracks.',
};

export const ITEM_LORE: Record<string, string> = {
  mushroom: 'Doubles your height and your confidence.',
  fire_flower: 'A flower that solves problems with fire.',
  star: 'Brief invincibility, permanent swagger.',
  one_up: 'A spare life, kept in a green mushroom.',
  clock: 'Slows the world. You stay exactly as fast.',
  magnet: 'Coins come to you. As they should.',
  shadow: 'Walk through walls. Briefly. Carefully.',
  elixir: 'Rare stomp-chain reward. Heals and refills rewind.',
  secret_key: 'Opens whatever the relic was hiding.',
};

export const ITEM_NAMES: Record<string, string> = {
  mushroom: 'Super Mushroom', fire_flower: 'Fire Flower', star: 'Super Star',
  one_up: '1-UP Mushroom', clock: 'Time Clock', magnet: 'Coin Magnet',
  shadow: 'Shadow Cloak', elixir: 'Rare Elixir', secret_key: 'Secret Key',
};
