import { BIOMES } from '../game/biomes';

const KEY = 'smb_discovered_biomes_v1';

/**
 * Tracks which of the 100 worlds the player has actually set foot in.
 * Gives a long-term collection goal on top of the level counter.
 */
let cache: Set<string> | null = null;

export function loadDiscovered(): Set<string> {
  if (cache) return cache;
  try {
    const raw = localStorage.getItem(KEY);
    cache = raw ? new Set(JSON.parse(raw) as string[]) : new Set();
  } catch {
    cache = new Set();
  }
  return cache;
}

/** Returns true when this biome was seen for the very first time. */
export function discover(biomeId: string): boolean {
  const set = loadDiscovered();
  if (set.has(biomeId)) return false;
  set.add(biomeId);
  try {
    localStorage.setItem(KEY, JSON.stringify([...set]));
  } catch {
    // Ignore storage failures — the run still works.
  }
  return true;
}

export function discoveredCount(): number {
  return loadDiscovered().size;
}

export const TOTAL_BIOMES = BIOMES.length;
