import { HighScoreEntry } from '../game/types';

const STORAGE_KEY = 'smb_arcade_highscores_v1';
const INITIALS_KEY = 'smb_arcade_last_initials_v1';

const DEFAULT_SCORES: HighScoreEntry[] = [
  {
    id: 'seed-1',
    initials: 'MAR',
    score: 28500,
    coins: 42,
    world: '1-3',
    date: '1985',
  },
  {
    id: 'seed-2',
    initials: 'LUI',
    score: 19400,
    coins: 31,
    world: '1-2',
    date: '1985',
  },
  {
    id: 'seed-3',
    initials: 'PEA',
    score: 14200,
    coins: 24,
    world: '1-2',
    date: '1985',
  },
  {
    id: 'seed-4',
    initials: 'TOA',
    score: 9600,
    coins: 18,
    world: '1-1',
    date: '1985',
  },
  {
    id: 'seed-5',
    initials: 'BOW',
    score: 5200,
    coins: 11,
    world: '1-1',
    date: '1985',
  },
];

export function loadHighScores(): HighScoreEntry[] {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(DEFAULT_SCORES));
      return [...DEFAULT_SCORES];
    }
    const parsed = JSON.parse(raw) as HighScoreEntry[];
    if (!Array.isArray(parsed) || parsed.length === 0) {
      return [...DEFAULT_SCORES];
    }
    return parsed
      .sort((a, b) => b.score - a.score)
      .slice(0, 7);
  } catch {
    return [...DEFAULT_SCORES];
  }
}

export function getTopScore(): number {
  const scores = loadHighScores();
  return scores.length > 0 ? scores[0].score : 10000;
}

export function isQualifyingHighScore(score: number): boolean {
  if (score <= 0) return false;
  const scores = loadHighScores();
  if (scores.length < 7) return true;
  return score > scores[scores.length - 1].score;
}

export function saveHighScore(entry: Omit<HighScoreEntry, 'id' | 'date'>): {
  scores: HighScoreEntry[];
  insertedId: string;
} {
  const scores = loadHighScores();
  const cleanInitials =
    entry.initials
      .toUpperCase()
      .replace(/[^A-Z0-9]/g, '')
      .slice(0, 3) || 'PL1';

  const newEntry: HighScoreEntry = {
    id: `hs-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`,
    initials: cleanInitials.padEnd(3, 'A').slice(0, 3),
    score: Math.floor(entry.score),
    coins: entry.coins,
    world: entry.world,
    date: new Date().toLocaleDateString(undefined, {
      month: 'short',
      day: 'numeric',
    }),
  };

  const merged = [...scores, newEntry]
    .sort((a, b) => b.score - a.score)
    .slice(0, 7);

  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(merged));
    localStorage.setItem(INITIALS_KEY, newEntry.initials);
  } catch {
    // Ignore storage quota errors in restricted environments
  }

  return { scores: merged, insertedId: newEntry.id };
}

export function loadLastInitials(): string {
  try {
    return localStorage.getItem(INITIALS_KEY) || 'MRO';
  } catch {
    return 'MRO';
  }
}
