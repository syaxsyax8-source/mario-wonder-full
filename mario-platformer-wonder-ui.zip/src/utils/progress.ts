import { TOTAL_LEVELS } from '../game/types';

const UNLOCKED_KEY = 'smb_unlocked_level_v1';
const CLEARED_KEY = 'smb_cleared_levels_v1';

/** Highest level the player is allowed to start from. */
export function loadUnlockedLevel(): number {
  try {
    const raw = localStorage.getItem(UNLOCKED_KEY);
    const n = raw ? parseInt(raw, 10) : 1;
    if (!Number.isFinite(n)) return 1;
    return Math.max(1, Math.min(TOTAL_LEVELS, n));
  } catch {
    return 1;
  }
}

export function unlockLevel(level: number): number {
  const target = Math.max(1, Math.min(TOTAL_LEVELS, Math.floor(level)));
  const current = loadUnlockedLevel();
  if (target <= current) return current;
  try {
    localStorage.setItem(UNLOCKED_KEY, String(target));
  } catch {
    // Ignore storage errors (private mode / quota).
  }
  return target;
}

/** Set of cleared level numbers, stored compactly as a sorted CSV. */
export function loadClearedLevels(): Set<number> {
  try {
    const raw = localStorage.getItem(CLEARED_KEY);
    if (!raw) return new Set();
    return new Set(
      raw
        .split(',')
        .map((v) => parseInt(v, 10))
        .filter((v) => Number.isFinite(v))
    );
  } catch {
    return new Set();
  }
}

export function markLevelCleared(level: number): Set<number> {
  const cleared = loadClearedLevels();
  cleared.add(Math.floor(level));
  try {
    // Keep only the most recent 4000 entries so storage never balloons.
    const list = [...cleared].sort((a, b) => a - b).slice(-4000);
    localStorage.setItem(CLEARED_KEY, list.join(','));
    return new Set(list);
  } catch {
    return cleared;
  }
}

export function resetProgress(): void {
  try {
    localStorage.removeItem(UNLOCKED_KEY);
    localStorage.removeItem(CLEARED_KEY);
  } catch {
    // Ignore storage errors.
  }
}
