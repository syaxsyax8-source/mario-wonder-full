import { CharacterId, CHARACTERS } from '../game/types';

const COINS_KEY = 'smb_banked_coins_v1';
const OWNED_KEY = 'smb_owned_chars_v1';
const SELECTED_KEY = 'smb_selected_char_v1';

/**
 * Coins are the shop currency and must survive closing the game.
 *
 * Writing to localStorage on every single coin pickup caused a synchronous
 * disk write inside the 60fps loop, so instead the balance is held in memory
 * and flushed on a short timer plus on every "page is going away" signal
 * (pagehide / visibilitychange / freeze / beforeunload). That keeps the hot
 * path allocation-free while guaranteeing the balance is never lost.
 */
let cachedCoins: number | null = null;
let pendingFlush = false;
let flushTimer: ReturnType<typeof setTimeout> | null = null;

function readCoinsFromStorage(): number {
  try {
    const n = parseInt(localStorage.getItem(COINS_KEY) || '0', 10);
    return Number.isFinite(n) && n >= 0 ? n : 0;
  } catch {
    return 0;
  }
}

/** Write the in-memory balance straight through to storage. */
export function flushCoins(): void {
  if (!pendingFlush || cachedCoins === null) return;
  try {
    localStorage.setItem(COINS_KEY, String(cachedCoins));
    pendingFlush = false;
  } catch {
    // Quota / private mode: keep the pending flag so a later attempt retries.
  }
}

function scheduleFlush(): void {
  pendingFlush = true;
  if (flushTimer !== null) return;
  flushTimer = setTimeout(() => {
    flushTimer = null;
    flushCoins();
  }, 400);
}

/** Install the save-on-exit guards. Safe to call more than once. */
let guardsInstalled = false;
export function installWalletGuards(): void {
  if (guardsInstalled || typeof window === 'undefined') return;
  guardsInstalled = true;

  const save = () => flushCoins();
  // pagehide covers mobile app-switching; visibilitychange covers tab hide;
  // beforeunload covers desktop close. Any one of them is enough.
  window.addEventListener('pagehide', save);
  window.addEventListener('beforeunload', save);
  window.addEventListener('blur', save);
  document.addEventListener('visibilitychange', () => {
    if (document.visibilityState === 'hidden') save();
  });
  // Chrome/Android can "freeze" a backgrounded page.
  window.addEventListener('freeze', save);
}

export function loadCoins(): number {
  if (cachedCoins === null) cachedCoins = readCoinsFromStorage();
  return cachedCoins;
}

export function addCoins(amount: number): number {
  const next = Math.max(
    0,
    Math.min(9_999_999, loadCoins() + Math.floor(amount))
  );
  cachedCoins = next;
  scheduleFlush();
  return next;
}

export function spendCoins(amount: number): boolean {
  const have = loadCoins();
  if (have < amount) return false;
  cachedCoins = have - amount;
  pendingFlush = true;
  // Purchases are important enough to persist immediately.
  flushCoins();
  return true;
}

export function loadOwnedCharacters(): CharacterId[] {
  try {
    const raw = localStorage.getItem(OWNED_KEY);
    if (!raw) return ['mario'];
    const list = JSON.parse(raw) as CharacterId[];
    const valid = Array.isArray(list)
      ? list.filter((c) => c in CHARACTERS)
      : [];
    return valid.includes('mario') ? valid : ['mario', ...valid];
  } catch {
    return ['mario'];
  }
}

export function buyCharacter(id: CharacterId): {
  ok: boolean;
  owned: CharacterId[];
  coins: number;
  reason?: string;
} {
  const owned = loadOwnedCharacters();
  if (owned.includes(id)) {
    return { ok: false, owned, coins: loadCoins(), reason: 'already owned' };
  }
  const def = CHARACTERS[id];
  if (!def) return { ok: false, owned, coins: loadCoins(), reason: 'unknown' };
  if (!spendCoins(def.cost)) {
    return { ok: false, owned, coins: loadCoins(), reason: 'not enough coins' };
  }
  const next = [...owned, id];
  try {
    localStorage.setItem(OWNED_KEY, JSON.stringify(next));
  } catch {
    // Ignore storage failures.
  }
  return { ok: true, owned: next, coins: loadCoins() };
}

export function loadSelectedCharacter(): CharacterId {
  try {
    const id = localStorage.getItem(SELECTED_KEY) as CharacterId | null;
    if (id && id in CHARACTERS && loadOwnedCharacters().includes(id)) return id;
  } catch {
    // Fall through to the default.
  }
  return 'mario';
}

export function saveSelectedCharacter(id: CharacterId): void {
  try {
    localStorage.setItem(SELECTED_KEY, id);
  } catch {
    // Ignore storage failures.
  }
}
