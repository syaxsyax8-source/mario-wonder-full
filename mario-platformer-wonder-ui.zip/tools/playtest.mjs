/**
 * Headless play-test bot.
 *
 * Drives the real engine with a simple "run right, jump at obstacles" AI and
 * reports how far it gets. Any level where the bot stalls against a wall is a
 * strong signal that a human would be blocked too.
 *
 *   node tools/playtest.mjs [count] [difficulty] [seedStride]
 */
globalThis.window = { setInterval: () => 0, clearInterval: () => {} };
globalThis.localStorage = { getItem: () => null, setItem: () => {} };

const { MarioGameEngine } = await import('/tmp/eng.mjs');

const TILE = 32;
const count = Number(process.argv[2] || 40);
const difficulty = process.argv[3] || 'medium';
const stride = Number(process.argv[4] || 197);

const engine = new MarioGameEngine();

// `godMode` isolates level geometry from combat/time pressure so a stall
// can only mean the terrain itself is impassable.
function playLevel(levelNumber, seconds = 120, godMode = true) {
  engine.startNewGame(levelNumber - 1, difficulty);
  engine.lives = 999; // we are testing geometry, not combat
  const flagX = engine.levelDef.flagCol * TILE;

  let bestX = 0;
  let stalledFrames = 0;
  let lastX = -1;
  let jumpHeld = false;
  let errors = 0;
  let deaths = 0;
  let wasDead = false;
  const deathCols = [];

  const frames = Math.round(seconds * 60);
  for (let f = 0; f < frames; f++) {
    const p = engine.player;

    // --- reactive AI -----------------------------------------------------
    const footRow = Math.floor((p.y + p.height - 2) / TILE);
    const rightEdge = p.x + p.width;

    // Look ahead proportionally to speed so jumps start in time.
    const lookPx = Math.max(26, Math.abs(p.vx) * 0.38 + 20);
    const lookCol = Math.floor((rightEdge + lookPx) / TILE);
    const nearCol = Math.floor((rightEdge + 6) / TILE);

    const solidAt = (c, r) => engine.isSolidTile(engine.getTile(c, r));

    // Wall directly ahead (needs a climb)?
    let wallAhead = false;
    for (let r = footRow; r > footRow - 4; r--) {
      if (solidAt(nearCol, r)) { wallAhead = true; break; }
    }

    // Gap ahead within the look-ahead window?
    let holeAhead = false;
    for (let c = nearCol; c <= lookCol; c++) {
      let floor = false;
      for (let r = footRow + 1; r < 15; r++) {
        if (engine.isSolidTile(engine.getTile(c, r)) ||
            engine.getTile(c, r) === 16 || engine.getTile(c, r) === 26) {
          floor = true; break;
        }
      }
      if (!floor) { holeAhead = true; break; }
    }

    // Vine handling: grab and climb when one is in reach.
    const vineCol = Math.floor((p.x + p.width / 2) / TILE);
    const onVine =
      engine.getTile(vineCol, Math.floor((p.y + 6) / TILE)) === 25 ||
      engine.getTile(vineCol, Math.floor((p.y + p.height / 2) / TILE)) === 25;

    const stuck = stalledFrames > 10;
    const wantJump = (wallAhead || holeAhead || stuck) && p.onGround;
    if (wantJump) jumpHeld = true;
    if (p.vy > 60) jumpHeld = false;

    const input = {
      left: false,
      right: !onVine || p.y < 7 * TILE,
      up: onVine && p.y > 6.5 * TILE,
      down: false,
      jumpHeld,
      jumpPressed: wantJump,
      runHeld: true,
      firePressed: f % 53 === 0,
    };

    if (godMode) {
      engine.player.starTimer = 30;   // ignore enemies
      engine.timeRemaining = 400;     // ignore the clock
    }
    try { engine.step(1 / 60, input); } catch { errors++; }

    if (engine.player.dead && !wasDead) {
      deaths++;
      deathCols.push(Math.round(engine.player.x / TILE));
    }
    wasDead = engine.player.dead;

    bestX = Math.max(bestX, engine.player.x);
    if (Math.abs(engine.player.x - lastX) < 0.4) stalledFrames++;
    else stalledFrames = 0;
    lastX = engine.player.x;

    if (engine.screen === 'stage_clear' || engine.screen === 'playing') {
      if (engine.player.x >= flagX - 8 || engine.screen === 'stage_clear') {
        return { cleared: true, pct: 100, errors, deaths, col: engine.levelDef.flagCol };
      }
    }
    if (engine.screen === 'gameover') break;
  }

  return {
    cleared: false,
    pct: Math.round((bestX / flagX) * 100),
    errors,
    deaths,
    deathCols: deathCols.slice(-6),
    col: Math.round(bestX / TILE),
    flagCol: engine.levelDef.flagCol,
    theme: engine.levelDef.theme,
  };
}

let cleared = 0;
const stuckLevels = [];
let totalErrors = 0;

for (let i = 0; i < count; i++) {
  const lv = 1 + i * stride;
  if (lv > 8000) break;
  const r = playLevel(lv);
  totalErrors += r.errors;
  if (r.cleared) cleared++;
  else stuckLevels.push(
      `lv${lv} ${r.theme} reached ${r.pct}% (col ${r.col}/${r.flagCol}) ` +
      `deaths=${r.deaths} at cols [${(r.deathCols || []).join(',')}]`
    );
}

console.log(`bot play-test: ${difficulty}, ${count} levels`);
console.log(`cleared: ${cleared}/${count}`);
console.log(`engine errors: ${totalErrors}`);
if (stuckLevels.length) {
  console.log('did not finish within time limit:');
  stuckLevels.slice(0, 12).forEach((s) => console.log('   ', s));
}
