/**
 * Physics-accurate reachability validator.
 *
 * Replicates the engine's jump/gravity model and flood-fills every landable
 * surface in a level to prove the flagpole can actually be reached.
 *
 *   node tools/reachability.mjs [stride] [difficulty]
 */

const TILE = 32;
const DT = 1 / 60;
const ROWS = 15;

// Tile ids (mirrors src/game/types.ts)
const T = {
  EMPTY: 0, GROUND: 1, BRICK: 2, Q_COIN: 3, Q_POWER: 4, Q_STAR: 5, Q_1UP: 6,
  MULTI: 7, SOLID: 8, USED: 9, PTL: 10, PTR: 11, PBL: 12, PBR: 13,
  POW: 14, SPRING: 15, BRIDGE: 16, LAVA: 17, CHECKPOINT: 18, SPIKE: 19,
  ICE: 20, CONV_L: 21, CONV_R: 22, JELLY: 23, CRUMBLE: 24, VINE: 25, CLOUD: 26,
  GRAPPLE: 27, BUTTON: 28, GATE: 29, PUSH: 30, WALL_RUN: 31, PHASE: 32,
};

const SOLID = new Set([
  T.GROUND, T.BRICK, T.Q_COIN, T.Q_POWER, T.Q_STAR, T.Q_1UP, T.MULTI,
  T.SOLID, T.USED, T.PTL, T.PTR, T.PBL, T.PBR, T.POW,
  T.SPIKE, T.ICE, T.CONV_L, T.CONV_R, T.JELLY, T.CRUMBLE,
  // Wall-run surfaces are ordinary solid blocks for pathing purposes.
  T.WALL_RUN,
]);
// Surfaces Mario can stand on (solid + one-way platforms)
// Gates open once their puzzle is solved and phase walls are thin, so
// neither is treated as a permanent barrier when checking reachability.
const STANDABLE = new Set([
  ...SOLID, T.BRIDGE, T.SPRING, T.CLOUD, T.CHECKPOINT, T.BUTTON,
]);

export function isSolid(t) { return SOLID.has(t); }
export function isStandable(t) { return STANDABLE.has(t); }

/** Peak jump height in pixels for a given launch velocity. */
export function jumpHeight(v0) {
  let vy = v0, y = 0, peak = 0;
  for (let i = 0; i < 400; i++) {
    let g = 1950;
    if (vy < 0) g = Math.abs(vy) < 95 ? 880 : 1180;
    else if (Math.abs(vy) < 85) g = 980;
    vy = Math.min(680, vy + g * DT);
    y += vy * DT;
    peak = Math.min(peak, y);
    if (y > 0) break;
  }
  return -peak;
}

/** Launch velocity used by the engine for a jump at horizontal speed vx. */
export function launchV(vx) { return -(550 + Math.abs(vx) * 0.15); }

export const JUMP_STAND = jumpHeight(launchV(0));    // ~124px  (3.9 tiles)
export const JUMP_RUN   = jumpHeight(launchV(345));  // ~150px  (4.7 tiles)

/**
 * Simulate a jump arc and collect every surface the player can land on.
 * Returns a list of {col,row} landing surfaces.
 */
function arcLandings(tiles, width, startCol, startRow, vx, v0, vineCols, extra) {
  const out = [];
  let x = startCol * TILE + TILE / 2;
  let y = startRow * TILE;           // feet position (top of the surface)
  let vy = v0;
  const H = 28;                       // small-Mario height (worst case for ledges)

  for (let step = 0; step < 220; step++) {
    let g = 1950;
    if (vy < 0) g = Math.abs(vy) < 95 ? 880 : 1180;
    else if (Math.abs(vy) < 85) g = 980;
    vy = Math.min(680, vy + g * DT);

    const nx = x + vx * DT;
    const ny = y + vy * DT;

    const colN = Math.floor(nx / TILE);
    if (colN < 0 || colN >= width) break;

    // Head / ceiling block: stop horizontal progress through solid walls.
    const headRow = Math.floor((ny - H) / TILE);
    const feetRow = Math.floor(ny / TILE);

    // Wall check along the path (only blocks when moving into solid tile body)
    const curCol = Math.floor(x / TILE);
    if (colN !== curCol) {
      let blocked = false;
      for (let r = headRow; r <= feetRow - 1; r++) {
        if (r >= 0 && r < ROWS && isSolid(tiles[r][colN])) { blocked = true; break; }
      }
      if (blocked) { vx = 0; }
    }

    x = x + vx * DT;
    y = ny;

    if (y > ROWS * TILE + 64) break;

    const col = Math.floor(x / TILE);
    if (col < 0 || col >= width) break;

    // Grabbing a vine counts as reaching that column at any height.
    if (vineCols.has(col)) {
      const r0 = Math.floor(y / TILE);
      for (let r = Math.max(0, r0 - 6); r <= Math.min(ROWS - 1, r0 + 6); r++) {
        if (tiles[r][col] === T.VINE) out.push({ col, row: r, viaVine: true });
      }
    }

    // Landing: moving down and crossing a standable surface top.
    if (vy > 0) {
      const r = Math.floor(y / TILE);
      // Moving platforms are not in the tilemap; treat them as surfaces too.
      if (extra && extra.has(col + ',' + r)) { out.push({ col, row: r }); break; }
      if (r >= 0 && r < ROWS && isStandable(tiles[r][col])) {
        const prevR = Math.floor((y - vy * DT) / TILE);
        if (prevR < r || isStandable(tiles[r][col])) {
          out.push({ col, row: r });
          break;
        }
      }
    }
  }
  return out;
}

/** All surfaces in the level: a surface is a standable tile with headroom. */
function collectSurfaces(tiles, width) {
  const list = [];
  const index = new Map();
  for (let c = 0; c < width; c++) {
    for (let r = 0; r < ROWS; r++) {
      if (!isStandable(tiles[r][c])) continue;
      // Need at least 1 free tile of headroom to stand (small Mario).
      if (r - 1 >= 0 && isSolid(tiles[r - 1][c])) continue;
      const key = c + ',' + r;
      index.set(key, list.length);
      list.push({ col: c, row: r });
    }
  }
  return { list, index };
}

/**
 * Flood-fill reachable surfaces from the spawn and report whether the flag
 * column (and every checkpoint) can be reached.
 */
export function analyse(level) {
  const { tiles, widthCols: width, flagCol, checkpoints = [] } = level;

  const vineCols = new Set();
  for (let c = 0; c < width; c++)
    for (let r = 0; r < ROWS; r++)
      if (tiles[r][c] === T.VINE) vineCols.add(c);

  // Moving platforms create reachable surfaces along their travel path.
  const platformSurfaces = [];
  for (const p of level.platforms || []) {
    const steps = 7;
    for (let i = 0; i <= steps; i++) {
      const f = (i / steps) * 2 - 1; // -1..1 (sine extremes)
      const px = p.col + f * (p.rangeCols || 0);
      const py = p.row + f * (p.rangeRows || 0);
      for (let w = 0; w < p.widthTiles; w++) {
        platformSurfaces.push({
          col: Math.round(px + w),
          row: Math.round(py),
          platform: true,
        });
      }
    }
  }

  const extraSurf = new Set(
    platformSurfaces.map((p) => p.col + ',' + p.row)
  );

  const { list, index } = collectSurfaces(tiles, width);
  for (const ps of platformSurfaces) {
    const key = ps.col + ',' + ps.row;
    if (!index.has(key) && ps.col >= 0 && ps.col < width && ps.row >= 0 && ps.row < ROWS) {
      index.set(key, list.length);
      list.push(ps);
    }
  }

  // Spawn surface: ground under column 3 (or the first standable column).
  let start = -1;
  for (let c = 2; c < width && start < 0; c++) {
    for (let r = 0; r < ROWS; r++) {
      if (index.has(c + ',' + r)) { start = index.get(c + ',' + r); break; }
    }
  }
  if (start < 0) return { ok: false, reason: 'no spawn surface', maxCol: 0 };

  const seen = new Uint8Array(list.length);
  const queue = [start];
  seen[start] = 1;
  let maxCol = 0;

  while (queue.length) {
    const cur = list[queue.pop()];
    maxCol = Math.max(maxCol, cur.col);

    const pushKey = (c, r) => {
      const k = c + ',' + r;
      const i = index.get(k);
      if (i !== undefined && !seen[i]) { seen[i] = 1; queue.push(i); }
    };

    // 1. Walk along contiguous surface (both directions).
    for (const dir of [1, -1]) {
      for (let d = 1; d <= 3; d++) {
        const c = cur.col + dir * d;
        if (c < 0 || c >= width) break;
        if (index.has(c + ',' + cur.row)) { pushKey(c, cur.row); } else break;
      }
    }

    // 2. Climb a vine at this column.
    if (vineCols.has(cur.col)) {
      for (let r = 0; r < ROWS; r++) {
        if (tiles[r][cur.col] === T.VINE) pushKey(cur.col, r);
        // Vines let you step off onto neighbours.
        for (const dc of [-1, 1]) {
          const c2 = cur.col + dc;
          if (c2 >= 0 && c2 < width && tiles[r] && index.has(c2 + ',' + r)) pushKey(c2, r);
        }
      }
    }

    // 3. Jump arcs. Launch velocity depends on the tile we stand on.
    const standTile = tiles[cur.row] ? tiles[cur.row][cur.col] : T.EMPTY;
    const launches = [];
    if (standTile === T.SPRING) launches.push(-755);
    else if (standTile === T.JELLY) launches.push(-640);
    // Normal jumps at several run-up speeds.
    for (const vx of [0, 150, 240, 345]) launches.push(launchV(vx));

    for (const v0 of launches) {
      for (const vxMag of [0, 110, 200, 290, 345]) {
        for (const dir of [1, -1]) {
          const hits = arcLandings(
            tiles, width, cur.col, cur.row, dir * vxMag, v0, vineCols, extraSurf
          );
          for (const h of hits) pushKey(h.col, h.row);
        }
      }
    }

    // 4. Simply walking off a ledge and falling.
    for (const dir of [1, -1]) {
      const hits = arcLandings(
        tiles, width, cur.col, cur.row, dir * 240, 0, vineCols, extraSurf
      );
      for (const h of hits) pushKey(h.col, h.row);
    }
  }

  // Did we reach the flag approach?
  let flagReached = false;
  for (let r = 0; r < ROWS; r++) {
    const i = index.get(flagCol + ',' + r);
    if (i !== undefined && seen[i]) { flagReached = true; break; }
  }
  // Also accept reaching any column at/after the flag.
  if (!flagReached) {
    for (let i = 0; i < list.length; i++) {
      if (seen[i] && list[i].col >= flagCol) { flagReached = true; break; }
    }
  }

  const missedCheckpoints = [];
  for (const cp of checkpoints) {
    let got = false;
    for (let r = 0; r < ROWS; r++) {
      const i = index.get(cp + ',' + r);
      if (i !== undefined && seen[i]) { got = true; break; }
    }
    if (!got) missedCheckpoints.push(cp);
  }

  return { ok: flagReached, maxCol, flagCol, missedCheckpoints };
}
