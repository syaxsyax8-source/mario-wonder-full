/**
 * Campaign-wide fairness validator.
 *
 * Proves that every sampled level can actually be completed:
 *   1. no forward step-up taller than a standing jump (3 tiles)
 *   2. the flagpole is reachable via real jump physics
 *   3. every checkpoint is reachable
 *   4. no pit is wider than the player can cross
 *
 *   node tools/validate-levels.mjs [stride] [difficulties...]
 */
import { analyse, JUMP_STAND, JUMP_RUN } from './reachability.mjs';

globalThis.window = { setInterval: () => 0, clearInterval: () => {} };
globalThis.localStorage = { getItem: () => null, setItem: () => {} };

const { getLevel } = await import('/tmp/lv.mjs');

// 31 = WALL_RUN (a solid surface), 28 = BUTTON (standable).
// 29 = GATE and 32 = PHASE_WALL are deliberately excluded: both are
// passable once opened / in Shadow form, so they are not barriers.
const SOLID = new Set([1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 19, 20, 21, 22, 23, 24, 31]);
const STAND = new Set([...SOLID, 16, 18, 26, 28]);
const VINE = 25;
const MAX_RISE = 3;

function wallHeight(d, c) {
  let h = 0;
  for (let r = 12; r >= 0; r--) {
    if (SOLID.has(d.tiles[r][c])) h++;
    else break;
  }
  return h;
}

const stride = Number(process.argv[2] || 11);
const diffs = process.argv.slice(3);
const difficulties = diffs.length ? diffs : ['easy', 'medium', 'hard', 'nightmare'];

console.log(
  `jump envelope: standing ${(JUMP_STAND / 32).toFixed(2)} tiles, ` +
  `sprinting ${(JUMP_RUN / 32).toFixed(2)} tiles (design cap ${MAX_RISE})`
);

let levels = 0;
const unfairWalls = [];
const unreachable = [];
const badCheckpoints = [];
const impassableGaps = [];

for (const diff of difficulties) {
  for (let lv = 1; lv <= 8000; lv += stride) {
    const d = getLevel(lv, diff);
    levels++;

    // 1. wall heights
    for (let c = 1; c < d.widthCols; c++) {
      const rise = wallHeight(d, c) - wallHeight(d, c - 1);
      if (rise > MAX_RISE) {
        unfairWalls.push(`${diff} lv${lv} col${c} rise ${rise}`);
      }
    }

    // 2 + 3. physics reachability
    const a = analyse(d);
    if (!a.ok) {
      unreachable.push(`${diff} lv${lv} ${d.theme} stuck ${a.maxCol}/${a.flagCol}`);
    }
    for (const cp of a.missedCheckpoints) {
      badCheckpoints.push(`${diff} lv${lv} cp@${cp}`);
    }

    // 4. pit traversability
    let gapStart = -1;
    for (let c = 0; c <= d.widthCols; c++) {
      const solid = c < d.widthCols && STAND.has(d.tiles[13][c]);
      if (!solid && gapStart < 0) gapStart = c;
      if (solid && gapStart >= 0) {
        const w = c - gapStart;
        if (w > 4) {
          let covered = false;
          for (let r = 3; r < 13 && !covered; r++) {
            for (let x = gapStart; x < c; x++) {
              const v = d.tiles[r][x];
              if (STAND.has(v) || v === VINE) { covered = true; break; }
            }
          }
          if (!covered) {
            covered = (d.platforms || []).some(
              (p) => p.col + p.widthTiles >= gapStart - 1 && p.col <= c + 1
            );
          }
          if (!covered) impassableGaps.push(`${diff} lv${lv} gap ${w}@${gapStart}`);
        }
        gapStart = -1;
      }
    }
  }
}

const report = (name, list) => {
  console.log(`${name}: ${list.length}`);
  list.slice(0, 6).forEach((x) => console.log('    ', x));
};

console.log(`\nlevels checked: ${levels} (stride ${stride}, ${difficulties.join('/')})`);
report('unfair walls (> 3 tile step-up)', unfairWalls);
report('unreachable flagpole', unreachable);
report('unreachable checkpoints', badCheckpoints);
report('impassable gaps', impassableGaps);

const total =
  unfairWalls.length + unreachable.length + badCheckpoints.length + impassableGaps.length;
console.log(total === 0 ? '\nPASS - every sampled level is completable.' : `\nFAIL - ${total} problems.`);
process.exit(total === 0 ? 0 : 1);
